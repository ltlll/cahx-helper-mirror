import logging
import random
import time

from core import ocr
from tasks.base import REWARD_POPUP_REGION, Task

log = logging.getLogger("task.huoyue")

# 以下均为 405x720 客户区坐标（玩法面板右下角活跃奖励福袋，布局固定）
BADGE_DOT_REGION = (351, 568, 20, 16)   # 福袋左上角红色叹号（可领取标记），像素检测
BADGE_CLICK_POS = (368, 590)            # 福袋图标点击位置
PANEL_TITLE_REGION = (140, 100, 130, 40)  # "活跃奖励"标题，判定面板已打开
CLAIM_BTN_REGION = (285, 170, 80, 420)  # 面板右侧"领取"按钮列（必须精确匹配，避开"已领取"）
CLAIM_POPUP_BLANK_POS = (200, 620)      # "恭喜获得"大弹窗下方空白处（顶部 (200,150) 会被弹窗盖住）
PANEL_CLOSE_POS = (377, 120)            # 活跃奖励面板右上角 X


class Huoyue(Task):
    """领活跃奖励：玩法面板 → 右下角活跃福袋（有红色叹号才可领）→ 活跃奖励面板
    点任意一个"领取"（一次领取全部档位）→ 关"恭喜获得"弹窗 → 关面板回主界面
    → 用掉领奖弹出的"每日养成礼盒"道具卡（dismiss_item_cards）。

    红色叹号用像素检测（r>180 且 g/b<120 的强红像素计数，参考 eat_cooking 的
    绿色 √ 检测）：可领时约 63 像素，已领时约 20（福袋边缘漏入），阈值取 40。
    无叹号 = 今日已领或活跃度不够，直接跳过不算失败。
    FOLLOWUPS：领完固定接整理背包（奖励涌入防爆满）。
    """

    name = "huoyue"
    title = "活跃奖励"
    category = "收尾任务"
    # 领完奖励背包会涌入一批奖励物品，固定接一个整理背包防爆满（用户要求）
    FOLLOWUPS = ("tidy_bag",)

    def _try_once(self):
        self.dismiss_popups()
        if not self.open_wanfa():
            return False
        if not self._has_red_dot(self.device.screenshot()):
            log.info("活跃奖励无红色叹号（已领取或活跃度不足），跳过")
            return True
        if not self._open_panel():
            return False
        if not self._claim_buttons(self.device.screenshot()):
            log.info("活跃奖励面板无“领取”按钮（已全部领取），跳过")
            self._close_panel()
            return True
        # 领取可能被吞（面板刚打开还在动画/被奖励遮罩盖住）：**按钮没消失就换一个
        # 「领取」候选再点**，最多 3 轮。2026-10-31 run e5ee47：5 号点一次
        # (324,242) 后既没弹「恭喜获得」、按钮也还在，脚本直接判负——两轮尝试
        # 都这样，白白丢掉今天的活跃奖励。旧逻辑还要求必须看到「恭喜获得」，
        # 但弹窗可能被别的遮罩吃掉，最终只认"领取按钮消失"这个正向证据。
        for attempt in range(3):
            cands = self._claim_buttons(self.device.screenshot())
            if not cands:
                break
            pos = cands[min(attempt, len(cands) - 1)]
            log.info("点击 [领取] @ (%d, %d)（第 %d/3 次，一次领取全部档位）",
                     pos[0], pos[1], attempt + 1)
            self.device.click(*pos)
            self._close_claim_popup()
            time.sleep(random.uniform(0.8, 1.2))
        else:
            screen = self.device.screenshot()
            if self._claim_buttons(screen):
                # 2026-11-11 实测（奶茶号）：背包不满、坐标与其他号一致、画面
                # 正常渲染，客户端却连续 ~3 分钟不响应任何领取点击（无弹窗无
                # 提示），随后自愈、人工领取正常——窗口瞬时"不响应点击"运行态
                # （同 10-29 整窗失灵先例，非沙盒号也会发生）。判负前重新置前
                # 窗口 + 等待约 15s 给它走出故障态，补试 2 次。
                log.warning("领取 3 次后仍有「领取」按钮，疑似窗口瞬时未响应点击，"
                            "重新置前并等待后补试")
                self.device.note_input_miss("huoyue_claim_fail",
                                            "领取按钮点击无效（按钮未消失）")
                self.device.activate()
                time.sleep(random.uniform(14, 18))
                for attempt in range(2):
                    cands = self._claim_buttons(self.device.screenshot())
                    if not cands:
                        break
                    pos = cands[0]
                    log.info("补试点击 [领取] @ (%d, %d)（第 %d/2 次）",
                             pos[0], pos[1], attempt + 1)
                    self.device.click(*pos)
                    self._close_claim_popup()
                    time.sleep(random.uniform(0.8, 1.2))
                else:
                    screen = self.device.screenshot()
                    if self._claim_buttons(screen):
                        log.warning("补试 2 次仍无效，放弃本轮。该窗口当时未响应"
                                    "任何领取点击（无提示弹窗）——可手动打开面板"
                                    "核对：手动能领即为客户端瞬时无响应运行态，"
                                    "稍后重跑即可")
                        self.report_unknown("claim_fail", screen,
                                            note="活跃奖励领取点击无效（按钮未消失）；"
                                                 "窗口未响应点击，非背包/坐标问题")
                        return False
        log.info("活跃奖励已全部领取")
        self._close_panel()
        # 领奖后会弹"每日养成礼盒"道具卡（主界面右下），直接用掉
        self.exit_panel_to_home()
        self.dismiss_item_cards()
        return True

    def _claim_buttons(self, screen):
        """返回领取按钮候选坐标（自上而下），排除"已领取"档位。

        只认按钮列区域 + 含"领取" + 不含"已"（"已领取"档位点了没反应，把它当
        候选会让重试永远打在灰按钮上）。
        """
        out = []
        for text, cx, cy, _ in ocr.scan(screen, CLAIM_BTN_REGION, min_score=0.5):
            t = text.replace(" ", "")
            if "领取" not in t or "已" in t:
                continue
            out.append((cx, cy))
        return sorted(out, key=lambda p: p[1])

    def _close_claim_popup(self, timeout=8):
        """等"恭喜获得"弹窗出现后点下方空白关闭。

        这个 7 格奖励的大弹窗顶部会盖住 base.BLANK_CLICK_POS (200,150)，
        必须点弹窗下方的空白处（实测 (200,620) 有效）。
        """
        deadline = time.time() + timeout
        while time.time() < deadline:
            if ocr.find_text(self.device.screenshot(), "点击空白处关闭",
                             region=REWARD_POPUP_REGION):
                break
            time.sleep(0.5)
        else:
            log.warning("领取后未等到“恭喜获得”弹窗")
            return
        for _ in range(4):
            self.device.click(*CLAIM_POPUP_BLANK_POS)
            time.sleep(random.uniform(1.0, 1.6))
            if not ocr.find_text(self.device.screenshot(), "点击空白处关闭",
                                 region=REWARD_POPUP_REGION):
                return
        log.warning("“恭喜获得”弹窗关不掉")

    @staticmethod
    def _has_red_dot(screen):
        """玩法面板右下角福袋上是否有红色叹号（可领取标记）。

        强红像素计数：可领时约 63，已领时约 20（福袋边缘漏入），阈值取 40。
        """
        x, y, w, h = BADGE_DOT_REGION
        crop = screen[y:y + h, x:x + w]
        b = crop[:, :, 0].astype(int)
        g = crop[:, :, 1].astype(int)
        r = crop[:, :, 2].astype(int)
        red = (r > 180) & (g < 120) & (b < 120)
        return int(red.sum()) >= 40

    def _open_panel(self):
        """点福袋打开活跃奖励面板。点击可能被吞，打不开就再点，最多 3 次。"""
        for i in range(3):
            self.device.click(*BADGE_CLICK_POS)
            deadline = time.time() + 6
            while time.time() < deadline:
                if ocr.find_text(self.device.screenshot(), "活跃奖励",
                                 region=PANEL_TITLE_REGION, min_similarity=0.9):
                    log.info("活跃奖励面板已打开")
                    return True
                time.sleep(0.6)
            log.warning("活跃奖励面板未打开，重试点福袋 (%d/3)", i + 1)
        return False

    def _close_panel(self):
        """点右上角 X 关闭活跃奖励面板（回到玩法面板），最多 3 次。"""
        for _ in range(3):
            if not ocr.find_text(self.device.screenshot(), "活跃奖励",
                                 region=PANEL_TITLE_REGION, min_similarity=0.9):
                return
            self.device.click(*PANEL_CLOSE_POS)
            time.sleep(random.uniform(0.8, 1.2))
        log.warning("活跃奖励面板 X 关不掉，按 ESC 兜底")
        self.device.press_esc()
