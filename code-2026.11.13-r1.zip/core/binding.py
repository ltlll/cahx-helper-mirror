"""账号 ↔ 客户端窗口句柄（hwnd）绑定解析。

绑定来源：
- 程序自己拉起的客户端（login.py / launch_missing / 登录崩溃重启）：登录时
  账号↔窗口配对是确切的，自动写入 db 的 hwnd 字段。
- 手动打开的客户端：窗口顺序配对可能错，不自动绑定，需在 GUI 账号编辑里
  用鼠标点选客户端指定。

解析规则（任务执行/登录都用这套）：
- 已绑定且窗口仍有效（IsWindow + 标题匹配）：用绑定句柄；
- 已绑定但窗口已失效：返回 None（提示重新指定，不退回顺序配对——
  顺序配对正是"选 1 个号却在第一个客户端执行"的元凶）。
  例外：**全部**账号绑定都失效且窗口数足够时，判定为客户端整批重启，
  退回顺序兜底配对并告警（否则一批新窗口一个都配不上，全部跳过登录）；
- 未绑定：按剩余窗口从左到右顺序兜底配对（旧行为），并告警。
"""
import logging

import win32gui

from core import db

log = logging.getLogger("binding")


def hwnd_valid(hwnd, keyword):
    """句柄仍指向一个游戏窗口。"""
    return bool(hwnd) and win32gui.IsWindow(hwnd) and keyword in win32gui.GetWindowText(hwnd)


def bind_account(account_id, hwnd):
    """登录成功等确切配对场景写入绑定。"""
    db.update_account(account_id, hwnd=hwnd)


def resolve_hwnds(accounts, hwnds, keyword, batch_fallback=True):
    """把账号列表解析成 hwnd 映射：{account_id: (hwnd 或 None, 来源)}。

    来源: "bound"（绑定命中）/ "fallback"（未绑定，顺序兜底）/ "dead"（绑定失效）/
    "missing"（窗口不够）。

    特例（batch_fallback=True 时）：全部绑定都失效（dead）且可用窗口数 >= 账号数，
    说明旧客户端整批退出、程序重新拉起了一整批新窗口（句柄全变），此时退回顺序
    配对并告警——否则 5 个窗口明明都在，账号却一个都配不上、全部跳过登录（实测教训）。
    **单账号列表必须传 batch_fallback=False**（重跑等场景）：1 个号绑定失效 + 桌面
    还剩任意游戏窗口就会命中特例，顺序兜底把任务跑到别的号上（2026-11-11 实测：
    重跑「奶茶朝夕相伴」跑到了桌面最左边的客户端）。
    """
    free = list(hwnds)
    result = {}
    dead = []
    # 先处理有绑定的（绑定是权威，不参与顺序配对）
    for acc in accounts:
        bound = acc.get("hwnd") or 0
        if not bound:
            continue
        if hwnd_valid(bound, keyword):
            result[acc["id"]] = (bound, "bound")
            if bound in free:
                free.remove(bound)
        else:
            log.warning("账号 %s（%s）绑定的句柄 %s 已失效，需在账号编辑里重新指定客户端",
                        acc["account"], acc["character"], bound)
            dead.append(acc)
    if batch_fallback and dead and len(dead) == len(accounts) and len(free) >= len(dead):
        log.warning("全部 %d 个账号的绑定句柄均已失效，且检测到 %d 个可用窗口——"
                    "判定为客户端整批重启（句柄变更），本轮退回按窗口顺序兜底配对；"
                    "建议在账号编辑里确认客户端指定", len(dead), len(free))
        for acc in dead:
            result[acc["id"]] = (free.pop(0), "fallback")
    else:
        for acc in dead:
            result[acc["id"]] = (None, "dead")
    # 未绑定的按剩余窗口从左到右兜底
    for acc in accounts:
        if acc["id"] in result:
            continue
        if free:
            log.info("账号 %s（%s）未绑定客户端，按窗口顺序兜底配对 hwnd=%s",
                     acc["account"], acc["character"], free[0])
            result[acc["id"]] = (free.pop(0), "fallback")
        else:
            result[acc["id"]] = (None, "missing")
    return result
