import logging
import sys
import time
import random

import yaml

from core.device import Device
from core.logsetup import account_tag, clear_account, set_account, setup_logging
from core.matcher import Matcher
from core.paths import ASSETS_DIR, CONFIG_PATH, ensure_user_files
from core.scheduler import Scheduler


def main():
    ensure_user_files()
    setup_logging("main")
    log = logging.getLogger("main")
    # 运行期间阻止息屏/睡眠/屏保锁屏（锁屏下截图全失效，2026-10-15 事故）
    from core.session_keepalive import keep_alive
    keep_alive.start(reason="main.py 任务运行")

    with open(CONFIG_PATH, encoding="utf-8") as f:
        config = yaml.safe_load(f)

    keyword = config.get("window_keyword") or Device.DEFAULT_KEYWORD
    all_hwnds = Device.find_all(keyword)
    if not all_hwnds:
        log.error("未找到游戏窗口，请先启动《长安幻想》桌面版")
        sys.exit(1)
    log.info("共发现 %d 个游戏窗口", len(all_hwnds))

    # 账号筛选：accounts 为窗口序号列表（1 起，按从左到右排序），缺省为全部
    accounts = config.get("accounts")
    if accounts:
        selected = [all_hwnds[i - 1] for i in accounts if 1 <= i <= len(all_hwnds)]
    else:
        selected = all_hwnds
    log.info("本次执行 %d 个账号", len(selected))

    matcher = Matcher(ASSETS_DIR, threshold=config.get("threshold", 0.85))

    # 账号记录优先用绑定的客户端句柄配对（程序拉起的自动绑定/手动指定），
    # 未绑定的按窗口从左到右兜底；config 的 accounts 过滤仍按窗口序号
    from core import binding, db
    db_accounts = db.list_accounts()
    resolved = binding.resolve_hwnds(db_accounts, all_hwnds, keyword)

    for idx, account in enumerate(db_accounts, 1):
        hwnd, source = resolved[account["id"]]
        if hwnd is None:
            log.warning("账号 %s（%s）%s，跳过", account["account"], account["character"],
                        "绑定句柄失效" if source == "dead" else "无配对窗口")
            continue
        if accounts and hwnd not in selected:
            continue
        set_account(account_tag(account, hwnd))  # 本账号后续日志自动带标签
        log.info("########## 账号 %d/%d (hwnd=%s) ##########", idx, len(db_accounts), hwnd)
        log.info("配对账号: %s | %s | %s（%s）", account["account"], account["character"],
                 account["role"],
                 {"bound": "绑定句柄", "fallback": "顺序兜底"}.get(source, source))
        device = Device(
            keyword=keyword,
            background_click=config.get("background_click", False),
            click_delay=(config["delay"]["click_min"], config["delay"]["click_max"]),
            hwnd=hwnd,
        )
        device.activate()
        try:
            Scheduler(device, matcher, config, account=account).run(config.get("tasks", []))
        except Exception:
            log.exception("账号 %d 执行异常，继续下一个账号", idx)
        if idx < len(db_accounts):
            time.sleep(random.uniform(5, 15))

    clear_account()
    log.info("所有账号执行完毕")


if __name__ == "__main__":
    main()
