"""OCR 文字识别（RapidOCR）：识别"随账号变化"的文字（如角色名、登录账号）。

固定 UI 元素（按钮/页签）仍用模板匹配；角色名/账号这种每个账号都不同的文字走 OCR，
新增账号只需在 GUI 填角色名，不必制作 角色卡_/角色_ 模板截图。
引擎懒加载（首次初始化约 2~5 秒），未安装依赖时降级为不可用（返回空结果）。

并发（引擎池）按本机 CPU **自动适配**，换电脑不必改代码；配置优先级从高到低：
  1. `reconfigure(engines=, intra_op=)` —— 运行期热更新（GUI 设置面板用它）
  2. 环境变量 `CAHX_OCR_ENGINES` / `CAHX_OCR_INTRA_OP`（临时调参用）
  3. config.yaml 的 `ocr_threads` 段：``engines: auto | intra_op: auto``
  4. 按 ``os.cpu_count()`` 自动估算（默认）
"""
import logging
import os
import threading
from difflib import SequenceMatcher

log = logging.getLogger("ocr")

_engines = []        # [[engine, lock]] 引擎槽位池（懒加载，最多 engines 个）
_unavailable = False
# 并行执行时多个窗口线程共用引擎池：同一引擎的推理必须串行（onnxruntime
# 本地库非线程安全），故每槽位一把锁；多槽位并行推理提升吞吐
_engine_lock = threading.Lock()

# ---- 引擎池并发配置（可动态调整）----
# 实测（36 逻辑核）：intra_op_num_threads=-1 会让每个引擎各自开满核数线程互相抢核，
# 「2 引擎不限线程」吞吐仅 0.44 次/s，比单引擎（0.55）还慢；限成「4 引擎 × 8 线程」
# 后达 0.87 次/s ≈ 翻倍。故不再交给 onnxruntime 自动开满线程，而是按核数估算并
# 限制单引擎线程数（过度订阅是这台机器 CPU 跑满却更慢的根因）。
_pool_lock = threading.Lock()
_pool_cache = None        # 解析结果 (engines, intra_op, source)；None = 尚未解析
_pool_override = {}       # reconfigure() 的运行时覆盖 {"engines": int, "intra_op": int}
_stale = False            # 配置已变，待引擎池空闲时清空并按新配置重建

_ENV_ENGINES = "CAHX_OCR_ENGINES"
_ENV_INTRA = "CAHX_OCR_INTRA_OP"

_PER_ENGINE_MAX_THREADS = 8   # 单引擎线程上限（再多收益递减、反而加剧抢占）
_MAX_ENGINES_CAP = 4          # 引擎数上限（槽位越多内存/调度开销越大）


def _parse_count(val):
    """把配置值解析成正整数；`auto` / 空 / 0 / 非法值返回 None（表示"走自动"）。"""
    if val is None or isinstance(val, bool):
        return None
    if isinstance(val, str):
        s = val.strip().lower()
        if s in ("", "auto"):
            return None
        try:
            val = int(s)
        except ValueError:
            return None
    try:
        n = int(val)
    except (TypeError, ValueError):
        return None
    return n if n > 0 else None


def _auto_pool(cpu):
    """按逻辑核数估算 (引擎数, 每引擎线程数)。

    目标：总线程数 ≈ 0.9×核数（留一点给系统与游戏客户端），单引擎 ≤ 8 线程。
    例：36 核 → 4×8；24 核 → 3×6；16 核 → 3×4；8 核 → 3×2；4 核 → 2×2；≤2 核 → 1×N。
    """
    n = max(1, int(cpu or 1))
    if n <= 2:
        return 1, n
    intra = max(2, min(_PER_ENGINE_MAX_THREADS, n // 4))
    engines = max(2, min(_MAX_ENGINES_CAP, int(n * 0.9) // intra))
    while engines > 1 and engines * intra > n:
        engines -= 1
    return engines, intra


def _config_segment():
    """读 config.yaml 的 ocr_threads 段（缺失/非法返回 {}）。"""
    try:
        import yaml
        from core.paths import CONFIG_PATH
        raw = yaml.safe_load(CONFIG_PATH.read_text(encoding="utf-8")) or {}
        seg = raw.get("ocr_threads")
        return seg if isinstance(seg, dict) else {}
    except Exception:
        return {}


def _resolve_pool():
    """解析生效配置：reconfigure() 覆盖 > 环境变量 > config.yaml > 按本机核数自动。"""
    cfg = _config_segment()

    def pick(key, env):
        # 运行时 override 一旦设置即压制环境变量与 config（值写成 0/auto 表示"回到自动"）
        if key in _pool_override:
            return _parse_count(_pool_override.get(key)), "override"
        for tag, src in (("env", os.environ.get(env)), ("config", cfg.get(key))):
            n = _parse_count(src)
            if n is not None:
                return n, tag
        return None, "auto"

    engines, e_src = pick("engines", _ENV_ENGINES)
    intra, i_src = pick("intra_op", _ENV_INTRA)
    if engines is None or intra is None:
        a_engines, a_intra = _auto_pool(os.cpu_count())
        if engines is None:
            engines, e_src = a_engines, "auto"
        if intra is None:
            intra, i_src = a_intra, "auto"
    return int(engines), int(intra), f"engines={e_src}/intra_op={i_src}"


def _pool_config():
    """返回缓存的 (engines, intra_op, source)；首次调用时解析并打一条 info 日志。"""
    global _pool_cache
    with _pool_lock:
        if _pool_cache is None:
            _pool_cache = _resolve_pool()
            log.info("OCR 引擎池：%d 引擎 × %d 线程/引擎（本机 %d 逻辑核，%s）",
                     _pool_cache[0], _pool_cache[1], os.cpu_count() or 0, _pool_cache[2])
        return _pool_cache


def pool_config():
    """当前生效的引擎池配置（GUI 显示 / 排查用）。"""
    engines, intra, source = _pool_config()
    return {"engines": engines, "intra_op": intra,
            "cpu_count": os.cpu_count() or 0, "source": source}


def reconfigure(engines=None, intra_op=None):
    """运行期调整引擎池并发，无需重启进程。

    None = 该字段保持不变；传 0 或 "auto" = 恢复按本机核数自动估算。
    已建好的引擎会在**池全部空闲时**清空并按新配置重建（正在推理的槽位不受影响，
    用完即弃），因此可在 GUI 设置面板里改完立刻生效。
    """
    global _pool_cache, _stale
    with _pool_lock:
        if engines is not None:
            _pool_override["engines"] = engines
        if intra_op is not None:
            _pool_override["intra_op"] = intra_op
        _pool_cache = None
        _stale = True
    _reap_idle()
    log.info("OCR 引擎池已重配置：%s", pool_config())


def saved_config():
    """config.yaml 里 ocr_threads 段的当前值（None = auto，供 GUI 回填）。"""
    seg = _config_segment()
    return {"engines": _parse_count(seg.get("engines")),
            "intra_op": _parse_count(seg.get("intra_op"))}


def save_config(engines=None, intra_op=None):
    """把并发配置写回 config.yaml 的 ocr_threads 段，并立即生效（无需重启）。

    参数为 None 表示该字段写 ``auto``（按本机核数自动估算）。
    写盘用行级替换以保留 config.yaml 里的注释；写盘失败只记日志，运行期配置仍生效。
    """
    def _fmt(v):
        return "auto" if v is None else str(int(v))

    try:
        from core.paths import CONFIG_PATH
        lines = CONFIG_PATH.read_text(encoding="utf-8").splitlines()
        start = next((i for i, ln in enumerate(lines)
                      if not ln[:1].isspace() and ln.strip() == "ocr_threads:"), None)
        if start is None:
            lines += ["",
                      "# OCR 引擎池并发（auto = 按本机 CPU 核数自动估算，通常无需修改）",
                      "ocr_threads:",
                      f"  engines: {_fmt(engines)}",
                      f"  intra_op: {_fmt(intra_op)}"]
        else:
            end = start + 1
            while end < len(lines) and lines[end].strip() and lines[end][:1] in (" ", "\t"):
                end += 1
            for key, val in (("engines", _fmt(engines)), ("intra_op", _fmt(intra_op))):
                hit = next((j for j in range(start + 1, end)
                            if lines[j].lstrip().startswith(key + ":")), None)
                if hit is None:
                    lines.insert(end, f"  {key}: {val}")
                    end += 1
                else:
                    indent = lines[hit][: len(lines[hit]) - len(lines[hit].lstrip())]
                    lines[hit] = f"{indent}{key}: {val}"
        CONFIG_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")
        log.info("OCR 并发已写入 config.yaml：engines=%s intra_op=%s",
                 _fmt(engines), _fmt(intra_op))
    except Exception:
        log.exception("写回 config.yaml 失败（运行期配置仍已生效）")

    reconfigure(engines=(0 if engines is None else engines),
                intra_op=(0 if intra_op is None else intra_op))


def _reap_locked():
    """内部：调用方须已持 _engine_lock。配置变更且所有槽位空闲时清空池（下次重建）。"""
    global _stale
    if _stale and all(not lk.locked() for _, lk in _engines):
        _engines.clear()
        _stale = False


def _reap_idle():
    with _engine_lock:
        _reap_locked()


def _use_v5():
    """是否启用 PP-OCRv5（config.yaml 的 ocr_engine: v5，且模型已下载）。

    实测 v5 检测模型对游戏美术字按钮（回帮/整理/下达指令等）漏检严重，
    默认必须用 v4；v5 仅留作实验对比（tools/ocr_compare.py）。
    """
    try:
        import yaml
        from core.paths import CONFIG_PATH, OCR_MODELS_DIR
        cfg = yaml.safe_load(CONFIG_PATH.read_text(encoding="utf-8")) or {}
        if cfg.get("ocr_engine") != "v5":
            return False
        return all((OCR_MODELS_DIR / f).exists() for f in (
            "ch_PP-OCRv5_det_mobile.onnx", "ch_PP-OCRv5_rec_mobile.onnx", "ppocrv5_dict.txt"))
    except Exception:
        return False


def _new_engine():
    """创建一个 OCR 引擎实例（约 2~5 秒）。未安装依赖返回 None。"""
    try:
        from rapidocr_onnxruntime import RapidOCR
    except ImportError:
        return None
    intra = _pool_config()[1]
    kw = {"intra_op_num_threads": intra} if intra > 0 else {}
    if _use_v5():
        from core.paths import OCR_MODELS_DIR
        log.info("初始化 OCR 引擎（PP-OCRv5，%d 线程/引擎）...", intra)
        return RapidOCR(
            det_model_path=str(OCR_MODELS_DIR / "ch_PP-OCRv5_det_mobile.onnx"),
            rec_model_path=str(OCR_MODELS_DIR / "ch_PP-OCRv5_rec_mobile.onnx"),
            rec_keys_path=str(OCR_MODELS_DIR / "ppocrv5_dict.txt"), **kw)
    log.info("初始化 OCR 引擎（内置 PP-OCRv4，%d 线程/引擎）...", intra)
    return RapidOCR(**kw)


def _acquire_engine():
    """获取一个引擎槽位及其推理锁（用完必须 lock.release()）。

    已有空闲槽位直接用；没满引擎数上限就占位新建（槽是 [engine, lock] 列表原位更新，
    占位锁由创建者持有直到引擎就绪，其它线程不会拿到半成品）；都忙则阻塞等第一个槽位空闲。
    返回 (engine, lock)；不可用返回 (None, None)。
    """
    global _unavailable
    if _unavailable:
        return None, None
    max_engines = _pool_config()[0]
    while True:
        create_slot = None
        with _engine_lock:
            _reap_locked()          # 并发配置改了就趁池空闲重建
            for engine, lock in _engines:
                if engine is not None and not lock.locked():
                    lock.acquire()
                    return engine, lock
            if len(_engines) < max_engines:
                lock = threading.Lock()
                lock.acquire()
                create_slot = [None, lock]
                _engines.append(create_slot)
            else:
                slot = _engines[0]
        if create_slot is not None:
            break
        # 池满且全忙：锁外阻塞等第一个槽位（持槽线程 release 后由本线程接手）。
        # 用捕获的 slot 引用而非 _engines[0]，避免等待期间池被重建导致越界。
        # 优先捡被推理看门狗隔离的空槽（engine=None，保持池容量不缩水）。
        slot = next((s for s in _engines if s[0] is None), slot)
        slot[1].acquire()
        if slot[0] is None:
            # 等到的是被隔离的空槽：锁刚被隔离线程释放，由本线程重建引擎
            # （锁在手，其它线程拿不到半成品）。
            engine = _new_engine()
            if engine is None:
                _unavailable = True
                slot[1].release()
                return None, None
            slot[0] = engine
        return slot[0], slot[1]
    engine = _new_engine()
    with _engine_lock:
        if engine is None:
            _engines.remove(create_slot)
            create_slot[1].release()
            _unavailable = True
            log.warning("未安装 rapidocr-onnxruntime，OCR 文字识别不可用")
            return None, None
        create_slot[0] = engine
    return engine, create_slot[1]


def available():
    """OCR 是否可用（会触发引擎懒加载）。"""
    engine, lock = _acquire_engine()
    if lock is not None:
        lock.release()
    return engine is not None


# ---- 单次推理看门狗（2026-10-15 事故新增）----
# 实机事故：单次 engine(img) 可能在 onnxruntime/det 后处理原生层**永久自旋**
# （py-spy 实锤：7 号竞技任务开场复位时，线程在 _decor_hud_hit 的一次
# ocr.scan 里烧了 1 小时+ CPU，账号线程静默冻结 → 组队等待全员超时 →
# 其余 4 个账号的组队副本连环判失败）。原生调用无法从 Python 中断，改为
# 「工作线程 + 超时放弃」：调用方到点收回控制权，卡死引擎的槽位被隔离
# （下次使用时重建），僵尸线程继续自旋但不再接客（占用 1 核，进程重启才释放）。
_CALL_TIMEOUT_DEFAULT = 90.0   # 单次推理超时秒数（正常 <3s，5 开重载 <15s）
_timeout_cache = None
_zombie_count = 0
_ENV_CALL_TIMEOUT = "CAHX_OCR_CALL_TIMEOUT"


def _call_timeout():
    """单次推理超时秒数：env CAHX_OCR_CALL_TIMEOUT > config
    ocr_threads.call_timeout > 默认 90 秒。"""
    global _timeout_cache
    if _timeout_cache is None:
        try:
            val = float(os.environ.get(_ENV_CALL_TIMEOUT) or 0) or None
        except (TypeError, ValueError):
            val = None
        if val is None:
            n = _parse_count(_config_segment().get("call_timeout"))
            val = float(n) if n else None
        _timeout_cache = float(val or _CALL_TIMEOUT_DEFAULT)
    return _timeout_cache


def _infer_with_watchdog(engine, img, timeout):
    """带看门狗地执行一次 engine(img)。

    正常返回 engine 的 (result, elapse)；工作线程抛出的异常原样上抛；
    超时返回 None（调用方必须 _quarantine_slot 隔离该引擎后再继续）。
    """
    box = []
    done = threading.Event()

    def _worker():
        try:
            box.append(engine(img))
        except BaseException as exc:   # noqa: BLE001 —— 原样带回调用方线程
            box.append(exc)
        finally:
            done.set()

    t = threading.Thread(target=_worker, daemon=True, name="ocr-infer")
    t.start()
    if not done.wait(timeout):
        return None
    if not box:
        return ([], None)
    if isinstance(box[0], BaseException):
        raise box[0]
    return box[0]


def _quarantine_slot(engine, tag=""):
    """推理超时后隔离引擎槽位：槽位原位置 None（下次使用时重建），
    持有的推理锁由调用方 finally 释放，等待者拿到空槽后自动重建。"""
    global _zombie_count
    with _engine_lock:
        found = False
        for slot in _engines:
            if slot[0] is engine:
                slot[0] = None
                found = True
                break
        _zombie_count += 1
        n = _zombie_count
    log.critical(
        "OCR 推理超过 %.0f 秒未返回（%s），疑似 onnxruntime 原生层卡死，"
        "已%s隔离该引擎槽位（累计第 %d 次），本次调用按空结果继续",
        _call_timeout(), tag or "scan", "" if found else "（槽位已重建）", n)


def scan(screen, region=None, min_score=0.85):
    """识别截图（可限定区域）中的全部文字，返回 [(text, cx, cy, score)]。

    region 限定 (x, y, w, h) 搜索范围，提速并避免误中页面其它文字；
    返回坐标为全图坐标。
    """
    engine, lock = _acquire_engine()
    if engine is None:
        if lock is not None:
            lock.release()
        return []
    img, ox, oy = screen, 0, 0
    if region is not None:
        x, y, w, h = region
        img = screen[y:y + h, x:x + w]
        ox, oy = x, y
    try:
        result_pair = _infer_with_watchdog(engine, img, _call_timeout())
        if result_pair is None:
            _quarantine_slot(engine, tag=f"scan region={region}")
            return []
        result, _ = result_pair
    finally:
        lock.release()
    out = []
    for box, text, score in result or []:
        if score < min_score:
            continue
        cx = int(round(ox + sum(p[0] for p in box) / 4))
        cy = int(round(oy + sum(p[1] for p in box) / 4))
        out.append((text.strip(), cx, cy, score))
    return out


def scan_regions(screen, regions, min_score=0.85, gap=8):
    """一次 OCR 覆盖多个小区域：把各区域纵向拼成一张图，只调用一次引擎。

    5 开并发时每次 OCR 调用都有可观的**固定开销**（实测本机预热口径：
    dismiss_popups 空转路径的 5 次小区域调用合计 5.24s，合并成 1 次只要
    0.57s，省 74%——`debug/_ocr_batch_probe.py`）。把这些"顺便看一眼"的
    小区域检查合并，可在**不减少任何检查项**的前提下大幅提速。

    regions: ``[(key, (x, y, w, h)), ...]``，key 自定义（重复会互相覆盖）。
    返回 ``{key: [(text, cx, cy, score), ...]}``，坐标已还原为**全图坐标**
    （与 scan 同口径）。各区域之间留 gap 像素白边，防止跨区文字被并成一行。
    """
    out = {key: [] for key, _ in regions}
    if not regions:
        return out
    engine, lock = _acquire_engine()
    if engine is None:
        if lock is not None:
            lock.release()
        return out
    import numpy as np
    # 先裁剪并记录**实际**尺寸：region 越界时 scan() 靠 numpy 静默裁剪容错，
    # 这里拼接必须同样容错，否则窗口尺寸变小（离屏桩/异形窗口）会直接抛异常。
    crops = []
    for key, (x, y, w, h) in regions:
        crop = screen[y:y + h, x:x + w]
        if crop.ndim != 3 or crop.shape[0] == 0 or crop.shape[1] == 0:
            continue
        crops.append((key, x, y, crop))
    if not crops:
        return out
    width = max(c.shape[1] for _, _, _, c in crops)
    height = sum(c.shape[0] for _, _, _, c in crops) + gap * (len(crops) - 1)
    canvas = np.full((height, width, 3), 255, dtype=np.uint8)
    offs = []
    oy = 0
    for key, x, y, crop in crops:
        ch, cw = crop.shape[0], crop.shape[1]
        canvas[oy:oy + ch, 0:cw] = crop
        offs.append((key, oy, x, y, ch))
        oy += ch + gap
    try:
        result_pair = _infer_with_watchdog(engine, canvas, _call_timeout())
        if result_pair is None:
            _quarantine_slot(engine, tag="scan_regions")
            return out
        result, _ = result_pair
    finally:
        lock.release()
    for box, text, score in result or []:
        if score < min_score:
            continue
        by = sum(p[1] for p in box) / 4
        bx = sum(p[0] for p in box) / 4
        for key, seg_oy, seg_x, seg_y, seg_h in offs:
            if seg_oy <= by < seg_oy + seg_h:
                out[key].append((text.strip(), int(round(seg_x + bx)),
                                 int(round(seg_y + (by - seg_oy))), score))
                break
    return out


def any_match(texts, target, min_similarity=0.8):
    """已有一批 OCR 结果时，判断其中是否有与 target 匹配的文本。

    匹配规则与 find_text 完全一致（精确优先，否则序列相似度 >= min_similarity），
    用于"批量 OCR 先行探路、命中才调用原处理器"的场景，避免重复识别。
    texts 可传 scan 返回的完整元组，也可只传文本字符串。
    """
    for item in texts or ():
        text = item[0] if isinstance(item, (tuple, list)) else item
        if text == target:
            return True
        if SequenceMatcher(None, text, target).ratio() >= min_similarity:
            return True
    return False


def find_text(screen, target, region=None, min_score=0.85, min_similarity=0.8):
    """在截图中查找与 target 匹配的文字，返回 (cx, cy, score)；找不到返回 None。

    精确匹配优先；无精确匹配时接受相似度 >= min_similarity 的结果（容忍个别字误识别），
    多个候选取相似度最高者。
    """
    best = None  # (sim, score, cx, cy)
    for text, cx, cy, score in scan(screen, region, min_score):
        sim = 1.0 if text == target else SequenceMatcher(None, text, target).ratio()
        if sim >= min_similarity and (best is None or sim > best[0]):
            best = (sim, score, cx, cy)
    if best is None:
        return None
    return best[2], best[3], best[1]


def contains_text(screen, target, region=None, min_score=0.5):
    """区域内是否识别出包含 target 的文字（只判断是否存在，不返回位置）。

    用于"请给XX下达指令"这类内容固定但整行文字随账号变化的判定：
    OCR 可能把整行识别成一个文本框，find_text 的相似度匹配会被拒，
    包含匹配对此鲁棒。需要点击位置时仍用 find_text。
    """
    return any(target in text for text, *_ in scan(screen, region, min_score))


def dump_texts(screen, region=None):
    """返回区域内识别到的全部文字（排查识别失败时用）。"""
    return [text for text, *_ in scan(screen, region, min_score=0.5)]


def name_tag_like(text, me, max_gap=4):
    """`text` 是否是玩家头顶「称号+角色名」名牌（`me` = 本号角色名）。

    **不能用精确子串匹配**：OCR 会把名字读错 1~2 个字。2026-10-16 实测
    `外卖点到手颤` 被读成 `外卖点到手版`、前面还粘着称号「傲天一」——
    `me in text` 直接漏判，同一坐标被连点 159 次、单次尝试干耗 25 分钟。

    2026-10-25 事故（**一天挂掉 4 个号的宗门任务**）：旧阈值 0.8 只容忍错
    1 个字，而名牌 = 称号 + 角色名，OCR 连错 2 个字时重合率只有 4/6=0.67
    → `倾天一外卖点到手颤` 被读成 `倾天一外买点到手额` 后漏判，被当成对话
    选项连点 5 次 → `dialog_option_loop`/`chain_stuck` → 4 个号宗门全失败。
    现在改成两道判定：
      1. **滑动窗口**：名牌常带称号前缀（"倾天一"+"角色名"），只拿与角色名
         等长的窗口去比，避免前缀把重合率拉低；
      2. **允许 OCR 别字**：名字 ≥5 字容忍 2 个别字，≤4 字容忍 1 个；
         同时要求整段文字长度不超过 `len(me)+max_gap`（名牌 = 称号 2~4 字 +
         角色名），真对话选项/任务文案基本都更长，不会被误杀。

    凡是"扫画面中上部区域找对话选项/可点文本"的逻辑都必须排掉名牌——
    它固定在 cx≈206、cy≈335~374，与真选项同列同高（宗门任务、登录兜底、
    settle_scene 兜底阶梯都踩过同一个坑）。
    """
    if not me:
        return False
    text = "".join((text or "").split())
    me = "".join(me.split())
    if not text:
        return False
    if me in text:
        return True
    n = len(me)
    if n < 2 or len(text) < n or len(text) > n + max_gap:
        return False
    need = n - 2 if n >= 5 else n - 1   # 允许的 OCR 别字数
    for i in range(len(text) - n + 1):
        win = text[i:i + n]
        # 多重集重合（同一个字不重复计数）：容忍错字，也容忍语序漂移
        hit = sum(min(win.count(ch), me.count(ch)) for ch in set(me))
        if hit >= need:
            return True
    return False
