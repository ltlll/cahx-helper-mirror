import ctypes
import logging
import os
import subprocess
import sys
import time
from pathlib import Path

import pywintypes
import win32con
import win32gui
import win32process

from core.device import Device

log = logging.getLogger("launcher")

# Sandboxie 弹窗上可点击的按钮关键字（中英文都匹配）
_POPUP_BUTTON_KEYWORDS = ("关闭", "继续", "确定", "以后", "OK", "Close", "Continue", "Later")

# 只服务于本程序 Qt 界面的环境变量前缀，绝不能传给游戏客户端
_QT_UI_ENV_PREFIX = "QT_QPA_"


def client_subprocess_env():
    """拉起游戏客户端（含 Sandboxie Start.exe）时用的环境副本：剔除 QT_QPA_*。

    本程序的 Qt 界面在离屏场景下会把 QT_QPA_PLATFORM 设成 offscreen
    （tools/run_yitiaolong_headless.py），而 subprocess.Popen 默认继承整个
    环境——游戏客户端本身也是 Qt 程序（cahx-win_Data/SYKit/Qt5Core.dll），
    它只自带 windows 平台插件，一旦读到 offscreen 会立刻启动失败并弹一个
    模态错误框，标题 "cahx-win"、类名 #32770：

        This application failed to start because no Qt platform plugin
        could be initialized. Reinstalling the application may fix this
        problem. Available platform plugins are: windows.

    对话框会一直挂着阻塞客户端加载——上游只看到"启动闪屏不消失"→ 判卡死 →
    关窗重启 → 又弹一个，5 个号连环弹满屏（2026-10-15 实测）。
    所以凡是我们拉起的游戏子进程，一律把 QT_QPA_* 清掉。
    """
    env = dict(os.environ)
    for key in [k for k in env if k.startswith(_QT_UI_ENV_PREFIX)]:
        env.pop(key, None)
    return env


def launch_instance(game_exe, mode="direct", box=None, sandboxie_start=None):
    """启动一个客户端实例。mode: direct 直接启动 / sandbox 经 Sandboxie 启动。"""
    if mode == "sandbox":
        if not box:
            raise ValueError("sandbox 模式必须指定 box 名称")
        # 先清沙盘弹窗再启动：SandMan 的提醒弹窗只能 WM_CLOSE，而关闭它会让
        # SandMan 整个退出——那个副作用若落在启动窗口期里会牵连本次启动
        # （见 prepare_sandboxie 注释），所以提前到 Popen 之前做掉
        prepare_sandboxie()
        # 调用方通常已从 config（或自动探测）带来路径；这里再兜一层自动定位，
        # 免得换个安装目录就得改代码里的硬编码兜底。
        start = sandboxie_start or _default_sandboxie_start()
        cmd = [start, f"/box:{box}", game_exe]
    else:
        cmd = [game_exe]
    log.info("启动客户端: %s", " ".join(cmd))
    subprocess.Popen(cmd, cwd=str(Path(game_exe).parent),
                     env=client_subprocess_env())


def _default_sandboxie_start():
    """没给 sandboxie_start 时，按注册表自动定位；找不到直接报错，不要瞎猜路径。"""
    from core.locate import find_sandboxie_start

    found = find_sandboxie_start()
    if not found:
        raise RuntimeError("未指定 Sandboxie，且自动探测不到 Start.exe；"
                           "请在 config.yaml 的 login.sandboxie_start 里填写完整路径")
    log.info("自动定位 Sandboxie：%s（%s）", found.path, found.source)
    return found.path


def _child_buttons(hwnd):
    buttons = []

    def cb(h, _):
        if win32gui.GetClassName(h) == "Button":
            buttons.append((h, win32gui.GetWindowText(h)))

    win32gui.EnumChildWindows(hwnd, cb, None)
    return buttons


def dismiss_sandboxie_popups():
    """关闭 Sandboxie 的消息弹窗与免费版打赏提示。

    SBIE2224 崩溃报告等消息窗会堆积遮挡游戏窗口；免费版"继续使用/打赏"
    提示会阻塞 Start.exe，沙盒内程序根本起不来。优先用 Win32 消息点弹窗
    按钮（不占用真实鼠标，不影响并行登录的输入锁）；Sandboxie-Plus 的
    弹窗是 Qt 窗口无标准按钮子控件，退回 WM_CLOSE 整体关闭。
    只处理消息/通知/提醒类弹窗，不动 Sandboxie-Plus 主界面。

    返回本次关闭的弹窗数（调用方据此判断是否需要等 SandMan 退出，
    见 prepare_sandboxie）。
    """
    closed = []

    def cb(hwnd, _):
        if not win32gui.IsWindowVisible(hwnd):
            return
        title = win32gui.GetWindowText(hwnd)
        if "sandboxie" not in title.lower():
            return
        for btn, text in _child_buttons(hwnd):
            if any(k.lower() in text.lower() for k in _POPUP_BUTTON_KEYWORDS):
                if win32gui.IsWindowEnabled(btn):
                    win32gui.SendMessage(btn, win32con.BM_CLICK, 0, 0)
                    log.info("已关闭 Sandboxie 弹窗: [%s] 按钮 [%s]", title, text)
                    closed.append(hwnd)
                    return
                # 按钮灰着（打赏提示常有倒计时）：等下一轮再点
        # Sandboxie-Plus 的弹窗（捐赠提醒/通知等）是 Qt 窗口，没有标准 Button
        # 子控件，BM_CLICK 点不到，只能整体 WM_CLOSE（等价于点右上角 X）。
        # 主界面标题是 "Sandboxie-Plus"，不含下列关键字，不会被误关。
        # ⚠️ "reminder" 是英文界面的 Support Reminder（缺它则英文系统下漏关）。
        if (any(k in title for k in ("消息", "通知", "提醒", "捐赠"))
                or "message" in title.lower() or "reminder" in title.lower()):
            win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)
            log.info("已关闭 Sandboxie 弹窗: [%s]", title)
            closed.append(hwnd)

    win32gui.EnumWindows(cb, None)
    return len(closed)


_SANDMAN_TITLE = "Sandboxie-Plus"


def _sandman_windows():
    """SandMan（Sandboxie-Plus 控制器）当前的可见顶层窗口列表。"""
    found = []

    def cb(hwnd, _):
        if win32gui.IsWindowVisible(hwnd) and _SANDMAN_TITLE in win32gui.GetWindowText(hwnd):
            found.append(hwnd)

    win32gui.EnumWindows(cb, None)
    return found


def prepare_sandboxie(wait=5.0):
    """沙盘启动前置：先清掉会牵连 Start.exe 的 SandMan 弹窗，等它退干净再启动。

    «捐赠提醒» 这类 Qt 弹窗只能整体 WM_CLOSE，而它的 WM_CLOSE 等价于点
    SandMan 的「Quit」→ **SandMan 整个退出**。这个退出若发生在启动客户端的
    过程中，本次启动会被牵连：2026-10-12 23:09 实测——关弹窗后
    wait_new_window 等满 180 秒不见窗口，重试（此时 SandMan 已退、不再弹）
    4 秒就出窗口。所以把"关它"提前到 **Popen 之前**，副作用就不落在启动期。

    SandMan 没在跑（用户已关自启）/ 只有主界面没有弹窗时什么都不做——
    SbieSvc 自己不会弹这个提醒。
    """
    if not _sandman_windows():
        return
    if not dismiss_sandboxie_popups():
        return                     # 没有需要关的弹窗：SandMan 主界面正常开着，不动它
    log.info("检测到 Sandboxie 提醒弹窗（关闭它会连带退出 SandMan），"
             "先清理并等待 SandMan 退出，避免牵连客户端启动...")
    deadline = time.time() + wait
    while time.time() < deadline and _sandman_windows():
        time.sleep(0.2)
    if _sandman_windows():
        log.warning("Sandboxie 弹窗已关闭，但 SandMan 主窗口仍在；本次启动可能受影响")
    else:
        log.info("SandMan 已退出（SbieSvc 不会再弹该提醒），开始启动客户端")


def wait_new_window(keyword, existing_hwnds, timeout=180, interval=1):
    """等待一个不在 existing_hwnds 中的新游戏窗口出现，返回其 hwnd。"""
    deadline = time.time() + timeout
    while time.time() < deadline:
        new = set(Device.find_all(keyword)) - set(existing_hwnds)
        if new:
            hwnd = sorted(new)[0]
            log.info("检测到新窗口 hwnd=%s", hwnd)
            return hwnd
        dismiss_sandboxie_popups()  # 顺手清理可能阻塞启动的沙盒弹窗
        time.sleep(interval)
    log.error("等待新窗口超时")
    return None


def move_window(hwnd, x, y, w, h):
    try:
        win32gui.MoveWindow(hwnd, x, y, w, h, True)
    except pywintypes.error as e:
        # 错误 5（拒绝访问）：游戏进程权限比本工具高（如以管理员身份启动），
        # Windows UIPI 禁止低权限程序操作其窗口。平铺失败不阻塞登录，但窗口
        # 可能互相遮挡导致截图识别失败，需以同样权限重启本工具。
        log.warning("移动窗口失败 hwnd=%s: %s（游戏可能是管理员权限运行的，"
                    "请用同样权限启动本工具，或都不要用管理员运行）", hwnd, e)
        return False
    log.info("窗口 hwnd=%s 已移动到 (%d, %d) %dx%d", hwnd, x, y, w, h)
    return True


def close_window(hwnd):
    """请求关闭窗口（等价于点右上角 X）。返回是否已发出关闭请求。

    用于处理"客户端卡死"（窗口还在、画面定格在启动闪屏上）——这类窗口的
    消息循环仍在响应 WM_CLOSE（实测冻结窗口 1 秒内关闭），可以安全关掉
    释放客户端实例名额后重新启动。
    """
    try:
        win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)
        return True
    except Exception as e:
        log.warning("关闭窗口失败 hwnd=%s: %s", hwnd, e)
        return False


def force_close_window(hwnd, wait=5.0):
    """请求关闭窗口；窗口迟迟不消失（消息泵假死）则强制结束其进程。

    用于"运行中假死"（IsHungAppWindow=true，见 core.device._window_hung）：
    这种窗口的消息泵已经不处理消息，PostMessage(WM_CLOSE) 只是排进队列、
    可能永远没人处理（2026-10-12 23:20 实测「火锅涮到夜半」假死后点击全废、
    空转 4.5 分钟到超时），而它还占着一个客户端实例名额。
    等待 wait 秒仍不消失就 TerminateProcess 掉。

    返回窗口是否已消失（True = 可以重新启动客户端）。
    """
    close_window(hwnd)
    deadline = time.time() + wait
    while time.time() < deadline:
        if not win32gui.IsWindow(hwnd):
            return True
        time.sleep(0.25)
    if not win32gui.IsWindow(hwnd):
        return True
    try:
        _, pid = win32process.GetWindowThreadProcessId(hwnd)
        # PROCESS_TERMINATE(0x0001) | PROCESS_QUERY_LIMITED_INFORMATION(0x1000)
        hproc = ctypes.windll.kernel32.OpenProcess(0x0001 | 0x1000, False, pid)
        if not hproc:
            log.error("假死窗口 hwnd=%s 关不掉也结束不了进程 pid=%s"
                      "（权限不足？请用同样权限启动本工具）", hwnd, pid)
            return False
        try:
            ctypes.windll.kernel32.TerminateProcess(hproc, 1)
            log.warning("假死窗口 hwnd=%s 消息泵无响应，已强制结束进程 pid=%s", hwnd, pid)
        finally:
            ctypes.windll.kernel32.CloseHandle(hproc)
    except Exception as e:
        log.error("强制结束假死客户端进程失败 hwnd=%s: %s", hwnd, e)
        return False
    for _ in range(20):
        if not win32gui.IsWindow(hwnd):
            return True
        time.sleep(0.25)
    return not win32gui.IsWindow(hwnd)


def _work_area(hwnd=None):
    """窗口所在显示器的工作区（已扣掉任务栏）：(left, top, right, bottom)。

    优先用 hwnd 所在显示器（多屏时把那一屏的右下角当基准），hwnd 无效或
    查询失败退回主显示器，再失败退回整屏尺寸。坐标是物理像素——先确保
    进程 DPI 感知，否则高缩放屏上算出来的右下角会偏。
    """
    try:
        from core.device import _set_dpi_awareness
        _set_dpi_awareness()
    except Exception:
        pass
    try:
        import win32api
        mon = 0
        if hwnd:
            try:
                mon = win32api.MonitorFromWindow(hwnd, 2)  # MONITOR_DEFAULTTONEAREST
            except Exception:
                mon = 0
        if not mon:
            mon = win32api.MonitorFromPoint((0, 0), 1)     # MONITOR_DEFAULTTOPRIMARY
        info = win32api.GetMonitorInfo(mon)
        return tuple(info.get("Work") or info["Monitor"])
    except Exception as e:
        log.warning("取显示器工作区失败，退回整屏尺寸: %s", e)
        import win32api
        return (0, 0, win32api.GetSystemMetrics(0), win32api.GetSystemMetrics(1))


def order_hwnds_by_account(hwnds):
    """按「账号」页从上到下的顺序排窗口（未绑定的窗口按传入相对顺序排最后）。

    平铺顺序必须跟账号页一致（用户规则：账号页从上到下 = 桌面从左到右）。
    顺序来源是 db 的 sort_order（= 账号页拖拽后的顺序），配对依据是
    accounts.hwnd 绑定——绑定失效（客户端重启换句柄）时这些窗口排不上，
    就按传入顺序跟在后面，不猜。
    """
    hwnds = [h for h in hwnds]
    if len(hwnds) < 2:
        return hwnds
    try:
        from core import db
        accounts = db.list_accounts()
    except Exception as e:
        log.warning("读账号列表失败，按原顺序平铺: %s", e)
        return hwnds
    rank = {}
    for i, acc in enumerate(accounts):
        h = int(acc.get("hwnd") or 0)
        if h and h in hwnds and h not in rank:
            rank[h] = i
    if not rank:
        log.info("没有窗口能对上账号绑定（可能是手动开的客户端），按原顺序平铺")
        return hwnds
    bound = sorted([h for h in hwnds if h in rank], key=lambda h: rank[h])
    rest = [h for h in hwnds if h not in rank]
    if rest:
        log.info("平铺：%d 个窗口按账号顺序，%d 个未绑定排最后", len(bound), len(rest))
    return bound + rest


def tile_windows(hwnds, win_w=421, win_h=759, start_x=None, start_y=None,
                 gap=5, per_row=5, order_by_account=True, valign="top"):
    """把窗口平铺排列（避免互相遮挡——截图读屏幕像素，被遮挡会识别失败）。

    排列规则：
    - **顺序 = 账号页从上到下的账号顺序**，桌面上从左往右排（见
      `order_hwnds_by_account`，配对靠账号绑定的 hwnd）；
    - **横向右对齐、纵向上对齐**：start_x/start_y 留空时自动按工作区
      （扣任务栏）定位；显式给数值则按数值放（老配置兼容）。
    - `valign` 控制纵向：默认 `"top"`（贴工作区上沿），传 `"bottom"` 退回旧行为
      （贴下沿）。为什么默认改成上对齐（2026-11-06）：客户端整块贴在右下角时，
      第三方弹窗（搜狗输入法推广、"向僵尸开炮"之类）+ 游戏内网页公告窗都从右下
      冒出来，直接压住客户区右下角的「背包」等图标 —— 6 号 05:34 的 eat_cooking
      就因此「等待超时，未找到模板: 背包」判负。dxcam 抓的是屏幕像素，窗口被挡
      多少就丢多少，位置挪到上半屏是最省事的规避。
    """
    hwnds = list(hwnds or [])
    if not hwnds:
        return
    if order_by_account:
        hwnds = order_hwnds_by_account(hwnds)
    cols = max(1, min(int(per_row or 5), len(hwnds)))
    rows = (len(hwnds) + cols - 1) // cols
    total_w = cols * win_w + (cols - 1) * gap
    total_h = rows * win_h + (rows - 1) * gap
    left, top, right, bottom = _work_area(hwnds[0])
    if start_x is None:
        start_x = right - total_w          # 右对齐
    if start_y is None:
        if str(valign).lower() == "bottom":
            start_y = bottom - total_h     # 旧行为：下对齐
        else:
            start_y = top                  # 上对齐：躲开右下角冒出来的第三方弹窗
    start_x = max(left, int(start_x))      # 窗口比屏幕还宽时别推到屏幕外
    start_y = max(top, int(start_y))
    log.info("平铺 %d 个窗口：%dx%d 每行 %d 个，起点 (%d, %d)，纵向%s对齐"
             "（工作区 %s）",
             len(hwnds), total_w, total_h, cols, start_x, start_y,
             "下" if str(valign).lower() == "bottom" else "上",
             (left, top, right, bottom))
    for i, hwnd in enumerate(hwnds):
        row, col = divmod(i, cols)
        move_window(hwnd, start_x + col * (win_w + gap),
                    start_y + row * (win_h + gap), win_w, win_h)


def is_admin():
    """当前进程是否以管理员权限运行。"""
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def hwnd_elevated(hwnd):
    """窗口所属进程是否以提升权限运行；查询失败（窗口已关闭等）返回 None。"""
    _, pid = win32process.GetWindowThreadProcessId(hwnd)
    hproc = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)  # QUERY_LIMITED_INFORMATION
    if not hproc:
        return None
    try:
        tok = ctypes.c_void_p()
        if not ctypes.windll.advapi32.OpenProcessToken(hproc, 0x0008, ctypes.byref(tok)):
            return None
        try:
            buf, sz = ctypes.c_ulong(), ctypes.c_ulong()
            ctypes.windll.advapi32.GetTokenInformation(tok, 20, ctypes.byref(buf), 4, ctypes.byref(sz))
            return bool(buf.value)  # TokenElevation
        finally:
            ctypes.windll.kernel32.CloseHandle(tok)
    finally:
        ctypes.windll.kernel32.CloseHandle(hproc)


def relaunch_as_admin():
    """以管理员身份重启当前程序（弹 UAC）。用户确认返回 True，拒绝返回 False。

    打包（PyInstaller）模式下 sys.executable 即 exe 本体；脚本模式下用
    python.exe + 脚本绝对路径，工作目录固定为脚本所在目录。
    """
    if getattr(sys, "frozen", False):
        exe = sys.executable
        args = " ".join(f'"{a}"' for a in sys.argv[1:])
        cwd = str(Path(sys.executable).parent)
    else:
        exe = sys.executable
        script = Path(sys.argv[0]).resolve()
        args = " ".join([f'"{script}"'] + [f'"{a}"' for a in sys.argv[1:]])
        cwd = str(script.parent)
    ret = ctypes.windll.shell32.ShellExecuteW(None, "runas", exe, args, cwd,
                                              win32con.SW_SHOWNORMAL)
    log.info("请求管理员重启: %s %s (ret=%s)", exe, args, ret)
    return ret > 32
