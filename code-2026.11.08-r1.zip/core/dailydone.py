# -*- coding: utf-8 -*-
"""每日一次型任务的完成记录（吃烹饪/吃宝宝烹饪等）。

记录存 data/daily_done.json：{day_key: {账号标识: [task_name, ...]}}。
日界不是 0 点而是凌晨 5 点（游戏日常刷新时间）：现在时刻减 5 小时得到的
日期才是"今天"，过 5 点自动算新的一天。旧日期记录读取时清掉。
"""
import json
import logging
import threading
from datetime import datetime, timedelta

from core.paths import DATA_DIR

log = logging.getLogger("dailydone")

_lock = threading.Lock()
DAY_START_HOUR = 5  # 每天 5:00 刷新


def _day_key():
    return (datetime.now() - timedelta(hours=DAY_START_HOUR)).date().isoformat()


def _load():
    path = DATA_DIR / "daily_done.json"
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save(data):
    path = DATA_DIR / "daily_done.json"
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)


def is_done(account_key, task_name):
    """该账号今天（按 5 点日界）是否已完成过该任务。"""
    with _lock:
        done = _load().get(_day_key(), {})
        return task_name in done.get(str(account_key), [])


def mark_done(account_key, task_name):
    with _lock:
        data = {_day_key(): _load().get(_day_key(), {})}  # 只保留今天
        data[_day_key()].setdefault(str(account_key), [])
        if task_name not in data[_day_key()][str(account_key)]:
            data[_day_key()][str(account_key)].append(task_name)
        _save(data)
    log.info("每日任务记录：%s 今天已完成 %s（明天 5 点后重置）",
             account_key, task_name)
