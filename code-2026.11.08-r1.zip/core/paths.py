"""统一路径管理：开发模式与 PyInstaller 打包（frozen）模式兼容。

打包后为绿色便携包布局，用户数据全部裸露在 exe 同级（可改可换）：
    cahx-helper.exe
    _internal/          # 代码、依赖、OCR 模型、默认素材（勿动）
    config.yaml         # 用户配置（首次启动从 defaults 复制，之后不覆盖）
    assets/images/      # 模板素材（首次启动复制；用户可增删改）
    data/               # 账号库（运行期生成）
    debug/              # 日志与调试截图
"""
import shutil
import sys
from pathlib import Path

FROZEN = getattr(sys, "frozen", False)

if FROZEN:
    ROOT = Path(sys.executable).resolve().parent   # exe 所在目录（用户侧，可写）
    BUNDLE = Path(sys._MEIPASS)                    # 包内临时解包目录（只读）
else:
    ROOT = Path(__file__).resolve().parent.parent
    BUNDLE = ROOT

CONFIG_PATH = ROOT / "config.yaml"
ASSETS_DIR = ROOT / "assets" / "images"
DATA_DIR = ROOT / "data"
DEBUG_DIR = ROOT / "debug"
UNKNOWN_DIR = DEBUG_DIR / "unknown"   # 脚本无法判定的场景截图（等人看图说明处理方式）

# ---- 热更新（boot.py 引导器 + core/updater.py；仅打包版生效，开发模式禁用）----
APP_DIR = ROOT / "app"                       # 版本化载荷根目录
VERSIONS_DIR = APP_DIR / "versions"          # app/versions/<版本>/ 一版一份载荷
CURRENT_JSON = APP_DIR / "current.json"      # 当前载荷指针 {"code": "<版本>"}
PENDING_JSON = APP_DIR / "pending.json"      # 已下载待生效版本（重启时由 boot 应用）
ASSETS_BASELINE = APP_DIR / "assets_baseline.json"  # 素材基线哈希（保护用户改动）
UPDATE_STATE = DATA_DIR / "update_state.json"       # 崩溃回滚计数
BOOT_ERROR_LOG = DEBUG_DIR / "boot_error.log"       # 引导器崩溃/回滚记录

# PP-OCRv5 模型（tools/fetch_ocr_models.py 下载，打包时随 _internal 分发，用户无需修改）
OCR_MODELS_DIR = BUNDLE / "assets" / "ocr_models"

_DEFAULTS = BUNDLE / "defaults"


def ensure_user_files():
    """首启初始化：默认 config 和模板素材复制到 exe 同级（已存在则不覆盖）。"""
    DATA_DIR.mkdir(exist_ok=True)
    DEBUG_DIR.mkdir(exist_ok=True)
    UNKNOWN_DIR.mkdir(exist_ok=True)
    if not FROZEN:
        return
    if not CONFIG_PATH.exists():
        shutil.copy(_DEFAULTS / "config.yaml", CONFIG_PATH)
    if not ASSETS_DIR.exists():
        shutil.copytree(_DEFAULTS / "assets" / "images", ASSETS_DIR)
