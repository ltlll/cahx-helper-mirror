"""宿主机 Windows 外观小工具。

目前只做一件事：**把 Windows 11 的右键菜单还原成 Windows 10 的样子**
（就是 Win11 资源管理器里那一层"显示更多选项"折叠菜单，还原后一级菜单直接
显示复制/粘贴/发送到/属性等旧式项目）。

原理
----
Win11 的"精简"右键菜单是 ``IExplorerCommand`` 那一套新壳体；只要给旧壳体注册一个
**空的** ``InprocServer32``，外壳就会回退到 Win10 的经典菜单（``WM_CONTEXTMENU``
走 ``ShellExt`` 枚举）。具体就是一个注册表键：

    HKCU\\Software\\Classes\\CLSID\\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}
        \\InprocServer32\\(默认) = ""        ← 空字符串，必须有这个值

这个 CLSID 是 Win11 用来标记"新式菜单"的占位组件；把它在本用户下覆盖成一个
**没有实现**的空组件，新菜单就构建不出来，外壳自动退回经典菜单。删除整棵
``{86ca1aa0-...}`` 键即恢复 Win11 原生菜单。

为什么写在 HKCU
---------------
``HKCU\\Software\\Classes`` 是**当前用户**的类注册表，优先级高于
``HKLM\\Software\\Classes``，而且**普通权限就能写**——所以这个功能**不需要管理员、
不弹 UAC**（与 ``sandbox_tools`` 不同）。

生效时机
--------
外壳只在进程启动时读一次类注册表，所以改完必须**重启资源管理器**
（``restart_explorer()``：``taskkill /f /im explorer.exe`` + 重新拉起）。
重启会关掉所有已打开的文件资源管理器窗口（浏览器 / 其他程序不受影响），
所以 GUI 那边是先弹确认框再动手。

安全性
------
* 改动前把**改动前的原状**记进 ``data/wintweaks_backup.json``（只记第一次，
  之后不覆盖），``set_legacy_menu(False)`` 据此还原——如果那个键本来就是别人
  注册过的（值非空），还原时会写回原值而不是直接删。
* 只碰 ``HKCU`` 下面这一个 CLSID 键，不做任何宽匹配删除。
* 非 Windows / 非 Win11 一律拒绝执行并说明原因。

命令行：``python -m core.wintweaks``（只打印状态）/ ``--enable`` / ``--disable`` /
``--restart-explorer``。

自检：``python debug/_verify_wintweaks.py``（临时注册表键往返，不碰真实系统）。
"""

from __future__ import annotations

import json
import logging
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

try:
    import winreg
except ImportError:  # pragma: no cover - 非 Windows
    winreg = None

from core.paths import DATA_DIR

log = logging.getLogger(__name__)

# Win11 新式右键菜单的占位 CLSID（微软未公开，社区通用做法）
CONTEXT_MENU_CLSID = "{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}"

# ---- 可在自检里替换的注入点 ----
ROOT_KEY = winreg.HKEY_CURRENT_USER if winreg else None
CLASSES_BASE = r"Software\Classes\CLSID"     # 类注册表根（自检时指向临时键）
BACKUP_JSON = DATA_DIR / "wintweaks_backup.json"

MIN_WIN11_BUILD = 22000

CREATIONFLAGS = 0x08000000                    # CREATE_NO_WINDOW


# ---------------------------------------------------------------- 基础探测


def windows_build() -> int:
    """当前 Windows 内部版本号；非 Windows 返回 0。"""
    try:
        return int(sys.getwindowsversion().build)      # type: ignore[attr-defined]
    except Exception:                                  # noqa: BLE001
        return 0


def is_windows() -> bool:
    return winreg is not None


def is_win11() -> bool:
    """只有 Win11（含 Win Server 2022+）才有"新式右键菜单"这回事。"""
    return windows_build() >= MIN_WIN11_BUILD


@dataclass
class Info:
    """当前右键菜单状态。"""

    windows_build: int = 0
    is_win11: bool = False
    key_exists: bool = False            # HKCU 下那个 CLSID\InprocServer32 在不在
    legacy_enabled: bool = False        # 是否已还原成 Win10 样式
    value: str | None = None            # 那个 (默认) 值的内容（None = 值不存在）
    explorer_running: bool = False

    @property
    def supported(self) -> bool:
        return self.is_win11


def _key_path() -> str:
    return rf"{CLASSES_BASE}\{CONTEXT_MENU_CLSID}\InprocServer32"


def _clsid_path() -> str:
    return rf"{CLASSES_BASE}\{CONTEXT_MENU_CLSID}"


def _read_default(path: str) -> tuple[bool, str | None, int | None]:
    """读某个键的 (键是否存在, (默认)值, 值类型)。"""
    try:
        with winreg.OpenKey(ROOT_KEY, path) as k:
            try:
                value, vtype = winreg.QueryValueEx(k, "")
                return True, value, vtype
            except FileNotFoundError:
                return True, None, None
    except FileNotFoundError:
        return False, None, None


def _explorer_running() -> bool:
    try:
        # errors="replace"：中文系统的 tasklist 输出是 GBK，而解释器可能在
        # UTF-8 模式下跑 → 不设会把 reader 线程炸掉（实测踩到过）
        out = subprocess.run(
            ["tasklist", "/fi", "imagename eq explorer.exe", "/nh"],
            capture_output=True, text=True, errors="replace", timeout=10,
            creationflags=CREATIONFLAGS)
        return "explorer.exe" in (out.stdout or "").lower()
    except Exception:                                  # noqa: BLE001
        return False


def detect() -> Info:
    """只读探测当前状态（不写任何东西）。"""
    info = Info(windows_build=windows_build())
    info.is_win11 = info.windows_build >= MIN_WIN11_BUILD
    if not is_windows():
        return info
    exists, value, _ = _read_default(_key_path())
    info.key_exists = exists
    info.value = value
    # 判定标准与写法一致：键在、且 (默认) 值是**显式的空串**
    info.legacy_enabled = bool(exists and value is not None and not str(value).strip())
    info.explorer_running = _explorer_running()
    return info


def status_text(info: Info | None = None) -> str:
    info = info or detect()
    if not is_windows():
        return "当前系统不是 Windows，这个功能用不上。"
    if not info.is_win11:
        return (f"当前是 Windows 10 或更早（内部版本 {info.windows_build}），"
                "本来就是经典右键菜单，无需还原。")
    if info.legacy_enabled:
        return "已还原成 Windows 10 风格的右键菜单。"
    return "当前是 Windows 11 原生右键菜单（带「显示更多选项」那一层）。"


# ---------------------------------------------------------------- 写操作


def _save_prior(prior: dict) -> None:
    """记下改动前的原状；**已存在就不覆盖**（保住最早那份）。"""
    try:
        if BACKUP_JSON.exists():
            return
        BACKUP_JSON.parent.mkdir(parents=True, exist_ok=True)
        BACKUP_JSON.write_text(
            json.dumps(prior, ensure_ascii=False, indent=2), encoding="utf-8")
        log.info("已记录右键菜单原状：%s", BACKUP_JSON)
    except OSError as exc:
        log.warning("写 %s 失败：%s", BACKUP_JSON, exc)


def _load_prior() -> dict | None:
    try:
        return json.loads(BACKUP_JSON.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _delete_tree(path: str) -> bool:
    """递归删除 HKCU 下的一个键树；不存在也算成功。"""
    try:
        with winreg.OpenKey(ROOT_KEY, path, 0, winreg.KEY_ALL_ACCESS) as k:
            while True:
                try:
                    sub = winreg.EnumKey(k, 0)
                except OSError:
                    break
                _delete_tree(rf"{path}\{sub}")
    except FileNotFoundError:
        return True
    except OSError as exc:
        log.warning("打开 %s 失败：%s", path, exc)
        return False
    try:
        winreg.DeleteKey(ROOT_KEY, path)
        return True
    except FileNotFoundError:
        return True
    except OSError as exc:
        log.warning("删除 %s 失败：%s", path, exc)
        return False


def _enable_legacy() -> tuple[bool, str]:
    """写入空的 InprocServer32 → 还原成 Win10 风格。"""
    # 记原状（可能键本来就不存在）
    exists, value, vtype = _read_default(_key_path())
    _save_prior({"key_existed": exists, "default_set": value is not None,
                 "default_value": value, "value_type": vtype})
    try:
        with winreg.CreateKeyEx(ROOT_KEY, _key_path(), 0, winreg.KEY_SET_VALUE) as k:
            # 必须是**显式的空字符串**（值不存在无效）
            winreg.SetValueEx(k, "", 0, winreg.REG_SZ, "")
    except OSError as exc:
        return False, f"写注册表失败：{exc}"
    return True, "已写入经典右键菜单注册项。"


def _disable_legacy() -> tuple[bool, str]:
    """删除那个 CLSID 键 → 回到 Win11 原生菜单。"""
    prior = _load_prior()
    target = _clsid_path()

    # 原状是"别人注册过的非空值" → 写回原值，别把人家的注册干掉
    if prior and prior.get("key_existed") and prior.get("default_set") \
            and str(prior.get("default_value") or "").strip():
        try:
            with winreg.CreateKeyEx(ROOT_KEY, _key_path(), 0,
                                    winreg.KEY_SET_VALUE) as k:
                winreg.SetValueEx(k, "", 0, prior.get("value_type") or winreg.REG_SZ,
                                  prior.get("default_value") or "")
            return True, "已写回改动前本来就存在的注册值（未删除）。"
        except OSError as exc:
            return False, f"写注册表失败：{exc}"

    ok = _delete_tree(target)
    if not ok:
        return False, "删除注册表键失败（可能被安全软件拦截）。"
    try:
        BACKUP_JSON.unlink(missing_ok=True)
    except OSError:
        pass
    return True, "已删除经典右键菜单注册项。"


def restart_explorer(timeout: int = 30) -> tuple[bool, str]:
    """重启资源管理器让改动生效（会关掉已打开的文件资源管理器窗口）。"""
    if not is_windows():
        return False, "当前系统不是 Windows。"
    try:
        subprocess.run(["taskkill", "/f", "/im", "explorer.exe"],
                       capture_output=True, text=True, errors="replace",
                       timeout=timeout, creationflags=CREATIONFLAGS)
    except Exception as exc:                            # noqa: BLE001
        log.warning("结束 explorer 失败：%s", exc)
    # taskkill 之后桌面会短暂消失；显式拉起（多数情况 Win 自己也会拉，重复启动无害）
    try:
        subprocess.Popen(["explorer.exe"], creationflags=CREATIONFLAGS)
    except OSError as exc:
        return False, f"重新启动资源管理器失败：{exc}（按 Ctrl+Shift+Esc 手动新建 explorer.exe）"
    return True, "已重启资源管理器。"


def apply(enabled: bool, restart: bool = True) -> tuple[bool, str]:
    """开启/还原 Win10 风格右键菜单；``restart`` 时顺带重启资源管理器。

    返回 ``(是否成功, 给用户看的结果说明)``。
    """
    info = detect()
    if not is_windows():
        return False, "当前系统不是 Windows，这个功能用不上。"
    if not info.is_win11:
        return False, (f"当前是 Windows 10 或更早（内部版本 {info.windows_build}），"
                       "本来就是经典右键菜单，无需改动。")

    parts: list[str] = []
    if enabled:
        if info.legacy_enabled:
            parts.append("本来就已经是经典右键菜单，注册表未改动")
        else:
            ok, msg = _enable_legacy()
            if not ok:
                return False, msg
            parts.append("已写入经典右键菜单注册项")
    else:
        if not info.key_exists:
            parts.append("本来就是 Windows 11 原生菜单，注册表未改动")
        else:
            ok, msg = _disable_legacy()
            if not ok:
                return False, msg
            parts.append("已删除经典右键菜单注册项")

    if restart:
        rok, rmsg = restart_explorer()
        parts.append(rmsg if rok else f"⚠ {rmsg}")
    else:
        parts.append("需要重启资源管理器（或注销）后生效")
    return True, "；".join(parts) + "。"


# ---------------------------------------------------------------- CLI


def _main(argv: list[str]) -> int:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    info = detect()
    print("=== 右键菜单状态 ===")
    print(f"  Windows 内部版本: {info.windows_build}"
          f"（Win11+：{info.is_win11}）")
    print(f"  经典菜单已启用？: {info.legacy_enabled}")
    print(f"  注册表键在不在  : {info.key_exists}  值={info.value!r}")
    print(f"  资源管理器在跑？: {info.explorer_running}")
    print(f"  说明            : {status_text(info)}")

    if "--enable" in argv:
        ok, msg = apply(True)
        print(f"\n[还原成 Win10 样式] ok={ok} {msg}")
        return 0 if ok else 1
    if "--disable" in argv:
        ok, msg = apply(False)
        print(f"\n[恢复 Win11 原生] ok={ok} {msg}")
        return 0 if ok else 1
    if "--restart-explorer" in argv:
        ok, msg = restart_explorer()
        print(f"\n[重启资源管理器] ok={ok} {msg}")
        return 0 if ok else 1
    return 0


if __name__ == "__main__":
    raise SystemExit(_main(sys.argv[1:]))
