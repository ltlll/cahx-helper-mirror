"""兼容中文路径的图像读写。

OpenCV 的 imread/imwrite 在 Windows 上遇到非 ASCII 路径会静默失败，
这里统一用 Python 读写字节流，再用 imdecode/imencode 处理。
"""
from pathlib import Path

import cv2
import numpy as np


def imread(path):
    data = np.fromfile(str(path), dtype=np.uint8)
    return cv2.imdecode(data, cv2.IMREAD_COLOR)


def imwrite(path, img):
    path = Path(path)
    ext = path.suffix or ".png"
    ok, buf = cv2.imencode(ext, img)
    if not ok:
        raise IOError(f"图像编码失败: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    buf.tofile(str(path))
