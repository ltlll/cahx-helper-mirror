"""页面锚点判定（page anchors）：用页面上**固定不变的几个元素**判断"当前到了流程的哪一步"。

判定分三级
----------
1. 锚点命中数 >= need      → 确认在该页（纯模板匹配，**0 次 OCR**）
2. 命中数处于灰区（0 < 命中 < need）或锚点素材缺失 → 用该页登记的 OCR 关键词兜底
3. 命中数 = 0 且互斥元素没出现 → 不在该页
另有互斥元素（`exclude`）：命中即直接判"不是本页"，连灰区都不进。

为什么不"单个模板命中就下结论"
--------------------------------
- 同一张图会被多个页面复用——`公告关闭` 的 X 与诗悦登录框/服务器选择页右上角
  的 X **是同一张图**，单模板判定必然把 A 页判成 B 页；
- 反过来，单模板漏检/素材缺失就让整条流程卡住，多锚点只要还剩一个在线就能确认。

为什么不"整页 OCR"
------------------
一次区域 OCR 实测 0.5~1.5s（本机 CPU 已跑满、引擎槽位加不动），而一次小区域
模板匹配 < 5ms。凡是能用固定元素确认的步骤都不该付 OCR 的钱；OCR 只留给
"字是动态的"（角色名/手机号/系统弹窗文案）和"固定元素判不出来"的兜底。

region 必须写死
---------------
405x720 客户区内各页布局固定，限定范围匹配既快又准：全图匹配半透明图标
假阳性高（实测误判分高于真按钮）。region=None 只用于"整块都是这页特有"的
大模板（如全屏按钮），代价是慢。

用法
----
    pages = [PAGE_LOGIN_BOX, PAGE_SERVER_SELECT, ...]      # 按优先级排列
    got = anchors.identify(matcher, screen, pages, contains=flow._contains)
    if got and got.page.key == "login_box":
        method.click(*got.primary[:2])                     # primary = 主锚点命中坐标
`contains(text, region) -> bool` 是唯一的 OCR 入口（登录流程传 `LoginFlow._contains`，
它自带帧内缓存）；不传 = 判定不出来时放弃（不付 OCR 的钱）。
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field

log = logging.getLogger("anchors")


@dataclass(frozen=True)
class Anchor:
    """页面上一个固定元素。template 为模板名（assets/images 下唯一）。"""
    template: str
    region: tuple | None = None      # (x, y, w, h)；None = 全图（慢，慎用）
    threshold: float = 0.90
    ccoeff_floor: float = 0.45
    note: str = ""                   # 人读注释（日志/自检里显示）


@dataclass(frozen=True)
class Page:
    """一个页面/流程步骤的锚点集合。"""
    key: str
    label: str
    anchors: tuple
    need: int | None = None          # 命中数下限；None = 全部可用锚点都要命中
    exclude: tuple = ()              # 互斥锚点（模板名或 Anchor）：命中即判"不是本页"
    ocr_texts: tuple = ()            # 灰区时用 OCR 确认的关键词
    ocr_region: tuple | None = None  # 关键词的搜索区域（None = 全图）
    # 浮层页：**允许盖在别的页面上共存**（如"公告/系统弹窗"的右上角 X，可以
    # 叠在踏入长安页/角色页上）。浮层不参与 `resolve` 的"唯一性"检查——否则
    # "公告叠在踏入长安上"这个**完全正常的场景**会被判成歧义而整帧不动作，
    # 流程直接卡死。非浮层页（独占页）互相之间必须唯一。
    overlay: bool = False


@dataclass
class Hit:
    anchor: Anchor
    box: tuple | None = None         # (cx, cy, score) 或 None
    available: bool = True           # 素材是否存在（缺素材不算"未命中"）

    @property
    def ok(self) -> bool:
        return self.box is not None


@dataclass
class Probe:
    """一次页面判定的完整结果（可打印、可断言）。"""
    page: Page
    hits: list = field(default_factory=list)
    n_hit: int = 0
    n_avail: int = 0
    need: int = 0
    excluded: tuple = ()             # 命中的互斥模板名
    ok: bool = False
    undecided: bool = False          # 固定元素判不出来（灰区/素材缺失）
    source: str = "template"         # template | ocr | exclude | undecided | empty
    ocr_result: bool | None = None
    missing: tuple = ()              # 缺素材的模板名

    @property
    def primary(self) -> tuple | None:
        """主锚点命中坐标：**按 anchors 声明顺序取第一个命中的**。

        不取"最高分"——声明顺序才是语义顺序（如登录框页声明 进入游戏 在前、
        账号下拉在后，点击必须点 进入游戏，不能因为下拉箭头分高就点它）。
        """
        for h in self.hits:
            if h.ok:
                return h.box
        return None

    def box(self, template: str) -> tuple | None:
        """指定锚点的命中坐标（同名取第一个）。"""
        for h in self.hits:
            if h.anchor.template == template and h.ok:
                return h.box
        return None

    def detail(self) -> str:
        got = ", ".join(f"{h.anchor.template}@{h.box[0]},{h.box[1]}({h.box[2]:.2f})"
                        for h in self.hits if h.ok) or "无"
        return (f"{self.page.key}({self.page.label}) 命中 {self.n_hit}/{self.need}"
                f"（可用 {self.n_avail}）[{got}] 判定={self.source}"
                f"{'/排除:' + ','.join(self.excluded) if self.excluded else ''}")


# ---------------------------------------------------------------- 统计（可观测）
_STATS = {"probe": 0, "template": 0, "ocr": 0, "undecided": 0,
          "exclude": 0, "empty": 0, "pages": {}}


def stats_reset():
    _STATS.update(probe=0, template=0, ocr=0, undecided=0, exclude=0, empty=0)
    _STATS["pages"] = {}


def stats() -> dict:
    return {"probe": _STATS["probe"], "template": _STATS["template"],
            "ocr": _STATS["ocr"], "undecided": _STATS["undecided"],
            "exclude": _STATS["exclude"], "empty": _STATS["empty"],
            "pages": dict(_STATS["pages"])}


def stats_text() -> str:
    s = stats()
    ocr_rate = (s["ocr"] / s["probe"] * 100) if s["probe"] else 0.0
    return (f"页面判定 {s['probe']} 次：模板命中 {s['template']}、"
            f"OCR 兜底 {s['ocr']}（{ocr_rate:.0f}%）、干净否定 {s['empty']}、"
            f"判不出 {s['undecided']}、互斥排除 {s['exclude']}")


# ---------------------------------------------------------------- 底层
def _has(matcher, name) -> bool:
    try:
        return bool(matcher.has_template(name))
    except Exception:
        return False


def _default_find(matcher):
    def find(screen, anchor: Anchor):
        try:
            return matcher.find(screen, anchor.template, threshold=anchor.threshold,
                                region=anchor.region, ccoeff_floor=anchor.ccoeff_floor)
        except FileNotFoundError:
            return None
        except Exception as e:            # 素材损坏/尺寸不符等：当未命中，不中断流程
            log.debug("锚点 %s 匹配异常: %s", anchor.template, e)
            return None
    return find


def _as_anchor(a) -> Anchor:
    return a if isinstance(a, Anchor) else Anchor(template=a)


def probe(matcher, screen, page: Page, contains=None, find=None) -> Probe:
    """判定 screen 是不是 page。`find(screen, anchor) -> box|None`、`contains(text, region)->bool` 可替换（测试桩）。"""
    finder = find or _default_find(matcher)
    p = Probe(page=page)
    missing = []
    for a in page.anchors:
        avail = _has(matcher, a.template)
        box = finder(screen, a) if avail else None
        p.hits.append(Hit(a, box, avail))
        if avail:
            p.n_avail += 1
            if box:
                p.n_hit += 1
        else:
            missing.append(a.template)
    p.missing = tuple(missing)

    # 互斥元素：命中即"不是本页"，比正向锚点优先级更高
    hit_ex = []
    for a in page.exclude:
        a = _as_anchor(a)
        if _has(matcher, a.template) and finder(screen, a):
            hit_ex.append(a.template)
    p.excluded = tuple(hit_ex)

    need = page.need if page.need is not None else p.n_avail
    p.need = need
    _STATS["probe"] += 1
    _STATS["pages"][page.key] = _STATS["pages"].get(page.key, 0) + 1

    if hit_ex:
        p.source = "exclude"
        _STATS["exclude"] += 1
        return p
    if p.n_avail == 0:
        p.undecided = True                    # 素材全缺：模板判不了，交给 OCR
    elif p.n_hit >= p.need and p.need > 0:
        p.ok, p.source = True, "template"
        _STATS["template"] += 1
        return p
    elif p.n_hit == 0 and p.n_avail >= p.need:
        p.source = "empty"                    # 干净否定：锚点够用且一个都没中
        _STATS["empty"] += 1
        return p
    else:
        p.undecided = True                    # 灰区（部分命中）或素材数不够 need

    if not p.undecided:
        return p
    # 固定元素判不出来 → OCR 兜底（没给 OCR 入口就放弃，不额外花钱）
    if contains is not None and page.ocr_texts:
        try:
            p.ocr_result = any(contains(t, page.ocr_region) for t in page.ocr_texts)
        except Exception as e:
            log.debug("页面 %s OCR 兜底异常: %s", page.key, e)
            p.ocr_result = False
        if p.ocr_result:
            p.ok, p.source = True, "ocr"
            _STATS["ocr"] += 1
            return p
        p.source = "ocr"
        return p
    p.source = "undecided"
    _STATS["undecided"] += 1
    return p


def identify(matcher, screen, pages, contains=None, find=None):
    """按优先级返回第一个确认命中的页面 Probe；都不命中返回 None。

    ⚠️ 假阳性会"抢先"：两个页面同时命中时这里会返回优先级高的那个（=赌运气）。
    需要"判不准就别动"的场合（要按判定结果点击的），用 `identify_unique`。
    """
    for page in pages:
        p = probe(matcher, screen, page, contains=contains, find=find)
        if p.ok:
            return p
    return None


def resolve(probes, order, overlays=()):
    """已算好的 Probe 集合 → (可用页面 key 列表, 歧义说明)。

    规则（`probes` = {key: Probe}，`order` = 优先级顺序，`overlays` = 浮层页 key）
    ---------------------------------------------------------------------------
    - `oks` = 本帧确认命中的页面（按 order 排序）
    - `独占页` = oks 里去掉 overlays —— **只有独占页参与唯一性检查**：
      - 独占页 0 或 1 个 → 正常：usable = oks（含浮层，浮层由调用方按点击
        顺序先处理，如"先关公告再点按钮"）
      - 独占页 ≥2 个 → 至少一个是假阳性：
        - 恰好 1 个是 `source == "ocr"` 确认的 → 采信它（+ 浮层）
        - 否则（多个模板命中，或多个 OCR 命中）→ **判歧义**，usable = []

    为什么要有这道闸：模板会被多个页面复用（公告 X 与诗悦登录框右上角的 X
    是同一张图）、半透明图标假阳性又高。两个**独占**页面同时"确认命中"意味着
    至少一个是错的——此时按优先级点击就是赌，可能把登录框关了或点进错页面。
    不确定就别点，交给调用方的兜底/OCR。

    为什么不能简单地说"≥2 个命中就算歧义"：公告是浮层，正常就叠在踏入长安
    页/角色页上（登录后常见），那种情况下两页确实同时命中——按"≥2 就歧义"
    会把合法场景判死、整帧不动作导致登录超时。
    """
    oks = [k for k in order if k in probes and probes[k].ok]
    ex = [k for k in oks if k not in overlays]
    if len(ex) <= 1:
        return oks, ""
    detail = " | ".join(probes[k].detail() for k in ex)
    ocr_ex = [k for k in ex if probes[k].source == "ocr"]
    if len(ocr_ex) == 1:
        keep = [k for k in oks if k in overlays or k == ocr_ex[0]]
        return keep, (f"独占页 {'/'.join(ex)} 同时命中，仅 {ocr_ex[0]} 经 OCR 确认："
                      f"{detail}")
    return [], (f"独占页 {'/'.join(ex)} 同时命中且无法区分"
                f"（无唯一 OCR 确认）：{detail}")


def identify_unique(matcher, screen, pages, contains=None, find=None):
    """识别页面，**多个独占页同时命中时判为歧义**：返回 (Probe 或 None, 说明)。

    与 `identify` 的区别：identify 短路返回第一个命中的（快，但被假阳性抢先），
    本函数全部判定后走 `resolve`，只在"唯一可信"时才返回 Probe。
    """
    probes = {p.key: probe(matcher, screen, p, contains=contains, find=find)
              for p in pages}
    keys, why = resolve(probes, [p.key for p in pages],
                        overlays=[p.key for p in pages if p.overlay])
    return (probes[keys[0]] if keys else None), why


def identify_all(matcher, screen, pages, contains=None, find=None):
    """全量判定（诊断/自检用）：返回全部 Probe。线上走 identify 短路更省。"""
    return [probe(matcher, screen, p, contains=contains, find=find) for p in pages]


def find_anchor(matcher, screen, anchor: Anchor, find=None):
    """单独找一个锚点（用于"等某个固定元素出现"的等待循环）。

    模板缺失返回 None（等待循环里表现为"等不到"，调用方走 OCR 兜底）。
    """
    if not has_anchor(matcher, anchor):
        return None
    return (find or _default_find(matcher))(screen, anchor)


def has_anchor(matcher, anchor: Anchor) -> bool:
    """锚点的模板素材是否已做出来（没做出来 = 只能走 OCR 兜底）。"""
    return _has(matcher, anchor.template)


def wait_anchor(device, matcher, anchor: Anchor, timeout=8, interval=0.5):
    """轮询截图直到锚点出现或超时，返回 (cx, cy, score) 或 None（不付 OCR）。

    模板缺失立刻返回 None（不空转整个超时）。
    """
    import time
    if not has_anchor(matcher, anchor):
        log.debug("锚点 %s 无模板素材，跳过等待", anchor.template)
        return None
    deadline = time.time() + timeout
    finder = _default_find(matcher)
    while time.time() < deadline:
        box = finder(device.screenshot(), anchor)
        if box:
            return box
        time.sleep(interval)
    return None
