# -*- coding: utf-8 -*-
"""离线授权（秘钥注册）系统：机器码绑定 + 天数/永久期限 + 2 小时试用。

流程：朋友启动软件看到「机器码」发给你 → 你用 tools/make_license.py 生成
绑定该机+期限的密钥 → 他粘贴进「软件授权」窗口激活。密钥 payload 内含目标
机器指纹哈希，**在别的机器上验签后指纹比对必失败**——同一把 key 转发无效。

密钥格式：payload(14B) + ed25519 签名(64B)，base32 大写去填充、5 字符分组。
  payload = magic(1B) | fp_hash(8B) | expire(2B, 距 2026-01-01 天数, 0xFFFF=永久)
            | issued(2B) | note_len(1B) | note(note_len B, UTF-8)
私钥只在维护者机器（tools/_license_private.key，gitignore）；公钥在下面
_PUBLIC_KEY_HEX（tools/make_license.py --init 生成后粘入）。

试用：未激活可试用 TRIAL_SECONDS（按**软件真实运行时长**累计，GUI 里 QTimer
每 60s 固定 +60——改系统时间无效）。三处冗余存储取最大（注册表 HKCU +
%LOCALAPPDATA%\\cahx-helper + data/trial.json），重装软件只丢 data/ 一处，
"重装重置试用"无效。

开发模式（非 FROZEN）status() 恒为 ("dev", None)，GUI 不做任何拦截。

⚠️ 诚实声明：这是"防君子"门槛——Python 打包产物可被有技术的人绕过，
授权的意义是防止随手转发，不是强保护。

自检：python debug/_verify_license.py（改本文件 / make_license.py 后必跑）。
"""
import base64
import binascii
import hashlib
import json
import logging
import os
import struct
import time
from dataclasses import dataclass
from pathlib import Path

from core import _ed25519
from core.paths import DATA_DIR, FROZEN

log = logging.getLogger("license")

# ed25519 公钥（tools/make_license.py --init 生成后粘到这里）
_PUBLIC_KEY_HEX = "42018d5bf7932f9ed779e14875c24eed387c01f3ab8bb9e937abc6340258134d"

TRIAL_SECONDS = 2 * 3600          # 试用时长（按软件真实运行时长累计）
# expire 天数基准：2026-01-01 **本地**零点（到期日按当地民用日期算，
# 不能混用 UTC——东八区 0~8 点 UTC 日期比本地晚一天，跨零点会差一天）
_EXPIRE_EPOCH = time.mktime((2026, 1, 1, 0, 0, 0, 0, 0, -1))
_PERMANENT = 0xFFFF


def _days_now():
    """今天距 _EXPIRE_EPOCH 的本地民用天数。"""
    lt = time.localtime()
    local_midnight = time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday,
                                  0, 0, 0, 0, 0, -1))
    return int((local_midnight - _EXPIRE_EPOCH) // 86400)
_MAGIC = 0xC1
_KEY_PAYLOAD_LEN = 14             # magic+fp+expire+issued+note_len（note 另算）
_LICENSE_JSON = DATA_DIR / "license.json"
_TRIAL_JSON = DATA_DIR / "trial.json"
_REG_PATH = r"Software\cahx-helper"
_REG_VALUE = "TrialUsed"

# 应用盐：让指纹/试用文件哈希与本工具绑定（别的工具读不到同一份值）
_SALT = b"cahx-helper/license/v1"


@dataclass
class LicenseInfo:
    expire_date: str = ""     # 'YYYY-MM-DD'；空 = 永久
    permanent: bool = False
    note: str = ""


# ---------------------------------------------------------------- 机器指纹

def machine_fingerprint():
    """本机指纹：HKLM MachineGuid 加盐 sha256。读不到注册表时抛异常。"""
    import winreg
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                        r"SOFTWARE\Microsoft\Cryptography") as k:
        guid, _ = winreg.QueryValueEx(k, "MachineGuid")
    return hashlib.sha256(_SALT + str(guid).encode()).hexdigest()


def _fp_hash(fp_prefix):
    """20 位机器码前缀（hex）→ 密钥里的 8 字节哈希。

    ⚠️ 签发（make_key）与验证（verify_key）两侧必须用同一口径——
    机器码只给用户看前 20 位，所以哈希的也只能是前 20 位。
    """
    return hashlib.sha256(_SALT + bytes.fromhex(fp_prefix)).digest()[:8]


def machine_code(fp=None):
    """显示给用户的机器码：指纹前 20 位 hex，5 组 XXXX-XXXX-XXXX-XXXX-XXXX。"""
    fp = fp or machine_fingerprint()
    raw = fp[:20].upper()
    return "-".join(raw[i:i + 4] for i in range(0, 20, 4))


def parse_machine_code(text):
    """用户给的机器码 → 20 位 hex（容错横线/空格/大小写）。失败返回 None。"""
    raw = "".join(c for c in (text or "") if c in "0123456789abcdefABCDEF")
    return raw.lower() if len(raw) == 20 else None


# ---------------------------------------------------------------- 密钥编解码

def _b32e(data):
    s = base64.b32encode(data).decode().rstrip("=")
    return "-".join(s[i:i + 5] for i in range(0, len(s), 5))


def _b32d(text):
    raw = "".join(c for c in (text or "").upper() if c.isalnum())
    pad = (-len(raw)) % 8
    try:
        return base64.b32decode(raw + "=" * pad)
    except (binascii.Error, ValueError):
        return None


def make_key(fp_prefix, days=None, note="", sk=None):
    """签发密钥（仅 tools/make_license.py 用；sk=32B 私钥种子）。

    fp_prefix: 20 位 hex（机器码解析后的形式）；days: None=永久。
    """
    fp_hash = _fp_hash(fp_prefix)
    today = _days_now()
    expire = _PERMANENT if days is None else today + days
    issued = today
    note_b = (note or "").encode("utf-8")[:200]
    payload = struct.pack("<B8sHHB", _MAGIC, fp_hash, expire, issued, len(note_b)) + note_b
    sig = _ed25519.signature(payload, sk, _ed25519.publickey(sk))
    return _b32e(payload + sig)


def verify_key(key_text):
    """验证密钥 → (LicenseInfo, "") 或 (None, 失败原因)。"""
    blob = _b32d(key_text)
    if blob is None or len(blob) < _KEY_PAYLOAD_LEN + 64:
        return None, "密钥格式不正确"
    payload, sig = blob[:-64], blob[-64:]
    if not _PUBLIC_KEY_HEX:
        return None, "程序未配置授权公钥（请联系维护者）"
    try:
        _ed25519.checkvalid(sig, payload, bytes.fromhex(_PUBLIC_KEY_HEX))
    except ValueError:
        return None, "密钥无效（签名不符）"
    try:
        magic, fp_hash, expire, issued, note_len = struct.unpack(
            "<B8sHHB", payload[:_KEY_PAYLOAD_LEN])
    except struct.error:
        return None, "密钥格式不正确"
    if magic != _MAGIC:
        return None, "密钥格式不正确"
    try:
        if _fp_hash(machine_fingerprint()[:20]) != fp_hash:
            return None, "这把密钥不是给这台机器的（机器码不匹配）"
    except Exception:
        return None, "读取本机指纹失败，无法验证密钥"
    note = payload[_KEY_PAYLOAD_LEN:_KEY_PAYLOAD_LEN + note_len].decode(
        "utf-8", "replace")
    if expire == _PERMANENT:
        return LicenseInfo(permanent=True, note=note), ""
    expire_ts = _EXPIRE_EPOCH + expire * 86400
    expire_date = time.strftime("%Y-%m-%d", time.localtime(expire_ts))
    if time.time() > expire_ts + 86399:   # 到期日当天仍可用
        return None, f"这把密钥已于 {expire_date} 到期（请联系维护者续期）"
    return LicenseInfo(expire_date=expire_date, note=note), ""


# ---------------------------------------------------------------- 已激活状态

def activate(key_text):
    """激活：验证通过写 data/license.json。返回 (ok, msg)。"""
    info, err = verify_key(key_text)
    if info is None:
        return False, err
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    _LICENSE_JSON.write_text(json.dumps({
        "key": key_text.strip(),
        "activated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "expire_date": info.expire_date,
        "permanent": info.permanent,
        "note": info.note,
    }, ensure_ascii=False, indent=1), encoding="utf-8")
    msg = "激活成功：永久授权" if info.permanent else f"激活成功：有效期至 {info.expire_date}"
    log.info("授权%s", msg)
    return True, msg


def _activated_info():
    """读已激活 key 并重新验证 → (LicenseInfo, 是否有激活记录)。

    info=None 且 had_record=True = 密钥过期/被换机/被改——按 expired 处理，
    **不能**回落试用（否则过期用户白捡一段试用）。
    """
    try:
        rec = json.loads(_LICENSE_JSON.read_text(encoding="utf-8"))
        info, _ = verify_key(rec.get("key", ""))
        return info, True
    except Exception:
        return None, False


# ---------------------------------------------------------------- 试用计时

def _hmac(data_bytes):
    return hashlib.sha256(_SALT + data_bytes).hexdigest()[:16]


def _pack_trial(used):
    body = json.dumps({"used": int(used)}, separators=(",", ":")).encode()
    return body + b"." + _hmac(body).encode()


def _unpack_trial(blob):
    try:
        body, mac = blob.rsplit(b".", 1)
        if mac.decode() != _hmac(body):
            return 0
        return max(0, int(json.loads(body.decode()).get("used", 0)))
    except Exception:
        return 0


def _trial_localappdata():
    try:
        p = Path(os.environ.get("LOCALAPPDATA") or "") / "cahx-helper" / "trial.dat"
        return p
    except Exception:
        return None


def _trial_read_reg():
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _REG_PATH) as k:
            v, _ = winreg.QueryValueEx(k, _REG_VALUE)
        return _unpack_trial(base64.b64decode(v))
    except Exception:
        return 0


def _trial_write_reg(used):
    try:
        import winreg
        k = winreg.CreateKey(winreg.HKEY_CURRENT_USER, _REG_PATH)
        winreg.SetValueEx(k, _REG_VALUE, 0, winreg.REG_SZ,
                          base64.b64encode(_pack_trial(used)).decode())
        winreg.CloseKey(k)
    except Exception as e:
        log.info("试用计时写注册表失败（忽略）：%s", e)


def _trial_read_file(path):
    try:
        return _unpack_trial(Path(path).read_bytes())
    except Exception:
        return 0


def _trial_write_file(path, used):
    try:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(_pack_trial(used))
    except Exception as e:
        log.info("试用计时写文件失败（忽略）：%s", e)


def trial_used():
    """已用试用秒数：三处存储取最大（单处被删/重装不重置）。"""
    vals = [_trial_read_reg(),
            _trial_read_file(_TRIAL_JSON)]
    lap = _trial_localappdata()
    if lap is not None:
        vals.append(_trial_read_file(lap))
    return max(vals)


def trial_add(seconds):
    """累计试用秒数（三处都写）。返回累计后的总值。"""
    used = trial_used() + int(seconds)
    _trial_write_reg(used)
    _trial_write_file(_TRIAL_JSON, used)
    lap = _trial_localappdata()
    if lap is not None:
        _trial_write_file(lap, used)
    return used


def trial_remaining():
    return max(0, TRIAL_SECONDS - trial_used())


# ---------------------------------------------------------------- 总状态

def status():
    """→ ("activated", LicenseInfo) | ("trial", 剩余秒) | ("expired", None) | ("dev", None)"""
    if not FROZEN:
        return "dev", None
    info, had_record = _activated_info()
    if info is not None:
        return "activated", info
    if had_record:
        return "expired", None   # 激活过但密钥已过期/失效：不回落试用
    rem = trial_remaining()
    return ("trial", rem) if rem > 0 else ("expired", None)


def status_text():
    """设置页/徽章用的简短状态描述。"""
    st, info = status()
    if st == "dev":
        return "开发模式（不校验授权）"
    if st == "activated":
        if info.permanent:
            return "已激活：永久授权"
        try:
            left = (time.mktime(time.strptime(info.expire_date, "%Y-%m-%d"))
                    - time.time()) / 86400 + 1
            return f"已激活：有效期至 {info.expire_date}（剩 {max(0, int(left))} 天）"
        except Exception:
            return f"已激活：有效期至 {info.expire_date}"
    if st == "trial":
        m = info // 60
        return f"试用中：剩余 {m // 60} 小时 {m % 60} 分钟"
    return "未授权（试用已结束）"
