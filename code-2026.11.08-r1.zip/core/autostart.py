# -*- coding: utf-8 -*-
r"""开机自启（core/autostart.py，2026-10-25）

HKCU\Software\\Microsoft\\Windows\\CurrentVersion\\Run 写/删一个键
（`cahx-helper` → exe 路径）。写在 HKCU，普通权限即可，不弹 UAC。

只服务打包版：开发模式 enable() 会指向 python + boot.py，没有意义，
GUI 侧的开关在开发模式下置灰（见 gui.LoginTab._build_autostart_tool）。

自启后的形态：config `gui.show_main_on_start` 默认关 → 启动只显示桌面
宠物 + 托盘，不弹大主窗口（pet.py 桌面宠物形态）。
"""
from __future__ import annotations

import logging
import sys
import winreg

log = logging.getLogger("gui")

RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
VALUE_NAME = "cahx-helper"


def is_frozen() -> bool:
    return bool(getattr(sys, "frozen", False))


def enabled() -> bool:
    """当前是否已登记开机自启。"""
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as k:
            winreg.QueryValueEx(k, VALUE_NAME)
            return True
    except OSError:
        return False


def enable() -> bool:
    """登记开机自启（打包版 exe 路径）。成功返回 True。"""
    if not is_frozen():
        log.warning("开发模式不登记开机自启（打包版才有效）")
        return False
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0,
                            winreg.KEY_SET_VALUE) as k:
            winreg.SetValueEx(k, VALUE_NAME, 0, winreg.REG_SZ,
                              f'"{sys.executable}"')
        log.info("已开启开机自启：%s", sys.executable)
        return True
    except OSError:
        log.exception("写入开机自启注册表失败")
        return False


def disable() -> bool:
    """取消开机自启。成功（或本就没登记）返回 True。"""
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0,
                            winreg.KEY_SET_VALUE) as k:
            winreg.DeleteValue(k, VALUE_NAME)
        log.info("已关闭开机自启")
        return True
    except FileNotFoundError:
        return True
    except OSError:
        log.exception("删除开机自启注册表失败")
        return False
