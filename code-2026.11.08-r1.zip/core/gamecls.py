"""门派（职业）数据 + 角色门派徽标自学习识别。

背景（用户 2026-10-12）：
- 账号的「职业」从 3 个分类（输出/封印/奶妈）升级为游戏实际的 10 个门派；
- 任务侧的差异化操作仍按**分类**走（db.role），所以选了门派就自动映射分类；
- 进入游戏在"确认角色/信息页"时，希望靠角色名旁边的**门派徽标**自动推算门派。

为什么是"自学习"而不是对官网图标做模板匹配：
- 实测（debug/ 下对照实验）游戏内徽标是粉色/蓝色系小圆徽（信息页 ~22px、
  角色页 ~15px），官网美术图标是橙金色画风，直方图相关性 ≈ 0、形状 IoU 无
  判别力——**画风不同，直接匹配官网图标不可行**；
- 因此沿用 core/charfp 的路线：db 里**指定了门派**的角色，在读到其信息页/
  角色页时把徽标裁剪存进 `data/class_fp/<角色名>.png` 当样本；之后识别别的
  角色时与样本比对（归一化 HSV 直方图相关性 + 灰度模板匹配取平均），足够像
  就推断为同一门派并写回 db。多开小号常与主号同门派——每个门派标一次即可。
- 相似度不达标（首见门派 / 徽标被遮挡 / 截图异常）→ **不动 db**，log
  WARNING + 存图 debug/unknown/ 供核对（AGENTS.md「识别不了就报告」铁律）。

标定说明（单样本，2026-10-12）：徽标区域是从用户提供的截图测得的，两个检测点：
- 信息页（405x720 客户区）：名字行（INFO_NAME_REGION x=235 起）左侧的圆徽，
  区域约 (204, 4, 24, 24)；再往左就是头像边缘，不能再宽。
- 角色页（踏入长安后的角色列表）：条目名字行中心下方 +21px、x 81..96 处的
  小圆徽（debug/acc2_char.png 实测两张卡一致）。
实机若发现裁偏，跑 `python -m core.gamecls --probe <整屏截图>` 核对。
"""
import logging
from pathlib import Path

import cv2
import numpy as np

from core.imgio import imread, imwrite
from core.paths import DATA_DIR, DEBUG_DIR

log = logging.getLogger("gamecls")

# ---------------------------------------------------------------------------
# 门派表（来源 doc/技能图鉴/门派技能.md，10 门派、职责四大类；
# 分类映射沿用项目原三分类：输出 / 封印 / 奶妈）
# ---------------------------------------------------------------------------
CLASSES = {
    # 物理输出
    "弈剑": "输出",
    "唐门": "输出",
    "不良司": "输出",
    "高老庄": "输出",
    # 法术输出
    "龙宫": "输出",
    # 治疗辅助
    "普陀": "奶妈",
    "古灵": "奶妈",
    # 封印控制
    "青丘": "封印",
    "九玄": "封印",
    "广寒": "封印",
}

# 官网美术图标（白图形 + 米色圆底）：仅给 GUI 展示/文档用，**不用于匹配**
ICONS_DIR = Path("doc") / "技能图鉴" / "icons" / "门派"

# 徽标裁剪区（405x720 客户区坐标，单样本标定）
INFO_BADGE_REGION = (204, 4, 24, 24)      # 信息页：名字行左侧圆徽
ENTRY_BADGE_X = (81, 96)                  # 角色页：徽标 x 固定 81..96
ENTRY_BADGE_DY = (13, 28)                 # 相对名字行 OCR 中心 y 的偏移

FP_DIR = DATA_DIR / "class_fp"            # 徽标样本：data/class_fp/<角色名>.png

# 判定闸（charfp 同款思路：宁可不判，不能判错）
SCORE_MIN = 0.92        # 与样本的相似度下限
MARGIN_MIN = 0.06       # 领先"不同门派最好样本"的差距下限

_last_report = {}       # {角色名: ts} 避免同一窗口反复刷 WARNING（外部可清）


def role_of(cls):
    """门派 → 任务分类（未知门派返回 None）。"""
    return CLASSES.get(cls)


def badge_from_info_screen(screen):
    """信息页整屏截图 → 徽标裁剪（BGR）；截图异常返回 None。"""
    if screen is None or getattr(screen, "size", None) is None:
        return None
    h, w = screen.shape[:2]
    x, y, bw, bh = INFO_BADGE_REGION
    if w < x + bw or h < y + bh:
        return None
    return screen[y:y + bh, x:x + bw].copy()


def badge_from_entry_screen(screen, name_cy):
    """角色页整屏截图 + 名字行中心 y → 徽标裁剪；越界返回 None。"""
    if screen is None:
        return None
    h, w = screen.shape[:2]
    x0, x1 = ENTRY_BADGE_X
    y0, y1 = name_cy + ENTRY_BADGE_DY[0], name_cy + ENTRY_BADGE_DY[1]
    if y0 < 0 or y1 > h or x1 > w:
        return None
    return screen[y0:y1, x0:x1].copy()


def _signature(badge):
    """徽标 → (HSV 直方图, 灰度图)。归一化到 24x24、圆形掩码去四角背景。"""
    if badge is None or badge.size == 0:
        return None, None
    b = cv2.resize(badge, (24, 24), interpolation=cv2.INTER_AREA)
    mask = np.zeros((24, 24), np.uint8)
    cv2.circle(mask, (12, 12), 11, 255, -1)
    hsv = cv2.cvtColor(b, cv2.COLOR_BGR2HSV)
    hist = cv2.calcHist([hsv], [0, 1, 2], mask, [12, 4, 4],
                        [0, 180, 0, 256, 0, 256]).flatten()
    n = hist.sum()
    hist = hist / n if n > 0 else hist
    gray = cv2.cvtColor(b, cv2.COLOR_BGR2GRAY)
    return hist, gray


def _similarity(a_badge, b_badge):
    """两枚徽标的相似度 = 直方图相关性 + 灰度模板匹配的均值（各 0~1）。"""
    ha, ga = _signature(a_badge)
    hb, gb = _signature(b_badge)
    if ha is None or hb is None:
        return 0.0
    hist = cv2.compareHist(ha, hb, cv2.HISTCMP_CORREL)
    hist = max(0.0, float(hist))
    try:
        tm = cv2.matchTemplate(ga, gb, cv2.TM_CCOEFF_NORMED)[0][0]
    except cv2.error:
        return 0.0
    tm = max(0.0, float(tm))
    return 0.5 * hist + 0.5 * tm


def _fp_path(character):
    safe = "".join(c for c in character if c not in '\\/:*?"<>|').strip()
    return FP_DIR / f"{safe}.png"


def learn(character, badge, cls):
    """把角色 + 门派 的徽标存为样本（db 里指定了门派时由 observe 自动调用）。"""
    if not character or badge is None or badge.size == 0 or not cls:
        return False
    try:
        FP_DIR.mkdir(parents=True, exist_ok=True)
        imwrite(_fp_path(character), badge)
        log.info("已存 %s 的门派徽标样本（门派=%s），可供同门派小号自动识别",
                 character, cls)
        return True
    except Exception:
        log.exception("存门派徽标样本失败：%s", character)
        return False


def _cls_of(character, accounts):
    """从账号列表里查角色的门派（accounts: db.list_accounts() 结果）。"""
    for a in accounts or []:
        if a.get("character") == character:
            return a.get("cls") or ""
    return ""


def usable_sample_count(accounts):
    """可用于比对的样本数（有徽标文件、且对应账号在库里指定了门派）。

    只为把"冷启动：一个样本都没有"和"有样本但相似度不达标"两种情况在日志里
    分开——两者的处理办法完全不同（前者需要先去账号编辑里指定一个门派）。
    """
    n = 0
    try:
        paths = FP_DIR.glob("*.png") if FP_DIR.exists() else []
        for p in paths:
            if _cls_of(p.stem, accounts):
                n += 1
    except Exception:
        return 0
    return n


def classify(badge, accounts):
    """徽标 → (门派 or None, 最高分)。与全部样本比对，过双闸才返回门派。"""
    if badge is None or badge.size == 0:
        return None, 0.0
    samples = []
    for p in sorted(FP_DIR.glob("*.png")):
        im = imread(p)
        if im is None:
            continue
        cls = _cls_of(p.stem, accounts)
        if not cls:
            continue          # 没标门派的样本当不了老师
        samples.append((p.stem, cls, im))
    if not samples:
        return None, 0.0
    scored = [( _similarity(badge, im), stem, cls)
              for stem, cls, im in samples]
    scored.sort(reverse=True)
    top_score, top_stem, top_cls = scored[0]
    best_other = max((s for s, _stem, c in scored if c != top_cls),
                     default=0.0)
    if top_score < SCORE_MIN:
        return None, top_score
    if top_score - best_other < MARGIN_MIN:
        return None, top_score
    log.info("徽标识别：%s → 门派 %s（相似度 %.2f，领先 %.2f）",
             top_stem, top_cls, top_score, top_score - best_other)
    return top_cls, top_score


def observe(character, badge, accounts, account_id=None):
    """信息页/角色页读到角色后调用：学习（已标门派）或识别（未标门派）。

    返回 (cls or None, 已写回db?)。识别成功且与 db 不同（或 db 为空）时写回
    `cls` 与映射后的分类 `role`。
    """
    if not character or badge is None or badge.size == 0:
        return None, False
    mine = None
    for a in accounts or []:
        if a.get("character") == character:
            mine = a
            break
    if mine is None:
        return None, False
    cur = mine.get("cls") or ""
    if cur:
        learn(character, badge, cur)
        return cur, False
    # 未指定门派：尝试识别
    cls, score = classify(badge, accounts)
    if cls:
        try:
            from core import db
            db.update_account(mine["id"], cls=cls, role=CLASSES.get(cls, mine.get("role") or "输出"))
            log.info("账号「%s」门派自动识别为 %s（分类 %s），已写回账号库",
                     character, cls, CLASSES.get(cls))
            learn(character, badge, cls)
            return cls, True
        except Exception:
            log.exception("写回自动识别的门派失败：%s", character)
            return cls, False
    # 识别不了：报告但不刷屏（同一角色一次进程只报一次）
    if _last_report.get(character) != True:
        _last_report[character] = True
        try:
            DEBUG_DIR.mkdir(parents=True, exist_ok=True)
            imwrite(DEBUG_DIR / "unknown" / f"class_{character}.png", badge)
        except Exception:
            pass
        n = usable_sample_count(accounts)
        if n == 0:
            # 冷启动：从没在账号编辑里指定过门派 → 没有任何"老师样本"可比对。
            # 这不是识别失败，而是还没开张，提示要具体到能直接照做。
            log.warning("问题：门派样本库为空（data/class_fp 下 0 个可用样本），"
                        "无法自动识别「%s」的门派。请到账号页编辑**任意一个**角色，"
                        "在「职业（门派）」下拉里选好门派——下一轮登录会自动学习它"
                        "的徽标样本，同门派的小号随后即可自动识别", character)
        else:
            log.warning("问题：角色「%s」的门派徽标识别不了（与 %d 个可用样本比对，"
                        "最高相似度 %.2f 不达标），本次不改动职业；可在账号编辑里"
                        "手动指定门派，下轮登录会自动学习它的徽标", character, n, score)
    return None, False


def main(argv=None):
    """诊断入口：`python -m core.gamecls` 列样本；--probe <图> <cy> 看裁剪。"""
    import argparse
    ap = argparse.ArgumentParser(description="门派徽标样本库诊断")
    ap.add_argument("--list", action="store_true", help="列出现有样本")
    ap.add_argument("--probe", nargs=2, metavar=("截图", "名字行中心y"),
                    help="按角色页标定裁徽标并存 debug/ 检查")
    ap.add_argument("--clear", action="store_true", help="清空样本库")
    args = ap.parse_args(argv)
    if args.clear:
        if FP_DIR.exists():
            for p in FP_DIR.glob("*.png"):
                p.unlink()
            print(f"已清空 {FP_DIR}")
        return 0
    if args.probe:
        im = imread(args.probe[0])
        if im is None:
            print("读图失败", args.probe[0])
            return 1
        badge = badge_from_entry_screen(im, int(args.probe[1]))
        if badge is None:
            print("徽标裁剪越界")
            return 1
        out = DEBUG_DIR / "_cls_probe.png"
        imwrite(out, badge)
        print("已存", out)
        return 0
    FP_DIR.mkdir(parents=True, exist_ok=True)
    from core import db as _db
    accs = {a["character"]: a for a in _db.list_accounts()}
    print(f"样本目录 {FP_DIR}")
    for p in sorted(FP_DIR.glob("*.png")):
        acc = accs.get(p.stem)
        cls = (acc or {}).get("cls") or "(未指定)"
        print(f"  {p.stem}  门派={cls}")
    print(f"门派表：{CLASSES}")
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main(sys.argv[1:]))
