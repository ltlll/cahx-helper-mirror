"""角色名「区域指纹」：信息页名字行裁剪图的像素级比对（免 OCR 快通道）。

背景：定时任务触发前的窗口配对（login.preflight_clients）要逐窗口读
"当前登录角色"，原实现全靠 OCR——名字行 1~2 次 + 背包"整理"等待轮询，
每窗口 2~3 次 OCR ≈ 2~3s。而名字行是**固定位置、固定内容的美术字**：
同一角色每次截出来几乎逐像素一致，完全可以先做一次 <5ms 的像素比对，
比对不上再退回 OCR（顺带把确认过的名字指纹存档，下次就快了）——
这就是"指纹自学习"：OCR 只在第一次/画面变化时付一次钱。

指纹 = 名字行裁剪图经 **Otsu 自适应二值化**后的文字掩码（uint8 0/255）。

- 为什么不直接比灰度图：信息页面板可能半透明，背后的游戏画面会透过来，
  灰度相关系数会被背景变化拖低；二值化后只留文字笔画，天然免疫背景。
- 为什么用 IoU（交并比）而不用相关系数：掩码是稀疏的 0/1 图，IoU 语义
  直接（笔画重合度），且对亮度/对比度的线性变化完全不敏感。
- 防误配的关键一道闸：**文字像素占比必须落在 [INK_MIN, INK_MAX]**——
  两个"恰好都没字"的空白区域（比如区域被别的弹窗盖住）如果都接近全黑，
  IoU 会虚高，会把两个不同账号的窗口判成同一个角色（= 顶号事故）。
  占比闸 + 笔画差异双保险后，误配概率可忽略；漏配（分数不够）只会
  退回 OCR 多花 1 秒，不会出错——**宁可慢，不可配错**。

指纹存 `data/char_fp/<角色名>.png`（按角色名一一对应；/data/ 不进 git）。
自检：python debug/_verify_charfp.py
维护：python -m core.charfp --list / --drop <角色名> / --clear

防「判错被固化」（2026-10-12）
-----------------------------
上面三道闸防的是"两个指纹互相混淆"，**防不了"指纹本身就存错了"**：写指纹
那一步是 `OCR 读名字 → _match_character 模糊匹配(相似度阈值) → save_fp`，
这一步判错的话，存下来的就是"别的角色名 + 本人的笔画"；而这个错指纹之后
会**稳定高分命中**，指纹命中路径又完全不经过 OCR——自学习把一次偶发错误
固化成了永久错误（后果 = `_pair` 绑错账号 = 顶号/任务跑错账号）。

所以引入**对账（audit）**：
- `mark_saved`：刚存下的指纹标记为 fresh → **下次使用前必须 OCR 对账一次**
  （把错误存活期从"永久"压到"最多 1 次"）；
- `mark_hit`：每次命中记数，每 `AUDIT_EVERY` 次强制对账一次；
- 对账一致 → `audit_ok`（计数清零）；不一致 → `invalidate`（**删指纹文件**，
  下次重新 OCR 学习）；OCR 读不出 → `mark_audit_due`（不判决、下次再验）。
对账只多付 1 次 OCR（每 5 次命中 / 每个新指纹 1 次），换的是"错指纹活不过一次
使用"。开关见 `AUDIT_EVERY`（设 0 = 只保留"首用必验"，不再周期性对账）。
"""
import json
import logging
import re

import cv2
import numpy as np

from core.imgio import imread, imwrite
from core.paths import DATA_DIR

log = logging.getLogger("charfp")

FP_DIR = DATA_DIR / "char_fp"
THRESHOLD = 0.80     # IoU >= 此值才可能判"同一角色"
MARGIN = 0.10        # 最高分需领先第二名至少这么多（两个指纹都高分 = 分不清 → 不判）
INK_MIN = 0.02       # 文字像素占比下限（低于此 = 区域里基本没字，不可比）
INK_MAX = 0.55       # 上限（高于此 = 二值化极性反了/区域被大面积覆盖，不可比）
AUDIT_EVERY = 5      # 每 N 次指纹命中强制 OCR 对账一次（0 = 不做周期性对账）

# ---------------------------------------------------------------- 对账状态
# character -> {"hits": 距上次对账的命中次数, "fresh": 刚存下/待重验（下次命中必对账）}
#
# ⚠️ **必须落盘**（`FP_DIR/_audit.json`）：一轮里每个角色通常只被读 1 次
# （一个账号一个窗口），而两轮之间任务管家会重启——若只留内存态，`fresh`
# 一重启就没了，"首用必验"几乎永远不会触发（只有同一轮出现两个同名角色
# 才碰上）。落盘后每次新学的指纹**在下一轮首次被使用时**必被对账一次，
# 这才是"错指纹活不过一次使用"的真正保证。文件极小（几行 JSON）。
_STATE: dict = {}
_LOADED_FOR = None   # 已载入状态的 FP_DIR（测试会替换 FP_DIR，按目录重载）


def _state_path():
    return FP_DIR / "_audit.json"


def _ensure_loaded():
    """首次访问或 FP_DIR 变化时，从 `_audit.json` 载入对账状态（并清掉已失效条目）。"""
    global _LOADED_FOR
    d = str(FP_DIR)
    if _LOADED_FOR == d:
        return
    _STATE.clear()
    _LOADED_FOR = d
    try:
        p = _state_path()
        if p.exists():
            data = json.loads(p.read_text(encoding="utf-8"))
            for k, v in (data or {}).items():
                if fp_path(k).exists():          # 指纹已被删/作废 → 状态一并丢弃
                    _STATE[str(k)] = {"hits": int(v.get("hits", 0)),
                                      "fresh": bool(v.get("fresh", False))}
    except Exception as e:
        log.debug("对账状态读取失败（忽略，按空状态处理）: %s", e)


def _persist():
    global _LOADED_FOR
    _LOADED_FOR = str(FP_DIR)
    p = _state_path()
    try:
        if not _STATE:
            if p.exists():
                p.unlink()
            return
        FP_DIR.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(_STATE, ensure_ascii=False), encoding="utf-8")
    except Exception as e:
        log.debug("对账状态写入失败（忽略，退化成内存态）: %s", e)


def mark_saved(character):
    """刚保存了指纹 → 标记"待首验"：**下次使用前必须 OCR 对账一次**。

    这是防"判错被固化"最关键的闸：存指纹那一步判错的话，错指纹会一直
    高分命中且不再经过 OCR；首用必验让它在第一次被使用时就被拆穿。
    """
    _ensure_loaded()
    _STATE[str(character)] = {"hits": 0, "fresh": True}
    _persist()


def mark_audit_due(character):
    """把该指纹重新标记为"下次命中必须对账"（本次对账无法判定时用，如 OCR 读不出）。"""
    _ensure_loaded()
    st = _STATE.setdefault(str(character), {"hits": 0, "fresh": False})
    st["fresh"] = True
    _persist()


def mark_hit(character) -> bool:
    """记一次指纹命中，返回本次**是否必须 OCR 对账**。"""
    _ensure_loaded()
    st = _STATE.setdefault(str(character), {"hits": 0, "fresh": False})
    st["hits"] += 1
    due = st["fresh"] or (AUDIT_EVERY > 0 and st["hits"] % AUDIT_EVERY == 0)
    st["fresh"] = False               # 首验只做一次
    _persist()
    return due


def audit_ok(character):
    """对账一致（OCR 读出同一个角色）：清零计数，指纹可信度恢复。"""
    _ensure_loaded()
    st = _STATE.setdefault(str(character), {"hits": 0, "fresh": False})
    st["hits"] = 0
    st["fresh"] = False
    _persist()


def invalidate(character, reason=""):
    """对账不一致 → **作废指纹**（删文件）：下一次重新 OCR 学习。返回是否删到文件。"""
    _ensure_loaded()
    p = fp_path(character)
    gone = False
    try:
        if p.exists():
            p.unlink()
            gone = True
    except Exception as e:
        log.warning("作废指纹失败（%s）: %s", character, e)
    _STATE.pop(str(character), None)
    _persist()
    log.warning("指纹作废：%s（%s）——%s %s，下次将重新 OCR 学习",
                character, reason or "对账不一致",
                "已删除" if gone else "未找到", p)
    return gone


def audit_state() -> dict:
    """当前对账状态快照（诊断/自检用）。"""
    _ensure_loaded()
    return {k: dict(v) for k, v in _STATE.items()}


def reset_state():
    """清空对账状态（含落盘文件）。指纹文件本身不动。"""
    global _LOADED_FOR
    _ensure_loaded()
    _STATE.clear()
    _LOADED_FOR = str(FP_DIR)          # 避免随后把刚删的文件又读回来
    try:
        p = _state_path()
        if p.exists():
            p.unlink()
    except Exception as e:
        log.debug("对账状态文件删除失败: %s", e)


def list_fps():
    """已存档的指纹：[(角色名, 字节数)]（运维/诊断用）。"""
    if not FP_DIR.exists():
        return []
    return sorted((p.stem, p.stat().st_size) for p in FP_DIR.glob("*.png"))


def _safe_name(character):
    """角色名 → 安全文件名（Windows 文件名非法字符替换为下划线）。"""
    return re.sub(r'[\\/:*?"<>|]', "_", (character or "").strip()) or "_"


def fp_path(character):
    return FP_DIR / (_safe_name(character) + ".png")


def text_mask(crop_bgr):
    """裁剪图 → (二值文字掩码, 文字像素占比)。 crop 无效返回 (None, 0.0)。

    名字是浅色美术字、背景较深：Otsu 取阈后若亮像素是少数派则它就是文字；
    若暗像素是少数派（极性相反，如深色字浅底）取反，保证"文字=少数派"。
    """
    if crop_bgr is None or getattr(crop_bgr, "size", 0) == 0:
        return None, 0.0
    gray = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2GRAY)
    _t, binimg = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    ratio = float(np.count_nonzero(binimg)) / binimg.size
    if ratio > 0.5:                     # 亮像素占多数 → 文字是暗的那部分
        binimg = cv2.bitwise_not(binimg)
        ratio = 1.0 - ratio
    return binimg, ratio


def save_fp(character, crop_bgr):
    """把确认过的名字行裁剪图存为该角色的指纹。成功返回 True。"""
    mask, ratio = text_mask(crop_bgr)
    if mask is None or not (INK_MIN <= ratio <= INK_MAX):
        log.debug("指纹未保存（%s）：文字占比 %.2f 不在 [%s, %s]",
                  character, ratio, INK_MIN, INK_MAX)
        return False
    try:
        FP_DIR.mkdir(parents=True, exist_ok=True)
        imwrite(str(fp_path(character)), mask)
        return True
    except Exception as e:
        log.warning("指纹保存失败（%s）: %s", character, e)
        return False


def _load_mask(character):
    p = fp_path(character)
    if not p.exists():
        return None
    # imgio.imread 固定按 BGR 三通道解码（兼容中文路径），存的是单通道掩码，
    # 读回来转灰度即还原 0/255（0/255 灰度↔BGR↔灰度是无损往返）
    mask = imread(str(p))
    if mask is None:
        return None
    return cv2.cvtColor(mask, cv2.COLOR_BGR2GRAY)


def match(crop_bgr, character):
    """裁剪图与该角色指纹的相似度（IoU 0~1）；无指纹/不可比返回 -1.0。"""
    ref = _load_mask(character)
    if ref is None:
        return -1.0
    mask, ratio = text_mask(crop_bgr)
    if mask is None or mask.shape != ref.shape:
        return -1.0
    if not (INK_MIN <= ratio <= INK_MAX):
        return -1.0
    inter = np.count_nonzero(cv2.bitwise_and(mask, ref))
    union = np.count_nonzero(cv2.bitwise_or(mask, ref))
    if union == 0:
        return -1.0
    return inter / union


def best_match(crop_bgr, characters):
    """与所有候选角色的指纹比对，返回 (角色名 或 None, 最高分)。

    命中需同时满足：
    - 最高分 >= THRESHOLD；
    - **领先第二名至少 MARGIN**——两个指纹都接近高分说明"分不清是谁"，
      绝不能猜（猜错 = 绑错号 = 任务跑错账号），退回 OCR 才是安全侧。
    """
    scores = sorted(((match(crop_bgr, ch), ch) for ch in characters), reverse=True)
    if not scores:
        return None, -1.0
    best_s, best = scores[0]
    if best_s < THRESHOLD:
        return None, best_s
    if len(scores) > 1 and best_s - scores[1][0] < MARGIN:
        log.info("指纹比对模糊（第1 %.2f / 第2 %.2f），放弃猜测退回 OCR",
                 best_s, scores[1][0])
        return None, best_s
    return best, best_s


# ---------------------------------------------------------------- 运维命令行
def _main(argv=None):
    """指纹维护：--list / --drop <角色名> / --clear。

    怀疑指纹判错时：`--list` 看有哪些、`--drop <角色名>` 单个作废、
    `--clear` 全部作废（回到纯 OCR，下轮自动重新学习）。不用改代码/配置。
    """
    import argparse
    ap = argparse.ArgumentParser(prog="python -m core.charfp",
                                 description="角色名指纹维护（目录 %s）" % FP_DIR)
    ap.add_argument("--list", action="store_true", help="列出已存档指纹")
    ap.add_argument("--drop", metavar="角色名", help="删除指定角色的指纹")
    ap.add_argument("--clear", action="store_true", help="删除全部指纹（回到纯 OCR）")
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(message)s")

    if a.clear:
        n = 0
        for name, _size in list_fps():
            n += 1 if invalidate(name, "手动 --clear") else 0
        reset_state()                     # 连对账状态一起清掉，回到全新状态
        print("已删除 %d 个指纹（目录 %s）" % (n, FP_DIR))
        return 0
    if a.drop:
        ok = invalidate(a.drop, "手动 --drop")
        print(("%s：已删除 %s" % (a.drop, fp_path(a.drop))) if ok
              else ("%s：没有找到指纹文件（%s）" % (a.drop, fp_path(a.drop))))
        return 0
    rows = list_fps()
    print("指纹目录：%s" % FP_DIR)
    if not rows:
        print("（空——所有窗口都会走 OCR 识别）")
        return 0
    for name, size in rows:
        print("  %-24s %6d 字节" % (name, size))
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
