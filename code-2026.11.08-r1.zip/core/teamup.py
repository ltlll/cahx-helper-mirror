"""跨账号协同（5开组队）的进程内状态协调器。

GUI 并行执行任务时每账号一个线程，所有线程在同一进程内，因此用单例
协调器做同步，不走文件/网络：

- GUI 点"开始执行"时 begin(accounts) 重置本轮状态；
- 各账号跑到组队任务（必须是任务列表最后一个）时 arrive() 报到——
  到达即视为该号的其它任务已结束（成功或失败都算）；
- 全员到齐后队长端发邀请（start_round），队员端等邀请（wait_invite）
  接受后 mark_accepted，队长按**队伍人数 ≥ min_members**（组队任务 3 人 /
  含打地鼠 2 人）判定并 set_result——成员可能是别人登录的号，不逐个核对名字；
- team_success 记录最终组队结果，以后的"日常副本"类任务据此决定是否执行。

命令行 main.py 不调 begin()，协调器为空，组队任务会直接跳过。
"""
import logging
import random
import threading
import time

log = logging.getLogger("teamup")

# 全员到齐的最长等待（账号间任务耗时有差，宗门链约 10 分钟，留足余量）
READY_TIMEOUT = 1200
# 但有"进展"（未到达账号正在跑的任务名发生变化）时再顺延 READY_TIMEOUT，
# 总等待不超过这个硬上限。
#
# 2026-10-17 事故（run c03345）：队长 4 号被跑商拖了 17.5 分钟，6 号 06:17 先
# 到等齐点、600s 窗口在 06:27 就到点 → 被判"未确认离队"移出本轮组队，
# haishi/liudao/zhongkui 三项全判负（3 号同）；而 5/7 号到得晚反而赶上。
# 卡死不会自己好，所以不取消超时，只认"任务有推进"这一个顺延理由。
#
# 2026-10-30 事故（补跑轮）：6 号前一轮已跑完大部分任务，16:32 就到等齐点；
# 4/5 号这一轮从零开始，17:13 才到——差 41 分钟，正好越过 40 分钟硬上限 60 秒，
# zudui 放弃 → haishi/liudao/zhongkui 三个副本在 4 个号上全判负（12 项）。
# 顺延逻辑本身没问题（4/5 号的任务名一直在变，窗口一路顺延到顶），纯粹是上限
# 太小。正常轮各号进度差约 10~15 分钟，但补跑/重登轮动辄 40+ 分钟，故放到 60。
# 卡死的号 busy 不变、不会被顺延，所以放宽上限不会让卡死拖住全队。
READY_TIMEOUT_MAX = 3600
# 空闲即开组：有账号还没到达组队任务，但**其余未到达者都处于空闲状态**
# （不在跑任务、不在战斗/副本/家园，即任务已结束只是还没走到组队任务，
# 如组队任务失败重试中）时，等满这么久（秒）就开组，不再空等它。
IDLE_OPEN_WAIT = 20


class TeamCoordinator:
    def __init__(self):
        self._lock = threading.Lock()
        self._invite_event = threading.Event()
        self._finish_event = threading.Event()
        self._dungeon_event = threading.Event()
        self.expected = {}      # acc_id -> account 记录（含 character 名）
        self.captain_id = None
        self.ready = set()      # 已到达组队任务的账号
        self.team_left = set()  # 手动组队：已确认离队的队员（队长发邀请的前置）
        self.invite_round = 0
        self.invite_ts = 0.0    # 本轮邀请播报的墙钟时间（队员端打点用：算"播报→看到弹窗"）
        self.accepted = {}      # acc_id -> 已接受的轮次
        self.sensed = {}        # acc_id -> 已感知到邀请（点过"接受"按钮/浮标）的轮次。
                                # 用户规则 2026-10-13：队长发出邀请后应静默等"4 名队员
                                # 全部完成接收邀请动作"，再把资源交还队长判定是否组齐——
                                # accepted 只在弹出邀请弹窗并点掉后才上报，漏弹窗的号永远
                                # 不填；sensed 由队员端"见到邀请/点了接受/点了组队浮标"即上报，
                                # 队长据此判"感知完成"（不必等满 INVITE_WAIT 空转截图）
        self.result = None      # None=未定局 / True=组队成功 / False=失败
        self.dungeons = {}      # 副本名 -> {"round":0, "ready":{}, "done":None}
        self.lenient = False    # 宽容轮（地鼠轮）：队长被顶随机改选、邀不进队的可放弃
        self.captain_fail = {}  # acc_id -> 本号当队长时组队副本任务失败次数（自动改选用）
        self._reteam_pending = False  # 队长端失败后请求"下个组队副本任务重建队伍"
        self.min_members = 3    # 组队人数下限（组队任务 3 人 / 含打地鼠 2 人）
        self.extra_names = []   # 手输的队外队员角色名（手动组队的邀请目标）
        self.team_members = None  # 参与组队的账号 id 集合（None=全部 expected）
        self.team_mode = "auto"  # 本轮组队方式（auto=一键组队 / manual=逐个邀请）：
                                 # zudui 定稿后写入，供 dishu 在帮会领地等待期间
                                 # 用同样的方式补邀没进队的队员（用户规则 2026-10-12）
        self._leave_epoch = 0   # 离队确认轮次：队长每次发起整队 +1（旧确认作废，
                                # 解散重组时队员据此知道要重新离队，2026-10-12）
        self._settling = {}     # acc_id -> 标记时刻：正在战斗/场景复位中
                                #（用户规则：此时不能组队操作，等待不计入超时）
        self._busy = {}         # acc_id -> 正在跑的任务名（None=空闲）。
                                # 用户规则 2026-10-14：队长不必干等所有号走到
                                # 组队任务——只要没到达的号都在"空闲"（任务已
                                # 结束/未开始跑），就说明它们下一秒就到，可以
                                # 直接开组；有人真卡在任务里才继续等。

    def begin(self, accounts, lenient=False, min_members=None, extra_names=None,
              team=None):
        """一轮并行执行开始时重置状态。accounts: 实际能跑到任务的账号
        （hwnd 解析失败的账号必须提前剔除，否则会永远等它到达）。
        lenient=True（地鼠轮，本轮任务含 dishu）：队长被顶号时随机改选新队长
        而不是直接判负；组队多轮邀不进的人可由队长端放弃（减员放过）。
        min_members：组队人数下限（组队任务 3 人 / 含打地鼠 2 人，用户规则）。
        extra_names：手输的队外队员角色名（手动组队按名字逐个邀请）。
        team：组队编制 {"captain": id, "members": [id...]}（开始任务向导/
        一条龙方案）；给了 members 就把参与集收窄到"队长+队员"——不参与组队
        的账号只跑单人任务，不会因为永远不到组队任务把队长端卡在等待上。"""
        with self._lock:
            self.expected = {a["id"]: a for a in accounts}
            self.team_members = None
            if team and team.get("members") is not None:
                ids = set(team["members"])
                if team.get("captain") is not None:
                    ids.add(team["captain"])
                self.team_members = ids
                self.expected = {k: v for k, v in self.expected.items()
                                 if k in ids}
            self.captain_id = None
            if team and team.get("captain") is not None:
                if team["captain"] in self.expected:
                    self.captain_id = team["captain"]
                else:
                    # 指定的队长窗口失效/未登录（已被剔除出参与集）：本轮不组队。
                    # zudui 见 captain_id 为 None 会跳过组队，不至于干等。
                    # 注意：账号库不再有队长标记（2026-10-11 删除），没有"库内队长"可回退。
                    log.warning("本轮无法组队：指定的队长 id=%s 不在可参与组队的账号里"
                                "（窗口失效或未登录）", team["captain"])
            self.min_members = int(min_members or 3)
            self.team_mode = str((team or {}).get("mode") or "auto").strip().lower()
            self.extra_names = [str(n).strip() for n in (extra_names or [])
                                if str(n).strip()]
            self.ready = set()
            self.team_left = set()
            self._leave_epoch = 0
            self._settling = {}
            self.invite_round = 0
            self.invite_ts = 0.0
            self.accepted = {}
            self.sensed = {}
            self.result = None
            self.lenient = lenient
            self.captain_fail = {}
            self._reteam_pending = False
            self._invite_event.clear()
            self._finish_event.clear()
            self.dungeons = {}  # name -> {"round":0, "ready":{}, "done":None}，每个副本独立
            self._dungeon_event.clear()
        log.info("组队协调器已重置：%d 个参与账号，队长 id=%s，人数下限 %d，"
                 "组队方式 %s，队外队员 %s", len(self.expected), self.captain_id,
                 self.min_members, self.team_mode, self.extra_names or "无")

    def set_team_mode(self, mode):
        """记录本轮实际使用的组队方式（zudui 定稿后写入）：dishu 在帮会领地
        等待任务开始期间要按**同样的方式**补邀没进队的队员（用户规则 2026-10-12）。"""
        mode = str(mode or "auto").strip().lower()
        with self._lock:
            self.team_mode = mode
        return mode

    @property
    def begun(self):
        with self._lock:
            return bool(self.expected)

    @property
    def team_success(self):
        """组队最终结果（None=未定局）。以后的副本任务据此决定是否执行。"""
        with self._lock:
            return self.result

    @property
    def known_names(self):
        """已知的"应该在队里"的角色名：参与账号的角色名 + 手输队外队员名。

        队伍人数判定与手动组队的邀请名单都用它。注意成员可能是别人登录的号
        （不在名单里），所以最终人数以队伍面板识别到的行数为准（见 zudui
        的 _team_status），名单只用于邀请和"缺席者"计算。
        """
        with self._lock:
            names = [a.get("character") for a in self.expected.values()]
            return names + [n for n in self.extra_names if n not in names]

    def arrive(self, acc_id):
        with self._lock:
            self.ready.add(acc_id)
            log.info("账号 id=%s 已到达组队任务（%d/%d）",
                     acc_id, len(self.ready), len(self.expected))

    def drop(self, acc_id):
        """减员：账号提前退出本轮（被顶号等线程中止场景），从参与集移除，
        其余账号照常组队（wait_all_ready/wait_accepted 按缩减后的 expected 判定）。

        队长被顶号时：宽容轮（lenient，地鼠轮）从剩余账号**随机改选新队长**
        （新队长的线程在 zudui 队员等待里发现 captain_id 变成自己后接管发邀请）；
        非宽容轮维持原行为——无人发起组队，直接判负（result=False）并唤醒队员端，
        避免干等 MEMBER_GIVEUP。
        """
        with self._lock:
            if acc_id not in self.expected:
                return
            self.expected.pop(acc_id)
            self.ready.discard(acc_id)
            remaining = len(self.expected)
            if self.result is None and acc_id == self.captain_id:
                if self.lenient and remaining >= 2:
                    self.captain_id = random.choice(list(self.expected))
                    log.warning("队长 id=%s 退出本轮（被顶号），随机改选 id=%s（%s）为队长"
                                "（剩余 %d 个）", acc_id, self.captain_id,
                                self.expected[self.captain_id].get("character"),
                                remaining)
                    return
                self.result = False
                self._invite_event.set()
                self._finish_event.set()
                log.warning("队长 id=%s 退出本轮（被顶号），组队直接判负", acc_id)
            else:
                log.warning("账号 id=%s 退出本轮组队协调（剩余 %d 个）",
                            acc_id, remaining)

    def rejoin(self, acc):
        """顶号重登成功后归队：把账号放回参与集（不动 ready/accepted/result，
        重登成功的账号会重跑被中断的任务，自己重新 arrive/等待信号）。"""
        with self._lock:
            if acc["id"] in self.expected:
                return
            self.expected[acc["id"]] = acc
            n = len(self.expected)
        log.info("账号 id=%s（%s）重登归队（当前 %d 个参与）",
                 acc["id"], acc.get("character"), n)

    def mark_task(self, acc_id, task_name):
        """汇报账号当前正在跑的任务名（None = 空闲：任务之间的间隔/已跑完/
        还没开始）。队长端的 wait_all_ready 据此判断"没到达的号是不是在忙"。

        用户规则 2026-10-14：卡死一个任务会把全部账号拖住（队长死等组队），
        所以未到达者只在**确实在跑任务**时才值得等；空闲即视为"马上就到"。
        """
        with self._lock:
            if task_name:
                self._busy[acc_id] = task_name
            else:
                self._busy.pop(acc_id, None)

    def busy_tasks(self):
        """快照：acc_id -> 正在跑的任务名（仅含在忙的账号）。"""
        with self._lock:
            return dict(self._busy)

    def wait_all_ready(self, check_stop=None, timeout=READY_TIMEOUT,
                       idle_wait=IDLE_OPEN_WAIT, hard_max=READY_TIMEOUT_MAX):
        """等全员到达组队任务。超时返回 False；check_stop 用于响应 GUI 停止。

        用户规则 2026-10-14（**空闲即开组**）：团队里任何一个号卡死在单人
        任务（如宗门链）里，都不能让其余号无限干等——宗门卡死曾让整队停滞
        50 分钟。规则：
        - 全员到达 → 立刻开组；
        - 有未到达者，但它**不在忙**（任务已结束/在等下一个任务的间隙，只是
          还没走到组队任务），且这个状态持续 idle_wait 秒 → 提前开组，把它
          从参与集里移除（drop），它到组队任务时见 result 已定直接跳过；
        - 未到达者**确实在跑任务**（busy）→ 继续等，最多等到 timeout
          （2026-10-14 从 45 分钟收紧到 10 分钟——卡死不会自己好）。

        2026-10-17（有进展就顺延）：只看"到点"会把**慢但没卡死**的账号误判成
        缺席——run c03345 里队长被跑商拖 17.5 分钟，先到的 3/6 号窗口到点被移出
        组队，三个组队任务全灭，而晚到的 5/7 号反而赶上。现在改成：只要未到达
        账号**正在跑的任务变了**（= 有推进，不是原地空转），就把窗口顺延
        timeout 秒，但总时长不超过 hard_max（默认 60 分钟；2026-10-30 从 40 分钟
        放宽，见 READY_TIMEOUT_MAX 注释）。
        """
        started = time.time()
        deadline = started + timeout
        hard_deadline = started + max(hard_max, timeout)
        idle_since = None
        last_log = 0.0
        last_extend_log = 0.0
        last_busy = None
        while time.time() < deadline:
            if check_stop:
                check_stop()
            now = time.time()
            with self._lock:
                if self.expected and len(self.ready) >= len(self.expected):
                    return True
                pending = {a for a in self.expected if a not in self.ready}
                busy = {a: self._busy.get(a) for a in pending}
            if not any(busy.values()):
                # 全部未到达者都空闲：它们在往组队任务走，稍等即可
                if idle_since is None:
                    idle_since = now
                    log.info("未到达组队任务的账号 %s 均空闲（不在跑任务），"
                             "%d 秒后就绪即开组", sorted(pending), idle_wait)
                elif now - idle_since >= idle_wait:
                    with self._lock:
                        idle_ids = {a for a in pending if a not in self._busy}
                        for a in idle_ids:
                            self.expected.pop(a, None)
                            self.ready.discard(a)
                        left = dict(self.expected)
                    for a in idle_ids:
                        log.warning("账号 id=%s（%s）未到达且空闲超过 %d 秒，"
                                    "移出本轮组队（它到组队任务时会跳过）",
                                    a, left.get(a, {}).get("character"), idle_wait)
                    return bool(self.expected)
            else:
                if idle_since is not None:
                    idle_since = None
                # 有进展就顺延：未到达账号"正在跑的任务"变了，说明它在推进
                # （不是卡死在同一个任务里），不能按到点把它踢出组队。
                if last_busy is not None and busy != last_busy:
                    new_deadline = min(now + timeout, hard_deadline)
                    if new_deadline > deadline + 1:
                        # 顺延本身不吵，但"每到达一个号就打一条"会刷屏——
                        # 每分钟最多播报一次即可（真正的等待进度靠下面那条）。
                        if now - last_extend_log > 60:
                            log.info("组队等待：未到达账号有进展（%s → %s），"
                                     "等待窗口顺延 %.0f 秒（总上限 %.0f 秒）",
                                     last_busy, busy, new_deadline - now,
                                     hard_deadline - started)
                            last_extend_log = now
                        deadline = new_deadline
                last_busy = dict(busy)
                if now - last_log > 30:
                    log.info("等待未到达组队任务的账号：%s（仍在跑任务）；"
                             "最长再等 %.0f 秒", busy, deadline - now)
                    last_log = now
            time.sleep(2)
        return False

    # ---- 手动组队：队员先离队，队长等全员离队后再发邀请 ----

    # settling 标记的陈旧上限：超过此时长未解除视为线程已死，不再为它顺延等待
    SETTLING_STALE = 1800

    def mark_settling(self, acc_id, busy):
        """标记账号正在战斗/家园/副本等场景中复位（暂时无法离队/组队）。
        用户规则 2026-10-12：此时要等待，且等待不算入超时时间。"""
        with self._lock:
            if busy:
                self._settling[acc_id] = time.time()
            else:
                self._settling.pop(acc_id, None)

    def begin_leave_round(self):
        """队长发起（重新）整队：旧离队确认全部作废，队员需重新离队确认。

        一键组队解散转手动组队时，队员仍挂在解散后的旧队伍里（队长离队后
        队伍不散、自动继位），旧的"已离队"确认已失效——不作废的话队长会
        立刻放行建队，向仍在旧队里的号发邀请根本到不了（2026-10-12 实测）。
        队员端在邀请等待循环里比对 leave_epoch()，变化即重新离队确认。
        """
        with self._lock:
            self._leave_epoch += 1
            self.team_left = set()
            n = self._leave_epoch
        log.info("离队确认第 %d 轮开始：所有队员需重新确认离队", n)

    def leave_epoch(self):
        """当前离队确认轮次（队员端据此判断是否要重新离队）。"""
        with self._lock:
            return self._leave_epoch

    def mark_team_left(self, acc_id):
        """队员确认已退出旧队伍（队长发邀请的前置条件）。"""
        with self._lock:
            self.team_left.add(acc_id)
        log.info("账号 id=%s 已确认离队（%d/%d）", acc_id,
                 len(self.team_left), len(self.expected))

    def wait_all_left(self, timeout=150, check_stop=None):
        """队长等全部队员确认离队（不含队长自己）。返回仍未确认的队员 id 集合
        （空集合 = 全员已确认）。

        用户规则 2026-10-12：有队员在战斗/家园/副本等场景中复位（settling）
        时**等待不计入超时**——deadline 随复位状态持续顺延，队员复位完离队
        后照常确认；仅当剩余未确认者都不在复位状态时才按 timeout 判超时。
        """
        deadline = time.time() + timeout
        last_log = 0.0
        while True:
            if check_stop:
                check_stop()
            now = time.time()
            with self._lock:
                pending = {a for a in self.expected
                           if a != self.captain_id and a not in self.team_left}
                if not pending:
                    return set()
                settling = {a for a, ts in self._settling.items()
                            if now - ts < self.SETTLING_STALE}
            busy = sorted(pending & settling)
            if busy:
                # 有队员正在战斗/场景复位：等待顺延（不计入超时）
                deadline = max(deadline, now + 30)
                if now - last_log > 30:
                    log.info("队员 %s 正在战斗/场景复位，等待其离队（不计入超时）",
                             busy)
                    last_log = now
            elif now >= deadline:
                with self._lock:
                    return {a for a in self.expected
                            if a != self.captain_id and a not in self.team_left}
            time.sleep(1)

    def drop_unconfirmed_left(self):
        """手动组队：把仍未确认离队的队员移出本轮（队长等待超时后调用——
        向仍在旧队伍的号发邀请根本到不了，浪费整轮）。返回被减员的账号列表。"""
        with self._lock:
            others = {a: acc for a, acc in self.expected.items()
                      if a != self.captain_id and a not in self.team_left}
            for acc_id in others:
                self.expected.pop(acc_id)
                self.ready.discard(acc_id)
        for acc in others.values():
            log.warning("账号 id=%s（%s）未确认离队，移出本轮组队",
                        acc["id"], acc["character"])
        return list(others.values())

    # ---- 队长端 ----

    def start_round(self):
        """发出一轮组队邀请，唤醒等待中的队员端。"""
        with self._lock:
            self.invite_round += 1
            self.invite_ts = time.time()   # 队员端据此打点"播报→看到弹窗"的延迟
            r = self.invite_round
            self._invite_event.set()
        log.info("第 %d 轮组队邀请已发出", r)
        return r

    def wait_accepted(self, timeout, check_stop=None):
        """等队员接受（不强制全员，超时后由队长自行校验队伍人数）。"""
        deadline = time.time() + timeout
        while time.time() < deadline:
            if check_stop:
                check_stop()
            with self._lock:
                n = sum(1 for a in self.expected
                        if self.accepted.get(a, 0) >= self.invite_round)
                if n >= len(self.expected) - 1:  # 队长自己不算
                    return True
            time.sleep(2)
        return False

    def set_result(self, ok):
        with self._lock:
            self.result = ok
            self._invite_event.set()   # 唤醒队员端退出
            self._finish_event.set()
        log.info("组队结果: %s", "成功" if ok else "失败")

    # ---- 队员端 ----

    def wait_invite(self, last_round, timeout, check_stop=None):
        """等新一轮邀请或组队结束。返回当前轮次（>last_round 表示有新邀请，
        等于 last_round 表示结束/超时）。"""
        deadline = time.time() + timeout
        while time.time() < deadline:
            if check_stop:
                check_stop()
            with self._lock:
                if self.result is not None:
                    return last_round
                if self.invite_round > last_round:
                    return self.invite_round
            time.sleep(1)
        with self._lock:
            return self.invite_round

    def mark_accepted(self, acc_id, round_):
        with self._lock:
            self.accepted[acc_id] = max(self.accepted.get(acc_id, 0), round_)
            # 点了接受必然也"感知到"了邀请：一并记 sensed（用户规则 2026-10-13）
            self.sensed[acc_id] = max(self.sensed.get(acc_id, 0), round_)

    def mark_sensed(self, acc_id, round_=None):
        """队员端"感知到被邀请"（见到邀请弹窗 / 点了接受 / 点了组队浮标）时上报。

        用户规则 2026-10-13：队长发出邀请后静默等"4 名队员全部完成接收邀请动作"，
        再独占资源判是否组齐。sensed 让队长不必靠"每 5 秒截图数人头"去猜队员有没有
        收到——队员感知到就主动打卡，队长可据此提前进入人数判定。
        round_ 缺省取当前邀请轮次（队员在收到轮次信号后立即上报）。"""
        with self._lock:
            r = self.invite_round if round_ is None else round_
            self.sensed[acc_id] = max(self.sensed.get(acc_id, 0), r)

    def current_round(self):
        """当前邀请轮次（手动组队：队员端接受弹窗后按此轮次上报）。"""
        with self._lock:
            return self.invite_round

    def accepted_round(self, acc_id):
        """该账号已接受的最新轮次（手动组队：队长端等指定队员接受）。"""
        with self._lock:
            return self.accepted.get(acc_id, 0)

    def in_current_team(self, acc_id):
        """本号是否在**当前轮**队伍里（接受过当前轮邀请，或本号就是队长）。

        2026-10-18 run 188ac5 教训：队长端失败改选重建队伍（第 2 轮邀请）
        后，被排除在重建名单外的号（4 号）线程还睡在队员等待里，读到的是
        **全队共享**的 dungeon_result——4 人队打完钟馗它也跟着记"完成"，
        实际根本没参战。副本结果=全队结果，参战资格必须单独核。
        """
        with self._lock:
            if acc_id == self.captain_id:
                return True
            return (self.invite_round > 0
                    and self.accepted.get(acc_id, 0) >= self.invite_round)

    def wait_all_sensed(self, timeout, check_stop=None):
        """队长静默等"全部参与队员都完成了接收邀请动作"（用户规则 2026-10-13）。

        返回 (ok, missing)：ok=True 表示除队长外全部 sensed 已追上当前邀请轮次；
        missing=还没打卡的账号角色名列表（超时未全员感知时用于日志）。

        这里刻意不截图、不判队伍人数——队员端感知是**主动打卡**（mark_sensed），
        队长在这一步只读内存状态，屏幕/OCR 资源全留给队员端感知邀请用
        （用户要求：这期间所有资源给队员，待 4 人接受完再把资源交还队长判定）。"""
        deadline = time.time() + timeout
        while True:
            if check_stop:
                check_stop()
            with self._lock:
                r = self.invite_round
                pending = [a["character"] for aid, a in self.expected.items()
                           if aid != self.captain_id
                           and self.sensed.get(aid, 0) < r]
            if not pending:
                return True, []
            if time.time() >= deadline:
                return False, pending
            time.sleep(0.2)

    # ---- 副本协同（海市蜃楼/六道法门/钟馗捉鬼等：按副本名独立状态，
    # 一个副本失败不影响其它副本继续） ----

    def _dungeon(self, name):
        return self.dungeons.setdefault(name, {"round": 0, "ready": {}, "done": None})

    def dungeon_start_round(self, name):
        """队长发起一轮副本挑战，唤醒等待中的队员端（去点"准备"）。"""
        with self._lock:
            d = self._dungeon(name)
            d["round"] += 1
            r = d["round"]
            self._dungeon_event.set()
        log.info("副本 %s 第 %d 轮挑战已发起", name, r)
        return r

    def dungeon_round(self, name):
        """该副本队长已发起的轮次数（队员端判定"队长根本没发起"用）。"""
        with self._lock:
            d = self.dungeons.get(name)
            return d["round"] if d else 0

    def dungeon_wait_round(self, name, last_round, timeout, check_stop=None):
        """队员端等新一轮挑战或该副本结束。返回当前轮次（>last_round 表示有新
        挑战，等于 last_round 表示结束/超时）。"""
        deadline = time.time() + timeout
        while time.time() < deadline:
            if check_stop:
                check_stop()
            with self._lock:
                d = self.dungeons.get(name)
                if d and d["done"] is not None:
                    return last_round
                if d and d["round"] > last_round:
                    return d["round"]
            time.sleep(1)
        with self._lock:
            d = self.dungeons.get(name)
            return d["round"] if d else last_round

    def dungeon_mark_ready(self, name, acc_id, round_):
        with self._lock:
            d = self._dungeon(name)
            d["ready"][acc_id] = max(d["ready"].get(acc_id, 0), round_)

    def dungeon_wait_ready(self, name, timeout, check_stop=None):
        """队长等队员点完"准备"（不强制全员，超时后自行继续）。"""
        deadline = time.time() + timeout
        while time.time() < deadline:
            if check_stop:
                check_stop()
            with self._lock:
                d = self.dungeons.get(name)
                if d:
                    n = sum(1 for a in self.expected
                            if d["ready"].get(a, 0) >= d["round"])
                    if n >= len(self.expected) - 1:  # 队长自己不算
                        return True
            time.sleep(1)
        return False

    def dungeon_finish(self, name, ok):
        with self._lock:
            d = self._dungeon(name)
            d["done"] = ok
            self._dungeon_event.set()
        log.info("副本结果: %s %s", name, "完成" if ok else "失败")

    def dungeon_result(self, name):
        with self._lock:
            d = self.dungeons.get(name)
            return d["done"] if d else None

    # ---- 队长自动改选（2026-10-13） ----

    def note_captain_fail(self, acc_id):
        """记一次"该号当队长时某组队副本任务失败"（自动改选排序用）。"""
        if acc_id is None:
            return
        with self._lock:
            self.captain_fail[acc_id] = self.captain_fail.get(acc_id, 0) + 1

    def failover_captain(self, reason, reteam=True):
        """队长端在某组队副本任务失败 → 改选新队长并请求重建队伍。

        2026-10-13：定时一条龙指定 captain=4 号，它在 liudao 前回城失败（点小
        地图连点两次都打不开场景选择面板），liudao/zhongkui 全队被"队长端失败"
        连锁判负；同批任务手动轮换成 3 号当队长即全过。故队长端失败时自动改选：
        挑"当队长失败次数最少"的其它账号（未失败过的优先，同等取 id 小的；这样
        不会又换回刚失败的那个号），并把组队结果重置为未定局 + 置重建队伍标记，
        让**下个组队副本任务**由新队长带队重建队伍后再打。

        reteam=False（2026-10-17）：队伍没散（进副本入口失败，谁都没进副本），
        改选后**本项当场重试**即可，不重置组队结果、不请求重建队伍——见
        `dungeon_captain_retry`。

        返回新队长 id；没有可换的号返回 None（调用方按原逻辑如实判负）。
        """
        with self._lock:
            cur = self.captain_id
            cands = [a for a in self.expected if a != cur]
            if not cands:
                return None
            fresh = [a for a in cands if self.captain_fail.get(a, 0) == 0]
            pool = fresh or cands
            pool.sort(key=lambda a: (self.captain_fail.get(a, 0), a))
            self.captain_id = pool[0]
            new = self.captain_id
            if reteam:
                self.result = None        # 重置组队结果 → 允许重建队伍
                self._reteam_pending = True
            name = self.expected[new].get("character")
        log.warning("队长端失败（%s）：自动改选 id=%s（%s）为新队长，%s",
                    reason, new, name,
                    "下个组队副本任务将重建队伍后重试" if reteam
                    else "本项当场由新队长重试（队伍未散，不重建）")
        return new

    def dungeon_captain_retry(self, name, reason, retry_limit=1):
        """队长端在某组队副本任务失败：改选队长后让**本项当场重试**。

        2026-10-17 事故（run c03345）：4 号队长端 liudao 进场景失败 → 立刻
        `dungeon_finish(False)` 判负，5 号改选成队长后本项却已"组队已判负"短路，
        第 2 次尝试根本没执行 → liudao+zhongkui 对全队 5 个号全白丢。
        这里把"改选"和"判负"解耦：还能再试时只改选队长（队伍没散，不用重建），
        本副本结果保持未定局，调用方返回 False 触发下一次尝试，由新队长重新进
        入口；重试次数用尽才回落原逻辑。

        返回 True=已改选并重排本项（调用方**不要**再 dungeon_finish）；
        False=本项重试次数已用尽 / 没有可换的号。
        """
        with self._lock:
            d = self._dungeon(name)
            tried = d.get("captain_retry", 0)
            if tried >= retry_limit:
                return False
        if self.failover_captain(reason, reteam=False) is None:
            return False
        with self._lock:
            d = self._dungeon(name)
            d["captain_retry"] = d.get("captain_retry", 0) + 1
            self._dungeon_event.set()
        log.warning("本项 %s 已改选队长后重排队（第 %d/%d 次重试）",
                    name, tried + 1, retry_limit)
        return True

    def reteam_pending(self):
        """是否有"队长端失败后请求重建队伍"待处理。"""
        with self._lock:
            return self._reteam_pending

    def clear_reteam(self):
        with self._lock:
            self._reteam_pending = False


_coordinator = TeamCoordinator()


def coordinator():
    return _coordinator
