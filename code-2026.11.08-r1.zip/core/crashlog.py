"""全局崩溃 / 未捕获异常落盘（诊断「静默消失」）。

为什么需要它
------------
2026-10-30 一天之内两次：GUI 启动十几秒到十几分钟后进程凭空消失 ——
run.log 断在启动横幅附近、Windows 没有 WER 崩溃记录、boot_error.log 也没有
记录，等于零线索。前一晚 05:30 那轮零任务完成，最后查明是账号线程里的
`NameError`：异常绕过了任务级 try/except，走 threading.excepthook，而窗口版
exe 的 sys.stderr 是 None，于是"死得无声无息"。

这里统一接三个出口，全部写到 debug/crash.log：
  1. faulthandler  —— C 层致命错误（段错误 / abort / PyQt 槽异常 abort）带完整栈
  2. threading.excepthook —— 子线程未捕获异常（10-29 那类 NameError）
  3. sys.excepthook       —— 主线程未捕获异常
外加 atexit 记一行「正常退出」。**这一行在不在，是区分"主动退出/正常返回"与
"被 TerminateProcess 杀掉/崩溃"的唯一凭据** —— 查静默死亡先看它。

纪律：所有安装动作都 try/except 包住。诊断代码绝不许拖垮主程序（同
2026-10-30 看门狗事故的教训：辅助功能的失败不能变成主流程的失败）。
"""
import atexit
import faulthandler
import logging
import os
import sys
import threading
import time
import traceback

log = logging.getLogger("crashlog")

_installed = False
_fh_stream = None      # faulthandler 需要持有真实文件对象，不能让它被回收
_path = None
_MAX_BYTES = 2 * 1024 * 1024   # 单文件上限，超了就滚成 crash.log.1


def resolve_path(debug_dir=None):
    """debug/crash.log 的绝对路径。debug_dir 显式传入优先（自检用）。"""
    if debug_dir is not None:
        return os.path.join(str(debug_dir), "crash.log")
    try:
        from core.paths import DEBUG_DIR
        return str(DEBUG_DIR / "crash.log")
    except Exception:
        return os.path.join("debug", "crash.log")


def _rotate(path):
    """超过上限就滚一份（只留一代，避免 debug 目录无限膨胀）。"""
    try:
        if os.path.exists(path) and os.path.getsize(path) > _MAX_BYTES:
            os.replace(path, path + ".1")
    except Exception:
        pass


def _append(text):
    try:
        os.makedirs(os.path.dirname(_path) or ".", exist_ok=True)
        with open(_path, "a", encoding="utf-8") as f:
            f.write(text)
    except Exception:
        pass


def _stamp(title):
    return "\n%s ===== %s =====\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), title)


def _main_hook(exc_type, exc, tb):
    """主线程未捕获异常。不再转发给原 hook —— 窗口版 stderr 是 None，转过去等于丢。"""
    buf = _stamp("[主线程未捕获异常]") + "".join(
        traceback.format_exception(exc_type, exc, tb))
    _append(buf)


def _thread_hook(args):
    """子线程未捕获异常（daemon 线程崩了主线程毫无感知，只能靠这里留痕）。"""
    th = getattr(args, "thread", None)
    name = getattr(th, "name", "?")
    daemon = getattr(th, "daemon", "?")
    tb = getattr(args, "exc_traceback", None)
    buf = _stamp("[线程未捕获异常] thread=%s daemon=%s" % (name, daemon)) + "".join(
        traceback.format_exception(args.exc_type, args.exc_value, tb))
    _append(buf)


def _exit_hook():
    _append(_stamp("[进程退出] atexit 已走到 -> 属于主动退出/正常返回；"
                   "若某次异常消失后**没有**这一行，说明是被强制结束或真崩溃"))


def install(debug_dir=None):
    """装上三个钩子。可重复调用（第二次直接返回 False，不重复挂钩）。"""
    global _installed, _fh_stream, _path
    if _installed:
        return False
    try:
        _path = resolve_path(debug_dir)
        os.makedirs(os.path.dirname(_path) or ".", exist_ok=True)
        _rotate(_path)
        _append(_stamp("[安装] 崩溃诊断已启用 pid=%s py=%s argv=%s"
                       % (os.getpid(), sys.version.split()[0],
                          " ".join(sys.argv[:3]))))
        # ① C 层致命错误
        try:
            _fh_stream = open(_path, "a", encoding="utf-8")
            faulthandler.enable(file=_fh_stream)
        except Exception as e:
            log.debug("faulthandler 启用失败：%r", e)
        # ② 子线程未捕获异常
        try:
            threading.excepthook = _thread_hook
        except Exception as e:
            log.debug("threading.excepthook 设置失败：%r", e)
        # ③ 主线程未捕获异常
        try:
            sys.excepthook = _main_hook
        except Exception as e:
            log.debug("sys.excepthook 设置失败：%r", e)
        # ④ 正常退出留痕
        try:
            atexit.register(_exit_hook)
        except Exception as e:
            log.debug("atexit 注册失败：%r", e)
        _installed = True
        return True
    except Exception:
        # 装不上就静默放弃：宁可没有诊断，也不能让主程序起不来
        log.debug("崩溃诊断安装失败（忽略）", exc_info=True)
        return False


def path():
    """当前落盘路径（未安装时为 None），供界面/反馈包展示。"""
    return _path
