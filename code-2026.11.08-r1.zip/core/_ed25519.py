# -*- coding: utf-8 -*-
"""纯 Python ed25519 签名/验签（RFC 8032，vendored）。

为什么 vendored：本工具要求零新增依赖（新依赖 = 变更打包运行时 = 用户要全量
重装），授权签名只需要"启动/激活时各验签一次"，纯 Python 完全够用。

实现要点：扩展坐标（extended twisted Edwards coordinates, a=-1，公式来自
Explicit-Formulas Database 的 add-2008-hwcd / dbl-2008-hwcd）——点加/倍点
全程无求逆，仅编码/解码时各求逆一次，比仿射坐标快约两个数量级
（验签 ~50ms 量级）。正确性由 RFC 8032 官方测试向量保证
（debug/_verify_license.py 第 1 节）。

⚠️ 仅供 core/license.py 与 tools/make_license.py 使用，勿改、勿用于其它用途。
"""
import hashlib

_P = 2 ** 255 - 19
_L = 2 ** 252 + 27742317777372353535851937790883648493
_D = (-121665 * pow(121666, _P - 2, _P)) % _P


def _H(m):
    return hashlib.sha512(m).digest()


# ---- 扩展坐标点运算：点 = (X, Y, T, Z)，仿射 x=X/Z, y=Y/Z, T=XY/Z ----

def _pt_add(P1, P2):
    X1, Y1, T1, Z1 = P1
    X2, Y2, T2, Z2 = P2
    A = X1 * X2 % _P
    Bv = Y1 * Y2 % _P
    C = _D * T1 % _P * T2 % _P
    Dv = Z1 * Z2 % _P
    E = ((X1 + Y1) * (X2 + Y2) - A - Bv) % _P
    F = (Dv - C) % _P
    G = (Dv + C) % _P
    H = (Bv + A) % _P          # a=-1 → H = B - a*A = B + A
    return (E * F % _P, G * H % _P, E * H % _P, F * G % _P)


def _pt_double(P1):
    X1, Y1, _, Z1 = P1
    A = X1 * X1 % _P
    Bv = Y1 * Y1 % _P
    C = 2 * Z1 * Z1 % _P
    Dv = -A % _P               # a=-1 → D = a*A = -A
    E = ((X1 + Y1) * (X1 + Y1) - A - Bv) % _P
    G = (Dv + Bv) % _P
    F = (G - C) % _P
    H = (Dv - Bv) % _P
    return (E * F % _P, G * H % _P, E * H % _P, F * G % _P)


_IDENT = (0, 1, 0, 1)


def _scalarmult(P, e):
    Q = _IDENT
    while e:
        if e & 1:
            Q = _pt_add(Q, P)
        P = _pt_double(P)
        e >>= 1
    return Q


def _pt_eq(P1, P2):
    X1, Y1, _, Z1 = P1
    X2, Y2, _, Z2 = P2
    return (X1 * Z2 - X2 * Z1) % _P == 0 and (Y1 * Z2 - Y2 * Z1) % _P == 0


def _xrecover(y):
    xx = (y * y - 1) * pow(_D * y * y + 1, _P - 2, _P) % _P
    x = pow(xx, (_P + 3) // 8, _P)
    if (x * x - xx) % _P != 0:
        x = x * pow(2, (_P - 1) // 4, _P) % _P
    if x & 1:
        x = _P - x
    return x


_By = 4 * pow(5, _P - 2, _P) % _P
_Bx = _xrecover(_By)
_B = (_Bx, _By, _Bx * _By % _P, 1)


def _encodepoint(P):
    X, Y, _, Z = P
    zi = pow(Z, _P - 2, _P)
    x, y = X * zi % _P, Y * zi % _P
    out = bytearray(y.to_bytes(32, "little"))
    out[31] |= (x & 1) << 7
    return bytes(out)


def _decodepoint(s):
    if len(s) != 32:
        raise ValueError("point length is wrong")
    y = int.from_bytes(s, "little") & ((1 << 255) - 1)
    if y >= _P:
        raise ValueError("invalid point encoding")
    x = _xrecover(y)
    if (x & 1) != ((s[31] >> 7) & 1):
        x = _P - x
    if (-x * x + y * y - 1 - _D * x * x * y * y) % _P != 0:
        raise ValueError("decoding point that is not on curve")
    return (x, y, x * y % _P, 1)


def _secret_scalar(sk):
    h = bytearray(_H(sk))
    h[0] &= 248
    h[31] &= 63
    h[31] |= 64
    return int.from_bytes(h[:32], "little"), bytes(h[32:])


def publickey(sk):
    """sk(32B 种子) → pk(32B)。"""
    a, _ = _secret_scalar(sk)
    return _encodepoint(_scalarmult(_B, a))


def signature(m, sk, pk):
    """m → 64B 签名。"""
    a, prefix = _secret_scalar(sk)
    r = int.from_bytes(_H(prefix + m), "little") % _L
    R = _encodepoint(_scalarmult(_B, r))
    h = int.from_bytes(_H(R + pk + m), "little") % _L
    S = (r + h * a) % _L
    return R + S.to_bytes(32, "little")


def checkvalid(s, m, pk):
    """验签，失败抛 ValueError。"""
    if len(s) != 64:
        raise ValueError("signature length is wrong")
    if len(pk) != 32:
        raise ValueError("public-key length is wrong")
    Rpt = _decodepoint(s[:32])
    Apt = _decodepoint(pk)
    S = int.from_bytes(s[32:], "little")
    if S >= _L:
        raise ValueError("signature scalar out of range")
    h = int.from_bytes(_H(s[:32] + pk + m), "little") % _L
    if not _pt_eq(_scalarmult(_B, S), _pt_add(Rpt, _scalarmult(Apt, h))):
        raise ValueError("signature does not pass verification")
