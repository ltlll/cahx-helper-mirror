# -*- coding: utf-8 -*-
"""统一日志系统：**每一条日志自动带上当前账号标签**，并能一眼看出每个账号的问题。

背景（2026-10-10 事故复盘）：5 个账号各起一个线程并行执行，日志交错写进同一个
debug/run.log，行里没有任何账号信息。排查"4 个号卡在收益界面"时，只能另写一次性
正则脚本（曾经的 debug/_split_log.py、_skeleton.py）按任务顺序"猜"某行属于哪个
账号——既费时又不可靠。本模块从根上解决：

1. **账号上下文（线程局部）**：任务都在各账号自己的线程里跑，标签随线程自动跟随，
   业务代码无需在每个 log 调用里传账号。默认标签 "sys"（主线程/组队协调器）。
2. **逐行注入**：包装 logging 的 LogRecordFactory，给每条记录补 `account` 字段，
   任何 Formatter 引用 %(account)s 都安全（缺失时回退 "sys"）。
3. **三路落盘**：控制台 + debug/run.log（跨轮追加）+ debug/accounts/<标签>.log
   （每个账号一份，本进程首次写入时清空，专注"本轮"完整轨迹）。
4. **运行会话横幅**：每轮执行首尾各打一条 `run=xxxx` 横幅，便于从不断增长的
   run.log 里切出"这一轮"。

对外最小 API：
    setup_logging(app)                  # 进程启动时调用一次（幂等）
    set_account(tag) / clear_account()  # 账号线程进入/退出时设置
    account_tag(acc, hwnd)              # 由账号记录算出标签
    session_start(app) / session_end()  # 一轮执行首尾横幅
    log_problem(logger, msg, *args)     # 统一打"问题"（WARNING，可 grep）
"""
import logging
import os
import re
import sys
import threading
import time
import uuid
from pathlib import Path

from core.paths import DEBUG_DIR

# 逐行格式：时间(含毫秒) [级别] [账号标签] 正文
LOG_FORMAT = "%(asctime)s [%(levelname)s] [%(account)s] %(message)s"
# GUI 内嵌日志面板用的短格式（只到秒，界面紧凑）
GUI_LOG_FORMAT = "%(asctime)s|%(account)s|%(message)s"
GUI_LOG_DATEFMT = "%H:%M:%S"

ACCOUNTS_LOG_DIR = DEBUG_DIR / "accounts"
SYSTEM_TAG = "sys"

_tls = threading.local()
_run_state = threading.local()
_configured = False
_factory_installed = False

log = logging.getLogger("logsetup")


# ---------------------------------------------------------------------------
# 账号上下文
# ---------------------------------------------------------------------------
def current_account(default=SYSTEM_TAG):
    """当前线程的账号标签（未设置返回 default）。"""
    return getattr(_tls, "tag", None) or default


def set_account(tag):
    """设置当前线程的账号标签。"""
    _tls.tag = tag or None


def clear_account():
    _tls.tag = None


class account_context:
    """with account_context(tag): ... —— 退出时恢复原标签（可嵌套）。"""

    def __init__(self, tag):
        self.tag = tag
        self._prev = None

    def __enter__(self):
        self._prev = getattr(_tls, "tag", None)
        set_account(self.tag)
        return self.tag

    def __exit__(self, *exc):
        _tls.tag = self._prev
        return False


def account_tag(acc, hwnd=None):
    """由账号记录算出一个短、唯一、可 grep 的标签：`id:角色名`，队长追加 ★。

    角色名是账号↔窗口的权威标识（句柄重启会变，见 AGENTS.md）；缺角色名时退回
    id，再缺退 hwnd。例：`3:奶茶朝夕相伴★`（队长）/ `4:外卖点到手颤`（队员）。
    """
    acc = acc or {}
    aid = acc.get("id")
    name = acc.get("character")
    if aid is not None and name:
        tag = f"{aid}:{name}"
    elif name:
        tag = str(name)
    elif aid is not None:
        tag = f"id{aid}"
    else:
        tag = f"hwnd:{hwnd if hwnd is not None else '?'}"
    if acc.get("is_captain"):
        tag += "★"
    return tag


# ---------------------------------------------------------------------------
# LogRecordFactory：给每条记录注入 account 字段
# ---------------------------------------------------------------------------
def _install_factory():
    global _factory_installed
    if _factory_installed:
        return
    _factory_installed = True
    orig = logging.getLogRecordFactory()

    def factory(*args, **kwargs):
        record = orig(*args, **kwargs)
        try:
            record.account = current_account()
        except Exception:
            record.account = SYSTEM_TAG
        return record

    logging.setLogRecordFactory(factory)


_install_factory()


# ---------------------------------------------------------------------------
# 按账号分文件的 handler
# ---------------------------------------------------------------------------
_SAFE_RE = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def safe_filename(tag):
    """把标签转成安全的文件名（Windows 非法字符替换为 _）。"""
    return _SAFE_RE.sub("_", str(tag)).strip() or SYSTEM_TAG


class AccountFileHandler(logging.Handler):
    """把每条日志额外写入 debug/accounts/<标签>.log（每账号一份）。

    标签取自 record.account；文件在本进程首次写入该标签时以 'w' 打开，即每次
    启动程序都重置，专注"本轮"轨迹（跨轮历史看 run.log）。分文件失败不影响
    主流程（记到 logsetup 的 error 里）。
    """

    def __init__(self, base_dir, fmt):
        super().__init__()
        self.base_dir = Path(base_dir)
        self._handlers = {}
        self._lock = threading.Lock()
        self._own_fmt = fmt

    def _handler_for(self, tag):
        h = self._handlers.get(tag)
        if h is None:
            self.base_dir.mkdir(parents=True, exist_ok=True)
            path = self.base_dir / f"{safe_filename(tag)}.log"
            # 2026-10-25 起用追加模式：任务执行迁到 worker 子进程后，GUI 与
            # worker 两个进程都会写同一分账号文件，"w" 会互相清档；按 run
            # 横幅（session_start/end）切轮，logdigest 不受影响。
            h = logging.FileHandler(path, mode="a", encoding="utf-8")
            h.setFormatter(self._own_fmt)
            self._handlers[tag] = h
        return h

    def emit(self, record):
        try:
            tag = getattr(record, "account", None) or SYSTEM_TAG
            with self._lock:
                handler = self._handler_for(tag)
            handler.emit(record)
        except Exception:
            self.handleError(record)

    def close(self):
        with self._lock:
            for h in self._handlers.values():
                try:
                    h.close()
                except Exception:
                    pass
            self._handlers.clear()
        super().close()


# ---------------------------------------------------------------------------
# 会话横幅
# ---------------------------------------------------------------------------
def _banner(text):
    pad = max(0, 96 - len(text))
    line = "=" * 12 + f" {text} " + "=" * pad
    log.info(line)


def fmt_duration(secs):
    """把秒数格式化成 45s / 12m03s / 1h05m 这样的短串（日志用）。"""
    secs = int(secs)
    if secs < 60:
        return f"{secs}s"
    if secs < 3600:
        return f"{secs // 60}m{secs % 60:02d}s"
    return f"{secs // 3600}h{(secs % 3600) // 60:02d}m"


def session_start(app="app", extra=""):
    """一轮执行开始：打横幅并返回 run_id（供 session_end 用），标签重置为 sys。"""
    clear_account()
    run_id = uuid.uuid4().hex[:6]
    _run_state.run_id = run_id
    _run_state.started = time.time()
    tail = f" {extra}" if extra else ""
    _banner(f"运行开始 run={run_id} app={app} pid={os.getpid()}{tail}")
    return run_id


def session_end(app="app", extra=""):
    """一轮执行结束：打横幅（含 run_id 与总耗时）。与 session_start 成对调用。"""
    run_id = getattr(_run_state, "run_id", "?")
    started = getattr(_run_state, "started", None)
    dur = ""
    if started:
        dur = f" 用时 {fmt_duration(time.time() - started)}"
    clear_account()
    tail = f" {extra}" if extra else ""
    _banner(f"运行结束 run={run_id} app={app}{dur}{tail}")
    _run_state.run_id = None
    _run_state.started = None


# ---------------------------------------------------------------------------
# 统一初始化
# ---------------------------------------------------------------------------
def setup_logging(app="app", per_account=True, console=True):
    """配置根日志器（幂等，重复调用只生效一次）。

    控制台 + debug/run.log（跨轮追加，utf-8）+ debug/accounts/<标签>.log
    （可选，账号粒度）。所有 handler 用同一格式，含 [账号标签] 字段。
    """
    global _configured
    _install_factory()
    root = logging.getLogger()
    if _configured:
        return
    _configured = True
    root.setLevel(logging.INFO)
    fmt = logging.Formatter(LOG_FORMAT, defaults={"account": SYSTEM_TAG})

    if console:
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(fmt)
        root.addHandler(sh)

    DEBUG_DIR.mkdir(parents=True, exist_ok=True)
    try:
        fh = logging.FileHandler(DEBUG_DIR / "run.log", encoding="utf-8")
        fh.setFormatter(fmt)
        root.addHandler(fh)
    except OSError as e:  # 只读介质/权限问题：退化为仅控制台
        root.warning("run.log 无法写入（%s），仅输出到控制台", e)

    if per_account:
        root.addHandler(AccountFileHandler(ACCOUNTS_LOG_DIR, fmt))

    _banner(f"进程启动 app={app} pid={os.getpid()} py={sys.version.split()[0]}")


def gui_formatter():
    """GUI 内嵌日志面板用的 Formatter（含账号标签）。"""
    return logging.Formatter(GUI_LOG_FORMAT, datefmt=GUI_LOG_DATEFMT,
                             defaults={"account": SYSTEM_TAG})


def log_problem(logger, msg, *args):
    """统一的"问题"日志（WARNING 级），便于按级别 + 账号标签 grep 出所有异常。"""
    logger.warning("问题：%s" % msg, *args)
