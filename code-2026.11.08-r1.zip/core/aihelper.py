"""AI 兜底：脚本遇到没写过的画面时，交给多模态模型看截图并代做操作。

## 为什么要有这个模块

自动化脚本只能处理"写过的分支"。真实游戏里总有没见过的弹窗、改版后的界面、
偶发的活动推广……这些场景本来走 `Task.report_unknown()`：存图 + 打「问题」日志，
等人看了再补代码。AI 兜底把这些场景先交给多模态模型看一眼——能处理就直接处理掉，
处理不了再退回原来的"存图 + 问题日志"，人被打扰的次数只减不增。

## 三条硬原则

1. **旁路，不接管**：只在 `report_unknown()` 这类"脚本自己认输"的位置触发。
   能判定的分支一律走原逻辑（快、免费、确定）。AI 未配置 / 网络不通 / 超时 /
   返回乱码 → 一律返回 None，调用方继续走原来的人工兜底，行为与今天完全一致。

2. **模型说目标，程序算坐标**：多模态模型直接报像素坐标很不准（405x720 这种
   小图上常差几十像素，点歪就是事故）。所以优先让模型输出要点哪个**文字**，
   由 `core.ocr` 在画面里精确定位实际坐标；只有 OCR 也找不到时，才用它给的
   归一化坐标（0~1 比例 × 客户区尺寸）兜底。

3. **白名单 + 禁用词**：只允许 click_text / click_pos / drag / esc / wait 五种动作；
   坐标一律夹进客户区内；命中"充值/购买/退出游戏/注销/删除账号"等禁用词的点击
   直接拒绝——模型再自信也不让它碰这些。

## 换模型

改 config.yaml 的 `ai.base_url` / `ai.model` / `ai.api_key` 即可（OpenAI 兼容的
chat/completions 格式）。默认配的是智谱开放平台的免费多模态模型
`glm-4.1v-thinking-flash`（64K 上下文 / 16K 输出，支持视觉推理）。

智谱家三个**免费**视觉模型可选（都是 0 元）：
  glm-4.1v-thinking-flash    64K / 16K 输出 · 支持视觉推理 ← 默认（实测稳定）
  glm-4v-flash               16K /  1K 输出 · 只做图像理解（实测稳定，但输出上限仅 1K）
  glm-4.6v-flash            128K / 32K 输出 · 支持视觉推理（效果最好，但免费额度常被抢爆 → 429）
实测（2026-10-12）：`glm-4.6v-flash` 长期返回 429「该模型当前访问量过大」（与账号实名无关），
故主模型取实测稳定的 `glm-4.1v-thinking-flash`，效果最好的那个退回退链里等着。
想更稳可换便宜的付费版 `glm-4.6v-flashx`（约 $0.04/百万输入 token）。

本模块只用标准库 urllib 发请求、用已有的 opencv 编码图片，不新增依赖。
"""
from __future__ import annotations

import base64
import contextlib
import json
import logging
import os
import re
import sys
import threading
import time
import urllib.error
import urllib.request

if __package__ in (None, ""):        # 直接 `python core/aihelper.py` 跑自检时补上包根目录
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.paths import CONFIG_PATH, DATA_DIR

log = logging.getLogger("ai")

# 密钥的"不进 git"落点：config.yaml 会被提交进仓库（会推到 GitHub 与 NAS 镜像），
# 所以开发机上把 key 写这里；data/ 已在 .gitignore 中。
AI_KEY_FILE = DATA_DIR / "ai_key.txt"

DEFAULT_BASE_URL = "https://open.bigmodel.cn/api/paas/v4/chat/completions"
DEFAULT_MODEL = "glm-4.1v-thinking-flash"
DEFAULT_ACTIONS = ("click_text", "click_pos", "drag", "esc", "wait")
DEFAULT_FORBID = ("充值", "购买", "支付", "退出游戏", "注销", "删除账号", "卸载",
                  "解绑", "布置")

# 服务商预设：GUI 里选一家就自动填好接口地址与候选模型，用户只需要贴自己的 Key。
# 顺序 = GUI 下拉框顺序；第一家是默认（有免费额度、注册最简单）。
PROVIDERS = (
    {
        "name": "智谱 AI（GLM）· 有免费模型，推荐",
        "base_url": "https://open.bigmodel.cn/api/paas/v4/chat/completions",
        # 实测：免费款里的 glm-4.6v-flash 常被抢爆（HTTP 429），另两个稳定，故排在前面
        "models": ["glm-4.1v-thinking-flash", "glm-4v-flash", "glm-4.6v-flash",
                   "glm-4.6v-flashx", "glm-4.6v"],
        # 模型下拉里跟在名字后面的短标注（GUI 用；选中的仍是名字本身）
        "notes": {"glm-4v-flash": "输出上限只有 1K",
                  "glm-4.6v-flash": "效果最好但常被限流",
                  "glm-4.6v-flashx": "付费·最稳"},
        "key_page": "https://open.bigmodel.cn/usercenter/apikeys",
        "key_hint": "注册后到「API Keys」页新建一个，复制形如 xxxxxxxx.yyyyyyyy 的串",
    },
    {
        "name": "阿里通义千问（Qwen-VL）",
        "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",
        "models": ["qwen-vl-max", "qwen-vl-plus", "qwen3-vl-plus"],
        "key_page": "https://bailian.console.aliyun.com/",
        "key_hint": "在阿里云百炼控制台创建 API-KEY（新用户有免费额度）",
    },
    {
        "name": "字节豆包（火山方舟）",
        "base_url": "https://ark.cn-beijing.volces.com/api/v3/chat/completions",
        "models": ["doubao-1.5-vision-pro-32k", "doubao-1.5-vision-lite"],
        "key_page": "https://console.volcengine.com/ark",
        "key_hint": "在火山方舟控制台创建 API Key；模型名要填「接入点 ID」或模型 ID",
    },
    {
        "name": "自定义（任何 OpenAI 兼容接口）",
        "base_url": "",
        "models": [],
        "key_page": "",
        "key_hint": "接口需兼容 OpenAI 的 /chat/completions 格式，且支持图片输入",
    },
)

_lock = threading.Lock()
_cache = {"cfg": None, "mtime": 0.0}

# 「测试连接」用：GUI 上可能还没保存配置，先临时覆盖再探测（探测完即还原）
_override = None
_override_lock = threading.Lock()

# 最近一次请求失败的原因摘要（给 GUI 的测试连接显示，比"失败"两个字有用得多）。
# `_last_code` 是 HTTP 状态码（网络层失败为 0），`_last_detail` 是服务端返回的原文，
# 两者一起喂给 `explain_error()` 翻译成人话——直接把原始 JSON 丢给用户是看不懂的。
_last_error = ""
_last_code = 0
_last_detail = ""

# 绕开系统代理直连模型服务（国内接口走代理反而容易失败；
# 若有需要可把 ai.use_proxy 设为 true）
_direct = urllib.request.build_opener(urllib.request.ProxyHandler({}))
_via_proxy = urllib.request.build_opener()


# ---------------------------------------------------------------- 配置

def reload_config():
    """清掉配置缓存（改完 config.yaml 想立刻生效时调用；一般靠 mtime 自动感知）。"""
    with _lock:
        _cache["cfg"] = None
        _cache["mtime"] = 0.0


def config():
    """读 config.yaml 的 `ai:` 段。

    按文件 mtime 缓存——用户在编辑器里改完配置保存，下次调用自动重新读取，
    不需要重启程序。读文件失败一律当作"没配置"，绝不影响主流程。
    """
    try:
        mtime = CONFIG_PATH.stat().st_mtime
    except OSError:
        return {}
    with _lock:
        if _cache["cfg"] is not None and _cache["mtime"] == mtime:
            return _cache["cfg"]
    cfg = {}
    try:
        import yaml
        with open(CONFIG_PATH, encoding="utf-8") as f:
            raw = yaml.safe_load(f) or {}
        got = raw.get("ai")
        if isinstance(got, dict):
            cfg = got
    except Exception as e:                       # 配置坏了不能拖垮任务
        log.warning("读取 AI 配置失败（按未配置处理）：%s", e)
    with _lock:
        _cache["cfg"] = cfg
        _cache["mtime"] = mtime
    return cfg


def api_key():
    """取 API Key，按优先级：config.yaml 的 `ai.api_key` → 环境变量 → data/ai_key.txt。

    为什么要有后两条：`config.yaml` 本身在 git 里（会推到 GitHub 与备份镜像），把密钥
    写进去等于公开；`data/` 已在 .gitignore 中，所以开发机上把 key 放 `data/ai_key.txt`
    更安全。给朋友的分发包没有 git，直接在 config.yaml 里填也一样能用（优先级最高）。
    密钥只用于拼 Authorization 头，绝不写进日志。
    """
    got = str(config().get("api_key") or "").strip()
    if got:
        return got
    got = (os.environ.get("CAHX_AI_KEY") or "").strip()
    if got:
        return got
    try:                                         # 每行一个，# 开头为注释
        for line in AI_KEY_FILE.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                return line
    except OSError:
        pass
    return ""


def key_source():
    """密钥来自哪里（只报来源，不报内容；给自检/日志用）。"""
    if str(config().get("api_key") or "").strip():
        return "config.yaml"
    if (os.environ.get("CAHX_AI_KEY") or "").strip():
        return "环境变量 CAHX_AI_KEY"
    if api_key():
        return str(AI_KEY_FILE)
    return "（未配置）"


def available():
    """总开关打开 且 填了 api_key 才算可用。"""
    return bool(config().get("enabled")) and bool(api_key())


def allowed_actions():
    got = config().get("allow_actions")
    if isinstance(got, (list, tuple)) and got:
        return tuple(str(a).strip().lower() for a in got if str(a).strip())
    return DEFAULT_ACTIONS


def forbid_targets():
    got = config().get("forbid_targets")
    if isinstance(got, (list, tuple)) and got:
        return tuple(str(w) for w in got if str(w).strip())
    return DEFAULT_FORBID


def model_chain():
    """按顺序尝试的模型列表：`ai.model` 打头，其后依次是 `ai.fallback_models`。

    为什么要有回退：热门的免费模型（尤其 glm-4.6v-flash）经常直接返回 HTTP 429
    「该模型当前访问量过大」，此时换另一个免费模型通常立刻可用。多列几个，AI 兜底
    才不会因为限流而形同虚设。去重保序，至少返回主模型。
    """
    cfg = config()
    raw = [cfg.get("model") or DEFAULT_MODEL]
    fb = cfg.get("fallback_models")
    if isinstance(fb, str):
        raw.append(fb)
    elif isinstance(fb, (list, tuple)):
        raw.extend(fb)
    out, seen = [], set()
    for m in raw:
        m = str(m or "").strip()
        if m and m not in seen:
            seen.add(m)
            out.append(m)
    return out or [DEFAULT_MODEL]


def status():
    """一行状态说明（GUI / 日志用）。"""
    cfg = config()
    if not cfg.get("enabled"):
        return "已关闭"
    if not api_key():
        return "未填 api_key"
    return "已启用 · %s" % (cfg.get("model") or DEFAULT_MODEL)


# ---------------------------------------------------------------- 失败原因翻译

# 失败类别 → 处理建议。免费模型被限流（429）是最常见的一种，而且它**不是配置问题**，
# 必须和"Key 填错了"明确区分开，否则用户会一直去改一个本来没错的配置。
FAIL_TIPS = {
    "rate": "模型当前被限流（HTTP 429「该模型当前访问量过大」）。这不是配置问题——"
            "免费模型高峰期常被抢爆，等 1~2 分钟再点一次通常就好；也可以换个模型或服务商。",
    "auth": "API Key 无效（HTTP 401 身份验证失败）。检查两点：① Key 是否整段复制完整"
            "（智谱的形如 xxxxxxxx.yyyyyyyy）；② 账号是否已完成实名认证（未实名无法调用）。",
    "model": "模型名不存在（HTTP 400）。请在下拉框里重新选一个，或核对名字有没有打错。",
    "quota": "账号额度不足或已欠费，请到模型服务商控制台充值/查看免费额度。",
    "net": "连不上模型服务（网络问题）。检查网络/代理，或把配置里的 use_proxy 改一下再试。",
    "other": "调用失败，详见下面的原始信息。",
}


def explain_error(code=0, detail=""):
    """把一次失败的 (HTTP 状态码, 服务端原文) 翻译成 (类别, 给人看的一句话)。

    类别取 `FAIL_TIPS` 的键：rate 限流 / auth 鉴权 / model 模型名 / quota 额度 /
    net 网络 / other。服务端返回原文时优先取里面的 message，避免把整段 JSON 丢给用户。
    """
    body = str(detail or "")
    txt = body
    try:
        obj = json.loads(body)
        err = obj.get("error") if isinstance(obj, dict) else None
        if isinstance(err, dict):
            txt = str(err.get("message") or err.get("code") or body)
        elif err:
            txt = str(err)
        elif isinstance(obj, dict) and obj.get("message"):
            txt = str(obj["message"])
    except Exception:
        pass
    txt = " ".join(txt.split())[:120] or ("HTTP %s" % code if code else "未知错误")
    flat = body.replace(" ", "")

    if code == 429 or "1305" in flat or "访问量过大" in txt or "稍后再试" in txt:
        return "rate", "模型被限流：%s" % txt
    if code in (401, 403) or '"code":"1000"' in flat or "身份验证失败" in txt \
            or "令牌" in txt or "未授权" in txt:
        return "auth", "API Key 无效：%s" % txt
    if "模型不存在" in txt or "1211" in flat:
        return "model", "模型名不存在：%s" % txt
    if code == 402 or "余额" in txt or "欠费" in txt or "quota" in txt.lower() \
            or "1113" in flat:
        return "quota", "额度不足：%s" % txt
    if not code:
        # 请求发出去了但内容不对：别误报成"网络不通"（那会把用户引去查网络）
        if any(w in txt for w in ("输出解析失败", "返回不是 JSON", "响应结构异常")):
            return "other", "模型响应格式异常：%s" % txt
        return "net", "连接失败：%s" % txt
    if code >= 500:
        return "other", "模型服务端故障（HTTP %s）：%s" % (code, txt)
    return "other", "服务端拒绝了请求（HTTP %s）：%s" % (code, txt)


# ---------------------------------------------------------------- 临时覆盖

def _effective_cfg():
    """当前生效的 ai 配置（含「测试连接」期间的临时覆盖）。"""
    cfg = dict(config())
    with _override_lock:
        ov = _override
    if ov:
        for k in ("base_url", "model"):
            if ov.get(k):
                cfg[k] = ov[k]
    return cfg


def _effective_key():
    """当前生效的 API Key（含「测试连接」时用户刚输入、尚未保存的那个）。"""
    with _override_lock:
        ov = _override
    if ov is not None and ov.get("api_key") is not None:
        return str(ov["api_key"] or "").strip()
    return api_key()


@contextlib.contextmanager
def temporary(base_url=None, model=None, api_key_=None):
    """临时覆盖配置（GUI「测试连接」用：用户可能还没保存）。退出时自动还原。"""
    global _override
    with _override_lock:
        prev = _override
        _override = {"base_url": base_url, "model": model, "api_key": api_key_}
    try:
        yield
    finally:
        with _override_lock:
            _override = prev


# ---------------------------------------------------------------- 配置写回（GUI 用）

def _yaml_scalar(v):
    return '"%s"' % str(v).replace("\\", "\\\\").replace('"', '\\"')


def _ai_section(lines):
    """定位 config.yaml 里 `ai:` 段的 [起, 止) 行号；找不到返回 None。"""
    start = next((i for i, ln in enumerate(lines)
                  if not ln[:1].isspace() and ln.strip() == "ai:"), None)
    if start is None:
        return None
    end = start + 1
    while end < len(lines) and lines[end].strip() and lines[end][:1] in (" ", "\t"):
        end += 1
    return start, end


def save_key(key):
    """把 API Key 存到 data/ai_key.txt（该目录不进 git，随分发包发给朋友也安全）。"""
    try:
        AI_KEY_FILE.parent.mkdir(parents=True, exist_ok=True)
        txt = str(key or "").strip()
        AI_KEY_FILE.write_text(txt + "\n", encoding="utf-8")
        log.info("API Key 已保存到 %s（%s）", AI_KEY_FILE,
                 "已清空" if not txt else "共 %d 字符" % len(txt))
    except Exception:
        log.exception("保存 API Key 失败：%s", AI_KEY_FILE)


def save_settings(*, enabled=None, base_url=None, model=None,
                  fallback_models=None, api_key=None):
    """把 GUI 上的设置写回 config.yaml 的 ai 段（行级替换，保留注释）。

    `api_key` 语义：None=不动 / ""=清除 / 其他=保存到 `data/ai_key.txt`。
    无论哪种情况，config.yaml 里的 `api_key` 都会被清空——该文件会进 git，
    密钥只应待在 data/ 下（而且 config.yaml 里的值优先级最高，不清会盖掉新填的）。
    写盘失败只记日志，不抛异常。
    """
    fields = {}
    if enabled is not None:
        fields["enabled"] = "true" if enabled else "false"
    if base_url is not None:
        fields["base_url"] = _yaml_scalar(base_url)
    if model is not None:
        fields["model"] = _yaml_scalar(model)
    if fallback_models is not None:
        fields["fallback_models"] = ("[" + ", ".join(_yaml_scalar(m)
                                                     for m in fallback_models) + "]")
    if api_key is not None:
        fields["api_key"] = '""'
    try:
        lines = CONFIG_PATH.read_text(encoding="utf-8").splitlines()
        span = _ai_section(lines)
        if span is None:                      # 配置里没有 ai 段 → 追加一个
            lines += ["", "# AI 兜底（遇到脚本没写过的画面时交给大模型判断）", "ai:"]
            lines += ["  %s: %s" % (k, v) for k, v in fields.items()]
        else:
            start, end = span
            for key, val in fields.items():
                hit = next((j for j in range(start + 1, end)
                            if lines[j].lstrip().startswith(key + ":")), None)
                if hit is None:
                    lines.insert(end, "  %s: %s" % (key, val))
                    end += 1
                else:
                    indent = lines[hit][: len(lines[hit]) - len(lines[hit].lstrip())]
                    lines[hit] = "%s%s: %s" % (indent, key, val)
        CONFIG_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")
        reload_config()
        log.info("AI 设置已写入 config.yaml：%s", "、".join(sorted(fields)) or "（无变更）")
    except Exception:
        log.exception("写回 config.yaml 失败（运行期配置不受影响）")

    if api_key is not None:
        save_key(api_key)


def _reset_error():
    """清掉上一次请求的失败记录（每次探测前调，避免把旧原因混进这次的结论）。"""
    global _last_error, _last_code, _last_detail
    _last_error, _last_code, _last_detail = "", 0, ""


# 429 后等一小会儿再给同一个模型一次机会：免费模型的限流往往是瞬时的，
# 退避一次能少一次误报（真正被抢爆时也只是多花 1.5 秒）。
RETRY_DELAY_429 = 1.5

_KIND_LABEL = {"rate": "被限流", "auth": "Key 无效", "model": "模型名有误",
               "quota": "额度不足", "net": "网络不通", "other": "调用失败"}


def _format_fail(tried):
    """把逐模型的探测结果汇总成用户能据此行动的一段话。"""
    if not tried:
        return "连接失败（没有可测试的模型）。"
    lines = ["试了 %d 个模型都不通：" % len(tried)]
    for name, kind, why in tried:
        lines.append("   · %s —— %s" % (name, _KIND_LABEL.get(kind, kind)))
    kinds = {k for _n, k, _w in tried}
    # 多类错误时按"最该先处理"的顺序给建议：Key 错 > 模型名错 > 额度 > 网络 > 限流
    order = ("auth", "model", "quota", "net", "rate", "other")
    first = next((k for k in order if k in kinds), "other")
    detail = tried[-1][2] if len(kinds) == 1 or first == tried[-1][1] else ""
    lines.append("建议：" + FAIL_TIPS.get(first, FAIL_TIPS["other"]))
    if detail:
        lines.append("服务端原话：%s" % detail)
    return "\n".join(lines)


def test_connection(*, base_url=None, model=None, api_key_=None, timeout=20):
    """用（可能尚未保存的）设置发一次探测请求，返回 (ok, 给用户看的说明)。

    GUI 的「测试连接」用它。说明里会逐条列出试过哪些模型、各自失败在哪一步，
    并在全失败时给出可操作的下一步——因为最常见的失败是"免费模型被限流"，
    而它**不是配置问题**，必须和 Key 填错区分开，否则用户会去改一个本来没错的配置。
    主模型被限流会自动退避重试并依次试备用模型。
    """
    try:
        import numpy as np
    except Exception:
        return False, "本机缺少 numpy，无法自检"
    with temporary(base_url=base_url, model=model, api_key_=api_key_):
        cfg = _effective_cfg()
        if not _effective_key():
            return False, "还没有填 API Key"
        primary = str(cfg.get("model") or DEFAULT_MODEL)
        chain = [primary]
        # 备用模型只在"没换服务商"时试——不同家的模型名不通用，硬试只会白等
        same_endpoint = (not base_url) or (
            str(base_url).strip() == str(config().get("base_url") or "").strip())
        if same_endpoint:
            for m in model_chain():
                if m not in chain:
                    chain.append(m)
        probe = np.full((64, 64, 3), 240, dtype="uint8")
        messages = [{
            "role": "user",
            "content": [
                {"type": "image_url",
                 "image_url": {"url": "data:image/jpeg;base64,"
                                      + (encode_image(probe, 256, 70) or "")}},
                {"type": "text", "text": "这是一张空白测试图。只回复两个字：收到"},
            ],
        }]
        tried = []                                   # [(模型名, 类别, 服务端原话)]
        for m in chain:
            _reset_error()
            # parse=False：探测只要"能通、有回答"即算成功（提示词只让它回两个字，
            # 硬套动作 JSON 会把成功的请求误判成失败——这正是"测试连接"老报错的原因）
            obj = _request(m, messages, cfg, timeout, parse=False)
            note = ""
            if obj is None and explain_error(_last_code, _last_detail)[0] == "rate":
                # 限流往往只是瞬时的，退避一小会儿给同一个模型一次机会
                time.sleep(RETRY_DELAY_429)
                _reset_error()
                obj = _request(m, messages, cfg, timeout, parse=False)
                if obj is not None:
                    note = "（首次被限流，退避重试后恢复）"
            if obj is not None:
                tip = "连接成功 · %s（用时 %.1fs）%s" % (
                    obj.get("_model") or m, obj.get("_elapsed") or 0, note)
                if tried:
                    tip += "\n注意：%s 当前不可用，已自动跳过。" % "、".join(
                        n for n, _k, _w in tried)
                return True, tip
            kind, why = explain_error(_last_code, _last_detail)
            tried.append((m, kind, why))
            if kind == "auth":                       # Key 不对，再试别的模型也是白等
                break
    return False, _format_fail(tried)


# ---------------------------------------------------------------- 图片 / 解析

def encode_image(image, max_side=896, quality=85):
    """把截图编码成 JPEG 的 base64（长边超过 max_side 先等比缩小）。

    缩小只影响发给模型的图，不影响后续 OCR 定位与坐标换算——模型给的
    比例坐标与图片尺寸无关。
    """
    try:
        import cv2
    except Exception:
        return None
    try:
        h, w = image.shape[:2]
        scale = min(1.0, float(max_side) / float(max(h, w)))
        if scale < 1.0:
            image = cv2.resize(image, (max(1, int(w * scale)), max(1, int(h * scale))),
                               interpolation=cv2.INTER_AREA)
        ok, buf = cv2.imencode(".jpg", image,
                               [int(cv2.IMWRITE_JPEG_QUALITY), int(quality)])
        if not ok:
            return None
        return base64.b64encode(buf.tobytes()).decode("ascii")
    except Exception as e:
        log.warning("AI 兜底：截图编码失败 %s", e)
        return None


def parse_json(text):
    """从模型输出里抠出第一个 JSON 对象。

    模型经常裹 ```json 代码块，或者前面写一句"好的，分析如下："，
    甚至输出被 max_tokens 截断——这里逐层容错，抠不出来返回 None。
    """
    if not text or not isinstance(text, str):
        return None
    t = text.strip()
    t = re.sub(r"^\s*```(?:json)?\s*", "", t)
    t = re.sub(r"\s*```\s*$", "", t).strip()
    try:
        obj = json.loads(t)
        return obj if isinstance(obj, dict) else None
    except Exception:
        pass
    # 全角标点容错（2026-10-13 实测：glm-4.1v 输出 "reasoning":"…"，"confidence":…
    # ——reasoning 里的全角逗号是合法字符串内容，但把 JSON 结构里的逗号也写成
    # 全角就解析失败了）。归一化后再试一次；字符串值里的全角标点被替换成半角
    # 只影响 scene/reasoning 的展示文本，不影响动作语义。
    fixed = (t.replace("，", ",").replace("：", ":").replace("；", ";")
              .replace("（", "(").replace("）", ")").replace("【", "[").replace("】", "]"))
    try:
        obj = json.loads(fixed)
        return obj if isinstance(obj, dict) else None
    except Exception:
        pass
    start = t.find("{")
    while start != -1:
        depth = 0
        for i in range(start, len(t)):
            if t[i] == "{":
                depth += 1
            elif t[i] == "}":
                depth -= 1
                if depth == 0:
                    chunk = t[start:i + 1]
                    obj = None
                    for cand in (chunk, chunk.replace("，", ",").replace("：", ":")):
                        try:
                            obj = json.loads(cand)
                            break
                        except Exception:
                            continue
                    if isinstance(obj, dict):
                        return obj
                    break
        start = t.find("{", start + 1)
    return None


# ---------------------------------------------------------------- 提示词

def build_prompt(*, task_title="", tag="", note="", stage="", texts=(), w=0, h=0,
                 attempts=()):
    lines = [
        "你是《长安幻想》手游（PC 桌面版）的自动化助手。",
        "玩家写了一个自动做日常任务的脚本，现在脚本遇到了它没写过的画面，需要你判断。",
        "",
        "【脚本原本在做什么】%s" % (task_title or "（未知任务）"),
        "【脚本卡在哪一步】%s%s" % (tag or "（未知）",
                                    ("：" + note) if note else ""),
    ]
    if stage:
        lines.append("【脚本的最后阶段】%s" % stage)
    if texts:
        lines.append("【画面上已识别出的文字（可能有漏识别）】%s"
                     % " / ".join(str(t) for t in texts))
    if attempts:
        # 已尝试动作历史（2026-10-14）：防模型原地绕圈。今天 huoyue/zhanling
        # 就是每步独立看一帧、反复点同一个"任务"按钮，3 步白烧完放弃。
        lines.append("【本次已尝试过、且没让画面推进的动作（**不要再重复这些**）】"
                     + "；".join(str(a) for a in attempts))
        lines.append("↑ 如果下面你想给的动作和上面重复，请改试别的思路；"
                     "实在没有别的办法就直接 give_up。")
    lines += [
        "",
        "【你只能选一个动作，用 JSON 输出（只输出这一个 JSON，前后不要任何文字）】",
        '{"action":"click_text","target":"要点击的按钮上的文字",'
        '"scene":"这是什么画面","reasoning":"为什么这么点","confidence":0.9}',
        "  ↑ 首选。target 必须是画面上真实存在的文字，程序会拿它去精确找位置。",
        '{"action":"click_pos","x":0.5,"y":0.5,"scene":"...","reasoning":"...","confidence":0.5}',
        "  ↑ 只有在目标没有文字（纯图标）时才用。x/y 是 0~1 的比例，"
        "左上角 (0,0)、右下角 (1,1)。**x/y 两个字段都必须给，缺一个程序就没法点**。",
        '{"action":"click_pos","near":"附近的文字","x":0.5,"y":0.5,"scene":"...",'
        '"reasoning":"...","confidence":0.5}',
        "  ↑ 纯图标但旁边有文字标签时的**推荐写法**：填 near（旁边文字）+ 大致比例坐标，"
        "程序会用 OCR 找到那段文字、按 x/y 相对它微调，点得比纯比例坐标准得多。",
        '{"action":"drag","x":0.5,"y":0.8,"x2":0.5,"y2":0.3,"scene":"...","reasoning":"..."}'
        "   滑动（列表翻页、转动视角）",
        '{"action":"esc","scene":"...","reasoning":"..."}   按一次 ESC（关面板）',
        '{"action":"wait","seconds":3,"scene":"...","reasoning":"..."}   等一会儿再看',
        '{"action":"give_up","reasoning":"看不懂或不该动","confidence":1}   交给人工处理',
        "",
        "【必须遵守】",
        "1. 优先 click_text，把按钮上的字原样抄进 target，不要自己编画面上没有的字；",
        "2. 绝对不要点充值、购买、付费礼包、退出游戏、注销账号、删除角色这类按钮，"
        "遇到这种界面直接 give_up；",
        "3. 家园里的「布置」「设计」「保存」也绝不要点（会进入家具摆设/场景编辑"
        "模式，脚本出不来，2026-10-13 实测卡死一上午）——除非【脚本原本在做什么】"
        "明确就是家园布置类任务；",
        "4. 画面尺寸 %dx%d（比例坐标按这个尺寸算）；" % (w, h),
        "5. scene / reasoning / confidence 三个字段每次都要有。",
        "6. 纯图标目标必须给 x/y 或 near，缺了程序没法执行、会直接弃权这一步；"
        "target 也别照抄【画面文字】列表里你不确定在画面哪个位置的字"
        "（找不到位置同样弃权，2026-10-23 实测「巫」这种单字 9 次全废）。",
    ]
    return "\n".join(lines)


# ---------------------------------------------------------------- 调模型

def analyze(image, *, task_title="", tag="", note="", stage="", texts=(),
            extra_rules="", timeout=None, attempts=()):
    """把一张截图交给模型分析，返回解析后的 dict（含 `action`）；失败返回 None。

    任何异常（未配置、网络不通、超时、HTTP 错误、返回不是 JSON）都吞掉并返回
    None —— 调用方据此走原有的人工兜底，绝不因为 AI 出问题而中断任务。

    `attempts`：本次兜底里已经试过、且没让画面推进的动作描述列表（如
    ["click_text「任务」→ 画面无变化"]），拼进提示词防模型原地绕圈。
    """
    if not available():
        return None
    cfg = _effective_cfg()
    try:
        h, w = image.shape[:2]
    except Exception:
        return None
    b64 = encode_image(image, int(cfg.get("max_side") or 896),
                       int(cfg.get("jpeg_quality") or 85))
    if not b64:
        return None

    prompt = build_prompt(task_title=task_title, tag=tag, note=note,
                          stage=stage, texts=list(texts)[:40], w=w, h=h,
                          attempts=list(attempts)[:8])
    if extra_rules:
        prompt += "\n【本任务的补充说明】" + str(extra_rules)

    messages = [{
        "role": "user",
        "content": [
            {"type": "image_url",
             "image_url": {"url": "data:image/jpeg;base64," + b64}},
            {"type": "text", "text": prompt},
        ],
    }]
    # 逐个模型试：免费热门模型常返回 429「访问量过大」，换一个基本立刻可用。
    chain = model_chain()
    for i, model in enumerate(chain):
        obj = _request(model, messages, cfg, timeout)
        if obj is not None:
            if i:
                log.info("AI 兜底：主模型 %s 不可用，由 %s 顶上（用时 %ss）",
                         chain[0], model, obj.get("_elapsed"))
            return obj
        if i + 1 < len(chain):
            log.info("AI 兜底：%s 没出结果，改试 %s", model, chain[i + 1])
    return None


def _request(model, messages, cfg, timeout, parse=True):
    """向指定模型发一次请求；任意失败返回 None（只打日志、不抛异常）。

    `parse=True`（默认，任务兜底用）要求模型回答是约定的动作 JSON；
    `parse=False`（「测试连接」用）只要求"能通、有回答"，**不要求 JSON** ——
    探测提示词本来就只让它回两个字，硬套 JSON 会把成功的请求误判成失败。

    失败原因分档记录便于排查：HTTP 错误（429=限流最典型）/ 网络超时 / 返回非 JSON。
    最近一次失败会存进 `_last_error`，供 GUI 的「测试连接」把原因显示给用户。
    """
    global _last_error, _last_code, _last_detail
    payload = {
        "model": model,
        "messages": messages,
        "temperature": float(cfg.get("temperature") or 0.1),
    }
    if cfg.get("max_tokens"):
        payload["max_tokens"] = int(cfg["max_tokens"])

    url = cfg.get("base_url") or DEFAULT_BASE_URL

    # 智谱 GLM-4.6V 系列的"思考模式"**默认是开启的**（先想一大段再回答），对
    # "看一眼就决策"的兜底场景纯属浪费——本模块单请求只给 25s，思考会让它经常
    # 超时。所以默认显式关掉（config 里 `thinking: true` 可打开）。
    # 只在智谱接口上带这个字段：通义/豆包不认它，带上会直接 400。
    if "bigmodel.cn" in url:
        payload["thinking"] = {"type": "enabled" if cfg.get("thinking") else "disabled"}

    err_timeout = float(timeout or cfg.get("timeout") or 25)
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=body, method="POST", headers={
        "Content-Type": "application/json",
        "Authorization": "Bearer " + _effective_key(),
        "User-Agent": "cahx-helper/aihelper",
    })
    opener = _via_proxy if cfg.get("use_proxy") else _direct
    t0 = time.time()
    try:
        with opener.open(req, timeout=err_timeout) as resp:
            raw = resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        detail = ""
        try:
            detail = e.read().decode("utf-8", "replace")[:300]
        except Exception:
            pass
        _last_error = "HTTP %s %s" % (e.code, detail[:140])
        _last_code = e.code
        _last_detail = detail
        log.warning("AI 兜底：%s 返回 HTTP %s %s（用时 %.1fs）",
                    model, e.code, detail, time.time() - t0)
        return None
    except Exception as e:
        _last_error = "%s: %s" % (type(e).__name__, e)
        _last_code = 0
        _last_detail = "%s: %s" % (type(e).__name__, e)
        log.warning("AI 兜底：%s 调用失败 %s: %s（用时 %.1fs）",
                    model, type(e).__name__, e, time.time() - t0)
        return None

    elapsed = time.time() - t0
    try:
        data = json.loads(raw)
    except Exception:
        _last_error = "返回不是 JSON：%.120s" % raw
        _last_code, _last_detail = 0, "返回不是 JSON：%.200s" % raw
        log.warning("AI 兜底：%s 返回不是 JSON（用时 %.1fs）：%.200s", model, elapsed, raw)
        return None
    if isinstance(data, dict) and data.get("error"):
        _last_error = "接口报错：%.140s" % (data["error"],)
        _last_code = 0
        _last_detail = json.dumps(data, ensure_ascii=False)[:300]
        log.warning("AI 兜底：%s 接口报错（用时 %.1fs）：%.200s", model, elapsed, data["error"])
        return None
    try:
        content = data["choices"][0]["message"]["content"]
    except Exception:
        _last_error = "响应结构异常：%.120s" % raw
        _last_code, _last_detail = 0, "响应结构异常：%.200s" % raw
        log.warning("AI 兜底：%s 响应结构异常（用时 %.1fs）：%.200s", model, elapsed, raw)
        return None
    if isinstance(content, list):                 # 少数实现返回分段内容
        content = "".join(str(seg.get("text") or "") for seg in content
                          if isinstance(seg, dict))
    if not parse:                                 # 只探测连通性：有回答就算通
        return {"_raw": content, "_elapsed": round(elapsed, 1), "_model": model}
    obj = parse_json(content)
    if obj is None:
        _last_error = "模型输出解析失败：%.120s" % content
        _last_code, _last_detail = 0, "模型输出解析失败：%.200s" % content
        log.warning("AI 兜底：%s 输出解析失败（用时 %.1fs）：%.200s", model, elapsed, content)
        return None
    obj["_elapsed"] = round(elapsed, 1)
    obj["_model"] = model
    return obj


def diagnose():
    """`python core/aihelper.py` 打印配置与连通性自检（排查用）。"""
    cfg = config()
    print("配置文件      :", CONFIG_PATH)
    print("ai 段         :", json.dumps(cfg, ensure_ascii=False) if cfg else "（无）")
    print("状态          :", status())
    print("密钥来源      :", key_source())
    print("base_url      :", cfg.get("base_url") or DEFAULT_BASE_URL)
    print("模型（按序） :", " → ".join(model_chain()))
    print("允许的动作    :", "、".join(allowed_actions()))
    print("禁用点击词    :", "、".join(forbid_targets()))
    if not available():
        print("\n未启用：在 config.yaml 的 ai 段里把 enabled 设为 true 并填入 api_key。")
        return
    import numpy as np
    probe = np.full((64, 64, 3), 240, dtype="uint8")
    print("\n发起一次连通性探测（一张纯白小图，问它是什么）...")
    got = analyze(probe, task_title="连通性自检", tag="probe",
                  note="这只是一张空白图，请直接返回 give_up")
    if got is None:
        print("失败：没拿到可用结果，检查 api_key / 网络 / base_url。")
    else:
        print("成功：", json.dumps(got, ensure_ascii=False))


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO,
                        format="%(levelname)s %(name)s: %(message)s")
    diagnose()
