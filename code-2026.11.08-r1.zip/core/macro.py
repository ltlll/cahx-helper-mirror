# -*- coding: utf-8 -*-
"""动作宏：录制固定动作序列 → 对选中的所有账号窗口**同步广播**回放（类按键精灵）。

步骤模型（存 data/macros.json）：
    click      {x, y}                       单击（客户区相对坐标，405x720 基准）
    drag       {x1, y1, x2, y2}             拖拽
    esc        {}                           按 ESC（录制不采 ESC——与"停止/关浮层"
                                            语义冲突，需要时编辑器手动插）
    text       {text, method: paste|type}   输入文字（paste 走剪贴板支持中文）
    wait       {seconds}                    纯等待
    wait_image {template, timeout, on_timeout: stop|continue}
                                            等模板图出现（条件步骤，盲放唯一的读屏）
    所有步骤可带 pause（该步执行后的停顿秒数；录制时按时间戳自动生成）

同步广播语义：第 N 步在 A/B/C… 各窗口各执行一次 → 第 N+1 步……（步骤内快速
轮转，每号每步 ~0.3s；鼠标经 Device._input_lock 串行，**不做真并行**）。

⚠️ 盲放局限：除 wait_image 外不读屏——某号画面状态不一致（多弹窗/卡加载）
就会点歪，执行前应确认各号画面状态一致。

自检：python debug/_verify_macro.py（改本文件后必跑）。
"""
import json
import logging
import threading
import time
from pathlib import Path

from core.paths import ASSETS_DIR, DATA_DIR

log = logging.getLogger("macro")

MACROS_PATH = DATA_DIR / "macros.json"

STEP_TYPES = ("click", "drag", "esc", "text", "wait", "wait_image")
STEP_LABELS = {"click": "点击", "drag": "拖拽", "esc": "ESC", "text": "输入文字",
               "wait": "等待", "wait_image": "等图出现"}
DRAG_MIN_DIST = 12          # 按下→松开位移超过该像素判拖拽
PAUSE_MIN = 0.4             # 录制时步骤间隔小于该秒数不记 pause（回放本身有拟人延迟）
RECORD_INTERVAL = 0.05      # 录制轮询间隔
BETWEEN_ACCOUNTS = (0.15, 0.35)   # 广播时号间拟人抖动
CLIENT_W, CLIENT_H = 405, 720     # 客户区基准尺寸（越界校验用）


# ---------------------------------------------------------------- 模型与存储

def load_macros():
    try:
        data = json.loads(MACROS_PATH.read_text(encoding="utf-8"))
        return data.get("macros") or []
    except Exception:
        return []


def save_macros(macros):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    MACROS_PATH.write_text(json.dumps({"macros": macros}, ensure_ascii=False,
                                      indent=1), encoding="utf-8")


def find_macro(macros, name):
    for m in macros:
        if m.get("name") == name:
            return m
    return None


def new_macro(macros, name=None):
    base = name or "未命名宏"
    name, i = base, 2
    while find_macro(macros, name) is not None:
        name = f"{base}{i}"
        i += 1
    m = {"name": name, "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
         "steps": []}
    macros.append(m)
    return m


def make_step(stype, **kw):
    """构造一个步骤（带缺省值）。"""
    step = {"type": stype}
    if stype == "click":
        step.update(x=200, y=350)
    elif stype == "drag":
        step.update(x1=200, y1=260, x2=200, y2=620)
    elif stype == "text":
        step.update(text="", method="paste")
    elif stype == "wait":
        step.update(seconds=1.0)
    elif stype == "wait_image":
        step.update(template="", timeout=15, on_timeout="stop")
    step.update(kw)
    if stype != "wait":
        step.setdefault("pause", 0.5)
    return step


def validate_step(step, template_exists=None):
    """校验步骤合法性 → 错误信息字符串（空 = 合法）。

    template_exists: 可选回调（模板名 → bool），给了就校验 wait_image 的模板。
    """
    t = step.get("type")
    if t not in STEP_TYPES:
        return f"未知步骤类型: {t}"
    if t == "click":
        x, y = step.get("x"), step.get("y")
        if not (isinstance(x, (int, float)) and isinstance(y, (int, float))
                and 0 <= x < CLIENT_W and 0 <= y < CLIENT_H):
            return f"坐标越界（应在 0~{CLIENT_W}×0~{CLIENT_H}）"
    elif t == "drag":
        for k in ("x1", "y1", "x2", "y2"):
            v = step.get(k)
            if not isinstance(v, (int, float)):
                return "拖拽坐标缺失"
        if not (0 <= step["x1"] < CLIENT_W and 0 <= step["x2"] < CLIENT_W
                and 0 <= step["y1"] < CLIENT_H and 0 <= step["y2"] < CLIENT_H):
            return f"坐标越界（应在 0~{CLIENT_W}×0~{CLIENT_H}）"
    elif t == "text":
        if not step.get("text"):
            return "输入内容为空"
        if step.get("method") not in ("paste", "type"):
            return "输入方式应为 paste 或 type"
    elif t == "wait":
        if not isinstance(step.get("seconds"), (int, float)) or step["seconds"] <= 0:
            return "等待秒数应为正数"
    elif t == "wait_image":
        if not step.get("template"):
            return "未选模板"
        if template_exists is not None and not template_exists(step["template"]):
            return f"模板图不存在: {step['template']}"
        if step.get("on_timeout") not in ("stop", "continue"):
            return "超时策略应为 stop 或 continue"
    pause = step.get("pause")
    if pause is not None and (not isinstance(pause, (int, float)) or pause < 0):
        return "停顿应为非负秒数"
    return ""


def list_templates():
    """全部可用模板名（assets/images 递归，排除 .mask.png 掩码文件）。"""
    out = set()
    try:
        for p in ASSETS_DIR.rglob("*.png"):
            if not p.stem.endswith(".mask"):
                out.add(p.stem)
    except Exception:
        pass
    return sorted(out)


def step_summary(step):
    """步骤表里的参数摘要。"""
    t = step.get("type")
    if t == "click":
        return f"({step.get('x')}, {step.get('y')})"
    if t == "drag":
        return f"({step.get('x1')}, {step.get('y1')}) → ({step.get('x2')}, {step.get('y2')})"
    if t == "text":
        return f"{step.get('text', '')}（{'粘贴' if step.get('method') == 'paste' else '逐键'}）"
    if t == "wait":
        return f"{step.get('seconds')} 秒"
    if t == "wait_image":
        return (f"{step.get('template')} ≤{step.get('timeout')}s"
                f"（超时{'中止' if step.get('on_timeout') == 'stop' else '继续'}）")
    return ""


# ---------------------------------------------------------------- 录制

def _default_poll():
    """真机轮询：(左键按下?, 屏幕x, 屏幕y, F9按下?)。"""
    import win32api
    import win32con
    import win32gui
    lb = bool(win32api.GetAsyncKeyState(win32con.VK_LBUTTON) & 0x8000)
    f9 = bool(win32api.GetAsyncKeyState(win32con.VK_F9) & 0x8000)
    x, y = win32gui.GetCursorPos()
    return lb, x, y, f9


class Recorder:
    """录制器：轮询鼠标状态，把点击/拖拽识别为步骤（客户区相对坐标）。

    依赖注入：poll_fn() -> (lbutton, screen_x, screen_y, f9)；
    origin_fn() -> (客户区原点屏幕坐标)；sleep_fn / time_fn 可替换（测试用）。
    """

    def __init__(self, origin_fn, poll_fn=None, sleep_fn=time.sleep,
                 time_fn=time.monotonic):
        self._origin_fn = origin_fn
        self._poll = poll_fn or _default_poll
        self._sleep = sleep_fn
        self._time = time_fn
        self.steps = []
        self.recording = False

    def run(self):
        """录制主循环（阻塞，F9 按下沿结束）。返回录到的步骤列表。"""
        ox, oy = self._origin_fn()
        self.steps = []
        self.recording = True
        down = False
        down_at = down_pt = None
        max_dist = 0.0
        up_time = self._time()
        f9_held = False
        while self.recording:
            lb, sx, sy, f9 = self._poll()
            if f9 and not f9_held:
                break
            f9_held = f9
            now = self._time()
            if lb and not down:                     # 按下沿
                down = True
                down_at, down_pt = now, (sx - ox, sy - oy)
                max_dist = 0.0
            elif lb and down:                       # 按住移动
                d = ((sx - ox - down_pt[0]) ** 2 + (sy - oy - down_pt[1]) ** 2) ** 0.5
                max_dist = max(max_dist, d)
            elif down and not lb:                   # 松开沿
                gap = down_at - up_time
                pause = round(gap, 1) if gap >= PAUSE_MIN else None
                if max_dist > DRAG_MIN_DIST:
                    st = make_step("drag", x1=int(down_pt[0]), y1=int(down_pt[1]),
                                   x2=int(sx - ox), y2=int(sy - oy))
                else:
                    st = make_step("click", x=int(down_pt[0]), y=int(down_pt[1]))
                if pause and self.steps:   # 首个步骤不带 pause（那是启动延迟）
                    st["pause"] = pause
                self.steps.append(st)
                down = False
                up_time = now
            self._sleep(RECORD_INTERVAL)
        self.recording = False
        return self.steps


# ---------------------------------------------------------------- 同步广播回放

class MacroStopped(Exception):
    """用户点停止（协作式）。"""


def replay(steps, hwnds, progress_cb=None, stop_event=None,
           sleep_fn=time.sleep, device_factory=None, matcher=None,
           tile=True):
    """同步广播：每个步骤在所有窗口各执行一次，再进下一步。

    返回 (finished, detail)：finished=False 时 detail 说明中止原因
    （用户停止 / 某号 wait_image 超时中止 / 全部窗口不可用）。
    """
    import random

    from core.device import Device
    from core.matcher import Matcher

    if stop_event is None:
        stop_event = threading.Event()
    device_factory = device_factory or (lambda h: Device(hwnd=h))
    matcher = matcher or Matcher(ASSETS_DIR)

    # 前置：排除无效/假死窗口
    devices = []
    skipped = []
    for h in hwnds:
        try:
            d = device_factory(h)
            if d.is_hung():
                skipped.append(f"{h}(假死)")
                continue
            devices.append(d)
        except Exception:
            skipped.append(f"{h}(无效)")
    if not devices:
        return False, "没有可用的窗口（全部无效或假死）"

    if tile:
        try:
            from core import launcher
            launcher.tile_windows([d.hwnd for d in devices])
        except Exception as e:
            log.warning("宏回放：平铺窗口失败（继续执行）：%s", e)

    total_steps = len(steps)
    try:
        for si, step in enumerate(steps):
            for di, dev in enumerate(devices):
                if stop_event.is_set():
                    raise MacroStopped
                ok = _exec_step(dev, step, matcher, stop_event, sleep_fn)
                if progress_cb:
                    progress_cb(si, total_steps, di, len(devices), ok)
                if not ok and step.get("type") == "wait_image" \
                        and step.get("on_timeout") == "stop":
                    return False, (f"第 {si + 1} 步等图「{step.get('template')}」"
                                   f"超时中止（第 {di + 1} 个窗口）")
                sleep_fn(random.uniform(*BETWEEN_ACCOUNTS))
            pause = step.get("pause")
            if pause:
                _interruptible_sleep(pause, stop_event, sleep_fn)
    except MacroStopped:
        return False, f"用户停止（完成到第 {si + 1} 步）"
    detail = "全部完成"
    if skipped:
        detail += f"；跳过窗口: {', '.join(skipped)}"
    return True, detail


def _interruptible_sleep(seconds, stop_event, sleep_fn):
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        if stop_event.is_set():
            raise MacroStopped
        sleep_fn(min(0.2, end - time.monotonic()))


def _exec_step(dev, step, matcher, stop_event, sleep_fn):
    """在单个窗口执行一步。返回是否成功（wait_image 超时才可能 False）。"""
    t = step.get("type")
    if t == "click":
        dev.click(step["x"], step["y"])
    elif t == "drag":
        dev.drag(step["x1"], step["y1"], step["x2"], step["y2"])
    elif t == "esc":
        dev.press_esc()
    elif t == "text":
        if step.get("method") == "type":
            dev.type_text(step["text"])
        else:
            dev.paste_text(step["text"])
    elif t == "wait":
        _interruptible_sleep(float(step.get("seconds", 1)), stop_event, sleep_fn)
    elif t == "wait_image":
        deadline = time.monotonic() + float(step.get("timeout", 15))
        while time.monotonic() < deadline:
            if stop_event.is_set():
                raise MacroStopped
            if matcher.find(dev.screenshot(), step["template"]):
                return True
            sleep_fn(0.6)
        log.warning("宏回放：等图「%s」超时", step.get("template"))
        return False
    return True
