"""一条龙方案存储（data/yitiaolong.json，随 data/ 一起 gitignore）。

一条龙 = "5 人成队 → 组队方式 → 每人任务" 的完整编排。与旧版"一条龙"
（定时任务条目：跑 config.yaml 全量任务 + per_account 定制）相比，方案是
**显式**的：队伍成员、队长、组队方式、每个人的单人任务都写死在方案里，
不再依赖 db 里的队长标记和 per_account_tasks.json。

方案结构（一条 plan）：
    id         自增 id（整数，唯一）
    name       显示名（如 "早班一条龙"）
    members    [账号 id, ...] **恰好 5 个**，顺序 = 队伍顺序（第 1 个是主目标位）
    captain    账号 id，必须 ∈ members（队长的组队任务决定全队跑哪些副本）
    team_mode  "auto"=一键组队（帮会编队页）/ "manual"=手动组队（好友搜索邀请）
               —— 写入 zudui 任务的 mode 选项
    self_tasks {账号 id(str): [任务名, ...]} 每人自己的单人任务（可空列表）
    team_tasks [任务名, ...] 组队任务（日常副本：5开组队/海市蜃楼/六道/钟馗/打地鼠），
               5 人全队一起跑，只有队长能改
    preflight  客户端缺失时自动启动并登录（默认 True）
    note       备注（可选，界面未用）
    updated_at "YYYY-MM-DD HH:MM"

执行顺序仍取 config.yaml 的排列（全局顺序），方案只决定"每人跑哪些"。
FOLLOWUPS（活跃奖励→整理背包）由 scheduler.expand_followups 在执行时展开。
"""
import json
import time

from core.paths import DATA_DIR

PATH = DATA_DIR / "yitiaolong.json"

# 组队任务所在的分类（只有这类任务"需要组队才能完成"，仅队长可选）
TEAM_CATEGORY = "日常副本"

# 一条龙队伍的硬约束：恰好 5 人
TEAM_SIZE = 5

# 组队方式（与 5开组队 任务的 mode 次级选项一一对应）
TEAM_MODES = {
    "auto": ("一键组队", "帮会编队页一键邀请，最快，约 40 秒成队"),
    "manual": ("手动组队", "好友搜索逐个邀请，约 3 分钟，网络/跨服更稳"),
}
DEFAULT_TEAM_MODE = "auto"


def load():
    """读取全部方案。返回 {"plans": [...], "last_id": int}（文件损坏时视为空）。"""
    if not PATH.exists():
        return {"plans": [], "last_id": 0}
    try:
        raw = json.loads(PATH.read_text(encoding="utf-8"))
    except Exception:
        return {"plans": [], "last_id": 0}
    plans = raw.get("plans") if isinstance(raw, dict) else raw
    if not isinstance(plans, list):
        plans = []
    return {"plans": [p for p in plans if isinstance(p, dict)],
            "last_id": int(raw.get("last_id", 0) or 0) if isinstance(raw, dict) else 0}


def save(state):
    PATH.parent.mkdir(parents=True, exist_ok=True)
    PATH.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")


def plans():
    return load()["plans"]


def get(plan_id):
    """按 id 取方案（plan_id 为 None / 不存在时返回 None）。"""
    if plan_id in (None, "", 0):
        return None
    for p in plans():
        if p.get("id") == plan_id:
            return p
    return None


def upsert(plan):
    """新增或按 id 覆盖保存，返回落盘后的方案（自动分配 id、刷新 updated_at）。"""
    state = load()
    items = state["plans"]
    plan = dict(plan)
    plan["updated_at"] = time.strftime("%Y-%m-%d %H:%M")
    if plan.get("id"):
        for i, p in enumerate(items):
            if p.get("id") == plan["id"]:
                items[i] = plan
                break
        else:
            items.append(plan)
    else:
        state["last_id"] = int(state.get("last_id", 0) or 0) + 1
        plan["id"] = state["last_id"]
        items.append(plan)
    save(state)
    return plan


def remove(plan_id):
    state = load()
    state["plans"] = [p for p in state["plans"] if p.get("id") != plan_id]
    save(state)


def team_task_names(registry):
    """注册表里所有"需要组队才能完成"的任务名（日常副本分类），保持注册顺序。
    跳过 available=False 的未定稿任务（它们不该出现在任何可选清单里）。"""
    return [name for name, cls in registry.items()
            if getattr(cls, "category", "") == TEAM_CATEGORY
            and getattr(cls, "available", True)]


def single_task_names(registry):
    """注册表里可以每人单独跑的任务名（非日常副本），保持注册顺序。
    跳过 available=False 的未定稿任务（如「灵珠收集」两阶段）。"""
    return [name for name, cls in registry.items()
            if getattr(cls, "category", "") != TEAM_CATEGORY
            and getattr(cls, "available", True)]


def empty_plan():
    """一份空方案模板（向导"新建"用）。"""
    return {
        "id": 0,
        "name": "",
        "members": [],
        "captain": None,
        "team_mode": DEFAULT_TEAM_MODE,
        "self_tasks": {},
        "team_tasks": [],
        "preflight": True,
        # 按账号的任务参数（2026-11-04）：{str(账号id): {任务名: {键: 值}}}。
        # 目前只有 zhongcai.dish（种菜美食配方）；缺省/未配置 = 沿用 config.yaml
        # 全局默认。旧方案没有此键，一切照旧。
        "task_params": {},
    }


def task_params_for(plan, acc_id):
    """某成员在本方案里的任务参数覆盖 {任务名: {键: 值}}（无配置返回 {}）。

    JSON 键统一按字符串取（int/str 双兼容，与 self_tasks 同款处理）。
    """
    raw = plan.get("task_params") or {}
    params = raw.get(str(acc_id))
    if params is None:
        params = raw.get(acc_id)
    return dict(params) if isinstance(params, dict) else {}


def _as_ids(values):
    """JSON 里的 id 可能是 int 也可能是 str（手改过文件），统一成 int。"""
    out = []
    for v in values or []:
        try:
            out.append(int(v))
        except (TypeError, ValueError):
            out.append(v)
    return out


def member_ids(plan):
    """方案的成员 id 列表（int 化）。"""
    return _as_ids(plan.get("members"))


def captain_id(plan):
    try:
        return int(plan.get("captain"))
    except (TypeError, ValueError):
        return None


def validate(plan, valid_ids=None):
    """校验方案，返回错误文案；通过返回 None。

    valid_ids：账号库里现存的账号 id 集合（校验成员是否还存在）；
    None = 不校验（用于纯离线自检）。
    """
    if not str(plan.get("name") or "").strip():
        return "请填写方案名称"
    members = member_ids(plan)
    if len(members) != TEAM_SIZE:
        return f"一条龙必须选满 {TEAM_SIZE} 人（当前 {len(members)} 人）"
    if len(set(members)) != len(members):
        return "同一个账号被选了多次，请重新分配 5 个成员"
    if captain_id(plan) not in members:
        return "请从 5 名成员里指定队长"
    if plan.get("team_mode") not in TEAM_MODES:
        return "请选择组队方式"
    team = list(plan.get("team_tasks") or [])
    if team and "zudui" not in team:
        return "选了组队副本就必须包含「5开组队」（负责把 5 人拉进同一支队伍）"
    if valid_ids is not None:
        missing = [m for m in members if m not in valid_ids]
        if missing:
            return f"账号库里找不到成员（id={missing}），请重新选择"
    return None


def build_run(plan, registry, global_order):
    """把方案翻译成执行参数。

    返回 (names, names_map)：
      names     本轮任务并集（按 config.yaml 全局顺序）——状态面板总进度、地鼠轮识别用
      names_map {账号 id: 该账号的任务清单}——每个账号 = 自己的单人任务 ∪ 队长勾的组队任务，
                顺序一律取全局顺序（组队任务必须排在最后，协调器靠"到达组队任务"判定全员就绪）
    """
    team = [n for n in plan.get("team_tasks") or [] if n in registry]
    self_raw = plan.get("self_tasks") or {}
    used = set(team)
    per_acc = {}
    for acc_id in member_ids(plan):
        own = self_raw.get(str(acc_id))
        if own is None:
            own = self_raw.get(acc_id)
        own = [n for n in (own or []) if n in registry]
        used.update(own)
        per_acc[acc_id] = own
    names = [n for n in global_order if n in used]
    names_map = {acc_id: [n for n in names if n in set(own) or n in set(team)]
                 for acc_id, own in per_acc.items()}
    return names, names_map


def summarize(plan, name_of=None):
    """一句话摘要（定时任务表格 / 提示用）：5 人 + 组队方式 + 组队任务数。"""
    members = plan.get("members") or []
    who = name_of(members[0]) if (name_of and members) else f"{len(members)} 人"
    mode = TEAM_MODES.get(plan.get("team_mode"), ("", ""))[0]
    n_team = len(plan.get("team_tasks") or [])
    n_self = sum(len(v or []) for v in (plan.get("self_tasks") or {}).values())
    return f"{len(members)}人（{who} 等）· {mode} · 组队 {n_team} 项 / 单人 {n_self} 项"
