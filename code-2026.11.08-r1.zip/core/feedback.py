# -*- coding: utf-8 -*-
"""问题反馈：日志包 + 用户描述 → 企业微信群机器人 / Gitee 私有仓（双通道）。

通道由 config.yaml 的 feedback.channel 选择（默认 wecom）：
- wecom：企业微信群机器人 webhook——先发 markdown 摘要（即时通知）再传 zip
  附件（upload_media → file 消息，≤20MB）。国内直连必达。
- gitee：Gitee 私有仓——zip 经 contents API 提交进仓（base64，路径按时间戳
  唯一），再开 issue（标题=失败摘要，正文含机器码/版本/描述/附件路径），
  维护者 watch 仓库收通知；仓内沉淀可被 tools/feedback_watch.py 自动分析。

密钥安全（重要）：wecom_key / gitee_token 在主仓库的 config.yaml 里**永远留空**
（该文件会推到 GitHub 公开）；真实值放 data/feedback_wecom_key.txt /
data/feedback_gitee_token.txt（/data/ 已 gitignore），本模块读 config 为空时
回落读这两个文件；tools/build.py 打包时把真实值注入 dist 的
_internal/defaults/config.yaml——朋友拿到的包里有 key，主仓库永远没有。

⚠️ Gitee token 是全账号级（无单仓细粒度），建议用专门小号建反馈仓。
⚠️ 隐私：日志包含账号手机号/角色名，反馈仓必须私有。

自检：python debug/_verify_feedback.py（改本文件后必跑）。
"""
import base64
import json
import logging
import time
import urllib.request
import zipfile
from pathlib import Path

from core import logexport
from core.paths import CONFIG_PATH, DATA_DIR, DEBUG_DIR

log = logging.getLogger("feedback")

WECOM_BASE = "https://qyapi.weixin.qq.com/cgi-bin/webhook"
GITEE_BASE = "https://gitee.com/api/v5"
HTTP_TIMEOUT = 15
MAX_ZIP_BYTES = 19 * 1024 * 1024   # 企业微信文件消息上限 20MB，留 1MB 余量
# 密钥回落文件（维护者本机，/data/ 已 gitignore；打包时由 build.py 注入 dist）
KEY_FILES = {"wecom_key": "feedback_wecom_key.txt",
             "gitee_token": "feedback_gitee_token.txt"}

_ERR_TIPS = {
    40001: "key 无效（检查 feedback.wecom_key）",
    40058: "key 无效或机器人已被移出群聊",
    45009: "发送太频繁（接口限流），稍后再试",
}


def _read_secret_file(name):
    try:
        return (DATA_DIR / name).read_text(encoding="utf-8").strip()
    except Exception:
        return ""


def cfg():
    """config.yaml 的 feedback: 段；wecom_key/gitee_token 为空时回落 data/ 文件。"""
    try:
        import yaml
        with open(CONFIG_PATH, encoding="utf-8") as f:
            c = (yaml.safe_load(f) or {}).get("feedback") or {}
    except Exception:
        c = {}
    for key, fname in KEY_FILES.items():
        if not (c.get(key) or "").strip():
            c[key] = _read_secret_file(fname)
    return c


def channel():
    return (cfg().get("channel") or "wecom").strip().lower()


def configured():
    c = cfg()
    if not c.get("enabled", True):
        return False
    if channel() == "gitee":
        return bool(c.get("gitee_owner") and c.get("gitee_repo")
                    and c.get("gitee_token"))
    return bool(c.get("wecom_key"))


# ---------------------------------------------------------------- 打包

def build_zip(description, failures):
    """复用 logexport 打日志包，追加 feedback.txt。返回 zip 路径。"""
    zip_path = logexport.export_logs(DEBUG_DIR / "feedback_tmp")
    try:
        from core import license as lic
        machine = lic.machine_code()
    except Exception:
        machine = "（读取失败）"
    lines = [
        f"反馈时间: {time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"程序版本: {logexport.app_version()}",
        f"机器码: {machine}",
        "",
        "== 本轮失败任务 ==",
        *(failures or ["（无）"]),
        "",
        "== 用户描述 ==",
        description or "（未填写）",
    ]
    with zipfile.ZipFile(zip_path, "a", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("feedback.txt", "\n".join(lines))
    return Path(zip_path)


# ---------------------------------------------------------------- 企业微信发送

def _post_json(url, payload, method="POST"):
    req = urllib.request.Request(
        url, data=json.dumps(payload).encode("utf-8"), method=method,
        headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT) as r:
        return json.loads(r.read().decode("utf-8"))


def _upload_media(base, key, path):
    boundary = "----cahxfeedback7f3a"
    body = (
        f'--{boundary}\r\nContent-Disposition: form-data; name="media"; '
        f'filename="{path.name}"\r\n'
        f"Content-Type: application/zip\r\n\r\n"
    ).encode("utf-8") + path.read_bytes() + f"\r\n--{boundary}--\r\n".encode("utf-8")
    req = urllib.request.Request(
        f"{base}/upload_media?key={key}&type=file", data=body,
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
    with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT) as r:
        return json.loads(r.read().decode("utf-8"))


def _err_msg(resp):
    code = resp.get("errcode", -1)
    if code == 0:
        return ""
    return _ERR_TIPS.get(code) or f"企业微信返回错误 {code}: {resp.get('errmsg', '')}"


def send_wecom(key, zip_path, summary_md, base=WECOM_BASE):
    """先发 markdown 摘要、再发 zip 附件。返回 (ok, msg)。base 可注入（自检用）。"""
    zip_path = Path(zip_path)
    if zip_path.stat().st_size > MAX_ZIP_BYTES:
        return False, "日志包超过 20MB 上限，请改用「导出日志」手动发送"
    resp = _post_json(f"{base}/send?key={key}",
                      {"msgtype": "markdown", "markdown": {"content": summary_md}})
    err = _err_msg(resp)
    if err:
        return False, f"摘要发送失败：{err}"
    resp = _upload_media(base, key, zip_path)
    err = _err_msg(resp)
    if err:
        return False, f"附件上传失败：{err}"
    resp = _post_json(f"{base}/send?key={key}",
                      {"msgtype": "file",
                       "file": {"media_id": resp.get("media_id", "")}})
    err = _err_msg(resp)
    if err:
        return False, f"附件发送失败：{err}"
    return True, "已发送"


def make_summary(description, failures):
    """群里看到的 markdown 摘要。"""
    try:
        from core import license as lic
        machine = lic.machine_code()
    except Exception:
        machine = "未知"
    fail_lines = "\n".join(f"> {f}" for f in (failures or ["（无）"]))
    desc = (description or "（未填写）").strip()
    if len(desc) > 200:
        desc = desc[:200] + "…"
    return (
        f"**📮 任务管家问题反馈**\n"
        f"> 时间：{time.strftime('%m-%d %H:%M')}\n"
        f"> 版本：{logexport.app_version()}\n"
        f"> 机器码：{machine}\n"
        f"**失败任务：**\n{fail_lines}\n"
        f"**用户描述：**{desc}\n"
        f"日志包见附件（下一条消息）"
    )


# ---------------------------------------------------------------- Gitee 通道

def _gitee_err(resp_or_exc):
    """Gitee 错误翻译成人话。"""
    if isinstance(resp_or_exc, urllib.error.HTTPError):
        code = resp_or_exc.code
        return {401: "token 无效或已过期",
                403: "token 没有这个仓库的权限",
                404: "仓库不存在（检查 gitee_owner / gitee_repo）"}.get(
                    code, f"Gitee 返回 HTTP {code}")
    return str(resp_or_exc)


def send_gitee(c, zip_path, summary_md, failures=None, base=GITEE_BASE):
    """zip 提交进反馈仓 + 开 issue。返回 (ok, msg)。base 可注入（自检用）。"""
    import urllib.error
    token = c["gitee_token"].strip()
    owner, repo = c["gitee_owner"].strip(), c["gitee_repo"].strip()
    zip_path = Path(zip_path)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    date_dir = time.strftime("%Y-%m-%d")
    remote_path = f"feedback/{date_dir}/feedback-{stamp}.zip"
    try:
        # 1) 传附件（contents API，base64；路径唯一不会撞已有文件）
        _post_json(
            f"{base}/repos/{owner}/{repo}/contents/{remote_path}",
            {"access_token": token, "message": f"feedback {stamp}",
             "content": base64.b64encode(zip_path.read_bytes()).decode()},
            method="PUT")
        # 2) 开 issue（标题 = 第一条失败任务，正文 = 详情 + 附件路径）
        first_fail = (failures or ["见正文"])[0]
        title = f"[反馈] {stamp} {first_fail[:40]}"
        body = (summary_md.replace("日志包见附件（下一条消息）",
                                   f"日志包：仓内 `{remote_path}`"))
        _post_json(f"{base}/repos/{owner}/{repo}/issues",
                   {"access_token": token, "title": title, "body": body})
        return True, "已发送（Gitee 仓库）"
    except urllib.error.HTTPError as e:
        return False, _gitee_err(e)
    except Exception as e:
        return False, f"发送失败：{e}"


def send(description, failures):
    """总入口。返回 (ok, msg)；任何异常都返回 (False, 人话)，不抛。"""
    c = cfg()
    if not c.get("enabled", True):
        return False, "反馈通道未启用"
    if not configured():
        return False, "未配置反馈通道（请改用「导出日志」手动发给维护者）"
    zip_path = None
    try:
        zip_path = build_zip(description, failures)
        summary = make_summary(description, failures)
        if channel() == "gitee":
            return send_gitee(c, zip_path, summary, failures=failures)
        return send_wecom(c["wecom_key"].strip(), zip_path, summary)
    except Exception as e:
        log.warning("反馈发送失败：%s", e)
        return False, f"发送失败：{e}（可改用「导出日志」手动发送）"
    finally:
        if zip_path is not None:
            try:
                Path(zip_path).unlink(missing_ok=True)
            except Exception:
                pass


def test_channel():
    """设置页「测试通道」。返回 (ok, msg)。"""
    c = cfg()
    if channel() == "gitee":
        token = (c.get("gitee_token") or "").strip()
        owner = (c.get("gitee_owner") or "").strip()
        repo = (c.get("gitee_repo") or "").strip()
        if not (token and owner and repo):
            return False, "未配置 gitee_owner / gitee_repo / gitee_token"
        try:
            req = urllib.request.Request(
                f"{GITEE_BASE}/repos/{owner}/{repo}?access_token={token}",
                headers={"User-Agent": "cahx-helper"})
            with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT) as r:
                info = json.loads(r.read().decode("utf-8"))
            return True, f"通道正常：仓库 {info.get('full_name', owner + '/' + repo)}"
        except Exception as e:
            import urllib.error
            if isinstance(e, urllib.error.HTTPError):
                return False, _gitee_err(e)
            return False, f"连接失败：{e}"
    key = (c.get("wecom_key") or "").strip()
    if not key:
        return False, "未配置 feedback.wecom_key"
    try:
        resp = _post_json(
            f"{WECOM_BASE}/send?key={key}",
            {"msgtype": "markdown",
             "markdown": {"content":
                          f"**任务管家反馈通道测试**\n> {time.strftime('%Y-%m-%d %H:%M:%S')}"
                          f" 通道正常 ✅"}})
        err = _err_msg(resp)
        return (False, err) if err else (True, "测试消息已发送，请到群里查看")
    except Exception as e:
        return False, f"发送失败：{e}"
