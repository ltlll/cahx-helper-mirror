"""自动定位《长安幻想》客户端与 Sandboxie 的安装路径（注册表优先，文件系统兜底）。

为什么需要：config.yaml 的 ``login.game_exe`` / ``login.sandboxie_start`` 原本必须写死
本机绝对路径，换一台机器、换一个盘符、或者对方装的是另一代 Sandboxie，都得手改配置，
打包分发出去等于没配。本模块把这些路径变成「配置留空即自动探测」。

两类目标各有两种形态，都要覆盖：

游戏客户端（官方两套启动器留下的两种安装结构，与"Plus 与否"无关）
  * launcher 版：``<安装目录>\\Game\\cahx\\cahx-win.exe``
    来自诗悦官方 ``launcher.exe``（卸载项 ``长安幻想.<n>.release``，在 HKCU）。
  * starter 版：``<安装目录>\\Starter_Data\\cahx-win\\cahx-win.exe``
    来自"长安幻想启动器" ``Starter.exe``（它把游戏下载到自己的 ``Starter_Data`` 下，
    并在 ``HKCU\\SOFTWARE\\shiyue\\Starter`` 记下 ``KeyExePath_*`` / ``KeyGameInstallPath_*``）。

Sandboxie（两代产品，Start.exe 位置不同）
  * Sandboxie-Plus（新版，开源）→ ``<安装目录>\\Start.exe``，目录名通常含 ``Sandboxie-Plus``
  * 经典 Sandboxie（5.x，非 Plus）→ ``<安装目录>\\Start.exe``
  两者都装同名服务 ``SbieSvc``，其 ``ImagePath`` 指向安装目录 —— 这是最通用的锚点，
  不必先知道对方装的是哪一代。

所有探测都是只读（winreg + os.path.isfile），任何一步失败都安静跳过；
最终找不到就返回空结果，调用方回退到 config 里写死的路径。
"""

from __future__ import annotations

import logging
import os
import string
from dataclasses import dataclass
from pathlib import Path

try:
    import winreg
except ImportError:  # pragma: no cover - 非 Windows 平台
    winreg = None

log = logging.getLogger("locate")

GAME_EXE_NAME = "cahx-win.exe"
SANDBOXIE_EXE_NAME = "Start.exe"

# 游戏主程序在安装目录下的几种相对位置（按命中优先级）
GAME_TAILS: tuple[tuple[str, ...], ...] = (
    ("Game", "cahx", GAME_EXE_NAME),
    (GAME_EXE_NAME,),
    ("Starter_Data", "cahx-win", GAME_EXE_NAME),
)

# 游戏安装目录的常见位置（注册表没线索时兜底）
_GAME_DIR_TAILS = (
    (r"Program Files", "长安幻想"),
    (r"Program Files (x86)", "长安幻想"),
    (r"Program Files", "cahx"),
    (r"Program Files (x86)", "cahx"),
)
# Sandboxie 安装目录的常见位置
_SBIE_DIR_TAILS = (
    (r"Program Files", "Sandboxie-Plus"),
    (r"Program Files", "Sandboxie"),
    (r"Program Files (x86)", "Sandboxie-Plus"),
    (r"Program Files (x86)", "Sandboxie"),
)

_UNINSTALL_KEY = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"
_SBIE_SERVICE = r"SYSTEM\CurrentControlSet\Services\SbieSvc"
_SHIYUE_STARTER = r"SOFTWARE\shiyue\Starter"

# WOW64 视图：64 位与 32 位安装都要看（经典 Sandboxie 5.x 常是 32 位）
_VIEWS = ((winreg.KEY_WOW64_64KEY, "64"), (winreg.KEY_WOW64_32KEY, "32")) if winreg else ()


@dataclass
class Found:
    """一条探测结果。path 为 None 表示没找到。"""

    path: str | None = None
    source: str = ""      # 线索来源，排查时一眼看出是从哪找到的
    edition: str = ""     # sandboxie: "plus" / "classic"；游戏: "launcher" / "starter"
    note: str = ""        # 细节备注（如命中的相对路径）

    def __bool__(self) -> bool:
        return bool(self.path)


# --------------------------------------------------------------------------- 工具


def _as_text(value) -> str:
    """注册表值可能是 str 或 bytes（Unity PlayerPrefs 存的是 UTF-16 字节串）。"""
    if isinstance(value, bytes):
        for enc in ("utf-16-le", "utf-8", "gbk"):
            try:
                return value.decode(enc).rstrip("\x00")
            except UnicodeDecodeError:
                continue
        return value.decode("utf-8", "ignore").rstrip("\x00")
    return "" if value is None else str(value)


def _clean(raw) -> str:
    """去掉引号与 ``,0`` 图标索引后缀，得到干净的路径字符串。"""
    s = _as_text(raw).strip().strip('"').strip()
    if "," in s:
        head, _, tail = s.rpartition(",")
        if tail.strip().isdigit():
            s = head.strip().strip('"')
    return s.strip()


def _resolve_game_dir(directory, source: str) -> Found:
    """在候选目录下按 GAME_TAILS 找 cahx-win.exe。"""
    if not directory:
        return Found()
    p = Path(directory)
    for tail in GAME_TAILS:
        f = p.joinpath(*tail)
        try:
            if f.is_file():
                return Found(str(f), source, "launcher" if tail[0] == "Game" else "starter",
                             "/".join(tail))
        except OSError:
            continue
    return Found()


def _resolve_sandboxie_dir(directory, source: str) -> Found:
    if not directory:
        return Found()
    start = Path(directory) / SANDBOXIE_EXE_NAME
    try:
        if start.is_file():
            edition = "plus" if "plus" in str(directory).lower() else "classic"
            return Found(str(start), source, edition)
    except OSError:
        pass
    return Found()


def _uninstall_entries():
    """遍历 HKCU/HKLM × 32/64 位视图的所有卸载项。

    产出 (子键名, 值字典, 来源标签)。
    """
    if not winreg:
        return
    for hive, hive_name in ((winreg.HKEY_CURRENT_USER, "HKCU"),
                            (winreg.HKEY_LOCAL_MACHINE, "HKLM")):
        for view, view_name in _VIEWS:
            try:
                root = winreg.OpenKey(hive, _UNINSTALL_KEY, 0, winreg.KEY_READ | view)
            except OSError:
                continue
            try:
                count = winreg.QueryInfoKey(root)[0]
                for i in range(count):
                    try:
                        sub_name = winreg.EnumKey(root, i)
                        sub = winreg.OpenKey(root, sub_name, 0, winreg.KEY_READ | view)
                    except OSError:
                        continue
                    values = {}
                    try:
                        for j in range(winreg.QueryInfoKey(sub)[1]):
                            n, v, _ = winreg.EnumValue(sub, j)
                            values[n] = v
                    except OSError:
                        pass
                    yield sub_name, values, f"{hive_name}({view_name})\\...\\Uninstall\\{sub_name}"
            finally:
                try:
                    root.Close()
                except OSError:
                    pass


def _drive_roots():
    """本机存在的盘符根目录（兜底扫描用，isdir 开销可忽略）。"""
    for letter in string.ascii_uppercase:
        root = f"{letter}:\\"
        try:
            if os.path.isdir(root):
                yield root
        except OSError:
            continue


# ------------------------------------------------------------------- 游戏客户端


def _game_from_shiyue_starter() -> Found:
    """长安幻想启动器（Starter.exe）把游戏装在哪，它自己记在 HKCU\\SOFTWARE\\shiyue\\Starter。

    Unity PlayerPrefs 的键名带哈希后缀（``KeyExePath_h2253764455``），哈希由键名算出、
    跨版本稳定，但仍统一用前缀匹配，避免哪天后缀规则变了就失效。
    """
    if not winreg:
        return Found()
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, _SHIYUE_STARTER, 0, winreg.KEY_READ)
    except OSError:
        return Found()
    exe_cands, dir_cands = [], []
    try:
        for i in range(winreg.QueryInfoKey(key)[1]):
            name, value, _ = winreg.EnumValue(key, i)
            raw = _clean(value)
            if not raw:
                continue
            if name.startswith("KeyExePath"):
                exe_cands.append((raw, name))
            elif name.startswith("KeyGameInstallPath"):
                dir_cands.append((raw, name))
    except OSError:
        pass
    finally:
        try:
            key.Close()
        except OSError:
            pass

    for raw, name in exe_cands:
        try:
            if Path(raw).is_file():
                return Found(str(Path(raw)), f"HKCU\\SOFTWARE\\shiyue\\Starter\\{name}",
                             "starter")
        except OSError:
            continue
    for raw, name in dir_cands:
        found = _resolve_game_dir(raw, f"HKCU\\SOFTWARE\\shiyue\\Starter\\{name}")
        if found:
            return found
    return Found()


def _game_from_uninstall() -> Found:
    """从卸载项找游戏：DisplayIcon/InstallLocation/UninstallString 都试。"""
    for sub_name, values, source in _uninstall_entries():
        name = _as_text(values.get("DisplayName", ""))
        if "长安幻想" not in name and "cahx" not in sub_name.lower():
            continue
        for field_name in ("DisplayIcon", "InstallLocation", "UninstallString"):
            raw = _clean(values.get(field_name, ""))
            if not raw:
                continue
            p = Path(raw)
            directory = p.parent if p.suffix.lower() == ".exe" else p
            found = _resolve_game_dir(directory, f"{source}\\{field_name}")
            if found:
                return found
    return Found()


def _game_from_common_dirs() -> Found:
    """常见安装位置兜底（含各盘符 Program Files）。"""
    for root in _drive_roots():
        for tail in _GAME_DIR_TAILS:
            found = _resolve_game_dir(os.path.join(root, *tail), f"{root}{os.sep.join(tail)}")
            if found:
                return found
    for env in ("ProgramFiles", "ProgramFiles(x86)"):
        base = os.environ.get(env)
        if not base:
            continue
        for tail in _GAME_DIR_TAILS:
            found = _resolve_game_dir(os.path.join(base, *tail[1:]), f"%{env}%\\{tail[-1]}")
            if found:
                return found
    return Found()


def find_game_exe() -> Found:
    """自动定位游戏主程序 cahx-win.exe。找不到返回空 Found。"""
    for probe in (_game_from_shiyue_starter, _game_from_uninstall, _game_from_common_dirs):
        found = probe()
        if found:
            return found
    return Found()


# --------------------------------------------------------------------- Sandboxie


def _sandboxie_from_service() -> Found:
    """SbieSvc 服务的 ImagePath —— Plus 与经典版都有，是最通用的锚点。"""
    if not winreg:
        return Found()
    try:
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, _SBIE_SERVICE, 0, winreg.KEY_READ)
    except OSError:
        return Found()
    try:
        image, _ = winreg.QueryValueEx(key, "ImagePath")
    except OSError:
        try:
            key.Close()
        except OSError:
            pass
        return Found()
    try:
        key.Close()
    except OSError:
        pass
    exe = _clean(image)
    if not exe.lower().endswith(".exe"):
        # 形如 \??\D:\...\SbieDrv.sys 的情况不适用
        return Found()
    return _resolve_sandboxie_dir(Path(exe).parent,
                                  f"HKLM\\{_SBIE_SERVICE}\\ImagePath")


def _sandboxie_from_uninstall() -> Found:
    """卸载项：Sandboxie-Plus_is1（Inno Setup）或 Sandboxie（经典版）。"""
    for sub_name, values, source in _uninstall_entries():
        low = sub_name.lower()
        name = _as_text(values.get("DisplayName", ""))
        if not ("sandboxie" in low or "sandboxie" in name.lower()):
            continue
        for field_name in ("InstallLocation", "DisplayIcon", "UninstallString"):
            raw = _clean(values.get(field_name, ""))
            if not raw:
                continue
            p = Path(raw)
            directory = p.parent if p.suffix.lower() == ".exe" else p
            found = _resolve_sandboxie_dir(directory, f"{source}\\{field_name}")
            if found:
                return found
    return Found()


def _sandboxie_from_registry_key() -> Found:
    """经典 Sandboxie 会写 HKLM\\SOFTWARE\\Sandboxie（含 InstallLocation）。"""
    if not winreg:
        return Found()
    for sub in (r"SOFTWARE\Sandboxie", r"SOFTWARE\WOW6432Node\Sandboxie"):
        try:
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, sub, 0, winreg.KEY_READ)
        except OSError:
            continue
        try:
            for field_name in ("InstallLocation", "InstallDir", "InstallPath"):
                try:
                    raw, _ = winreg.QueryValueEx(key, field_name)
                except OSError:
                    continue
                found = _resolve_sandboxie_dir(_clean(raw), f"HKLM\\{sub}\\{field_name}")
                if found:
                    return found
        finally:
            try:
                key.Close()
            except OSError:
                pass
    return Found()


def _sandboxie_from_common_dirs() -> Found:
    for root in _drive_roots():
        for tail in _SBIE_DIR_TAILS:
            found = _resolve_sandboxie_dir(os.path.join(root, *tail),
                                           f"{root}{os.sep.join(tail)}")
            if found:
                return found
    return Found()


def find_sandboxie_start() -> Found:
    """自动定位 Sandboxie 的 Start.exe（返回值 edition 区分 plus / classic）。"""
    for probe in (_sandboxie_from_service, _sandboxie_from_uninstall,
                  _sandboxie_from_registry_key, _sandboxie_from_common_dirs):
        found = probe()
        if found:
            return found
    return Found()


# ------------------------------------------------------------------ 诊断入口


def diagnose() -> str:
    """把两条探测链的每一步结果都打出来（排查用，不影响主流程）。"""
    lines = []
    game = find_game_exe()
    lines.append("游戏主程序 cahx-win.exe:")
    if game:
        lines.append(f"    OK  {game.path}")
        lines.append(f"        来源={game.source}  结构={game.edition}  相对位置={game.note}")
    else:
        lines.append("    未找到（将回退 config.yaml 的 login.game_exe）")

    sbie = find_sandboxie_start()
    lines.append("Sandboxie Start.exe:")
    if sbie:
        lines.append(f"    OK  {sbie.path}")
        lines.append(f"        来源={sbie.source}  版本={sbie.edition}")
    else:
        lines.append("    未找到（将回退 config.yaml 的 login.sandboxie_start）")
    lines.append("")
    lines.append("各线索明细:")
    steps = (
        ("游戏/启动器记录", _game_from_shiyue_starter),
        ("游戏/卸载项", _game_from_uninstall),
        ("游戏/常见目录", _game_from_common_dirs),
        ("沙盘/SbieSvc 服务", _sandboxie_from_service),
        ("沙盘/卸载项", _sandboxie_from_uninstall),
        ("沙盘/注册表键", _sandboxie_from_registry_key),
        ("沙盘/常见目录", _sandboxie_from_common_dirs),
    )
    for label, fn in steps:
        found = fn()
        detail = found.path if found else "—"
        extra = f"  [{found.source}]" if found else ""
        lines.append(f"    {label:<16} {detail}{extra}")
    return "\n".join(lines)


# --------------------------------------------------------- config 接入


# 配置里写这些值等于「请自动探测」
_AUTO_TOKENS = {"", "auto", "自动", "auto-detect", "autodetect", "none"}


def _is_auto(raw) -> bool:
    """判断配置值是否表示"自动探测"。"""
    if raw is None:
        return True
    return str(raw).strip().lower() in _AUTO_TOKENS


def _resolve_one(raw, finder, field: str, label: str, required: bool) -> str | None:
    """按「手写值优先、不存在才探测」的规则定出一个路径。

    required=True（游戏主程序）时必须拿到结果，否则返回 None 让调用方报错；
    required=False（Sandboxie，可能装了也不用）只记一条日志。
    """
    if not _is_auto(raw):
        configured = str(raw).strip()
        try:
            if Path(configured).exists():
                return configured
        except OSError:
            pass
        log.warning("config.yaml 的 login.%s 指向的路径不存在（%s），改为自动探测",
                    field, configured)
    found = finder()
    if found:
        log.info("自动定位 %s：%s（来源：%s%s）", label, found.path, found.source,
                 f"，版本：{found.edition}" if found.edition else "")
        return found.path
    if required:
        log.error("未能自动找到%s，请在 config.yaml 的 login.%s 里手动填写完整路径",
                  label, field)
    else:
        log.info("未找到%s（若全部客户端都用直接启动模式，可忽略）", label)
    return None


def apply_login_paths(config) -> dict:
    """就地补全 config["login"] 的 game_exe / sandboxie_start，返回 login 段。

    规则：配置里写死的路径**存在就优先用**（老用户行为完全不变）；留空、删掉或写
    ``auto`` 时自动探测。探测结果只作用于内存，不会写回 config.yaml。
    """
    login = config.setdefault("login", {}) if isinstance(config, dict) else {}

    game = _resolve_one(login.get("game_exe"), find_game_exe,
                        "game_exe", "游戏主程序 cahx-win.exe", required=True)
    if game:
        login["game_exe"] = game

    sbie = _resolve_one(login.get("sandboxie_start"), find_sandboxie_start,
                        "sandboxie_start", "Sandboxie Start.exe", required=False)
    if sbie:
        login["sandboxie_start"] = sbie
    return login


if __name__ == "__main__":
    print(diagnose())
