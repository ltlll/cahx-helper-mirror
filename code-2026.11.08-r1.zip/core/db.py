"""账号数据的本地存储（SQLite）。

账号记录字段：
    account      登录账号（手机号，登录时与登录框脱敏号比对）
    server       区服（如 瑞雪兆丰年）
    character    角色名（登录时用于 OCR/模板匹配选角色）
    role         职业分类：封印 / 奶妈 / 输出（任务按分类做差异化操作）
    pwd2         二级密码（整理背包出售触发"安全锁"时自动输入）
    hwnd         绑定的客户端窗口句柄（0=未绑定；程序自己拉起的客户端登录时
                 自动绑定；手动打开的客户端顺序不可靠，需在 GUI 里鼠标指定）
    launch_mode  启动方式: direct 直连 / sandbox 沙盒
    sandbox_box  沙盒名（launch_mode=sandbox 时有效）
    remark       备注
    sort_order   显示/登录顺序（并行登录按此顺序与窗口从左到右配对，
                 任务执行同样按此配对 hwnd，因此账号的职业标记
                 对各客户端窗口生效）

注意：**账号库不再有"队长"字段**（2026-10-11 用户要求）。队长是"这一次运行"的
属性，由「开始任务」向导第 1 步或一条龙方案在运行时指定，写进内存里的
`acc["is_captain"]`，不落库（老库可能残留 is_captain 列，代码已不再读写）。
"""
import sqlite3

from core.paths import DATA_DIR

DB_PATH = DATA_DIR / "accounts.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    account TEXT NOT NULL,
    server TEXT NOT NULL,
    character TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT '输出',
    cls TEXT NOT NULL DEFAULT '',
    pwd2 TEXT NOT NULL DEFAULT '',
    hwnd INTEGER NOT NULL DEFAULT 0,
    launch_mode TEXT NOT NULL DEFAULT 'direct',
    sandbox_box TEXT NOT NULL DEFAULT '',
    remark TEXT NOT NULL DEFAULT '',
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);
"""

FIELDS = ("account", "server", "character", "role", "cls", "pwd2", "hwnd",
          "launch_mode", "sandbox_box", "remark")
COLUMNS = ("id", "account", "server", "character", "role", "cls", "pwd2",
           "hwnd", "launch_mode", "sandbox_box", "remark", "sort_order")


def _conn():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    cols = {r[1] for r in conn.execute("PRAGMA table_info(accounts)")}
    if "sort_order" not in cols:  # 老库迁移：按 id 顺序初始化
        conn.execute("ALTER TABLE accounts ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0")
        conn.execute("UPDATE accounts SET sort_order = id")
    if "role" not in cols:  # 老库迁移：默认输出
        conn.execute("ALTER TABLE accounts ADD COLUMN role TEXT NOT NULL DEFAULT '输出'")
    if "cls" not in cols:  # 2026-10-12：职业升级为实际门派（空 = 未指定，role 仍存分类）
        conn.execute("ALTER TABLE accounts ADD COLUMN cls TEXT NOT NULL DEFAULT ''")
    if "pwd2" not in cols:
        conn.execute("ALTER TABLE accounts ADD COLUMN pwd2 TEXT NOT NULL DEFAULT ''")
    if "hwnd" not in cols:
        conn.execute("ALTER TABLE accounts ADD COLUMN hwnd INTEGER NOT NULL DEFAULT 0")
    conn.commit()
    return conn


def add_account(account, server, character, role="输出", cls="", pwd2="",
                hwnd=0, launch_mode="direct", sandbox_box="", remark=""):
    with _conn() as conn:
        cur = conn.execute(
            "INSERT INTO accounts (account, server, character, role, cls, pwd2,"
            " hwnd, launch_mode, sandbox_box, remark, sort_order)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?,"
            " (SELECT COALESCE(MAX(sort_order), 0) + 1 FROM accounts))",
            (account, server, character, role, cls, pwd2, hwnd, launch_mode,
             sandbox_box, remark),
        )
        return cur.lastrowid


def list_accounts():
    with _conn() as conn:
        return [dict(r) for r in conn.execute(
            f"SELECT {', '.join(COLUMNS)} FROM accounts ORDER BY sort_order, id")]


def get_account(account_id):
    with _conn() as conn:
        row = conn.execute(
            f"SELECT {', '.join(COLUMNS)} FROM accounts WHERE id = ?", (account_id,)).fetchone()
        return dict(row) if row else None


def update_account(account_id, **fields):
    sets = ", ".join(f"{k} = ?" for k in fields if k in FIELDS)
    vals = [v for k, v in fields.items() if k in FIELDS]
    if not sets:
        return
    with _conn() as conn:
        conn.execute(f"UPDATE accounts SET {sets} WHERE id = ?", (*vals, account_id))


def set_account_order(ordered_ids):
    """按给定 id 列表顺序写回 sort_order（1..N），一个事务内完成。"""
    with _conn() as conn:
        conn.executemany("UPDATE accounts SET sort_order = ? WHERE id = ?",
                         [(i, acc_id) for i, acc_id in enumerate(ordered_ids, 1)])


def delete_account(account_id):
    with _conn() as conn:
        conn.execute("DELETE FROM accounts WHERE id = ?", (account_id,))
