"""定时任务条目的本地存储（data/schedules.json，gitignore）。

条目结构：
    id        自增 id
    name      显示名（如 "每日一条龙"）
    time      "HH:MM"（每天本地时间到点触发，仅 GUI 开着时生效）
    accounts  账号 id 列表（db.accounts.id）
    tasks     任务名列表；["*"] 表示一条龙（按 config.yaml 顺序全量执行）
    type      yitiaolong=一条龙 / custom=定时小任务 / dishu=打地鼠（限时，
              12:00/18:00 整点刷新，只跑 5开组队+打地鼠，建议提前 5~10 分钟触发）
    enabled   是否启用
    last_run  上次触发日期 "YYYY-MM-DD"（空串=从未触发；防当天重复触发）
"""
import json

from core.paths import DATA_DIR

SCHEDULES_PATH = DATA_DIR / "schedules.json"


def load_schedules():
    if not SCHEDULES_PATH.exists():
        return []
    try:
        return json.loads(SCHEDULES_PATH.read_text(encoding="utf-8"))
    except Exception:
        return []


def save_schedules(entries):
    SCHEDULES_PATH.parent.mkdir(parents=True, exist_ok=True)
    SCHEDULES_PATH.write_text(json.dumps(entries, ensure_ascii=False, indent=2),
                              encoding="utf-8")


def next_id(entries):
    return max((e.get("id", 0) for e in entries), default=0) + 1
