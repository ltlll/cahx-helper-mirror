# -*- coding: utf-8 -*-
"""运行中「整窗失灵」看门狗（core/clientwatch.py，2026-10-29）

背景（当天 05:30 一轮的实战教训）：沙盒客户端会进入一种很难靠单点判据识别的
运行态故障——

    渲染正常（截图里主城、左列图标、右上角头像全在）
    IsHungAppWindow=0（窗口没挂起，不像 preflight 处理的那种假死）
    点击落点守卫全过（GA_ROOTOWNER 命中本窗口，点击确实发出去了）
    模板匹配 score 0.97~1.00（按钮就在画面上）
    但客户端**不响应任何点击** → 每个任务都死在"等某个面板/模板出现"上

结果是两个号各 16/18 项全灭，还因为队长号卡在组队里，把 5 个号的组队任务
连坐成 15 例失败。这类客户端换个新的就好（同一批客户端全部重启后，下一轮
同样两个沙盒号 22/22、21/21 全成），所以问题只在于**什么时候认识到它坏了**。

登录期已经有 core/login_flow.py 的 ui_broken（看右上角「任务/队伍」页签），
但它只能覆盖"一进游戏就残废"的情况；本模块补的是"跑着跑着失灵"。

判据（刻意放宽召回、用两道闸门压住误杀）：
  1. 任务失败（TaskSkipped/Exception 都算）且该任务期间这台设备有
     ≥ misses 次"输入层失败信号"（= Matcher.wait_for 超时，见 Device
     .note_input_miss）——单个信号说明不了问题，可能是真没办成这一步；
  2. **连续** consecutive 个任务都这样，且窗口不挂起（挂起是另一类故障，
     由 preflight/launcher 的关窗重启处理，别混进来）；
  3. 最后用探针 `task.probe_input_alive()` 真去点一下主界面图标确认：
     面板开不了才判死。**不在主界面时探针返回 True（不判死）**——宁可让一个
     号多跑几个失败任务，也绝不误关正常客户端（误关要重登几分钟）。

场景失联判据（2026-11-08 7 号事故补）：任务困在**画面完全无法识别**的状态
（如全屏聊天面板盖住 HUD）时，settle_scene 反复「未识别场景」判负——这种
失败**不产生 wait_for 超时信号**（判据 1 永远不满足），且探针不在主界面必然
放行（判据 3 永远拦住），7 号当天陷在聊天面板 4.5h、拖死 12 例组队就是这两
个盲区叠加。现由 settle_scene 判负时打 `task._scene_lost` 标记 + 记一次
note_input_miss，本模块新增判据 0：**连续 scene_consecutive 个失败任务都带
场景失联标记 → 直接判死换新客户端，不走探针**（画面都识别不出来，探针无处
下手；换新有 max_relaunch 限额，误杀代价=重登几分钟，远小于连坐）。

本模块不做任何动作（不关窗、不重登），只给出判定；动作由 core/runner.py
（换新客户端 + 重建 Device）执行——这样判据可以纯桩测。

自检：debug/_verify_client_dead_watchdog.py
"""
from __future__ import annotations

import logging

log = logging.getLogger("gui")


class InputDeadWatch:
    """单账号一台设备的失灵判定器。用法（runner 内）：

        watch = InputDeadWatch(consecutive=3, misses=1, max_relaunch=2,
                               character=acc["character"])
        ... 每个任务开始无需特殊处理；失败时：
        if watch.judge(device, task=task):
            # 关窗换新客户端 → 成功后 watch.note_relaunch_ok()
            ...
        成功时：watch.note_ok(device)
    """

    def __init__(self, consecutive=3, misses=1, max_relaunch=2,
                 enabled=True, character="", scene_consecutive=4):
        self.consecutive = max(1, int(consecutive or 1))
        self.misses = max(1, int(misses or 1))
        self.max_relaunch = max(0, int(max_relaunch or 0))
        self.enabled = bool(enabled)
        self.character = character or ""
        # 场景失联判据阈值（判据 0，见模块 docstring）；<=0 关闭该判据
        self.scene_consecutive = int(scene_consecutive or 0)
        self.suspect = 0        # 连续"疑似输入失灵"的任务数
        self.scene_streak = 0   # 连续"场景失联"的失败任务数
        self.relaunched = 0     # 本轮已换过几次客户端

    # ---- 运行 ----

    def note_ok(self, device):
        """任务成功：清掉这台设备这轮的输入失灵计数与连续嫌疑。"""
        self.suspect = 0
        self.scene_streak = 0
        try:
            device.take_input_misses()
        except Exception:
            pass

    def judge(self, device, task=None):
        """任务失败后调用。返回 True = 判定整窗失灵，调用方应换新客户端（
        换新成功后调用 note_relaunch_ok / 失败调用 note_relaunch_fail）。"""
        if not self.enabled:
            return False
        if self.relaunched >= self.max_relaunch:
            return False   # 额度和 permits：本轮不再折腾客户端
        # ---- 判据 0：连续 N 个失败任务都死于「未识别场景」----
        # 不看输入 miss 计数（settle_scene 判负路径已补记一次，但那种任务
        # 也可能没有 wait_for 超时）、不跑探针（不在主界面探针必然放行）。
        if self.scene_consecutive > 0 and task is not None \
                and getattr(task, "_scene_lost", False):
            self.scene_streak += 1
            if self.scene_streak >= self.scene_consecutive:
                log.error("%s 连续 %d 个任务死于「未识别场景」（settle_scene 判负）"
                          "—— 画面完全无法识别，判定客户端状态坏死，换新客户端",
                          _tag(self.character), self.scene_streak)
                return True
            log.warning("%s 场景失联 %d/%d（本任务 settle_scene 判负，未识别场景）",
                        _tag(self.character), self.scene_streak,
                        self.scene_consecutive)
        else:
            # 普通失败（非场景失联）：严格"连续"语义，重置
            self.scene_streak = 0
        try:
            misses = device.take_input_misses()
        except Exception:
            misses = []
        # 窗口挂起不是"整窗失灵"：那是 another failure mode（ Hung 窗口由
        # launcher.force_close_window / preflight 处理），这里必须排除。
        hung = False
        try:
            hung = bool(device.is_hung())
        except Exception:
            hung = False
        if len(misses) < self.misses or hung:
            self.suspect = 0
            if hung:
                log.info("%s 窗口已挂起，不计入整窗失灵嫌疑（另一类故障）",
                         _tag(self.character))
            return False
        self.suspect += 1
        if self.suspect < self.consecutive:
            log.warning("%s 疑似输入失灵 %d/%d（本任务 %d 次面板/模板未到位）",
                        _tag(self.character), self.suspect, self.consecutive,
                        len(misses))
            return False
        # 最后一道确认：真点一下主界面图标，看面板开不开
        alive = True
        if task is not None:
            try:
                alive = bool(task.probe_input_alive())
            except Exception:
                alive = True   # 探针自己异常 → 按活着处理，不误杀
        if alive:
            log.warning("%s 已连续 %d 个任务卡在面板/模板，但输入存活探针通过——"
                        "按任务自身问题处理，不换客户端",
                        _tag(self.character), self.suspect)
            self.suspect = 0
            return False
        log.error("%s 连续 %d 个任务都卡在「面板打不开/找不到模板」且窗口未挂起，"
                  "输入存活探针也失败 —— 判定客户端整窗失灵",
                  _tag(self.character), self.suspect)
        return True

    # ---- 换新结算 ----

    def begin_relaunch(self):
        self.relaunched += 1
        self.suspect = 0
        self.scene_streak = 0
        return self.relaunched

    def note_relaunch_ok(self):
        self.suspect = 0
        self.scene_streak = 0

    def note_relaunch_fail(self):
        """换新失败：本轮不再重试（避免每个任务都触发一次冷启动）。"""
        self.suspect = 0
        self.scene_streak = 0
        self.relaunched = self.max_relaunch


def _tag(character):
    return f"账号 {character}" if character else "该账号"
