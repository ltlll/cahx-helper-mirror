# -*- coding: utf-8 -*-
"""拟人化节奏（用户规则 2026-10-13：不需要拟人延迟——"我自己手点的比这快"）。

背景：组队/离队这类流程里散落着大量"点一下等 1~1.5 秒""发完邀请等 5~8 秒"
的固定等待，5 开串起来就是几分钟。这些等待原本是为了拟人化/等界面动画，
现在统一收到这里，由 config.yaml 的一个倍率控制：

    delay:
      click_min/click_max      每次点击后的停顿（Device 直接读，见 core/device.py）
      pace_scale               流程内固定等待的倍率（本模块）

用法：把 ``time.sleep(random.uniform(a, b))`` 换成 ``pace.wait(a, b)``，
把等界面的 ``time.sleep(3)`` 换成 ``pace.wait(3)``（都会乘倍率）。

原则（改这里前先读）：
- **等"条件"不要等"时间"**：能轮询的（面板出现/弹窗消失）优先轮询，
  wait() 只用于"必须给游戏一点渲染时间"的地方；
- 游戏侧硬冷却（离队后 60 秒不能建队等）**不走倍率**，那些是游戏限制；
- 倍率来自配置，出问题改 config.yaml 即可，不用改代码。
"""
import logging
import random
import time

log = logging.getLogger("pace")

DEFAULT_SCALE = 0.3      # 配置读不到时的保守值（比真人手速略慢，但不至于拖流程）
_scale = None            # 惰性读配置后缓存


def scale(value):
    """把秒数按倍率缩放（0 倍率至少留 0.02s，避免变成纯忙等）。"""
    s = current()
    return max(0.02, float(value) * s) if value else 0.0


def set_scale(value):
    """强制设定倍率（测试/工具脚本用；None = 恢复读配置）。"""
    global _scale
    try:
        _scale = None if value is None else max(0.0, float(value))
    except (TypeError, ValueError):
        _scale = None


def current():
    """当前倍率：显式设置的优先，否则读 config.yaml 的 delay.pace_scale。"""
    global _scale
    if _scale is not None:
        return _scale
    try:
        import yaml
        from core.paths import CONFIG_PATH
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f) or {}
        v = (cfg.get("delay") or {}).get("pace_scale")
        _scale = DEFAULT_SCALE if v is None else max(0.0, float(v))
    except Exception:
        _scale = DEFAULT_SCALE
    return _scale


def wait(lo, hi=None):
    """流程等待：``wait(1.0, 1.5)`` 或 ``wait(3)``（都按倍率缩放）。

    返回实际等待时长（秒），便于日志/耗时统计核对。
    """
    span = float(lo) if hi is None else random.uniform(float(lo), float(hi))
    secs = scale(span)
    if secs > 0:
        time.sleep(secs)
    return secs
