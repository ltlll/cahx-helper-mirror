# -*- coding: utf-8 -*-
"""任务执行 worker 子进程的 GUI 侧客户端（core/workerclient.py，2026-10-25）

零 Qt 依赖（事件经回调抛出，GUI 层自己用 Qt 信号桥到 UI 线程）。

- `ensure_started()`：懒启动常驻 worker（打包 = `exe --worker`，
  开发 = `python boot.py --worker`，两条路都经 boot 派发，热更版本一致）；
  进程死了下次 send/ensure 自动重生。
- `send({...})`：一行 JSON 写 stdin。
- 读线程逐行解析 stdout：`CAHX1:` 前缀的协议行进 `on_event(dict)`，
  无前缀的杂散输出降级进日志；**EOF（worker 崩了/被杀）且非主动终止
  → on_event({"ev":"crashed"})**，GUI 据此收尸本轮并自动重生。
- `terminate()`：强制结束 = terminate（超时升级 kill）+ 补鼠标抬起
  （worker 可能死在拖拽中间态）+ 标记重生。
"""
from __future__ import annotations

import json
import logging
import subprocess
import sys
import threading
from pathlib import Path

log = logging.getLogger("gui")

PROTO_PREFIX = "CAHX1:"


def _spawn_cmd() -> list[str]:
    if getattr(sys, "frozen", False):
        return [sys.executable, "--worker"]
    root = Path(__file__).resolve().parent.parent
    return [sys.executable, str(root / "boot.py"), "--worker"]


class WorkerClient:
    def __init__(self):
        self._proc: subprocess.Popen | None = None
        self._lock = threading.Lock()
        self._stopping = False      # 主动 terminate/quit 期间 EOF 不算崩溃
        self.on_event = None        # callable(dict)，在**读线程**里回调
        self.hello_version = None

    # ------------------------------------------------------------ 生命周期

    def ensure_started(self):
        with self._lock:
            if self._proc is not None and self._proc.poll() is None:
                return
            cmd = _spawn_cmd()
            log.info("启动任务执行进程: %s", " ".join(cmd))
            self._stopping = False
            self._proc = subprocess.Popen(
                cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL, text=True, encoding="utf-8",
                errors="replace", bufsize=1)
            threading.Thread(target=self._reader, args=(self._proc,),
                             daemon=True).start()

    def terminate(self):
        """强制结束 worker（停止按钮第二阶段 / GUI 退出前清场）。"""
        with self._lock:
            proc = self._proc
        if proc is None or proc.poll() is not None:
            return
        self._stopping = True
        log.warning("强制结束任务执行进程（pid=%s）", proc.pid)
        try:
            proc.terminate()
            proc.wait(timeout=5)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass
        from core.device import force_mouse_up
        force_mouse_up()

    def shutdown(self):
        """GUI 退出前的礼貌关闭：先 quit 命令，不收敛再 terminate。"""
        try:
            self.send({"cmd": "quit"})
        except Exception:
            pass
        self.terminate()

    # ------------------------------------------------------------ 收发

    def send(self, cmd: dict):
        self.ensure_started()
        if cmd.get("cmd") == "quit":
            # quit 后的 EOF 是预期内退出，不算崩溃（须在 ensure_started 之后：
            # 重生会把 _stopping 复位为 False）
            self._stopping = True
        proc = self._proc
        try:
            proc.stdin.write(json.dumps(cmd, ensure_ascii=False,
                                        default=str) + "\n")
            proc.stdin.flush()
        except (OSError, ValueError) as e:
            log.warning("worker 管道写入失败（%s），重建进程", e)
            self._emit({"ev": "crashed", "detail": str(e)})

    def _emit(self, event: dict):
        cb = self.on_event
        if cb is not None:
            try:
                cb(event)
            except Exception:
                log.exception("worker 事件回调异常")

    def _reader(self, proc):
        try:
            for line in proc.stdout:
                line = line.rstrip("\n")
                if not line:
                    continue
                if not line.startswith(PROTO_PREFIX):
                    log.info("[worker] %s", line[:300])
                    continue
                try:
                    event = json.loads(line[len(PROTO_PREFIX):])
                except ValueError:
                    log.warning("worker 协议行解析失败: %r", line[:200])
                    continue
                if event.get("ev") == "hello":
                    self.hello_version = event.get("version")
                self._emit(event)
        except Exception:
            log.exception("worker 读线程异常")
        finally:
            rc = proc.poll()
            if not self._stopping:
                log.error("任务执行进程意外退出（rc=%s）", rc)
                self._emit({"ev": "crashed", "detail": f"rc={rc}"})
