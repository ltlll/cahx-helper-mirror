import logging
import random
import time

from core.logsetup import account_tag, fmt_duration, set_account
from tasks.base import AccountKicked, TaskSkipped, TaskStopped, TaskTimeout

log = logging.getLogger("scheduler")


def expand_followups(names, registry):
    """把任务的 FOLLOWUPS（跟随任务，如 huoyue→tidy_bag）展开进任务序列：
    紧跟在该任务之后；若序列里原本就紧随其后则不重复插入。未知任务名忽略。"""
    out = []
    for i, n in enumerate(names):
        out.append(n)
        cls = registry.get(n)
        nxt = names[i + 1] if i + 1 < len(names) else None
        for f in (getattr(cls, "FOLLOWUPS", ()) if cls else ()):
            if f not in registry:
                log.warning("跟随任务 %s 未注册，忽略", f)
                continue
            if f == nxt or out[-1] == f:
                continue
            out.append(f)
    return out


# 收尾任务统一排到全序列最后执行（用户规则 2026-10-14）："收尾任务在单人和
# 组队任务全部完成后再执行"。它们只依赖"背包里攒了什么"（整理背包/做烹饪吃
# 活力/领战令周礼），前置跑反而会因奖励还没入包而白跑一轮。
CLOSING_ORDER = ("tidy_bag", "cook", "zhanling")


def order_closing_tasks(names, registry):
    """把收尾任务（CLOSING_ORDER 里注册过的）原样后移到序列末尾，其余顺序不变。

    保持各收尾任务之间的既有相对顺序（稳定后移），不引入新任务、不删任务。
    """
    head = [n for n in names if n not in CLOSING_ORDER]
    tail = [n for n in names if n in CLOSING_ORDER]
    if tail:
        moved = [n for n in tail if n not in head]
        log.info("收尾任务后置：%s", "、".join(moved) or "（无需搬动）")
    return head + tail


def drop_unavailable_names(names, registry):
    """剔掉「流程未定稿」的任务名（`Task.available=False`，如「灵珠收集」两阶段），
    返回 (保留名单, 被剔名字)。GUI 账号线程与 Scheduler.run 共用同一判定。"""
    blocked = [n for n in names
               if not getattr(registry.get(n), "available", True)]
    if not blocked:
        return list(names), []
    return [n for n in names if n not in set(blocked)], blocked


def drop_unavailable(entries, registry):
    """同 drop_unavailable_names，但针对任务条目（dict 列表，含 name/enabled）。"""
    keep, blocked = drop_unavailable_names([t["name"] for t in entries], registry)
    kept = set(keep)
    return [t for t in entries if t["name"] in kept], blocked


class Scheduler:
    """按配置顺序执行任务，单个任务失败不影响后续任务。"""

    def __init__(self, device, matcher, config, account=None, stop_event=None):
        self.device = device
        self.matcher = matcher
        self.config = config
        self.account = account  # 当前窗口配对的账号记录（职业/队长），可空
        self.stop_event = stop_event  # threading.Event，GUI 停止按钮注入
        self._registry = self._load_tasks()

    @staticmethod
    def _load_tasks():
        from tasks.tidy_bag import TidyBag
        from tasks.yueka import Yueka
        from tasks.yueguang import YueguangBox
        from tasks.shouyi import Shouyi
        from tasks.zongmen import Zongmen
        from tasks.xunbao import Xunbao
        from tasks.liyao import Liyao
        from tasks.jingji import Jingji
        from tasks.zhongcai import Zhongcai
        from tasks.weimao import Weimao
        from tasks.paoshang import Paoshang
        from tasks.guild_shop import GuildShop
        from tasks.eat_cooking import EatCooking
        from tasks.eat_pet_food import EatPetFood
        from tasks.zudui import Zudui
        from tasks.haishi import Haishi
        from tasks.liudao import Liudao
        from tasks.zhongkui import Zhongkui
        from tasks.dishu import Dishu
        from tasks.huoyue import Huoyue
        from tasks.cook import Cook
        from tasks.zhanling import Zhanling
        from tasks.lingzhu import Lingzhu
        from tasks.shouli import Shouli
        # 注册顺序 = GUI 分组内的显示顺序（实际执行顺序取 config.yaml 的排列）。
        # 分组顺序：备战任务（整理背包/吃烹饪/吃宝宝烹饪）→ 日常 → 帮会 → 日常副本 → 收尾。
        return {cls.name: cls for cls in
                [TidyBag, EatCooking, EatPetFood,
                 Yueka, YueguangBox, Shouyi, Zongmen, Xunbao, Liyao, Jingji,
                 Weimao, Zhongcai,
                 Paoshang, GuildShop, Zudui, Haishi, Liudao,
                 Zhongkui, Dishu, Huoyue, Cook, Zhanling, Lingzhu, Shouli]}

    def run(self, task_configs):
        # 复制条目（避免改动调用方的 dict），并把顶层 task_timeout 作为各任务
        # 的默认硬超时（条目里写了 timeout 的以条目为准，见 Task._begin_timeout）。
        enabled = [dict(t) for t in task_configs if t.get("enabled")]
        # 流程未定稿的任务（如「灵珠收集」= 提交灵珠 + 接收灵珠）一律不执行：
        # GUI 任务页已置灰不可勾，但 config.yaml 被手工改成 enabled: true 时
        # 这里仍要拦住——半成品流程跑起来会动到真账号的资产。
        enabled, blocked = drop_unavailable(enabled, self._registry)
        if blocked:
            log.warning("以下任务流程未定稿（暂不可选），本轮跳过：%s", "、".join(blocked))
        default_timeout = self.config.get("task_timeout", 0)
        for t in enabled:
            t.setdefault("timeout", default_timeout)
        # FOLLOWUPS 跟随任务展开进序列（如活跃奖励领完固定接整理背包）
        names = expand_followups([t["name"] for t in enabled], self._registry)
        enabled = [next(t for t in enabled if t["name"] == n) for n in names]
        # 本轮日志自动带账号标签（命令行 main.py / tools/run_tasks.py 路径）
        tag = account_tag(self.account, getattr(self.device, "hwnd", None))
        set_account(tag)
        log.info("账号 %s 本轮任务 %d 个：%s", tag, len(enabled),
                 " → ".join(names) if names else "（无）")
        started = time.time()
        ok_count = 0
        failed = []
        timed_out = []
        stop_reason = "全部完成"
        opened = False   # 开场复位（回主界面 + 退队）本轮只做一次
        for entry in enabled:
            if self.stop_event is not None and self.stop_event.is_set():
                log.info("收到停止请求，剩余任务不再执行")
                stop_reason = "用户停止"
                break
            name = entry["name"]
            cls = self._registry.get(name)
            if cls is None:
                log.error("未知任务: %s，已跳过", name)
                failed.append(name)
                continue
            log.info("=== 开始任务: %s ===", name)
            task_t0 = time.time()
            try:
                task = cls(self.device, self.matcher, entry, account=self.account)
                task.stop_event = self.stop_event
                task.dismiss_popups()  # 任务开始前先清掉随机弹出的系统弹窗
                if not opened:
                    # 登录后的第一步：退出残留队伍（队员状态下切不了地图，
                    # 见 tasks/base.py::opening_reset）
                    opened = True
                    log.info("=== 开场复位：先退出残留队伍，再开始本轮任务 ===")
                    task.opening_reset()
                task.run()
                ok_count += 1
                log.info("=== 任务完成: %s (%.1fs) ===", name, time.time() - task_t0)
            except AccountKicked:
                log.warning("=== 账号被顶号（被迫下线），剩余任务跳过: %s ===", name)
                stop_reason = "被顶号下线"
                break
            except TaskSkipped as e:
                # 主动跳过但计入失败（如组队失败后副本未执行）：不重试、
                # 不留失败截图，继续下一个任务——小结里如实反映"没跑成"
                log.warning("=== 任务跳过（计入失败）: %s (%.1fs) —— %s ===",
                            name, time.time() - task_t0, e)
                failed.append(name)
            except TaskStopped:
                log.info("=== 任务已停止: %s ===", name)
                stop_reason = "用户停止"
                break
            except TaskTimeout:
                # 单项任务硬超时：任务已自行留存截图/问题日志并回主界面，这里只记录并继续下一项
                log.warning("=== 任务超时中止: %s (%.1fs)，已回主界面，继续下一个 ===",
                            name, time.time() - task_t0)
                timed_out.append(name)
            except Exception:
                log.exception("=== 任务异常: %s (%.1fs)，继续下一个 ===", name,
                              time.time() - task_t0)
                failed.append(name)
            d = self.config["delay"]
            time.sleep(random.uniform(d["between_tasks_min"], d["between_tasks_max"]))
        if failed or timed_out:
            log.warning("---- 账号小结 %s：成功 %d/%d，失败 %d 个 %s，超时 %d 个 %s，"
                        "用时 %s，结束原因：%s ----", tag, ok_count, len(enabled),
                        len(failed), failed, len(timed_out), timed_out,
                        fmt_duration(time.time() - started), stop_reason)
        else:
            log.info("---- 账号小结 %s：成功 %d/%d，失败 0，用时 %s，结束原因：%s ----",
                     tag, ok_count, len(enabled), fmt_duration(time.time() - started),
                     stop_reason)
        log.info("全部任务执行完毕")
