# -*- coding: utf-8 -*-
r"""跨进程输入互斥锁（core/xlock.py，2026-10-25）

背景：任务执行迁入独立 worker 子进程后，GUI 进程（登录/平铺/宏回放）与
worker 进程（任务点击）会**双进程抢同一只鼠标**。原 `Device._input_lock`
是进程内 threading.Lock，管不住别的进程。

本模块提供 `InputLock`：进程内 threading.Lock + Windows 命名互斥量
（`Local\cahx-helper-input-lock`）两层。关键性质：**持锁进程被 terminate
时 OS 自动释放互斥量**（另一方 WaitForSingleObject 拿到 WAIT_ABANDONED，
视为抢到并继续）——"强制结束 worker 后不会有孤儿锁卡死 GUI"靠的就是它。

用法与 threading.Lock 相同：`with InputLock(): ...`（Device 持有单例，
业务代码不直接用本模块）。
"""
from __future__ import annotations

import logging
import threading

import win32event
import win32con

log = logging.getLogger("gui")

MUTEX_NAME = r"Local\cahx-helper-input-lock"


class InputLock:
    """进程内线程锁 + 跨进程命名互斥量。接口与 threading.Lock 相同（with 可用）。"""

    def __init__(self, name: str = MUTEX_NAME):
        self._name = name
        self._local = threading.Lock()
        self._handle = None

    def _mutex(self):
        if self._handle is None:
            self._handle = win32event.CreateMutex(None, False, self._name)
        return self._handle

    def acquire(self):
        self._local.acquire()
        try:
            rc = win32event.WaitForSingleObject(self._mutex(), win32event.INFINITE)
            if rc == win32event.WAIT_ABANDONED:
                # 上一个持锁进程没释放就死了（被 terminate）：锁归我，继续
                log.warning("输入互斥量：上一个持锁进程异常退出，锁已接管")
        except Exception:
            self._local.release()
            raise

    def release(self):
        try:
            if self._handle is not None:
                win32event.ReleaseMutex(self._handle)
        except Exception:
            # 不是持锁者/句柄已失效：进程退出等场景，吞掉（本地锁照放）
            log.debug("ReleaseMutex 异常（可忽略）", exc_info=True)
        self._local.release()

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, *exc):
        self.release()
        return False
