"""宿主机沙盘（Sandboxie / Sandboxie-Plus）小工具。

目前只做一件事：把 Sandboxie-Plus 免费版的**捐赠提醒弹窗**永久关掉。

为什么需要它
------------
这个弹窗的判定逻辑写死在 Sandboxie 源码里（``SandboxiePlus/SandMan/Windows/
SupportDialog.cpp`` 的 ``CSupportDialog::CheckSupport``）：

  * 有有效支持者证书（``g_CertInfo.active``）→ 永不弹；
  * 安装不满 40 天 → 永不弹；
  * 其余情况先按安装时长算"间隔"（>730 天 12h / >365 天 24h / >182 天 5 天 /
    否则 30 天），间隔没到就跳过；**即使间隔到了，还有 1/5 的概率直接跳过**
    （``if ((rand() % 5) != 0) return false;``）。

所以免费版**没有**"关掉它"的开关——官方只有 ``AlwaysShowReminder=y`` 这个
**反向**开关（打开反而每次都弹）。见 2026-10-12 的排查记录。

关不掉它，就让它没机会弹
------------------------
弹窗只能由 ``SandMan.exe``（Qt 托盘 GUI）弹出：``CSandMan::OnBoxOpened`` 与
"在沙盒中运行"的请求处理里调用 ``CheckSupport``。``SbieSvc`` 是纯服务、没有
Qt，弹不了。**只要 SandMan 不常驻，就永远不会弹。**

于是「永久关闭」= 关掉 SandMan 的两条自启路径（正好对应 SandMan 设置页里
"Run Sandboxed - Actions" 下的两个勾选框，源码 ``SettingsWindow.cpp``）：

  1. ``Start UI with Windows``            → ``HKCU\\...\\CurrentVersion\\Run``
     里的 ``SandboxiePlus_AutoRun``（``AutorunEnable()`` 写的）；
  2. ``Start UI when a sandboxed process is started`` → ``Sandboxie.ini`` 的
     ``[UserSettings_<hash>]`` 段里的 ``SbieCtrl_EnableAutoStart``
     （``CSettingsWindow::ApplySettings`` 里 ``SetBool(..., false)``）。

本项目的客户端走 ``Start.exe /box:<名字>`` 直启沙盒，SandMan 只是界面/托盘，
关掉它沙盒照常工作；代价是没有托盘图标与沙盒主界面（要用时手动开 SandMan 即可，
开了之后仍有可能弹一次）。

需要管理员权限
--------------
``C:\\Windows\\Sandboxie.ini`` 的 ACL 是 ``BUILTIN\\Users:(I)(RX)``——**普通用户
只有读+执行，写不了**（2026-10-12 实测）。SandMan 自己之所以能改，是因为它把
配置交给 ``SbieSvc``（SYSTEM 服务）代写；我们没有那条通道（``SbieIni.exe`` 是给
沙盒内程序查询真实配置用的，在沙盒外无输出），所以**只能提权**。

于是 ``disable()`` / ``restore()`` 会先探测能不能写（真开一次 ``r+b`` 句柄），
写不了就用 ``ShellExecuteExW("runas")`` 重跑自身 CLI 子进程（``--sandbox-cli
<action>``，见 ``run_cli_action``），只弹一次 UAC。注册表那一步（HKCU Run）
本来就不需要管理员，但并到同一个提权进程里做，省一次往返。

安全性
------
* 改动前把 ``Sandboxie.ini`` 整份复制到 ``data/sandbox_backup/``，并把两条
  自启的原值记进 ``data/sandbox_backup.json``；``restore()`` 据此还原。
* **不碰** ``InstallationDate`` / ``LastReminder`` 这类 secure 参数——
  那是绕过作者刻意设计的捐赠机制，本项目不参与。
* 所有注册表操作都限死在 ``HKCU`` 的 ``Run`` 键里、且值名含 ``sandboxie``、
  值内容含 ``sandman``，不做任何宽匹配删除。
* UAC 被拒 / 超时都在返回值里说清楚，绝不静默。

命令行自检：``python -m core.sandbox_tools``（只打印状态）/ ``--disable`` /
``--restore``。
"""

from __future__ import annotations

import ctypes
import json
import logging
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path

try:
    import winreg
except ImportError:  # pragma: no cover - 非 Windows
    winreg = None

from core.paths import DATA_DIR, ROOT

log = logging.getLogger("sandbox_tools")

# HKCU 里的开机自启键（SandMan 的「Start UI with Windows」写的就是这里）
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"

# Sandboxie.ini 里跟"自动拉起 GUI"有关的两条键（段名固定为 UserSettings_<hash>）
INI_SECTION_PREFIX = "UserSettings_"
KEY_ENABLE = "SbieCtrl_EnableAutoStart"
KEY_AGENT = "SbieCtrl_AutoStartAgent"
AGENT_DEFAULT = "SandMan.exe -autorun"

BACKUP_DIR = DATA_DIR / "sandbox_backup"
BACKUP_JSON = DATA_DIR / "sandbox_backup.json"

# 提权子进程：父进程把动作与结果通过命令行 + 这个结果文件传递
# （ShellExecuteExW 只能拿到退出码，说明文字得另走一路）
CLI_FLAG = "--sandbox-cli"
ELEV_RESULT = Path(tempfile.gettempdir()) / "cahx-sandbox-elev.json"


@dataclass
class Info:
    """一次探测的结果（只读，不改任何东西）。"""

    found: bool = False
    edition: str = ""              # "plus" / "classic"
    start_exe: str = ""
    sandman_exe: str = ""
    install_dir: str = ""
    ini_path: str = ""
    ini_section: str = ""          # "UserSettings_4BC00582"，没找到为空
    ini_writable: bool = False     # 当前进程能不能写这份 ini（非管理员=False）
    autorun: dict[str, str] = field(default_factory=dict)   # Run 值名 → 值
    enable_autostart: bool = True  # ini 里的 SbieCtrl_EnableAutoStart

    @property
    def supported(self) -> bool:
        """只有 Plus 版有这个捐赠提醒弹窗；经典版 5.x 没有。"""
        return self.found and self.edition == "plus" and bool(self.sandman_exe)

    @property
    def disabled(self) -> bool:
        """两条自启都关着 = 提醒已被永久关闭。"""
        if not self.supported:
            return False
        return not self.autorun and not self.enable_autostart

    def needs_admin_for(self, action: str = "disable") -> bool:
        """做这个动作要不要先提权：只有「确实要写 ini、而现在又写不了」才要。

        注册表那半边（HKCU Run）普通权限就能改，所以「没装沙盘 / 经典版 /
        本来就已经关着」这些情况都不会弹 UAC。
        """
        if not self.supported or not self.ini_path or not self.ini_section:
            return False
        if self.ini_writable:
            return False
        if action == "disable":
            return bool(self.enable_autostart)   # 本就是关的 → 没什么可写
        return True


def _truthy(raw) -> bool:
    """Sandboxie 的布尔值写法：y/yes/true/1（大小写不敏感），空值按默认处理。"""
    return str(raw).strip().lower() in ("y", "yes", "true", "1", "on")


def is_elevated() -> bool:
    """当前进程是否已提权（管理员）。"""
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:                            # noqa: BLE001
        return False


def can_write(path: str | Path) -> bool:
    """真的开一次写句柄来判权限。

    比 ``os.access(W_OK)`` / 看 ACL 都可靠：这两者会被继承权限、UAC 虚拟化、
    提升令牌等绕进去（实测在管理员 shell 里查非管理员能不能写会得到错答案）。
    只开句柄不写任何字节，没有副作用。
    """
    try:
        with open(path, "r+b"):
            return True
    except PermissionError:
        return False
    except OSError as exc:
        log.info("写权限探测 %s 未通过：%s", path, exc)
        return False


# ------------------------------------------------------------------ 探测


def _ini_candidates(install_dir: str) -> list[Path]:
    """Sandboxie.ini 的几个可能位置：便携模式在安装目录，常规在系统目录。"""
    cands: list[Path] = []
    if install_dir:
        cands.append(Path(install_dir) / "Sandboxie.ini")
    cands.append(Path(r"C:\Windows\Sandboxie.ini"))
    program_data = Path(r"C:\ProgramData\Sandboxie\Sandboxie.ini")
    cands.append(program_data)
    return cands


def _read_ini_ex(path: Path) -> tuple[str, str]:
    """读 Sandboxie.ini，返回 (正文, 编码)。

    ⚠️ 本机实测这份 ini 是 **UTF-16 LE 带 BOM**（`\\xff\\xfe#\\x00...`）——
    Sandboxie 从很早就用 UTF-16 存配置。按 UTF-8 读会整篇乱码、`[UserSettings_xxx]`
    一个段都认不出来（2026-10-12 踩到）。所以 BOM 优先：先看前两个字节。
    """
    data = path.read_bytes()
    if data[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return data.decode("utf-16"), "utf-16"
    if data[:3] == b"\xef\xbb\xbf":
        return data.decode("utf-8-sig"), "utf-8-sig"
    for enc in ("utf-8", "mbcs", "latin-1"):
        try:
            return data.decode(enc), ("utf-8" if enc == "latin-1" else enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return data.decode("utf-8", "ignore"), "utf-8"


def _read_ini(path: Path) -> str:
    return _read_ini_ex(path)[0]


def _find_section(text: str, prefix: str) -> str:
    """找出 ``[UserSettings_xxx]`` 段名（驱动自己也是按这个前缀匹配的）。

    返回不带方括号的段名；没有就返回空串——这时不能瞎编段名写进去
    （hash 由 Sandboxie 自己算，写错了它根本不读），只能提示用户先开一次 GUI。
    """
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("[") and s.endswith("]"):
            name = s[1:-1].strip()
            if name.lower().startswith(prefix.lower()):
                return name
    return ""


def _ini_get(text: str, section: str, key: str) -> str | None:
    """读某个段里的一个键（段内、首个匹配）；没有返回 None。"""
    lines = text.splitlines()
    inside = False
    for line in lines:
        s = line.strip()
        if s.startswith("[") and s.endswith("]"):
            inside = s[1:-1].strip().lower() == section.lower()
            continue
        if not inside or not s or s[0] in "#;":
            continue
        if "=" in s and s.split("=", 1)[0].strip().lower() == key.lower():
            return s.split("=", 1)[1].strip()
    return None


def _run_values() -> dict[str, str]:
    """HKCU\\...\\Run 里属于 Sandboxie GUI 的自启项（值名含 sandboxie 且指向 sandman）。"""
    if not winreg:
        return {}
    out: dict[str, str] = {}
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_READ) as k:
            for i in range(winreg.QueryInfoKey(k)[1]):
                name, value, _ = winreg.EnumValue(k, i)
                text = "" if value is None else str(value)
                if "sandboxie" in name.lower() and "sandman" in text.lower():
                    out[name] = text
    except OSError as exc:
        log.warning("读取开机自启项失败：%s", exc)
    return out


def detect() -> Info:
    """探测本机沙盘情况（只读，无副作用）。"""
    from core.locate import find_sandboxie_start

    info = Info()
    found = find_sandboxie_start()
    if not found:
        return info

    info.found = True
    info.edition = found.edition or ""
    info.start_exe = found.path or ""
    info.install_dir = str(Path(info.start_exe).parent) if info.start_exe else ""

    sandman = Path(info.install_dir) / "SandMan.exe"
    if sandman.is_file():
        info.sandman_exe = str(sandman)

    for cand in _ini_candidates(info.install_dir):
        try:
            if cand.is_file():
                info.ini_path = str(cand)
                break
        except OSError:
            continue

    if info.ini_path:
        info.ini_writable = can_write(info.ini_path)
        try:
            text = _read_ini(Path(info.ini_path))
            info.ini_section = _find_section(text, INI_SECTION_PREFIX)
            if info.ini_section:
                raw = _ini_get(text, info.ini_section, KEY_ENABLE)
                # 缺省是 true（源码 GetBool("SbieCtrl_EnableAutoStart", true)）
                info.enable_autostart = True if raw is None else _truthy(raw)
        except OSError as exc:
            log.warning("读取 %s 失败：%s", info.ini_path, exc)

    info.autorun = _run_values()
    return info


def status_text(info: Info | None = None) -> str:
    """一句话状态（给 GUI tooltip / 命令行用）。"""
    info = info or detect()
    if not info.found:
        return "未检测到 Sandboxie"
    if not info.supported:
        return f"检测到 {info.edition or '未知版本'} Sandboxie：经典版没有捐赠提醒弹窗，无需关闭"
    return "捐赠提醒已关闭" if info.disabled else "捐赠提醒未关闭"


# ------------------------------------------------------------------ 改 ini


def _ini_set(text: str, section: str, key: str, value: str) -> str | None:
    """把 ``[section]`` 里的 ``key`` 改成 ``value``（不存在则插到段首）。

    段不存在返回 None（调用方据此报错，不新建段）。行尾风格（CRLF/LF）原样保留。
    """
    lines = text.splitlines(keepends=True)
    default_nl = "\r\n" if "\r\n" in text else "\n"

    def bare(line: str) -> str:
        return line.rstrip("\r\n")

    def tail(line: str) -> str:
        return line[len(bare(line)):]

    hdr = None
    for i, line in enumerate(lines):
        s = line.strip()
        if s.startswith("[") and s.endswith("]") and \
                s[1:-1].strip().lower() == section.lower():
            hdr = i
            break
    if hdr is None:
        return None

    end = len(lines)
    for j in range(hdr + 1, len(lines)):
        s = lines[j].strip()
        if s.startswith("[") and s.endswith("]"):
            end = j
            break

    for j in range(hdr + 1, end):
        s = lines[j].strip()
        if not s or s[0] in "#;":
            continue
        if "=" in s and s.split("=", 1)[0].strip().lower() == key.lower():
            lines[j] = f"{key}={value}{tail(lines[j]) or default_nl}"
            return "".join(lines)

    new_line = f"{key}={value}{tail(lines[hdr]) or default_nl}"
    lines.insert(hdr + 1, new_line)
    return "".join(lines)


def _write_text(path: Path, text: str, encoding: str) -> None:
    """按原编码写回（务必与 _read_ini_ex 拿到的编码配对，否则 Sandboxie 读不懂）。"""
    path.write_text(text, encoding=encoding, newline="")


def _backup_ini(info: Info) -> str:
    """改动前把整份 ini 复制到 data/sandbox_backup/，返回副本路径（失败返回空串）。"""
    if not info.ini_path:
        return ""
    try:
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y%m%d-%H%M%S")
        dest = BACKUP_DIR / f"Sandboxie.ini.{stamp}.bak"
        shutil.copy2(info.ini_path, dest)
        log.info("已备份 Sandboxie 配置：%s", dest)
        return str(dest)
    except OSError as exc:
        log.warning("备份 Sandboxie.ini 失败：%s", exc)
        return ""


def _save_backup(info: Info, ini_copy: str) -> None:
    """记录原始状态供 restore() 还原；已存在则不覆盖（保住最早的那份原值）。"""
    if BACKUP_JSON.exists():
        return
    try:
        text = _read_ini(Path(info.ini_path)) if info.ini_path else ""
        payload = {
            "at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "edition": info.edition,
            "sandman_exe": info.sandman_exe,
            "ini_path": info.ini_path,
            "ini_section": info.ini_section,
            "ini_copy": ini_copy,
            "autorun": info.autorun,
            "enable_autostart": (
                _ini_get(text, info.ini_section, KEY_ENABLE)
                if (text and info.ini_section) else None),
            "autostart_agent": (
                _ini_get(text, info.ini_section, KEY_AGENT)
                if (text and info.ini_section) else None),
        }
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        BACKUP_JSON.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        log.info("已记录沙盘自启原值：%s", BACKUP_JSON)
    except OSError as exc:
        log.warning("写入 %s 失败：%s", BACKUP_JSON, exc)


# ------------------------------------------------------------- 关闭 / 恢复


def _set_run_values(names, values: dict[str, str] | None) -> list[str]:
    """删掉（values=None）或写回（values=dict）指定的 Run 值，返回成功的值名。"""
    if not winreg or not names:
        return []
    done = []
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0,
                            winreg.KEY_READ | winreg.KEY_SET_VALUE) as k:
            for name in names:
                try:
                    if values is None:
                        winreg.DeleteValue(k, name)
                    else:
                        winreg.SetValueEx(k, name, 0, winreg.REG_SZ,
                                          values.get(name, ""))
                    done.append(name)
                except OSError as exc:
                    log.warning("处理自启项 %s 失败：%s", name, exc)
    except OSError as exc:
        log.warning("打开开机自启键失败：%s", exc)
    return done


def _stop_sandman() -> bool:
    """结束正在运行的 SandMan（它就是弹窗的来源）。

    安全说明：SandMan 只是 Qt 界面/托盘，沙盒本身跑在 SbieSvc + 驱动上，结束它
    不会影响沙盒内正在运行的游戏。本项目的 ``launcher.dismiss_sandboxie_popups``
    本来就会在点掉那个弹窗时让 SandMan 退出（弹窗的 Quit 分支会 PostQuitMessage），
    所以这条路径是已经在跑的。
    """
    try:
        out = subprocess.run(["taskkill", "/IM", "SandMan.exe", "/F"],
                             capture_output=True, text=True, timeout=15,
                             creationflags=0x08000000)  # CREATE_NO_WINDOW
    except (OSError, subprocess.SubprocessError) as exc:
        log.warning("结束 SandMan 失败：%s", exc)
        return False
    ok = out.returncode == 0
    log.info("结束 SandMan：%s", (out.stdout or out.stderr or "").strip() or ok)
    return ok


# ------------------------------------------------------------------ 提权

# ShellExecuteExW 的结构体（只用到这几个字段；顺序与 win32 定义一致）
class _SHELLEXECUTEINFOW(ctypes.Structure):
    _fields_ = [
        ("cbSize", ctypes.c_ulong),
        ("fMask", ctypes.c_ulong),
        ("hwnd", ctypes.c_void_p),
        ("lpVerb", ctypes.c_wchar_p),
        ("lpFile", ctypes.c_wchar_p),
        ("lpParameters", ctypes.c_wchar_p),
        ("lpDirectory", ctypes.c_wchar_p),
        ("nShow", ctypes.c_int),
        ("hInstApp", ctypes.c_void_p),
        ("lpIDList", ctypes.c_void_p),
        ("lpClass", ctypes.c_wchar_p),
        ("hkeyClass", ctypes.c_void_p),
        ("dwHotKey", ctypes.c_ulong),
        ("hIcon", ctypes.c_void_p),        # union：hIcon / hMonitor
        ("hProcess", ctypes.c_void_p),
    ]


_SEE_MASK_NOCLOSEPROCESS = 0x00000040
_SW_SHOWNORMAL = 1
_ERROR_CANCELLED = 1223
_WAIT_TIMEOUT = 0x102


def _shell_execute_runas(exe: str, params: str, cwd: str) -> int | None:
    """以管理员身份启动（弹 UAC），返回进程句柄；用户拒绝返回 None。"""
    shell32 = ctypes.WinDLL("shell32", use_last_error=True)
    shell32.ShellExecuteExW.restype = ctypes.c_int
    sei = _SHELLEXECUTEINFOW()
    sei.cbSize = ctypes.sizeof(sei)
    sei.fMask = _SEE_MASK_NOCLOSEPROCESS
    sei.lpVerb = "runas"
    sei.lpFile = exe
    sei.lpParameters = params
    sei.lpDirectory = cwd
    sei.nShow = _SW_SHOWNORMAL
    if not shell32.ShellExecuteExW(ctypes.byref(sei)):
        err = ctypes.get_last_error()
        log.info("UAC 提权未启动（错误码 %s%s）", err,
                 "，用户取消" if err == _ERROR_CANCELLED else "")
        return None
    return sei.hProcess


def _elevated_command(action: str) -> tuple[str, str, str]:
    """提权重跑自身时的 (exe, 参数, 工作目录)。

    打包（PyInstaller）模式 ``sys.executable`` 就是 exe 本体；脚本模式用
    ``python.exe -m core.sandbox_tools``——工作目录必须是项目根，否则提权进程
    根本 import 不到 ``core``（本模块唯一对 cwd 有要求的地方）。
    """
    if getattr(sys, "frozen", False):
        return sys.executable, f"{CLI_FLAG} {action}", str(Path(sys.executable).parent)
    return sys.executable, f"-m core.sandbox_tools {CLI_FLAG} {action}", str(ROOT)


def _attach_file_log() -> None:
    """提权子进程没有控制台，日志必须落文件，否则出问题无从查起。"""
    from core.paths import DEBUG_DIR
    try:
        DEBUG_DIR.mkdir(parents=True, exist_ok=True)
        handler = logging.FileHandler(DEBUG_DIR / "sandbox_elev.log", encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        log.addHandler(handler)
        log.setLevel(logging.INFO)
    except OSError:
        pass


def _run_elevated(action: str, timeout: int = 180) -> tuple[bool, str]:
    """弹一次 UAC、在提权进程里做完整套动作，返回 (是否成功, 说明)。

    为什么非要提权：``C:\\Windows\\Sandboxie.ini`` 的 ACL 只给 Users 读+执行
    （``Users:(I)(RX)``），非管理员进程 ``open(..., "r+b")`` 直接 PermissionError。
    """
    try:
        ELEV_RESULT.unlink()
    except OSError:
        pass

    exe, params, cwd = _elevated_command(action)
    log.info("沙盘操作需要管理员权限，请求提权：%s %s", exe, params)
    hproc = _shell_execute_runas(exe, params, cwd)
    if not hproc:
        return False, ("已取消管理员授权，沙盘设置未改动。\n"
                       "关闭捐赠提醒需要管理员权限才能改 Sandboxie.ini；"
                       "注册表那半边不需要，但要和 ini 一起做完才有意义。")

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    try:
        if kernel32.WaitForSingleObject(hproc, timeout * 1000) == _WAIT_TIMEOUT:
            return False, f"提权进程 {timeout} 秒内没结束，已放弃等待，请重试。"
        code = ctypes.c_ulong()
        kernel32.GetExitCodeProcess(hproc, ctypes.byref(code))
        exit_code = code.value
    finally:
        kernel32.CloseHandle(hproc)

    try:
        payload = json.loads(ELEV_RESULT.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        payload = {}
        log.warning("没读到提权进程的结果文件：%s", ELEV_RESULT)
    else:
        try:
            ELEV_RESULT.unlink()
        except OSError:
            pass

    ok = bool(payload.get("ok", exit_code == 0))
    msg = payload.get("msg") or (
        "提权操作已完成。" if ok else
        f"提权进程异常退出（退出码 {exit_code}），详见 debug/sandbox_elev.log")
    return ok, msg


def run_cli_action(action: str) -> int:
    """提权子进程的入口：做完动作把结果写成 JSON 给父进程，返回退出码。

    由 ``_run_elevated`` 通过 ``--sandbox-cli <action>`` 拉起；也支持手工执行
    （``python -m core.sandbox_tools --sandbox-cli disable``）复现问题。

    ``probe`` 是**零副作用**动作，只为自检提权链路（``_run_elevated`` 的
    ShellExecuteExW + 等待 + 结果文件那一套）是否通——它只回一句、不碰配置。
    """
    _attach_file_log()
    log.info("提权子进程开始：%s（elevated=%s）", action, is_elevated())
    try:
        if action == "probe":
            ok, msg = True, "提权链路自检：未改动任何配置。"
        elif action == "disable":
            ok, msg = disable(allow_elevate=False)
        elif action == "restore":
            ok, msg = restore(allow_elevate=False)
        else:
            ok, msg = False, f"未知动作 {action!r}（只认 probe / disable / restore）"
    except Exception as exc:                     # noqa: BLE001
        log.exception("提权子进程执行失败")
        ok, msg = False, f"操作异常：{exc}"
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        ELEV_RESULT.write_text(
            json.dumps({"ok": ok, "msg": msg, "action": action},
                       ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError as exc:
        log.warning("写结果文件失败：%s", exc)
    log.info("提权子进程结束：ok=%s %s", ok, msg)
    return 0 if ok else 1


def disable(stop_running: bool = True, allow_elevate: bool = True) -> tuple[bool, str]:
    """永久关闭 Sandboxie-Plus 的捐赠提醒，返回 (是否成功, 给用户看的结果说明)。

    非管理员运行时，写 ``Sandboxie.ini`` 那一步会自动弹一次 UAC、在提权进程里
    做完；``allow_elevate=False`` 时直接返回说明（提权子进程用，避免递归提权）。
    """
    info = detect()
    if not info.found:
        return False, "本机没有检测到 Sandboxie，这个功能用不上。"
    if not info.supported:
        return False, (f"检测到的是 {info.edition or '未知版本'} 版 Sandboxie，"
                       "它没有捐赠提醒弹窗，无需关闭。")
    if allow_elevate and info.needs_admin_for("disable"):
        return _run_elevated("disable")
    return _disable_impl(info, stop_running)


def _disable_impl(info: Info, stop_running: bool = True) -> tuple[bool, str]:
    """关掉两条自启（假定当前进程已有写 ini 的权限）。"""
    changes: list[str] = []

    # ① 开机自启项
    if info.autorun:
        done = _set_run_values(list(info.autorun), None)
        changes += [f"已取消开机自启（{n}）" for n in done]
    else:
        changes.append("开机自启本来就是关的")

    # ② ini 里的 GUI 自启
    ini_ok = False
    if info.ini_path and info.ini_section:
        copy = _backup_ini(info)
        _save_backup(info, copy)
        if info.enable_autostart:
            try:
                text, enc = _read_ini_ex(Path(info.ini_path))
                new_text = _ini_set(text, info.ini_section, KEY_ENABLE, "n")
            except OSError as exc:
                new_text, enc = None, "utf-8"
                log.warning("改写 %s 失败：%s", info.ini_path, exc)
            if new_text is None:
                changes.append("写入 ini 失败（段名没找到）")
            else:
                try:
                    _write_text(Path(info.ini_path), new_text, enc)
                    ini_ok = True
                    changes.append("已关闭「沙盒启动时打开沙盘界面」")
                except OSError as exc:
                    changes.append(f"写入 ini 失败（{exc}）")
        else:
            ini_ok = True
            changes.append("「沙盒启动时打开沙盘界面」本来就是关的")
    else:
        changes.append("没找到 Sandboxie.ini 的 UserSettings 段，"
                       "请先手动打开一次 SandMan 再重试")

    # ③ 顺手结束当前还在跑的 SandMan（否则它这一轮仍可能弹一次）
    if stop_running and _stop_sandman():
        changes.append("已结束当前运行的沙盘界面进程")

    ok = ini_ok or not info.ini_path
    summary = "；".join(changes) + "。"
    summary += ("以后开机不再自动启动沙盘界面，捐赠提醒也就不会再出现；"
                "需要托盘图标或沙盒主界面时手动打开 SandMan 即可。")
    log.info("关闭沙盘捐赠提醒：%s", summary)
    return ok, summary


def restore(allow_elevate: bool = True) -> tuple[bool, str]:
    """还原 disable() 的改动（回到"开机自启 + 沙盒启动时打开界面"）。

    与 ``disable`` 对称：要写 ini 时同样自动走一次 UAC 提权。
    """
    info = detect()
    if not info.found:
        return False, "本机没有检测到 Sandboxie。"
    if allow_elevate and info.needs_admin_for("restore"):
        return _run_elevated("restore")
    return _restore_impl(info)


def _restore_impl(info: Info) -> tuple[bool, str]:
    try:
        backup = json.loads(BACKUP_JSON.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        backup = {}

    notes: list[str] = []

    # ① 开机自启项：优先用备份里的原值，没有就按安装目录重建
    saved = backup.get("autorun") or {}
    if not saved and info.sandman_exe:
        saved = {"SandboxiePlus_AutoRun": f'"{info.sandman_exe}" -autorun'}
    if saved:
        done = _set_run_values(list(saved), saved)
        notes.append(f"已恢复开机自启（{len(done)} 项）" if done else "恢复开机自启失败")

    # ② ini：只改回那两条键，不整份覆盖（用户这期间可能改过别的）
    if info.ini_path and info.ini_section:
        want_enable = backup.get("enable_autostart")
        want_enable = "y" if want_enable is None else want_enable
        want_agent = backup.get("autostart_agent") or AGENT_DEFAULT
        try:
            text, enc = _read_ini_ex(Path(info.ini_path))
            new_text = _ini_set(text, info.ini_section, KEY_ENABLE, want_enable)
            if new_text is not None:
                new_text = _ini_set(new_text, info.ini_section, KEY_AGENT, want_agent)
            if new_text is None:
                notes.append("没找到 UserSettings 段，ini 未改动")
            else:
                _write_text(Path(info.ini_path), new_text, enc)
                notes.append("已恢复「沙盒启动时打开沙盘界面」")
        except OSError as exc:
            notes.append(f"写 ini 失败（{exc}）")
    else:
        notes.append("没找到 Sandboxie.ini，只改了开机自启项")

    summary = "；".join(notes) + "。下次开机沙盘界面会照常出现。"
    log.info("恢复沙盘自启：%s", summary)
    return True, summary


# ------------------------------------------------------------------ 命令行


def _main(argv: list[str]) -> int:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")

    # 提权子进程入口（由 _run_elevated 用 runas 拉起）：只执行动作 + 写结果文件
    if CLI_FLAG in argv:
        i = argv.index(CLI_FLAG)
        action = argv[i + 1] if i + 1 < len(argv) else ""
        return run_cli_action(action)

    info = detect()
    print("=== 探测结果 ===")
    print(f"  找到沙盘     : {info.found}（{info.edition or '—'}）")
    print(f"  Start.exe    : {info.start_exe or '—'}")
    print(f"  SandMan.exe  : {info.sandman_exe or '—'}")
    print(f"  Sandboxie.ini: {info.ini_path or '—'}  段={info.ini_section or '—'}")
    print(f"  开机自启项   : {info.autorun or '（无）'}")
    print(f"  EnableAutoStart: {info.enable_autostart}")
    print(f"  提醒已关闭？ : {info.disabled}   —— {status_text(info)}")
    print(f"  管理员权限   : {is_elevated()}")
    print(f"  ini 可写     : {info.ini_writable}"
          f"（需要提权改？ disable={info.needs_admin_for('disable')} "
          f"restore={info.needs_admin_for('restore')}）")

    if "--disable" in argv:
        ok, msg = disable()
        print(f"\n[关闭] ok={ok} {msg}")
        return 0 if ok else 1
    if "--restore" in argv:
        ok, msg = restore()
        print(f"\n[恢复] ok={ok} {msg}")
        return 0 if ok else 1
    return 0


if __name__ == "__main__":
    import sys

    raise SystemExit(_main(sys.argv[1:]))
