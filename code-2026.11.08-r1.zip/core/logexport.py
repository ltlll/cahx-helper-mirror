"""日志导出：把最近运行日志 + 配置 + 失败截图打成 zip，供发回分析。

GUI 两个入口调用：顶栏「导出日志」按钮、右侧「运行日志」面板头部的「导出」。
安装目录下的 debug/ 文件夹本身也是可直接取走的原始日志（软件打不开时的兜底）。
内容选取原则（分析错误需要的东西）：
- run.log 尾部（最近 1MB）：任务流程与报错全文（含账号手机号，发回前自行斟酌）
- accounts/<账号标签>.log 尾部（每账号最近 512KB）：按账号拆好的独立轨迹
  （core.logsetup 产出，直接看"某个账号这一轮干了什么、哪里失败"）
- config.yaml / schedules.json / yitiaolong.json / daily_done.json：
  任务勾选、定时、按账号定制的当前配置
- 最近 3 天的失败/超时调试截图（最多 10 张）：出错时的画面状态
- system_info.txt：版本、Windows、屏幕分辨率/缩放、当前游戏窗口列表
明确不含 data/accounts.db（账号手机号库）。
"""
import logging
import platform
import subprocess
import time
import zipfile
from pathlib import Path

from core.paths import CONFIG_PATH, DATA_DIR, DEBUG_DIR, FROZEN, ROOT

log = logging.getLogger("logexport")

LOG_TAIL_BYTES = 1024 * 1024   # run.log 只带最后 1MB（全量会很大）
ACCOUNT_LOG_TAIL_BYTES = 512 * 1024  # 每个账号分文件只带最后 512KB
MAX_SHOTS = 10                 # 失败截图最多带 10 张
SHOT_MAX_AGE_S = 3 * 86400     # 只带最近 3 天的调试截图

# 随包导出的配置文件（相对 ROOT / DATA_DIR）
CONFIG_FILES = ["config.yaml"]
DATA_FILES = ["schedules.json", "yitiaolong.json", "daily_done.json"]


def app_version():
    """版本标识：git 提交哈希（开发模式）或载荷版本号（frozen）。

    公开函数（2026-10-12 从 `_app_version` 提升）：设置页「程序信息」与
    日志导出两处共用同一个版本串，避免两处各写一份。
    2026-10-15 热更新架构后，frozen 模式下**业务代码版本 = 载荷版本**
    （app/current.json，热更会换），exe 构建日期只是运行时（引导器）的版本。
    """
    try:
        out = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"], cwd=ROOT,
            capture_output=True, text=True, timeout=5)
        if out.returncode == 0:
            return f"git:{out.stdout.strip()}"
    except Exception:
        pass
    if FROZEN:
        try:
            from core.updater import current_version
            ver = current_version()
            if ver:
                return f"v{ver}"
        except Exception:
            pass
        return f"打包构建于 {time.strftime('%Y-%m-%d %H:%M', time.localtime(ROOT.joinpath('cahx-helper.exe').stat().st_mtime))}"
    return "未知"


def _system_info():
    lines = [
        f"导出时间: {time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"版本: {app_version()}",
        f"运行模式: {'打包 exe' if FROZEN else '开发模式'}",
        f"Windows: {platform.platform()}",
        f"安装目录: {ROOT}",
    ]
    try:
        import ctypes
        user32 = ctypes.windll.user32
        w = user32.GetSystemMetrics(0)
        h = user32.GetSystemMetrics(1)
        try:
            dpi = ctypes.windll.shcore.GetScaleFactorForDevice(0)
        except Exception:
            dpi = -1
        lines.append(f"屏幕: {w}x{h}, 缩放: {dpi}%")
    except Exception:
        pass
    try:
        from core.device import Device
        hwnds = Device.find_all()
        lines.append(f"当前游戏窗口数: {len(hwnds)}")
    except Exception as e:
        lines.append(f"游戏窗口检测失败: {e}")
    return "\n".join(lines)


def _tail(path, max_bytes):
    data = path.read_bytes()
    if len(data) <= max_bytes:
        return data
    tail = data[-max_bytes:]
    nl = tail.find(b"\n")
    return tail[nl + 1:] if 0 <= nl < 200 else tail


def export_logs(dest_dir):
    """打包日志到 dest_dir（不存在自动创建），返回 zip 路径。"""
    out_dir = Path(dest_dir)
    try:
        out_dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        # 桌面可能被 OneDrive 重定向或不可写，退回用户主目录，保证一定导得出来
        out_dir = Path.home()
        log.warning("导出目录不可写（%s），改用 %s", dest_dir, out_dir)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    zip_path = out_dir / f"cahx-logs-{stamp}.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        run_log = DEBUG_DIR / "run.log"
        if run_log.exists():
            zf.writestr("run.log", _tail(run_log, LOG_TAIL_BYTES))
        # 按账号分文件（core/logsetup 产出）：每个账号尾部一段，便于直接看单号轨迹
        acc_dir = DEBUG_DIR / "accounts"
        if acc_dir.exists():
            for p in sorted(acc_dir.glob("*.log")):
                zf.writestr(f"accounts/{p.name}", _tail(p, ACCOUNT_LOG_TAIL_BYTES))
        for name in CONFIG_FILES:
            p = ROOT / name
            if p.exists():
                zf.write(p, name)
        for name in DATA_FILES:
            p = DATA_DIR / name
            if p.exists():
                zf.write(p, f"data/{name}")
        now = time.time()
        shots = sorted(
            [p for p in list(DEBUG_DIR.glob("*_fail.png"))
             + list(DEBUG_DIR.glob("*_timeout.png"))
             if now - p.stat().st_mtime < SHOT_MAX_AGE_S],
            key=lambda p: p.stat().st_mtime, reverse=True)[:MAX_SHOTS]
        for p in shots:
            zf.write(p, f"debug/{p.name}")
        zf.writestr("system_info.txt", _system_info())
    log.info("日志已导出: %s", zip_path)
    return zip_path
