# -*- coding: utf-8 -*-
"""任务运行期间的会话保活：阻止息屏/睡眠/屏保锁屏。

背景（2026-10-15 事故）：自动化依赖截图 + 前台输入，锁屏/息屏后 dxcam 与
mss 全部失效（dxcam 还会陷入无限恢复循环拖死全部账号线程）。任务执行中
拟人化点击会重置系统空闲计时，但**组队等待/登录观察等长等待段可能连续
数分钟无输入**，超过电源计划的息屏/锁屏阈值就会中断运行。

用法：
    from core.session_keepalive import keep_alive
    keep_alive.start()   # 运行开始时调用（幂等）
    keep_alive.stop()    # 运行结束时调用（恢复系统默认策略）

原理：SetThreadExecutionState(ES_CONTINUOUS | ES_DISPLAY_REQUIRED |
ES_SYSTEM_REQUIRED) —— 系统级"我有活干"声明，阻止显示器关闭与系统睡眠
（进而阻止"息屏后锁定"），不模拟输入、不绕过用户手动锁屏（Win+L 仍然
照常锁，锁了就等用户解锁）。
"""
import ctypes
import logging
import threading

log = logging.getLogger("session")

ES_CONTINUOUS = 0x80000000
ES_SYSTEM_REQUIRED = 0x00000001
ES_DISPLAY_REQUIRED = 0x00000002


class _KeepAlive:
    def __init__(self):
        self._lock = threading.Lock()
        self._refs = 0

    def start(self, reason=""):
        """声明"运行中，别睡别锁"（引用计数，支持嵌套调用）。"""
        with self._lock:
            self._refs += 1
            n = self._refs
        prev = ctypes.windll.kernel32.SetThreadExecutionState(
            ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED)
        if not prev:
            log.warning("SetThreadExecutionState 失败（防息屏可能不生效）")
        elif n == 1:
            log.info("会话保活已开启%s（运行期间阻止息屏/睡眠/屏保锁屏）",
                     f"：{reason}" if reason else "")

    def stop(self):
        """引用归零后恢复系统默认电源策略。"""
        with self._lock:
            if self._refs <= 0:
                return
            self._refs -= 1
            n = self._refs
        if n == 0:
            ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS)
            log.info("会话保活已关闭（恢复系统默认息屏/睡眠策略）")

    def is_locked(self):
        """当前是否处于锁屏/安全桌面（OpenInputDesktop 打不开即锁屏）。"""
        DESKTOP_GENERIC_ALL = 0x000F
        h = ctypes.windll.user32.OpenInputDesktop(0, False, DESKTOP_GENERIC_ALL)
        if h:
            ctypes.windll.user32.CloseDesktop(h)
            return False
        return True

    @property
    def active(self):
        """当前是否有保活声明生效（账号页小工具「禁止锁屏」的开关状态用）。"""
        with self._lock:
            return self._refs > 0


keep_alive = _KeepAlive()
