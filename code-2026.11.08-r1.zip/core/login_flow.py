"""单实例登录状态机：每轮截一帧，按优先级判断当前界面并执行动作。

流程：登录框校验账号（不符则点开倒三角切换）→ 进入游戏 → 关闭公告
→ 踏入长安页点上方区服栏 → 服务器选择页"我的角色"页签 → 点目标角色卡
→ 角色页左侧列表选中目标角色 → 进入长安 → 主界面。
直接点"踏入长安"会进默认区服，可能不是目标区服，所以必须先选服。

登录成功判定（_is_logged_in）：登录后不一定停在云梦长安主界面——可能在副本/
特殊场景，也可能被强制拉进战斗，此时左侧"活动/玩法/商城"锚点不在或被遮。
故改为多路特征任一命中即算进游戏：主界面三锚点 / 战斗画面 / 背包+头像 /
左上角地图名。详见 _is_logged_in 的说明。

角色卡/角色条目/登录账号的定位：模板匹配优先，OCR（core/ocr.py）兜底，
按角色名/脱敏手机号识别，新增账号免做模板。
供 login.py（命令行）与 gui.py（界面）共用。
"""
import logging
import os
import random
import re
import time

from core import anchors, dialogs, ocr

log = logging.getLogger("login.flow")

MAIN_SCREEN_MARKERS = ("活动", "玩法", "商城")
# 主界面左侧按钮列在 405x720 客户区内的锚点（按钮中心），位置固定不变
MAIN_SCREEN_ANCHORS = {"活动": (30, 175), "玩法": (30, 220), "商城": (30, 355)}

# ---- 登录成功判定（"已进入游戏"的多路特征，任一命中即算登录成功）----
# 背景：登录后不一定停在云梦长安主界面——可能在副本/特殊场景，也可能被
# 强制拉进战斗（攻城夺宝等），此时左侧"活动/玩法/商城"锚点根本不在/被遮。
# 判定标准改为"出现任意一个只有进入游戏后才有的稳定 UI 特征"：
#   A. 主界面锚点：活动/玩法/商城（原判定，收紧为全中 -> 见 _on_main_screen）
#   B. 主界面通用 UI：背包入口 + 右上角头像（主界面/副本/大部分场景都有）
#   C. 左上角地图名（云梦长安/副本名/场景名，有地图名=已在游戏内场景）
#   D. 战斗画面：右下角"自动"+ 左下角"战况"（或顶部回合数/阶段数）
#
# 主界面左侧"活动/玩法/商城"锚点区域（与 tasks/base.py MAIN_ANCHOR_REGIONS 一致）
_MAIN_ANCHOR_REGIONS = {
    name: (max(0, cx - 37), max(0, cy - 32), 75, 64)
    for name, (cx, cy) in MAIN_SCREEN_ANCHORS.items()
}

# 主界面右侧"背包"入口（405x720 客户区内固定位置；与 tasks/base.py BEIBAO_REGION 一致）
BAG_REGION = (340, 520, 80, 100)
# 右上角头像（战斗外一般可见；模板缺失时靠 OCR 的"角色名/等级"兜底）
AVATAR_REGION = (330, 8, 75, 75)
# 左上角地图名/场景名（有一行地名文字=已经在游戏场景里）
MAP_NAME_REGION = (0, 0, 130, 52)
# 战斗画面：右下角"自动"按钮 + 左下角"战况"（主界面同位置是"协助"，不误中）
BATTLE_AUTO_REGION = (330, 650, 75, 62)
BATTLE_MARK_REGION = (10, 608, 110, 64)
# 战斗顶部信息：回合数/阶段数（形式如"第3回合"、"回合 3/30"、"阶段 2"）
BATTLE_TOP_REGION = (120, 0, 180, 46)
_BATTLE_ROUND_RE = re.compile(r"(回合|阶段)")

# 右上角「任务 | 队伍」页签（实测 2026-10-10：主界面 (309,94)/(368,94)，狮王守卫等
# 副本场景同位置同款）——**游戏内所有场景恒定出现，登录期页面没有**，是比
# "背包+头像"更稳的兜底信号。判定用全图 OCR + 坐标过滤（见 _detect_ingame_tabs）。
TABS_REGION = (280, 70, 125, 50)

# 客户端启动闪屏（诗悦 logo，assets/images/login/客户端闪屏.png）：正常几秒即过。
# 若同一个窗口持续停在这里超过 SPLASH_HANG_SECONDS，判定客户端启动后卡死——
# 实测这种窗口像素 10 分钟零变化，继续等只会白白吃满登录超时；由调用方
# 关窗重启（占着窗口却永远登不进去，还会挤占客户端实例名额）。
SPLASH_REGION = (40, 230, 330, 180)
# 2026-10-15 事故修正：并发冷启动（一条龙 preflight 一次拉 5 个客户端）时，
# 磁盘/CPU 争用会把闪屏阶段从"几秒"拖到 2 分钟以上，90 秒阈值过短 →
# 客户端被误判卡死强关、再重启、再被强关，整轮登录全部失败。
# 默认放宽到 240 秒，可用环境变量 CAHX_SPLASH_TIMEOUT 覆盖。
SPLASH_HANG_SECONDS = float(os.environ.get("CAHX_SPLASH_TIMEOUT") or 240)

# 运行中假死（IsHungAppWindow=true）：客户端消息泵不再响应（游戏端偶发，
# 2026-10-12 23:20 实测「火锅涮到夜半」点完「进入游戏」8 秒后假死）。此时
# device 层会跳过置顶/置前，mouse_event 点击落在冻结画面上全部无效；更隐蔽的是
# dxcam 在屏幕无更新时返回 None → 用缓存帧 → OCR 一直复读冻结前的旧画面
# （日志里表现为"还能识别到公告"，其实是缓存假象），状态机于是空转到 login_timeout
# （实测白耗 4.5 分钟）。所以持续挂起超过 HANG_HARD_SECONDS 直接判客户端假死，
# 由调用方关窗（必要时强杀进程）后重启。阈值要够长：短暂的假死（加载/GC）会自愈。
HANG_HARD_SECONDS = 30

# ---- 登录后「UI 完整性体检」（2026-10-28：沙盒残废客户端）----
# 现象：沙盒/冷启动偶发"残废客户端"——已经进到游戏里（左侧按钮列/背包/头像都
# 在，登录状态机照常判成功），但右上角「任务 | 队伍」页签始终不出现，之后
# **所有点击全部无反应**（任务流程必然一路卡到超时）。这种客户端本身坏了，
# 换一个新的就好（用户实测：重启 5~10 次内能碰到一个正常的）。
# 所以登录成功后必须体检：观察 UI_CHECK_GRACE 秒（每 UI_CHECK_INTERVAL 秒采样
# 一次页签），页签一直不出现 → ui_broken=True，由调用方关窗重启换客户端。
# 页签一旦出现就按旧行为只等 5 秒（留时间给登录后的延迟弹窗），不拖慢正常登录。
UI_CHECK_GRACE = float(os.environ.get("CAHX_UI_CHECK_GRACE") or 15)
UI_CHECK_INTERVAL = 2.0   # 体检采样间隔（每次一次全图 OCR，别太密）

# 登录兜底阶梯里"剧情选项"同一坐标连点这么多次仍无进展 → 判假选项，不再点它
# （改走"跳过"/ESC）。2026-10-16 实测：兜底把玩家头顶名牌读成选项，反复点
# @(206,335)，一路白烧到 300 秒登录超时 → 关窗重启（用户看到的"自动退号"）。
LOGIN_OPT_REPEAT_ABORT = 3

# 登录兜底"剧情选项"扫描区（画面中上部）：胶囊按钮中心 150≤cx≤260。
# 注意：**必须排除玩家头顶名牌**——它固定在 cx≈206、cy≈335~374，与真选项同列同高。
FALLBACK_OPTION_REGION = (60, 290, 290, 180)

# 登录期页面上会落在左上角区域、不能当成"已进游戏地图名"的字样。
# （含游戏登录页与误截到本工具 GUI 时出现的字样——后者不是游戏画面）
_LOGIN_PAGE_WORDS = ("踏入长安", "进入游戏", "我的角色", "选择", "公告",
                     "诗悦", "登录", "账号", "服务器", "区服", "开始游戏",
                     "日常任务", "添加账号", "备注", "定时任务")
# 汉字判定：地图名/场景名至少要有汉字，用于筛掉 OCR 的 '□□□□' 之类垃圾
_HAN_RE = re.compile(r"[\u4e00-\u9fff]")


# 踏入长安按钮上方的区服栏：OCR 定位失败时退回的固定纵向偏移
SERVER_BAR_OFFSET_Y = -75

# 踏入长安页左上角竖排图标列最上面的圆形头像/账号图标：点击弹出诗悦账号登录框
# （"账号校验失败"善后用。assets/images/login/ 无现成模板，固定坐标来自
# 用户截图红框标注，2026-10-08；图标紧贴客户区左上角）
ACCOUNT_ICON_POS = (22, 13)

# OCR 搜索区域（405x720 客户区）
CARD_LIST_REGION = (135, 115, 260, 510)   # 服务器选择页右侧角色卡网格
ENTRY_LIST_REGION = (0, 0, 210, 400)      # 角色页左上角角色列表
# 服务器选择面板的区服列表（右侧内容列，不含左缘页签）：会话落在错误区服时
# （如固定区服的小号客户端），在这里逐字找目标区服直接点它切服。
SERVER_LIST_REGION = (140, 90, 255, 480)
SERVER_GROUP_TABS = ("乘风区", "盛世大唐", "锦绣长安")  # 区服分组页签（面板左缘）
# 面板左缘页签列（推荐/我的角色/乘风区/盛世大唐/锦绣长安）：模板是"选中态"紫色
# 文字，新版客户端默认停在「推荐」时「我的角色」是灰的，匹配不上 —— OCR 兜底
# 在该区域内逐字找（实测灰字置信度 0.9998）。
SERVER_TAB_REGION = (0, 90, 140, 490)
ACCOUNT_FIELD_REGION = (90, 338, 220, 44)   # 登录框当前账号栏
ACCOUNT_LIST_REGION = (90, 385, 230, 235)   # 登录框下拉账号列表（展开时覆盖下方按钮）
ABORT_SCAN_REGION = dialogs.DIALOG_SCAN_REGION  # 系统弹窗统一扫描区（过期/战斗中/扫码/内存优化）
BATTLE_CANCEL_FALLBACK = (105, 447)         # 战斗中弹窗"取消"按钮的兜底点击位置

# 脱敏手机号，如 182****7182 → ("182", "7182")
_ACCOUNT_RE = re.compile(r"(\d{3})\D{1,8}(\d{4})")


# ---- 登录流程页面锚点表（2026-10-12：固定元素判"到没到这一步"，判不出来再 OCR）----
# 每页登记"固定不变的几个元素"，命中数达标 = 确认到达该页（0 次 OCR）；
# 判不出来（灰区/素材缺失）才用 ocr_texts 兜底。互斥元素（exclude）排除同图标页：
# 公告关闭的 X 与诗悦登录框右上角的 X **是同一张图**，不排除就会把登录框的 X
# 当公告关掉（登录框从此再点不开，只能重启客户端）。
# 阈值与页表改造前的散落 _find 调用逐一对应（进入游戏/踏入长安/我的角色 0.95、
# 进入长安/账号下拉 0.90），行为不变，只是判定收敛成一张显式的表。
# 公告关闭后从 0.90 提到 0.95：服务器面板/登录框自己的 X 与它同图标但只匹配
# 0.90~0.93，真公告弹窗的 X 实测 ≥0.987（2026-10-13 01:07 选服页死循环整改）。
# 登录框"进入游戏"按钮的 OCR 兜底区域（405x720；与 login.py LOGIN_SCREEN_REGION 一致）
LOGIN_BOX_BTN_REGION = (80, 390, 245, 60)

PAGE_SPLASH = anchors.Page(
    "splash", "客户端启动闪屏",
    (anchors.Anchor("客户端闪屏", SPLASH_REGION, 0.90),))

PAGE_LOGIN_BOX = anchors.Page(
    "login_box", "诗悦登录框（进入游戏）",
    (anchors.Anchor("进入游戏", None, 0.95, note="登录框大按钮"),
     anchors.Anchor("账号下拉", None, 0.90, note="账号栏倒三角")),
    need=1,
    ocr_texts=("进入游戏",), ocr_region=LOGIN_BOX_BTN_REGION)

PAGE_SERVER_SELECT = anchors.Page(
    "server_select", "服务器选择页（点角色卡=选服+选角色）",
    # 2026-10-30 事故（7 号「火锅涮到夜半」连续两天登不进去）：游戏改版后这个
    # 面板默认停在「推荐」页签，「我的角色」变成**灰色未选中态**，而模板是紫色
    # 选中态 → 唯一锚点匹配不上。单锚点页在 n_hit==0 时被判成"干净否定"，
    # **连 OCR 兜底都不会跑** → 整页判"未识别" → 兜底 ESC 关掉面板 → 弹回
    # 踏入长安页 → 再点选择区服 → 再 ESC，死循环到登录超时。
    # 修法：加一个不受选中态影响的稳定锚点——顶部「服务器选择」标题（实测
    # 正样本 1.000、负样本最高 0.364，阈值 0.95 足够安全），need=1 任一命中即认。
    (anchors.Anchor("服务器选择", None, 0.95, note="顶部标题（不受页签选中态影响）"),
     anchors.Anchor("我的角色", None, 0.95, note="页签")),
    need=1,
    ocr_texts=("服务器选择", "我的角色"))

PAGE_SERVER_ENTER = anchors.Page(
    "server_enter", "踏入长安页（先点区服栏）",
    (anchors.Anchor("踏入长安", None, 0.95),),
    ocr_texts=("踏入长安",))

PAGE_CHAR = anchors.Page(
    "char_page", "角色页（左侧选中角色后进入长安）",
    (anchors.Anchor("进入长安", None, 0.90),),
    ocr_texts=("进入长安",))

PAGE_ANNOUNCE = anchors.Page(
    "announce", "公告/系统弹窗（右上角 X）",
    # 阈值 0.95：公告弹窗的 X 实测 ≥0.987，而服务器选择面板/登录框右上角自己的
    # X 是同一图标但渲染略有差异、只匹配到 0.90~0.93——阈值太低会把面板 X 当
    # 公告关掉（关面板 → 弹回踏入长安页 → 死循环，2026-10-13 01:07 实测）。
    (anchors.Anchor("公告关闭", None, 0.95, note="右上角关闭 X"),),
    # 登录框自己的 X 与公告关闭同图标：登录框可见时（进入游戏/账号下拉命中）
    # 这个 X 是登录框的，绝不能当公告关。公告可以叠在踏入长安/角色页上，
    # 所以这两页**不**进互斥表（先关公告再点按钮是对的）。
    exclude=(anchors.Anchor("进入游戏", None, 0.95),
             anchors.Anchor("账号下拉", None, 0.90)),
    # 浮层页：公告正常就叠在踏入长安页/角色页上 → 允许共存，不参与
    # anchors.resolve 的"独占页唯一性"检查（否则合法场景被判歧义而卡死）
    overlay=True)

PAGE_MAIN = anchors.Page(
    "main", "主界面（活动/玩法/商城齐全）",
    tuple(anchors.Anchor(name, region, 0.88, 0.45)
          for name, region in _MAIN_ANCHOR_REGIONS.items()),
    need=3)

# step() 分支按这个顺序消费（与页表改造前的判定顺序一致：登录框 → 服务器选择页
# → 公告 → 踏入长安 → 角色页）。
LOGIN_PAGES = (PAGE_LOGIN_BOX, PAGE_SERVER_SELECT, PAGE_ANNOUNCE,
               PAGE_SERVER_ENTER, PAGE_CHAR)
LOGIN_PAGE_ORDER = tuple(p.key for p in LOGIN_PAGES)   # 判定/点击优先级
# 浮层页（允许盖在别的页面上共存，不参与唯一性检查）：目前只有"公告/系统弹窗"
LOGIN_OVERLAY_PAGES = tuple(p.key for p in LOGIN_PAGES if p.overlay)


class LoginFlow:
    def __init__(self, device, matcher, character=None, account=None, timeout=300,
                 stop_event=None, server=None, ui_check_grace=None):
        self.device = device
        self.matcher = matcher
        # 登录后 UI 体检的观察时长（秒）：None = 用模块默认 UI_CHECK_GRACE
        # （可用 config.yaml login.ui_check_grace 或环境变量 CAHX_UI_CHECK_GRACE 调）
        self.ui_check_grace = float(ui_check_grace) if ui_check_grace else UI_CHECK_GRACE
        self.character = character
        self.account = account           # 完整手机号，用于校验登录框当前账号
        self.server = server             # 配置的区服名（数据库 accounts.server）
        self.stop_event = stop_event     # 外部停止信号（worker 化后停止要贯通登录阶段）
        self.deadline = time.time() + timeout
        self.abort_reason = None       # 设置后 run() 中止登录并跳过该账号
        self.client_hung = False       # 客户端卡死（启动闪屏不消失）：调用方应关窗重启
        self.ui_broken = False         # 客户端 UI 残废（登录后「任务/队伍」页签不出）：调用方应关窗重启
        self._tabs_seen = False        # 体检期内已确认右上角页签可见
        self._ui_check_at = 0.0        # 上次页签采样时刻（限频，见 UI_CHECK_INTERVAL）
        self.char_selected = False     # 角色页已选中目标角色
        self._account_ok = False       # 登录框当前账号已确认是目标账号
        self._main_since = None        # 首次进入主界面的时间（用于弹窗宽限观察期）
        self._reopen_login_box = False  # "账号校验失败"善后：点头像重开登录框
        self._reopen_click_at = 0.0     # 上次点头像的时间（重开无效则每隔几秒再点）
        self._reopen_clicks = 0         # 点头像次数（超过上限则中止本账号）
        self._char_clicks = 0
        self._last_action = None
        self._last_action_time = 0
        self._last_enter_click = 0     # 最近一次点"进入游戏/进入长安"的时间
        self._last_account_click = 0   # 最近一次操作账号下拉/账号条目的时间
        self._frames = 0
        self._warned = set()
        self._idle_frames = 0
        self._dlg_opt_key = None       # 兜底阶梯里"剧情选项"的坐标聚类（8px 网格）
        self._srv_click_at = 0.0       # 上次点区服条目/分组页签的时间（限频）
        self._srv_tab_idx = 0          # 区服分组页签轮询游标
        self._dlg_opt_repeat = 0       # 同一坐标已连点次数（假选项早退用）
        self._splash_since = None      # 客户端启动闪屏首次出现的时刻（卡死判定用）
        self._hung_since = None        # 窗口首次判定"无响应"的时刻（运行中假死判定用）
        self._scan_cache = {}          # 帧内 OCR 去重：(region, min_score) -> texts
        self._page_probes = None       # 帧内页面锚点判定缓存（_pages 惰性计算）
        self._last_page_key = None     # 上一帧识别出的页面（页面变化时打一条日志）
        self._ss_stuck = 0             # 服务器选择页连续"有页签无角色卡"帧数（错号善后用）
        self._ss_diag_at = 0.0         # 上次服务器选择页诊断存帧的时刻（限频）

    def _find(self, screen, name, **kwargs):
        """查找模板；模板缺失只警告一次并当作未找到，保证流程能继续走。"""
        try:
            return self.matcher.find(screen, name, **kwargs)
        except FileNotFoundError:
            if name not in self._warned:
                self._warned.add(name)
                log.warning("模板缺失，相关步骤将跳过: %s.png", name)
            return None

    def _has_template(self, name):
        return self.matcher.has_template(name)

    def _warn_once(self, key, msg, *args):
        if key not in self._warned:
            self._warned.add(key)
            log.warning(msg, *args)

    def _scan(self, screen, region, min_score=0.85):
        """本帧内的区域 OCR 缓存：同一帧同一区域只识别一次。

        "已进入游戏"的多路检测会重复扫描同一区域（背包/头像各被检两次），
        而并行登录时 OCR 是最重的单点（实测小区域约 0.9 秒、5 窗口争用引擎；
        实测提高引擎槽位无收益——本机 onnxruntime 已把 CPU 吃满，加槽位只会
        互相拖慢）。所以唯一的解法是**减少每帧识别次数**，去重后每帧从
        4~8 次降到 2~4 次。缓存按帧清空，由 step()/run() 负责。
        """
        key = (region, min_score)
        cache = getattr(self, "_scan_cache", None)
        if cache is None:      # 兼容不经 __init__ 构造（测试/离线模拟）的场景
            cache = self._scan_cache = {}
        hit = cache.get(key)
        if hit is None:
            hit = ocr.scan(screen, region, min_score)
            cache[key] = hit
        return hit

    def _contains(self, screen, target, region, min_score=0.5):
        """区域内是否识别出含 target 的文字（走帧内缓存）。"""
        return any(target in t for t, *_ in self._scan(screen, region, min_score))

    def _texts(self, screen, region, min_score=0.5):
        """区域内的文字列表（走帧内缓存，阈值与 ocr.dump_texts 一致）。"""
        return [t for t, *_ in self._scan(screen, region, min_score)]

    def _pages(self, screen):
        """本帧的页面锚点判定（惰性计算 + 帧内缓存，与 _scan_cache 同帧清空）。

        一帧只做一遍模板匹配：_is_logged_in 的反向门槛（_on_login_page）与
        step() 的点击分支共用同一份命中坐标，避免同一帧对同一模板匹配两遍。
        兼容不经 __init__ 构造（测试/离线模拟）的场景（同 _scan_cache）。
        """
        probes = getattr(self, "_page_probes", None)
        if probes is None:
            contains = lambda text, region: self._contains(screen, text, region)
            probes = {p.key: anchors.probe(self.matcher, screen, p,
                                           contains=contains)
                      for p in LOGIN_PAGES}
            self._page_probes = probes
        return probes

    def _on_main_screen(self, screen):
        """主界面判定：活动/玩法/商城必须出现在左侧按钮列的固定锚点处。

        这些半透明图标全屏匹配假阳性极高（实测误判分数高于真按钮），
        但它们在 405x720 客户区内的位置永远固定，锚点小区域匹配既快又准。
        三锚点全中才算（PAGE_MAIN.need=3），与页表化之前一致。
        """
        return anchors.probe(self.matcher, screen, PAGE_MAIN).ok

    def _detect_battle(self, screen):
        """战斗画面判定：右下角"自动"+（左下角"战况" 或 顶部回合/阶段数）。

        战斗中左侧主界面锚点全被遮住，是"登录成功但被判失败"的主因之一。
        "自动"是战斗才有的按钮；再叠一个"战况"/"回合/阶段"交叉确认防误判。
        """
        if not self._contains(screen, "自动", BATTLE_AUTO_REGION, min_score=0.5):
            return False
        if self._contains(screen, "战况", BATTLE_MARK_REGION, min_score=0.5):
            return True
        # 顶部回合数/阶段数（"第3回合"、"回合 3/30"、"阶段 2"）
        return any(_BATTLE_ROUND_RE.search(t)
                   for t in self._texts(screen, BATTLE_TOP_REGION))

    def _detect_ingame_ui(self, screen):
        """游戏内通用 UI 判定：背包入口 + 右上角头像（主界面/副本/多数场景都有）。

        登录后可能落在副本或特殊场景，左侧"活动/玩法/商城"不在，但背包与头像
        这类全局 UI 依然在——它们比锚点更宽松，用来覆盖"进游戏了但不在长安"。
        两个特征都要求命中，避免单个图标误判。
        """
        has_bag = self._find(screen, "背包", threshold=0.88, region=BAG_REGION,
                             ccoeff_floor=0.45) is not None
        if not has_bag:
            has_bag = self._contains(screen, "背包", BAG_REGION, min_score=0.5)
        if not has_bag:
            return False
        has_avatar = self._find(screen, "头像", threshold=0.88, region=AVATAR_REGION,
                                ccoeff_floor=0.45) is not None
        if not has_avatar:
            # 头像模板可能缺失：改判右上角是否有文字（角色名/等级）兜底
            has_avatar = bool(self._texts(screen, AVATAR_REGION))
        return has_avatar

    def _has_bag_or_avatar(self, screen):
        """背包或头像任一命中（地图名判定的伴随条件）。"""
        if self._find(screen, "背包", threshold=0.88, region=BAG_REGION,
                      ccoeff_floor=0.45) is not None:
            return True
        if self._contains(screen, "背包", BAG_REGION, min_score=0.5):
            return True
        if self._find(screen, "头像", threshold=0.88, region=AVATAR_REGION,
                      ccoeff_floor=0.45) is not None:
            return True
        return bool(self._texts(screen, AVATAR_REGION))

    def _detect_ingame_map(self, screen):
        """左上角地图名判定：有地名文字 = 已经在游戏场景内（云梦长安/副本场景名）。

        **地图名不能单独作为成功依据**：服务器选择页/角色页的左上角也有汉字
        （角色列表的"角色名"正落在 MAP_NAME_REGION 内，实测 21:03 角色页被
        误判成"检测到地图名"假成功退出）。所以地图名必须伴随至少一个其它
        游戏内信号（背包或头像）才算数——真实场景里右侧 UI 和地图名同屏。

        另有两道过滤：
        - 排除登录期页面的字样（踏入长安/账号登录/公告等）；
        - 要求至少 2 个汉字：OCR 对不可读美术字常吐 '□□□□' 方框垃圾；
        - 目标角色名本身不算地图名（角色列表里显示的就是它）。
        """
        texts = self._texts(screen, MAP_NAME_REGION)
        found_map_name = False
        for t in texts:
            t = t.strip()
            if any(k in t for k in _LOGIN_PAGE_WORDS):
                continue
            if self.character and self.character in t:
                continue
            han = "".join(ch for ch in t if _HAN_RE.match(ch))
            if len(han) >= 2:
                found_map_name = True
                break
        if not found_map_name:
            return False
        return self._has_bag_or_avatar(screen)

    def _scan_all(self, screen):
        """全图 OCR（帧内缓存）。

        ⚠️ 小区域裁剪 OCR 会**漏检**（实测 2026-10-10 狮王守卫场景："背包(380,580)"
        明明在 BAG_REGION 内，region 裁剪扫描读不到、全图扫描能读到；右上角"109"同理）。
        关键兜底判定（页签/背包/头像的 OCR 兜底）一律走全图 + 坐标过滤。
        """
        key = ("__all__", 0)
        cache = getattr(self, "_scan_cache", None)
        if cache is None:
            cache = self._scan_cache = {}
        hit = cache.get(key)
        if hit is None:
            hit = ocr.scan(screen)
            cache[key] = hit
        return hit

    def _detect_ingame_tabs(self, screen):
        """右上角「任务 | 队伍」页签判定：游戏内所有场景（主界面/副本/帮派领地）
        右上角都有这对页签（实测 (309,94)/(368,94)），登录期页面没有。

        用全图 OCR + 坐标过滤（TABS_REGION 内），不走小区域裁剪（会漏检，见 _scan_all）。
        """
        for t in self._scan_all(screen):
            text, x, y = t[0], t[1], t[2]
            if TABS_REGION[0] <= x <= TABS_REGION[0] + TABS_REGION[2] \
                    and TABS_REGION[1] <= y <= TABS_REGION[1] + TABS_REGION[3] \
                    and ("任务" in text or "队伍" in text):
                return True
        return False

    def _on_login_page(self, screen):
        """登录期页面判定：登录流程独有的按钮/页签可见 = 肯定还没进游戏。

        做**反向**门槛（比"点过进入游戏"的正向门槛可靠）：窗口可能上一轮就
        已经在游戏内（比如停在帮派领地/副本），新一轮登录状态机不会再点
        "进入游戏"，正向门槛会把宽松信号全封死导致超时（实测：已在游戏内的
        窗口二次登录，5/5 全部超时）。

        标志物除登录框（进入游戏）与踏入长安页（踏入长安）外，还覆盖
        **服务器选择页（我的角色）与角色页（进入长安）**——它们是登录流程的
        中间页，同样不是游戏内场景，且出现频次很高（实测 21:09 那轮 41 次
        点击里有 20+ 次花在这两页）。命中即跳过后续全部 OCR 检测：这些页面
        每帧本要跑 4~8 次区域识别（约 3~7 秒），现在降到 0 次，只做几张
        模板匹配（毫秒级）——这是提升并行登录速度最直接的一刀。

        2026-10-12 起走页面锚点表（LOGIN_PAGES）：多元素+互斥+OCR 兜底，
        判定结果缓存在本帧 _page_probes，step() 的点击分支直接复用坐标。
        """
        pr = self._pages(screen)
        return any(pr[key].ok for key in
                   ("login_box", "server_select", "server_enter", "char_page"))

    def _on_splash(self, screen):
        """客户端启动闪屏（诗悦 logo）判定。模板缺失时返回 False（当作非闪屏）。"""
        return self._find(screen, "客户端闪屏", threshold=0.9,
                          region=SPLASH_REGION) is not None

    def _is_logged_in(self, screen):
        """登录成功判定：以下任一成立即算已进入游戏。

        1. 主界面锚点（活动+玩法+商城）齐全
        2. 战斗画面（自动 + 战况/回合数）
        3. 游戏内通用 UI（背包 + 右上角头像）
        4. 左上角有地图名（在长安/帮派领地/副本等场景内）

        原实现只认第 1 条，导致"登录后不在长安主界面"或"登录后被拉进战斗"
        一律被判失败；这里改为多路特征任一命中，覆盖上述场景。

        反向门槛：看到"进入游戏/踏入长安"按钮则肯定还在登录期，直接判负，
        防止登录页上的文字/图标被宽松信号误判（正向"点过进入游戏"门槛不可
        靠——已在游戏内的窗口二次登录时状态机不会再点按钮，见 _on_login_page）。
        """
        if self._on_main_screen(screen):
            return True
        if self._on_login_page(screen):
            return False
        if self._detect_battle(screen):
            log.info("判定登录成功：检测到战斗画面")
            return True
        if self._detect_ingame_ui(screen):
            log.info("判定登录成功：检测到游戏内 UI（背包+头像）")
            return True
        if self._detect_ingame_map(screen):
            log.info("判定登录成功：检测到左上角地图名")
            return True
        if self._detect_ingame_tabs(screen):
            log.info("判定登录成功：检测到右上角「任务/队伍」页签")
            return True
        return False

    def _post_login_check(self, screen):
        """登录成功之后的收尾判定：UI 完整性体检 + 延迟弹窗观察。

        返回 True = 登录完成（可以交付给任务流程）；False = 继续观察/已判残废。

        UI 完整性体检见 UI_CHECK_GRACE 的说明：进了游戏但右上角「任务 | 队伍」
        页签始终不出现的客户端，之后所有点击都无反应（残废客户端），必须换一个。
        两条例外不判残废（都退回旧的"只等 5 秒"行为）：
        - OCR 不可用：没有判据，绝不凭空判死（宁可交给任务层的超时/兜底）；
        - 战斗画面：被拉进战斗时右侧 HUD 与常态不同，且战斗结束由任务层
          settle_scene 处理，不该在登录期判死这个客户端。
        """
        if getattr(self, "ui_broken", False):
            return False   # 已判残废：等 run() 收口（不重复存帧）
        since = getattr(self, "_main_since", None) or time.time()
        elapsed = time.time() - since
        if not getattr(self, "_tabs_seen", False):
            now = time.time()
            if now - getattr(self, "_ui_check_at", 0.0) >= UI_CHECK_INTERVAL:
                self._ui_check_at = now
                if self._detect_ingame_tabs(screen):
                    self._tabs_seen = True
                    log.info("UI 体检通过：右上角「任务/队伍」页签已出现")
        grace = getattr(self, "ui_check_grace", None) or UI_CHECK_GRACE
        if getattr(self, "_tabs_seen", False):
            return elapsed >= 5        # 旧行为：留 5 秒给登录后的延迟弹窗
        if not ocr.available():
            self._warn_once("no_ocr_ui_check", "OCR 不可用，跳过登录后 UI 体检")
            return elapsed >= 5
        if self._detect_battle(screen):
            log.info("UI 体检：当前在战斗画面，跳过页签检查（战斗由任务层处理）")
            return elapsed >= 5
        if elapsed >= grace:
            self.ui_broken = True
            log.error("登录后 %.0f 秒内右上角「任务/队伍」页签始终未出现，"
                      "判定客户端 UI 残废（此后点击将全部无反应）→ 交由调用方关窗重启",
                      elapsed)
            self._save_ui_broken_frame(screen)
        return False

    def _save_ui_broken_frame(self, screen):
        """残废客户端留证：存一帧到 debug/ui_broken_<时间>.png（失败不影响流程）。"""
        try:
            import cv2  # noqa: PLC0415
            from core.paths import DEBUG_DIR  # noqa: PLC0415
            ok, buf = cv2.imencode(".png", screen)
            if ok:
                buf.tofile(str(DEBUG_DIR / f"ui_broken_{time.strftime('%H%M%S')}.png"))
        except Exception:
            log.exception("UI 残废存帧失败")

    def _click(self, name, hit, cooldown=5):
        if self._last_action == name and time.time() - self._last_action_time < cooldown:
            return  # 冷却期内不重复点，等界面响应
        log.info("点击 [%s] @ (%d, %d) score=%.3f", name, hit[0], hit[1], hit[2])
        self.device.click(hit[0], hit[1])
        self._last_action = name
        self._last_action_time = time.time()
        if name in ("进入游戏", "进入长安"):
            self._last_enter_click = self._last_action_time
        elif name.startswith("账号"):
            self._last_account_click = self._last_action_time

    def _ss_diag(self, screen, card_name):
        """登录页（选服/角色页）找不到目标的限频诊断：日志细节 + 存帧等人看。"""
        now = time.time()
        if now - self._ss_diag_at < 30 and self._ss_stuck % 4:
            return
        self._ss_diag_at = now
        tpl_ok = bool(card_name) and self._has_template(card_name)
        tpl_hit = self._find(screen, card_name, threshold=0.95) if tpl_ok else None
        log.warning("选服页诊断：页签可见但没找到角色卡 %r（模板存在=%s 模板命中=%s）；"
                    "卡片区 OCR=%s", self.character, tpl_ok, tpl_hit,
                    self._texts(screen, CARD_LIST_REGION))
        try:
            import cv2  # noqa: PLC0415
            from core.paths import DEBUG_DIR  # noqa: PLC0415
            ok, buf = cv2.imencode(".png", screen)
            if ok:
                buf.tofile(str(DEBUG_DIR / f"ss_diag_{time.strftime('%H%M%S')}.png"))
        except Exception:
            log.exception("选服页诊断存帧失败")

    def _find_card(self, screen, card_name, tab_visible):
        """服务器选择页的角色卡：模板优先，OCR 角色名兜底。"""
        if card_name and self._has_template(card_name):
            card = self._find(screen, card_name, threshold=0.95)
            if card:
                return card
        if tab_visible:
            hit = self._ocr_exact_hit(screen, self.character, CARD_LIST_REGION)
            if hit is None:
                # 卡片区没认出目标角色：全屏再找一次。卡片区坐标是按 405x720
                # 客户区标定的，面板被拖动/窗口尺寸差异时目标卡可能在区域外
                #（2026-10-26 装机实测）。全屏同样只认逐字一致（防近似名）。
                hit = self._ocr_exact_hit(screen, self.character)
            return hit
        return None

    def _find_entry(self, screen, entry_name):
        """角色页左侧列表条目：模板优先（角色卡模板含名字+服务器，名字特定），
        OCR 兑底只接受逐字一致的命中（防近似名小号被点进去，2026-10-26）。"""
        for tpl in (entry_name,
                    f"角色卡_{self.character}" if self.character else None):
            if tpl and self._has_template(tpl):
                entry = self._find(screen, tpl, threshold=0.9)
                if entry:
                    return entry
        return self._ocr_exact_hit(screen, self.character, ENTRY_LIST_REGION)

    @staticmethod
    def _norm_name(s):
        """名字归一化：去空白/间隔号/标点后再比较。"""
        return re.sub(r"[\s·・.。,，:：'’\"“”]+", "", s or "")

    def _ocr_exact_hit(self, screen, name, region=None):
        """OCR 找角色名，但只接受**逐字一致**的命中。

        2026-10-26 run f52bd9 实锤：ocr.find_text 的模糊闸门（ratio 0.8）会把
        名字只差一两个字的小号条目当成本号点进去（33 级小号顶着 0.978 相似度
        被当成火锅涮到夜半登录：全天 15/22 任务大乱、家园购房剧情、组队邀请
        永远收不到——好友列表里的大号根本不在线）。角色身份识别必须逐字
        相等；只有近似命中时告警+存帧+返回 None，由调用方重试/中止。"""
        if not name:
            return None
        target = self._norm_name(name)
        if region is None:
            # 全屏：region 缺省时按帧尺寸算（比 ABORT_SCAN_REGION 大，
            # _find_card 的全屏兑底需要真正覆盖整幅画面）
            h, w = screen.shape[:2]
            region = (0, 0, w, h)
        rows = self._scan(screen, region, min_score=0.6)
        exact = [r for r in rows if self._norm_name(r[0]) == target]
        if exact:
            t, cx, cy, sc = max(exact, key=lambda r: r[3])
            return (cx, cy, sc)
        from difflib import SequenceMatcher  # noqa: PLC0415
        near = []
        for r in rows:
            t = self._norm_name(r[0])
            if not t:
                continue
            if target in t or t in target or SequenceMatcher(None, t, target).ratio() >= 0.6:
                near.append(r[0])
        if near:
            self._warn_once("entry_similar_name",
                            "OCR 只找到 %r 的近似名条目（候选=%s），逐字不一致"
                            "不点击（防登错号）", name, near[:6])
            try:
                self._ss_diag(screen, name)
            except Exception:
                pass  # 诊断存帧失败不影响主流程
        return None

    def _observe_class_badge(self, screen, name_cy):
        """角色页顺带学习/识别门派徽标（2026-10-12 新增，用户需求）。

        目标角色条目名字行下方的小圆徽交给 core.gamecls：已指定门派的角色存
        样本（自学习），未指定的尝试按样本识别并写回账号库。任何失败只记
        日志，**绝不打断登录流程**。
        """
        try:
            from core import db as _db, gamecls
            badge = gamecls.badge_from_entry_screen(screen, name_cy)
            if badge is None:
                return
            gamecls.observe(self.character, badge, _db.list_accounts())
        except Exception:
            log.exception("门派徽标学习/识别失败（不影响登录流程）")

    def _navigate_server_list(self, screen):
        """选服面板不在"我的角色"页签时：在区服列表里逐字找目标区服点它，
        找不到就轮询点分组页签（乘风区/盛世大唐/锦绣长安）翻列表。全部限频，
        找不到卡的总帧数仍由 _ss_stuck 累计触发重开登录框兑底。

        返回 True = 本帧真的点了一下（切服/翻分组），调用方据此判断"还有进展，
        继续等"；False = 限频中或没找到可点的东西。"""
        now = time.time()
        if now - self._srv_click_at < 6.0:
            return False
        hit = self._ocr_exact_hit(screen, self.server, SERVER_LIST_REGION)
        if hit:
            self._srv_click_at = now
            self._ss_stuck = 0
            log.info("区服列表里找到目标区服 %r，点击切服", self.server)
            self._click(f"区服:{self.server}", hit, cooldown=5)
            return True
        # 当前列表没有目标区服：翻下一个分组页签
        tab_name = SERVER_GROUP_TABS[self._srv_tab_idx % len(SERVER_GROUP_TABS)]
        self._srv_tab_idx += 1
        tab_hit = self._ocr_exact_hit(screen, tab_name,
                                      (0, 90, 140, 480))  # 面板左缘页签列
        if tab_hit:
            self._srv_click_at = now
            log.info("区服列表无 %r，切到分组页签 %r 继续找", self.server, tab_name)
            self._click(f"区服分组:{tab_name}", tab_hit, cooldown=5)
            return True
        return False

    def _report_server_bar(self, screen, btn_hit):
        """踏入长安页区服栏诊断：只报告当前显示的区服与配置是否一致
        （小号固定区服场景下，这里不一致=会话落在错误区服的前哨信号）。"""
        x0 = max(0, btn_hit[0] - 130)
        y0 = max(0, btn_hit[1] - 125)
        h = btn_hit[1] - 30 - y0
        if h <= 10:
            return
        texts = [t for t, *_ in self._scan(screen, (x0, y0, 260, h))]
        if not texts:
            return
        target = self._norm_name(self.server)
        if any(self._norm_name(t) == target for t in texts):
            self._warn_once("srv_bar_ok", "区服栏已显示目标区服 %r", self.server)
        else:
            self._warn_once("srv_bar_mismatch",
                            "区服栏显示 %r，配置区服是 %r（若持续不一致，"
                            "选服面板将找不到目标角色卡）", texts[:3], self.server)

    def _find_server_bar(self, screen, btn_hit):
        """踏入长安按钮上方的区服栏：OCR 找栏内服务器名文字，找不到退回固定偏移。"""
        x0 = max(0, btn_hit[0] - 130)
        y0 = max(0, btn_hit[1] - 125)
        h = btn_hit[1] - 30 - y0
        if h > 10:
            texts = self._scan(screen, (x0, y0, 260, h))
            if texts:
                # 取最靠下的文字（紧贴按钮的就是区服栏）
                text, cx, cy, score = max(texts, key=lambda r: r[2])
                return (cx, cy, score)
        return (btn_hit[0], btn_hit[1] + SERVER_BAR_OFFSET_Y, btn_hit[2])

    @staticmethod
    def _account_digits(text):
        m = _ACCOUNT_RE.search(text)
        return (m.group(1), m.group(2)) if m else None

    def _is_target_account(self, text):
        if not self.account or len(self.account) < 7:
            return False
        d = self._account_digits(text)
        return bool(d) and d[0] == self.account[:3] and d[1] == self.account[-4:]

    def _masked_account(self):
        return f"{self.account[:3]}****{self.account[-4:]}"

    def _check_login_account(self, screen):
        """登录框账号校验。返回 True=当前账号已是目标；False=在登录框且已处理
        （点开下拉/点选账号/告警），本帧不点进入游戏；None=不在登录框。"""
        field = self._scan(screen, ACCOUNT_FIELD_REGION)
        if not any(self._account_digits(t) for t, *_ in field):
            return None
        if any(self._is_target_account(t) for t, *_ in field):
            log.info("登录账号已确认: %s", self._masked_account())
            return True
        entries = [(t, cx, cy) for t, cx, cy, _ in self._scan(screen, ACCOUNT_LIST_REGION)
                   if self._account_digits(t)]
        if not entries:
            # 下拉未展开：点账号栏右侧的倒三角（坐标复用本帧页面锚点判定）
            arrow = self._pages(screen)["login_box"].box("账号下拉")
            if arrow:
                self._click("账号下拉", arrow)
            else:
                self._warn_once("no_arrow", "未找到账号下拉箭头，无法切换账号")
            return False
        target = [(t, cx, cy) for t, cx, cy in entries if self._is_target_account(t)]
        if target:
            t, cx, cy = target[0]
            self._click(f"账号:{t}", (cx, cy, 1.0))
        else:
            self._warn_once("account_missing",
                            "下拉列表中没有目标账号 %s（识别到: %s），请人工处理",
                            self._masked_account(), [t for t, *_ in entries])
        return False

    def _check_system_dialogs(self, screen):
        """统一扫描系统类弹窗（一次 OCR），命中返回 True：
        - 省电模式（客户端休眠，画面变暗+滑轨）：滑动解锁。解锁后底下的
          顶号弹窗才会露出来，两者可能叠加（实测教训）
        - "被迫下线"顶号弹窗：登录场景允许点"退出游戏"——客户端关窗则由
          run_login_parallel 的重启逻辑拉起，退回登录界面则状态机继续正常登录
        - "当前角色正处于战斗当中"：点"取消"让位于战斗，并中止本账号
        - "登录信息过期，请重新登录"toast / 扫码登录页：中止本账号
        - "当前账号校验失败，无法进入服务器"（互顶时重登触发）：点"确认"关弹窗，
          置 _reopen_login_box，由 step() 点头像重开登录框（不中止，继续登录）
        - "内存占用较高"优化提示：勾选"永久不提示"后点"确认"（不中止）
        """
        # 省电模式用自己的 SLEEP_SCAN_REGION 精扫（滑轨文字 y≈536 在弹窗区下沿）
        if dialogs.handle_sleep_mode(self.device, screen):
            return True
        texts = self._scan(screen, ABORT_SCAN_REGION)
        if not texts:
            return False
        # 客户端有新版本（2026-10-30 全账号翻车）：直接起的 cahx-win.exe 会弹
        # 「温馨提示 / 发现新版本，请打开启动器获取最新游戏版本 / 确定」，此时
        # **任何点击都无效**——点确定后客户端会走 WaitToQuit 自行退出（窗口随即
        # "消息泵无响应"）。旧逻辑把这个弹窗正文当成剧情选项（它正好落在
        # FALLBACK_OPTION_REGION 里、cx≈202/cz≈314）反复点，白烧满 300 秒登录
        # 超时再关窗换客户端，5 个号全中、一轮 14 分钟零任务。必须当场明确中止，
        # 让用户看到"去开启动器更新"这句话，而不是"登录状态机超时"。
        if any(k in t for t, *_ in texts for k in
               ("发现新版本", "请打开启动器", "最新游戏版本")):
            confirm = [(cx, cy) for t, cx, cy, _ in texts
                       if t.strip() in ("确定", "确认")]
            if confirm:
                self._click("新版本提示-确定", (confirm[0][0], confirm[0][1], 1.0),
                            cooldown=3)
            self.abort_reason = (
                "游戏客户端有新版本：请打开官方启动器 launcher.exe 点【更新游戏】"
                "完成更新后再跑（客户端现在点了确定就会自行退出）")
            return True
        if any(k in t for t, *_ in texts for k in dialogs.KICKED_KEYWORDS):
            btn = [(cx, cy) for t, cx, cy, _ in texts if "退出游戏" in t]
            if btn:
                log.warning("检测到顶号弹窗（被迫下线），点击 [退出游戏] 后重登")
                self._click("顶号-退出游戏", (btn[0][0], btn[0][1], 1.0), cooldown=3)
            else:
                log.warning("检测到顶号弹窗但未定位到 [退出游戏] 按钮")
            return True
        if any("战斗" in t and "登录" in t for t, *_ in texts):
            cancel = [(cx, cy) for t, cx, cy, _ in texts if t.strip() == "取消"]
            x, y = cancel[0] if cancel else BATTLE_CANCEL_FALLBACK
            self._click("战斗中-取消", (x, y, 1.0))
            self.abort_reason = "角色正在战斗中，已取消登录"
            return True
        if any("登录信息过期" in t or "重新登录" in t for t, *_ in texts):
            self.abort_reason = "登录信息过期，需人工重新登录"
            return True
        if any("扫码" in t for t, *_ in texts):
            self.abort_reason = "需要扫码登录"
            return True
        if any("账号校验失败" in t for t, *_ in texts):
            confirm = [(cx, cy) for t, cx, cy, _ in texts if t.strip() == "确认"]
            if confirm:
                log.warning("账号校验失败（可能正被互顶），点 [确认] 后从头像重开登录框")
                self._click("校验失败-确认", (confirm[0][0], confirm[0][1], 1.0),
                            cooldown=2)
                self._reopen_login_box = True
            return True
        return dialogs.handle_memory_dialog(self.device, screen, texts)

    def _pick_fallback_option(self, screen):
        """登录兜底阶梯：从画面中上部挑一个"剧情选项"坐标（已排除玩家头顶名牌）。

        两类隐患都要挡：
        ① **玩家头顶「称号+角色名」名牌**——固定在 cx≈206/cy≈335~374，与真选项
           同列同高，被读成一条 3 字以上的文本。2026-10-16 实测登录期这条兜底
           反复点名牌 @(206,335)，一路白烧到 300 秒登录超时 → 关窗换新客户端
           （用户看到的"自动退号"）。用 `ocr.name_tag_like` 排除。
        ② **同一坐标连点仍无进展**——真选项点一次就消失。连点
           `LOGIN_OPT_REPEAT_ABORT` 次还在同一处，判假选项返回 None，
           让调用方落到"跳过/ESC"而不是继续空点。

        返回 (cx, cy) 或 None。OCR 异常时返回 None（不抛出）。
        """
        try:
            me = str(self.character or "").replace(" ", "")
            opts = [(cx, cy) for t, cx, cy, _sc in
                    ocr.scan(screen, FALLBACK_OPTION_REGION, min_score=0.5)
                    if len(t) >= 3 and 150 <= cx <= 260
                    and not ocr.name_tag_like(t.replace(" ", ""), me)]
        except Exception:
            return None
        if not opts:
            self._dlg_opt_key, self._dlg_opt_repeat = None, 0
            return None
        hit = min(opts, key=lambda p: p[1])  # 最靠上的选项
        key = (hit[0] // 8, hit[1] // 8)     # 8px 网格聚类，容忍 OCR 抖动
        # 用 getattr 兜底：自检脚本常手搓实例（不跑 __init__），别让新字段炸掉
        if key == getattr(self, "_dlg_opt_key", None):
            self._dlg_opt_repeat = getattr(self, "_dlg_opt_repeat", 0) + 1
        else:
            self._dlg_opt_key, self._dlg_opt_repeat = key, 1
        if self._dlg_opt_repeat > LOGIN_OPT_REPEAT_ABORT:
            log.warning("登录兜底选项 @ (%d, %d) 已连点 %d 次无进展，判定假选项，"
                        "改走跳过/ESC", hit[0], hit[1], self._dlg_opt_repeat)
            self._dlg_opt_key, self._dlg_opt_repeat = None, 0
            return None
        return hit

    def step(self):
        """处理一帧，返回 True 表示已进入游戏（登录成功）。"""
        # 运行中假死：窗口消息泵不响应 → 之后的点击全部无效，且 dxcam 会用缓存帧
        # 让 OCR 复读旧画面（看起来"还有反应"），必须尽早判死而不是空转到超时。
        # 短暂挂起（加载/GC）会自愈：一旦恢复就清零计时，只有**持续**挂起才判死。
        # 挂起时本帧直接返回、不做任何动作——截图拿到的可能是冻结前的缓存帧，
        # 拿它判"已进入游戏"会误报成功。
        is_hung = getattr(self.device, "is_hung", None)
        if callable(is_hung) and is_hung():
            if self._hung_since is None:
                self._hung_since = time.time()
                log.warning("窗口无响应（IsHungAppWindow），开始计时（持续 %.0f 秒判定假死）",
                            HANG_HARD_SECONDS)
            elif time.time() - self._hung_since >= HANG_HARD_SECONDS:
                self.client_hung = True
                log.error("窗口持续 %.0f 秒无响应，判定客户端假死（点击已无效），"
                          "交由调用方关窗重启", time.time() - self._hung_since)
            return False
        self._hung_since = None

        screen = self.device.screenshot()
        self._scan_cache.clear()   # 帧内 OCR 缓存：新一帧重新识别
        self._page_probes = None   # 帧内页面锚点缓存：同上（首次访问时计算）

        # 客户端启动闪屏（诗悦 logo）：正常几秒即过；长时间停留 = 客户端卡死。
        # 这帧不做任何点击/ESC、也不计入"无匹配帧数"，否则会一直按 ESC 空转。
        if self._on_splash(screen):
            if getattr(self, "_splash_since", None) is None:
                self._splash_since = time.time()
                log.info("检测到客户端启动闪屏，等待客户端加载...")
            elif time.time() - self._splash_since >= SPLASH_HANG_SECONDS:
                self.client_hung = True
                log.error("客户端启动闪屏持续 %.0f 秒未消失，判定客户端卡死，需关窗重启",
                          time.time() - self._splash_since)
            return False
        self._splash_since = None

        if self._is_logged_in(screen):
            # 主界面可能紧跟着弹"内存优化"提示：先处理掉；
            # 再宽限观察几秒，防止登录一结束弹窗才出来无人处理
            if dialogs.handle_memory_dialog(self.device, screen,
                                            self._scan(screen, ABORT_SCAN_REGION)):
                return False
            if self._main_since is None:
                self._main_since = time.time()
                log.info("已进入游戏（登录成功特征命中），观察后续弹窗并做 UI 体检...")
            return self._post_login_check(screen)

        # "账号校验失败"善后（互顶重登）：点过"确认"回到踏入长安页，
        # 先关公告（若有），再点左上角头像图标重开诗悦登录框（手机号已预填），
        # 之后走正常"进入游戏"流程——不当中止处理
        if self._reopen_login_box:
            # 登录框已经重新出现（诗悦登录框的"进入游戏"可见）→ 善后完成，
            # 交回正常流程继续登录。**必须先确认再清标志**，见下面的教训。
            if self._find(screen, "进入游戏", threshold=0.95):
                log.info("账号校验失败善后：登录框已重新打开，回到正常登录流程")
                self._reopen_login_box = False
                return False
            hit = self._find(screen, "公告关闭", threshold=0.9)
            if hit:
                # 公告 X 与内存优化弹窗的 X 同图标：点之前先排除内存优化
                if dialogs.handle_memory_dialog(self.device, screen,
                                                self._scan(screen, ABORT_SCAN_REGION)):
                    return False
                self._click("公告关闭", hit)
                return False
            # 2026-10-16 事故：旧代码点一次"头像"就把 _reopen_login_box 清掉，
            # 那一次点空了之后，状态机把"踏入长安页"当正常页面反复点"选择区服"
            # （页面上根本没有登录框），登录框始终回不来，白耗到登录状态机超时
            # （7 号整账号本轮被跳过）。改为：没看到登录框就每隔 8 秒再点一次，
            # 上限 6 次仍无果才明确中止本账号（日志写清楚，不再静默超时）。
            if time.time() - self._reopen_click_at >= 8:
                self._reopen_click_at = time.time()
                self._reopen_clicks += 1
                log.warning("账号校验失败善后：第 %d 次点头像重开登录框",
                            self._reopen_clicks)
                self._click("头像-重开登录框",
                            (ACCOUNT_ICON_POS[0], ACCOUNT_ICON_POS[1], 1.0),
                            cooldown=0)
            if self._reopen_clicks >= 6:
                self.abort_reason = "账号校验失败后重开登录框始终未出现"
                return False
            return False

        # 系统弹窗的 OCR 扫描只在风险窗口内执行：开局几帧（窗口可能直接
        # 开在扫码/过期页）、刚点过进入游戏/进入长安后的 15 秒内、或连续
        # 无匹配的未知页面。常规页面不扫，避免每帧全量 OCR 拖慢轮询
        self._frames += 1
        # 页面判定轨迹：页面切换时打一条（含锚点命中明细），日志直接能看出
        # "流程到了哪一步、是模板确认还是 OCR 兜底"
        pr = self._pages(screen)
        # 歧义检测（2026-10-12）：多个**独占页**在同一帧都"确认命中" = 至少一个是
        # 假阳性（模板会被多页复用——公告 X 与登录框 X 同图；半透明图标假阳性
        # 又高）。此时按优先级取第一个就是赌运气，可能把登录框关了/点进错页。
        # 规则见 anchors.resolve：只认"唯一 OCR 确认"的那个，否则**本帧不采信、
        # 不点击**，交给下面的兜底阶梯（剧情选项 / ESC）。
        # 浮层页（公告）不参与唯一性检查——它本来就叠在别的页面上。
        usable, amb = anchors.resolve(pr, LOGIN_PAGE_ORDER,
                                      overlays=LOGIN_OVERLAY_PAGES)
        if amb:
            sig = tuple(k for k in LOGIN_PAGE_ORDER if k in pr and pr[k].ok)
            if sig != getattr(self, "_last_amb_sig", None):
                self._last_amb_sig = sig
                log.warning("页面判定歧义，本帧不采信、不点击：%s", amb)
        else:
            self._last_amb_sig = None
        page_key = usable[0] if usable else None
        if page_key != getattr(self, "_last_page_key", None):
            self._last_page_key = page_key
            log.info("当前页面: %s", pr[page_key].detail() if page_key
                     else ("页面判定歧义（不动作）" if amb
                           else "未识别（固定元素与 OCR 都判不出，走兜底动作）"))

        def _box(key, template):
            """取本帧"可用页面"里某个锚点的坐标；歧义帧一律 None（= 不点击）。

            所有按页面判定结果点击的分支都必须用它，不能直接 `pr[k].box(...)`
            ——那会绕过歧义闸。
            """
            pg = pr.get(key)
            return pg.box(template) if pg is not None and key in usable else None
        risky = (self._frames <= 3 or self._idle_frames >= 2
                 or time.time() - self._last_enter_click < 15)
        if risky and self._check_system_dialogs(screen):
            return False

        card_name = f"角色卡_{self.character}" if self.character else None
        entry_name = f"角色_{self.character}" if self.character else None
        # 有角色卡模板或 OCR 可用时走选服流程，否则退化为直接点踏入长安（旧行为）
        can_select_server = bool(self.character) and (
            self._has_template(card_name) or ocr.available())

        # 服务器选择页：点目标角色卡（点卡 = 选区服 + 选角色）。卡片可见就点，
        # 不可见就静默等下一帧——**不能**拿"卡片从屏幕消失"当"点击成功"置永久
        # 标志：点卡后被游戏弹回踏入长安页时卡片同样会消失，标志一旦置位就永远
        # 跳过选卡分支；之后服务器面板右上角自己的 X（与公告关闭同图标，匹配分
        # 仅 0.90~0.93）会被当公告点掉 → 关掉整个面板 → 弹回踏入长安页 → 再开
        # 选服 → 再误关……死循环到登录超时（2026-10-13 01:07「外卖点到手颤」
        # 实测白耗 5 分钟，4/5 成功的那 1 个失败就是它）。
        # ⚠ 必须限定 server_select 页（2026-10-26 r6 事故）：本块原本不分页面
        # 每帧都跑，靠"找不到就落空"继续往下；r6 在块尾加了区服导航 + 无条件
        # return False 后，登录框/踏入长安页的每一帧都在这里提前返回——账号
        # 校验、点击进入游戏永远执行不到，全部账号静默空转到登录超时（17:00
        # 全军覆没，用户手动点击一切正常）。页面守卫是唯一正确写法。
        if can_select_server and page_key == "server_select":
            tab = self._find(screen, "我的角色")
            if tab is None and ocr.available():
                # 2026-10-30：模板是"选中态"紫色文字；新版客户端默认停在「推荐」
                # 页签时「我的角色」是灰色未选中，模板匹配不上（7 号两天登不进去
                # 的直接原因）。OCR 逐字兜底实测灰字置信度 0.9998，形状很稳。
                hit_tab = self._ocr_exact_hit(screen, "我的角色", SERVER_TAB_REGION)
                if hit_tab:
                    tab = hit_tab
            card = self._find_card(screen, card_name, tab_visible=tab is not None)
            if card:
                self._ss_stuck = 0
                self._click(f"角色卡:{self.character}", card)
                return False
            if tab is not None:
                self._ss_stuck += 1
                self._ss_diag(screen, card_name)
                if self._ss_stuck >= 8:
                    # 连续 8 帧有页签、没角色卡：目标角色不在当前列表里。
                    # 先试"区服列表切服"——卡片可能躺在别的区服（会话落在错误
                    # 区服时"我的角色"里翻不到），这里点一下就能换服重来。
                    if self.server and ocr.available() and \
                            self._navigate_server_list(screen):
                        self._ss_stuck = 0
                        return False
                    # 切服也点不动：十有八九是客户端登着别的诗悦账号（2026-10-26 装机实测：
                    # 「我的角色」列表里只有别人账号的角色卡，worker 反复点页签到
                    # 登录超时）。善后 = 关掉选择面板（它的 X 与公告关闭同图标，
                    # 阈值 0.90 能命中）→ 点左上角头像重开登录框 → 正常流程会
                    # 重新校验账号并切到正确账号。
                    self._ss_stuck = 0
                    log.warning("服务器选择页连续 8 次未找到角色卡 %r，"
                                "疑似登错账号——关闭面板并重开登录框换号",
                                self.character)
                    hit = self._find(screen, "公告关闭", threshold=0.90)
                    if hit:
                        self._click("关闭选服面板", hit)
                    self._reopen_login_box = True
                    self._reopen_click_at = 0.0
                    return False
                self._click("我的角色", tab)  # 服务器选择页：切到"我的角色"页签
                return False
            # 不在"我的角色"页签（推荐/区服列表）：若配置了区服且能在列表里逐字
            # 找到它，直接点它切服。背景：固定区服的小号客户端（2026-10-26 用户
            # 确认小号改不了区服）会把会话落在错误区服，"我的角色"里永远翻不到
            # 目标角色卡——这是唯一的切服入口。找不到则轮询分组页签翻列表。
            if self.server and ocr.available():
                self._navigate_server_list(screen)
            return False

        # 登录框：配了账号且 OCR 可用时先校验当前账号，不符则切换后再进游戏。
        # 必须在公告关闭之前：登录框右上角的 X 与公告关闭是同一图标。
        # 账号校验的 OCR 只在登录框可见（进入游戏命中）、开局几帧、或刚操作过
        # 账号下拉时执行（下拉展开会遮挡进入游戏按钮），常规页面不做，避免拖慢轮询
        hit = _box("login_box", "进入游戏")
        if self.account and not self._account_ok and (
                hit or self._frames <= 3
                or time.time() - self._last_account_click < 10):
            if ocr.available():
                status = self._check_login_account(screen)
                if status is True:
                    self._account_ok = True
                elif status is False:
                    return False
            else:
                self._warn_once("no_ocr_account", "OCR 不可用，跳过登录账号校验")
                self._account_ok = True

        if hit:
            self._click("进入游戏", hit)
            return False

        # 公告关闭必须在服务器选择页/登录框判定之后：这些面板的 X 与公告关闭
        # 是同一个图标，先判公告会误关面板（关了又开，死循环）。
        # "内存优化"弹窗的 X 也是这个图标：点 X 前确认不是它（要走勾选+确认流程）
        # 互斥判定已收敛进 PAGE_ANNOUNCE（登录框可见时 ok=False，box 必为 None）
        hit = _box("announce", "公告关闭")
        if hit:
            if dialogs.handle_memory_dialog(self.device, screen,
                                            self._scan(screen, ABORT_SCAN_REGION)):
                return False
            self._click("公告关闭", hit)
            return False

        # 踏入长安页：配了角色必须先点上方的区服栏选服，直接点踏入长安可能进错区
        hit = _box("server_enter", "踏入长安")
        if hit:
            if can_select_server:
                if self.server and ocr.available():
                    self._report_server_bar(screen, hit)
                self._click("选择区服", self._find_server_bar(screen, hit))
            else:
                self._click("踏入长安", hit)
            return False

        hit = _box("char_page", "进入长安")
        if hit:
            if self.character and not self.char_selected:
                # 角色页：左侧列表点目标角色使其选中（连点两帧防丢击，点已选中项无副作用）
                entry = self._find_entry(screen, entry_name)
                if entry:
                    self._observe_class_badge(screen, entry[1])
                    self._click(f"角色:{self.character}", entry, cooldown=2)
                    self._char_clicks += 1
                    if self._char_clicks >= 2:
                        self.char_selected = True
                elif entry_name and not self._has_template(entry_name) and not ocr.available():
                    # 既无模板又无 OCR，无法校验选中状态，警告后放行
                    self._warn_once("no_entry_verify",
                                    "无法校验角色选中状态（缺 %s.png 且 OCR 不可用），直接进入", entry_name)
                    self.char_selected = True
                else:
                    self._entry_miss = getattr(self, "_entry_miss", 0) + 1
                    self._warn_once(
                        "entry_not_found",
                        "角色页未找到角色名 %r，区域识别结果: %s",
                        self.character, self._texts(screen, ENTRY_LIST_REGION))
                    if self._entry_miss >= 8:
                        # 2026-10-26：连续 8 帧都没有逐字一致的角色条目——宁可
                        # 中止该账号（登录失败，人工介入），也绝不把近似名小号
                        # 点进去跑一天任务（run f52bd9 教训）。
                        self.abort_reason = (
                            f"角色页找不到与 {self.character!r} 逐字一致的角色"
                            "条目（疑似近似名小号/他人会话），中止登录防登错号")
                    return False
            self._click("进入长安", hit)
            return False

        # 兜底：连续多帧无任何匹配（可能是不认识的面板挡住了主界面），
        # 按 ESC 尝试关闭。登录框/启动页/角色页都有模板命中，不会误按。
        # 注意剧情动画/对话（开服剧情、任务链剧情）：① 可能带选项（【括号】
        # 风格或无括号胶囊多选项，同 tasks/zongmen._find_dialog_option）——
        # 有选项未选时"跳过"无效，必须先点选项（实测"劫镖山匪"两选项卡死
        # 20 分钟）；② 无选项时右下角"跳过"（OCR 常读成"→跳过"）；③ 都没有
        # 再按 ESC。
        self._idle_frames += 1
        if self._idle_frames >= 10:
            hit = self._pick_fallback_option(screen)
            if hit:
                log.info("剧情对话带选项，点最上面的选项 @ (%d, %d)", hit[0], hit[1])
                self.device.click(hit[0], hit[1])
            else:
                hit2 = None
                try:
                    # 实测 OCR 把按钮读成"→跳过"（相似度 0.8），阈值不能卡 1.0
                    hit2 = ocr.find_text(screen, "跳过", min_similarity=0.6)
                except Exception:
                    hit2 = None
                if hit2:
                    # find_text 返回 (cx, cy, score)，只取坐标
                    log.info("疑似剧情动画挡住登录流程，点击 [跳过] @ (%d, %s)",
                             hit2[0], hit2[1])
                    self.device.click(hit2[0], hit2[1])
                else:
                    log.info("连续 %d 帧无匹配，按 ESC 尝试关闭异常面板",
                             self._idle_frames)
                    self.device.press_esc()
            self._idle_frames = 0
        return False

    def run(self):
        while time.time() < self.deadline:
            # getattr 兜底：部分自检/工具用手工拼的 LoginFlow（不经 __init__）
            if getattr(self, "stop_event", None) is not None \
                    and self.stop_event.is_set():
                log.info("登录状态机收到停止请求，中断登录")
                return False
            try:
                if self.step():
                    log.info("已进入游戏，登录成功")
                    return True
                if self.abort_reason:
                    log.warning("登录中止: %s", self.abort_reason)
                    return False
                if self.client_hung:
                    log.warning("客户端卡死（启动闪屏不消失 / 窗口持续无响应），交由调用方关窗重启")
                    return False
                if getattr(self, "ui_broken", False):
                    log.warning("客户端 UI 残废（登录后右上角「任务/队伍」页签不出、"
                                "点击无反应），交由调用方关窗重启")
                    return False
            except Exception as e:
                log.error("登录状态机异常（窗口可能已关闭）: %s", e)
                return False
            time.sleep(random.uniform(0.15, 0.3))
        # 超时后最后再看几眼：首次登录的客户端资源加载慢（实测可达 4 分钟），
        # 可能刚进游戏特征就位，按成功处理避免误杀——**但同样要过 UI 体检**
        # （残废客户端若从这里放行，会一路卡死在任务流程里，见 _last_chance_ui_check）
        try:
            if self._last_chance_ui_check():
                return True
        except Exception:
            log.exception("超时补检异常")
        log.error("登录状态机超时")
        return False

    def _last_chance_ui_check(self):
        """登录超时后的补检：进游戏特征刚就位时，补一次 UI 完整性体检。

        只看一帧不够——OCR 偶发漏检会把正常客户端误判成残废，所以这里最多
        再观察 UI_CHECK_GRACE 秒（每 UI_CHECK_INTERVAL 秒采样一次页签）。
        页签出现 / OCR 不可用 / 战斗画面 → 按成功放行；始终不出现 → ui_broken。
        """
        if getattr(self, "ui_broken", False):
            return False
        grace = getattr(self, "ui_check_grace", None) or UI_CHECK_GRACE
        deadline = time.time() + grace
        last = None
        while time.time() < deadline:
            try:
                self._scan_cache.clear()
                screen = self.device.screenshot()
                last = screen
                if not self._is_logged_in(screen):
                    return False
                if self._main_since is None:
                    self._main_since = time.time()
                if self._detect_ingame_tabs(screen):
                    log.info("超时后进游戏特征才出现，且 UI 体检通过，按登录成功处理")
                    return True
                if not ocr.available():
                    log.info("超时后进游戏特征才出现（OCR 不可用，跳过 UI 体检），"
                             "按登录成功处理")
                    return True
                if self._detect_battle(screen):
                    log.info("超时后进游戏特征才出现（战斗中，跳过 UI 体检），按登录成功处理")
                    return True
            except Exception as e:
                log.error("超时补检失败（窗口可能已关闭）: %s", e)
                return False
            time.sleep(UI_CHECK_INTERVAL)
        self.ui_broken = True
        log.error("超时后进游戏特征已出现，但 %.0f 秒内右上角「任务/队伍」页签"
                  "始终未出现，判定客户端 UI 残废 → 交由调用方关窗重启", grace)
        if last is not None:
            self._save_ui_broken_frame(last)
        return False
