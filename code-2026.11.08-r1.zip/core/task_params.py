# -*- coding: utf-8 -*-
"""默认清单（config.yaml 的 `tasks[].enabled`）与任务参数（次级选项）的读写。

2026-10-14 从 `gui.py` 的 `TasksTab` 搬出（重构批次②）：这些是**纯 YAML 读写**，
不依赖任何 Qt 符号，放在 core 里可以离屏单测、也能被非 GUI 入口复用。
GUI 侧保留同名薄封装转调（见 `TasksTab.default_list` 等），外部调用点不变。

约定（务必保持）：
- 「默认清单」的**唯一**来源 = `tasks[].enabled == true`，按文件顺序；
- 写回一律走**按行文本替换**，保留文件里的全部注释与缩进；
- 参数只认「非缺省」值（`_saved_suboption` 负责回落与旧版列表键兼容）。
"""
from __future__ import annotations

import logging

import yaml

from core.paths import CONFIG_PATH

log = logging.getLogger("taskparams")


# ---------------------------------------------------------------- 读

def read_config(config_path=None):
    """读 config.yaml；失败返回空 dict（并记日志，不抛）。"""
    path = config_path or CONFIG_PATH
    try:
        with open(path, encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except Exception:
        log.exception("读 config.yaml 失败")
        return {}


def default_list(config_path=None):
    """默认清单 = `tasks[].enabled` 为 true 的任务名（按文件顺序）。

    这是**唯一**的默认清单来源：向导第 2 步的预填、任务页 ③ 卡展示都读它。
    """
    cfg = read_config(config_path)
    return [t["name"] for t in (cfg.get("tasks") or [])
            if isinstance(t, dict) and t.get("enabled")]


def enabled_task_configs(config_path=None):
    """所有任务的勾选状态（= 默认清单），按 config.yaml 的文件顺序。

    2026-10-12 起任务页不再有可勾选芯片，所以这里**只读 config.yaml**。
    """
    cfg = read_config(config_path)
    return [{"name": t.get("name"), "enabled": bool(t.get("enabled"))}
            for t in (cfg.get("tasks") or []) if isinstance(t, dict)]


def checked_task_names(config_path=None):
    """默认清单里的任务名（向导第 2 步预填 + ③ 卡渲染的共同数据源）。"""
    return [t["name"] for t in enabled_task_configs(config_path) if t["enabled"]]


def saved_suboption(entry, spec):
    """config.yaml 里已存的次级选项单值；无配置 = spec 默认值。

    兼容旧版列表键（layers / modes，取首个有效值）——老配置不改也不会报错。
    """
    raw = entry.get(spec["key"])
    if raw is None:
        for k in spec.get("legacy_keys", ()):
            legacy = entry.get(k)
            if isinstance(legacy, (list, tuple)):
                legacy = legacy[0] if legacy else None
            if legacy is not None:
                raw = legacy
                break
    valid = [v for v, _ in spec["options"]]
    return raw if raw in valid else spec["default"]


def saved_params(param_tasks, param_specs, config_path=None):
    """config.yaml 里已存的参数（仅**非缺省**值）：{任务名: 值}。

    用于 ③ 卡渲染带参数胶囊、以及向导第 2 步「任务参数」的初值。
    `param_tasks` / `param_specs` 由调用方传入（GUI 侧是 `TasksTab.PARAM_TASKS`
    与 `TasksTab.PARAM_SPECS`），避免 core 反向依赖 gui。
    """
    out = {}
    cfg = read_config(config_path)
    entries = {t.get("name"): t for t in (cfg.get("tasks") or [])
               if isinstance(t, dict)}
    for name in param_tasks:
        spec = param_specs.get(name)
        if spec is None or name not in entries:
            continue
        value = saved_suboption(entries[name], spec)
        if value != spec["default"]:
            out[name] = value
    return out


# ---------------------------------------------------------------- 写

def save_default_list(names, config_path=None):
    """把本次勾选写回 config.yaml（`enabled`），并返回未在 tasks 段里找到的任务名。

    - `names`：要标记为 enabled 的任务名集合（**只认名字，其余一律 false**）
    沿用按行文本替换的写法，**保留文件里的全部注释**。
    调用方（GUI）拿到 missing 后自行记日志/刷新。
    """
    path = config_path or CONFIG_PATH
    names = list(names)
    lines = path.read_text(encoding="utf-8").splitlines()
    out, in_tasks, cur, seen = [], False, None, set()
    for line in lines:
        s = line.strip()
        if s.startswith("tasks:"):
            in_tasks = True
        elif in_tasks and s and not line.startswith((" ", "-", "#")):
            in_tasks = False       # 离开 tasks 段
        if in_tasks and s.startswith("- name:"):
            cur = s.split(":", 1)[1].split("#", 1)[0].strip()
            seen.add(cur)
        elif in_tasks and s.startswith("enabled:") and cur is not None:
            indent = line[: len(line) - len(line.lstrip())]
            line = f"{indent}enabled: {'true' if cur in names else 'false'}"
        out.append(line)
    path.write_text("\n".join(out) + "\n", encoding="utf-8")
    return [n for n in names if n not in seen]


def save_task_option(task_name, key, value, config_path=None):
    """把任务的参数（次级选项）单值写回 config.yaml 该任务条目。

    已有 key 行或旧版列表键（layers / modes）的行整行替换，没有则在
    `- name` 行后插入；`value=None` 删除该行（回到缺省）；保留其余注释。

    2026-10-12 从 `TasksTab` 的方法提升为模块级函数；2026-10-14 再搬进 core
    （写回现在发生在「开始任务」向导里，不再是任务页芯片行为）。
    """
    path = config_path or CONFIG_PATH
    legacy_keys = {"layer": ("layers",), "mode": ("modes",)}.get(key, ())
    hit_prefixes = tuple(f"{k}:" for k in (key,) + legacy_keys)
    lines = path.read_text(encoding="utf-8").splitlines()
    out, in_tasks, in_entry, wrote, entry_pos = [], False, False, False, None
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("tasks:"):
            in_tasks = True
        elif in_tasks and stripped and not line.startswith((" ", "-", "#")):
            in_tasks = False      # 离开 tasks 段
        if in_tasks and stripped.startswith("- name:"):
            cur = stripped.split(":", 1)[1].split("#", 1)[0].strip()
            in_entry = cur == task_name
            if in_entry:
                entry_pos = len(out)   # "- name: X" 行在 out 中的下标
        elif in_entry and stripped.startswith(hit_prefixes):
            if value is None:
                continue           # 删除该行（回到缺省）
            indent = line[: len(line) - len(line.lstrip())]
            line = f"{indent}{key}: {value}"
            wrote = True
            in_entry = False
        out.append(line)
    if not wrote and value is not None and entry_pos is not None:
        base = lines[entry_pos]
        indent = base[: len(base) - len(base.lstrip())] + "  "
        out.insert(entry_pos + 1, f"{indent}{key}: {value}")
        wrote = True
    if not wrote and value is not None:
        log.warning("config.yaml 的 tasks 段缺少 %s 条目，%s 未写入", task_name, key)
        return
    path.write_text("\n".join(out) + "\n", encoding="utf-8")


def save_params(params, config_path=None):
    """批量写参数：`params` = {任务名: {键: 值}}，值 None = 删掉该行回到缺省。"""
    for task, kv in (params or {}).items():
        for key, value in kv.items():
            save_task_option(task, key, value, config_path)
