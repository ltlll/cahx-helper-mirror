# -*- coding: utf-8 -*-
"""热更新（仅打包版生效）：检测 → 下载 → 暂存，重启后由 boot.py 应用。

职责划分：
- 本模块（载荷内，可热更）：读 manifest、比版本、下载校验、暂存到
  ``app/versions/<版本>/`` 并写 ``app/pending.json``、GUI 重启入口、
  崩溃计数清零（mark_boot_ok）与旧版本 GC。
- boot.py（引导器，不热更）：应用 pending（切指针 + 素材合并）、崩溃回滚。
  运行中的进程**绝不**替换当前版本目录，切换只发生在下次启动，天然规避
  Windows 文件锁。

开发模式（非 FROZEN）所有入口静默返回 None/False，开发与自检不受影响。
"""
import hashlib
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path

from core.paths import (CONFIG_PATH, CURRENT_JSON, DATA_DIR, DEBUG_DIR, FROZEN,
                        PENDING_JSON, ROOT, UPDATE_STATE, VERSIONS_DIR)

log = logging.getLogger("updater")

CHUNK = 64 * 1024
HTTP_TIMEOUT = 10            # 兼容旧引用：单次 socket 操作超时（连接另算）
CONNECT_TIMEOUT = 15         # 建立连接超时（国内直连 github 常卡在这里）
READ_TIMEOUT = 30            # 单次 socket 读超时（慢速镜像每块几十 KB，30s 足够）
DOWNLOAD_TOTAL_TIMEOUT = 900  # 单个源下载总时长上限（9 分钟 ≈ 260KB/s 跑完 143MB）
KEEP_VERSIONS = 2            # 版本目录最多保留几版（当前版 + 回滚用上一版）

# ---------------------------------------------------------------- 更新源
# 2026-11-02：实测本机「直连 github.com」完全不通（connect 卡死），而
# objects.githubusercontent.com、gh-proxy.com、ghfast.top、cdn.jsdelivr.net
# 都能通 → 单一地址必然失败。改为**多源串行回退**：任一源成功即停。
GH_RELEASE_BASE = ("https://github.com/ltlll/cahx-helper-updates"
                   "/releases/download/autoupdate")
# 前缀镜像：把 github 全 URL 拼在镜像域名后面即可。留空串 = 直连。
MIRROR_PREFIXES = ("", "https://gh-proxy.com/", "https://ghfast.top/")
# jsDelivr 仓库镜像：不走 Release 那套 302 跳转，国内有可用 CDN 节点。
# 由 tools/publish_mirror.py 把 manifest.json / code-*.zip 推到
# ltlll/cahx-helper-mirror 的 main 分支。
JSDELIVR_TEMPLATE = "https://cdn.jsdelivr.net/gh/ltlll/cahx-helper-mirror@main/{name}"
# 离线更新包目录：把 code-*.zip 丢进来，启动即装（不依赖任何网络）。
LOCAL_UPDATE_DIR = DATA_DIR / "update"
# 载荷完整性关键文件（boot.py 内有一份相同拷贝，改动需同步）
REQUIRED_PAYLOAD_FILES = ("payload.json", "gui.py", "pet.py", "worker.py",
                          "core/paths.py", "theme/app.qss")

# 版本号格式：2026.10.15-r1（-rN 可省，缺省为 r0）
_VER_RE = re.compile(r"^(\d{4})\.(\d{1,2})\.(\d{1,2})(?:-r(\d+))?$")


@dataclass
class UpdateInfo:
    """一条可更新的版本（check_update 的返回值）。"""
    version: str
    url: str
    sha256: str
    size: int = 0
    changelog: str = ""
    min_runtime: str = ""      # 要求的最低运行时（exe）构建日期 YYYY.MM.DD
    full_url: str = ""         # needs_full 时提示的全量包下载地址
    needs_full: bool = False   # 运行时太旧，热更无意义，需全量重装
    local_path: str = ""       # 非空 = 来自 data/update/ 的离线包，无需下载
    source: str = ""           # 实际命中的源（日志/排查用）


# ---------------------------------------------------------------- 版本号

def version_key(ver):
    """'2026.10.15-r1' → ((2026,10,15), 1)；解析失败返回 None。"""
    m = _VER_RE.match((ver or "").strip())
    if not m:
        return None
    return (int(m.group(1)), int(m.group(2)), int(m.group(3))), int(m.group(4) or 0)


def is_newer(new, cur):
    """new 是否比 cur 新。任一解析失败 → False（不认识的一律不更）。"""
    kn, kc = version_key(new), version_key(cur)
    if kn is None or kc is None:
        return False
    return kn > kc


def current_version():
    """当前载荷版本（app/current.json）；开发模式或缺失返回 None。"""
    if not FROZEN:
        return None
    try:
        return (json.loads(CURRENT_JSON.read_text(encoding="utf-8")) or {}).get("code")
    except Exception:
        return None


def pending_version():
    """已下载待生效的版本号（无则 None）。"""
    try:
        return (json.loads(PENDING_JSON.read_text(encoding="utf-8")) or {}).get("version")
    except Exception:
        return None


def runtime_version():
    """运行时（引导器 exe）构建版本 = exe 文件日期，YYYY.MM.DD。

    热更只换载荷；manifest 的 min_runtime 高于它说明新版载荷依赖了
    新运行时（如新增三方库），必须全量重装。
    """
    if not FROZEN:
        return None
    try:
        mt = Path(sys.executable).stat().st_mtime
        return time.strftime("%Y.%m.%d", time.localtime(mt))
    except Exception:
        return None


# ---------------------------------------------------------------- 配置

def _update_cfg():
    """config.yaml 的 update: 段（文件没有该段/读失败 → 空 dict，按缺省放行）。"""
    try:
        import yaml
        with open(CONFIG_PATH, encoding="utf-8") as f:
            return (yaml.safe_load(f) or {}).get("update") or {}
    except Exception:
        return {}


def enabled():
    return FROZEN and bool(_update_cfg().get("enabled", True))


# ---------------------------------------------------------------- 检测

_LAST_ERROR = ""      # 最近一次 check_update 的失败原因（"" = 无错或已是最新）


def last_error():
    """最近一次检查的失败原因；已是最新/未检查返回 ""。GUI 用来区分
    「确实没有新版本」和「网络不通」——旧实现两者都返回 None，界面只能
    笼统说「已是最新」，用户完全看不出是断网。"""
    return _LAST_ERROR


def _dedup(items):
    out = []
    for x in items:
        if x and x not in out:
            out.append(x)
    return out


def _manifest_urls():
    """manifest 的候选地址：config 指定 → 直连 → 前缀镜像 → jsDelivr。"""
    cfg_url = (_update_cfg().get("manifest_url") or "").strip()
    urls = [cfg_url]
    for pre in MIRROR_PREFIXES:
        if cfg_url.startswith("https://github.com/"):
            urls.append(pre + cfg_url)
        elif pre == "":
            urls.append(GH_RELEASE_BASE + "/manifest.json")
        else:
            urls.append(pre + GH_RELEASE_BASE + "/manifest.json")
    urls.append(JSDELIVR_TEMPLATE.format(name="manifest.json"))
    return _dedup(urls)


def _asset_urls(info):
    """代码包的候选地址：manifest 里的 url → 前缀镜像 → jsDelivr。

    jsDelivr 用文件名（``code-<版本>.zip``），镜像仓库里同名放一份。
    """
    urls = [info.url]
    if info.url.startswith("https://github.com/"):
        urls += [pre + info.url for pre in MIRROR_PREFIXES if pre]
    else:
        # manifest 给的已经是镜像地址：再补上标准地址兜底
        urls += [pre + GH_RELEASE_BASE + f"/code-{info.version}.zip"
                 for pre in MIRROR_PREFIXES]
    urls.append(JSDELIVR_TEMPLATE.format(name=f"code-{info.version}.zip"))
    return _dedup(urls)


def _open_url(url, timeout=None):
    req = urllib.request.Request(url, headers={"User-Agent": "cahx-helper"})
    return urllib.request.urlopen(req, timeout=timeout or CONNECT_TIMEOUT)


def local_packages():
    """data/update/ 下所有可用的离线包（版本比当前新的才算）。返回 UpdateInfo 列表。"""
    cur = current_version()
    found = []
    try:
        if not LOCAL_UPDATE_DIR.is_dir():
            return found
        for z in sorted(LOCAL_UPDATE_DIR.glob("*.zip")):
            try:
                with zipfile.ZipFile(z) as zf:
                    meta = json.loads(zf.read("payload.json").decode("utf-8"))
            except Exception as e:
                log.info("热更新：离线包 %s 读不出 payload.json（%s），跳过", z.name, e)
                continue
            ver = str(meta.get("version") or "")
            if not is_newer(ver, cur):
                log.info("热更新：离线包 %s 版本 %s 不高于当前 %s，跳过", z.name, ver, cur)
                continue
            found.append(UpdateInfo(
                version=ver, url="", sha256="", size=z.stat().st_size,
                changelog=str(meta.get("changelog") or "本地离线更新包"),
                local_path=str(z), source="local"))
    except Exception as e:
        log.info("热更新：扫描离线包失败（忽略）：%s", e)
    found.sort(key=lambda i: version_key(i.version) or ((0, 0, 0), 0))
    return found


def check_update():
    """找可用新版本：**先离线包、再远端多源**，都没有/都失败返回 None。

    2026-11-02：远端改为串行回退多个源（直连 GitHub 在部分网络彻底不通，
    gh-proxy / ghfast / jsDelivr 往往能用）。失败原因记在 last_error()，
    调用方可据此区分「已是最新」和「网络不通」。
    """
    global _LAST_ERROR
    _LAST_ERROR = ""
    if not enabled():
        return None

    # 1) 离线包：用户主动放进去的，优先级最高（零网络依赖）
    locals_ = local_packages()
    if locals_:
        info = locals_[-1]
        log.info("热更新：发现离线包 %s（%s），直接安装",
                 info.version, Path(info.local_path).name)
        return info

    # 2) 远端 manifest：逐个源试，第一个拿到就用
    manifest, tried = None, []
    for url in _manifest_urls():
        try:
            with _open_url(url, CONNECT_TIMEOUT) as r:
                manifest = json.loads(r.read().decode("utf-8"))
            log.info("热更新：manifest 命中 %s", url)
            break
        except Exception as e:
            tried.append(url)
            log.info("热更新：源不可用 %s（%s）", url, e)
    if manifest is None:
        _LAST_ERROR = (f"{len(tried)} 个更新源均无法访问"
                       "（可把更新包放到 data/update/ 后重启）")
        log.info("热更新：检查失败（忽略，不影响使用）：%s", _LAST_ERROR)
        return None

    code = manifest.get("code") or {}
    ver = str(code.get("version") or "")
    cur = current_version()
    if not is_newer(ver, cur):
        return None
    info = UpdateInfo(
        version=ver,
        url=str(code.get("url") or ""),
        sha256=str(code.get("sha256") or "").lower(),
        size=int(code.get("size") or 0),
        changelog=str(code.get("changelog") or ""),
        min_runtime=str(code.get("min_runtime") or ""),
    )
    if not info.url or not info.sha256:
        log.warning("热更新：manifest 缺 url/sha256，忽略版本 %s", ver)
        return None
    rt = runtime_version()
    if info.min_runtime and rt and is_newer(info.min_runtime, rt):
        info.needs_full = True
        info.full_url = str((manifest.get("full") or {}).get("url") or "")
        log.info("热更新：%s 要求运行时 ≥ %s（本机 %s），需全量重装",
                 ver, info.min_runtime, rt)
    return info


# ---------------------------------------------------------------- 下载与暂存

def _sha256_file(path, cancel=None):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for blk in iter(lambda: f.read(CHUNK), b""):
            if cancel is not None and cancel.is_set():
                return None
            h.update(blk)
    return h.hexdigest()


def _download_one(url, zip_path, info, progress_cb=None, cancel=None):
    """从单个源下载并算 sha256。成功（含校验通过）返回 True。

    慢速镜像（实测 gh-proxy ≈ 260KB/s）只要在持续吐数据就不算超时，但用
    DOWNLOAD_TOTAL_TIMEOUT 兜住"龟速永不完成"的情况。
    """
    h = hashlib.sha256()
    done = 0
    t0 = time.time()
    try:
        with _open_url(url, CONNECT_TIMEOUT) as r, open(zip_path, "wb") as f:
            total = int(r.headers.get("Content-Length") or info.size or 0)
            if progress_cb:
                progress_cb(0, total)
            while True:
                if cancel is not None and cancel.is_set():
                    log.info("热更新：下载被取消")
                    return False
                if time.time() - t0 > DOWNLOAD_TOTAL_TIMEOUT:
                    log.warning("热更新：源 %s 超过 %d 秒仍未下完（已 %.1f MB），换源",
                                url, DOWNLOAD_TOTAL_TIMEOUT, done / 1024 / 1024)
                    return False
                blk = r.read(CHUNK)
                if not blk:
                    break
                f.write(blk)
                h.update(blk)
                done += len(blk)
                if progress_cb:
                    progress_cb(done, total)
    except Exception as e:
        log.info("热更新：下载源失败 %s（%s）", url, e)
        return False
    if info.sha256 and h.hexdigest() != info.sha256:
        log.warning("热更新：源 %s 的包 sha256 不符（期望 %s 实得 %s），换源",
                    url, info.sha256, h.hexdigest())
        return False
    log.info("热更新：下载完成 %.1f MB（源 %s）", done / 1024 / 1024, url)
    return True


def _stage_zip(zip_path, info, progress_cb=None, cancel=None):
    """解压 → 校验关键文件 → 原子改名 → 写 pending.json。"""
    staging = VERSIONS_DIR / f".staging-{info.version}"
    final = VERSIONS_DIR / info.version
    try:
        VERSIONS_DIR.mkdir(parents=True, exist_ok=True)
        shutil.rmtree(staging, ignore_errors=True)
        staging.mkdir(parents=True)
        with zipfile.ZipFile(zip_path) as zf:
            zf.extractall(staging)
        missing = [p for p in REQUIRED_PAYLOAD_FILES if not (staging / p).exists()]
        if missing:
            log.warning("热更新：载荷缺关键文件 %s，已丢弃", missing)
            shutil.rmtree(staging, ignore_errors=True)
            return False
        # 包内版本必须与预期一致（离线包放错/换源拿到旧包都会被这里拦住）
        try:
            got = json.loads((staging / "payload.json").read_text(encoding="utf-8"))
            got_ver = str(got.get("version") or "")
        except Exception:
            got_ver = ""
        if got_ver and got_ver != info.version:
            log.warning("热更新：包内版本 %s ≠ 期望 %s，已丢弃", got_ver, info.version)
            shutil.rmtree(staging, ignore_errors=True)
            return False
        shutil.rmtree(final, ignore_errors=True)
        # 同分区目录改名是原子的，但 Windows 上刚解压出来的目录常被 Defender
        # 实时扫描短暂持有句柄 → WinError 5。2026-11-02 手动装包实测第一次
        # 必失败、第二次成功，所以这里退避重试，别把一次杀软抖动当成更新失败。
        last_exc = None
        for attempt in range(5):
            try:
                os.rename(staging, final)
                last_exc = None
                break
            except OSError as e:
                last_exc = e
                log.info("热更新：暂存目录改名失败（第 %d/5 次）：%s", attempt + 1, e)
                time.sleep(0.6 * (attempt + 1))
        if last_exc is not None:
            raise last_exc
        _write_json(PENDING_JSON, {"version": info.version,
                                   "staged_at": time.strftime("%Y-%m-%d %H:%M:%S")})
        log.info("热更新：%s 已就绪（源 %s），重启后生效",
                 info.version, info.source or "本地包")
        return True
    except Exception as e:
        log.warning("热更新：解压/暂存失败：%s", e)
        shutil.rmtree(staging, ignore_errors=True)
        return False


def download_and_stage(info, progress_cb=None, cancel=None):
    """把新版本落到 app/versions/ 并写 pending.json。成功 True。

    离线包（info.local_path）直接解压；否则按 _asset_urls() 逐源下载回退。
    全程不碰当前版本目录，任何失败都返回 False 并清理现场。
    """
    if info.local_path:
        return _stage_zip(Path(info.local_path), info, progress_cb, cancel)

    tmp_dir = DEBUG_DIR / "updates" / "tmp"
    zip_path = tmp_dir / f"code-{info.version}.zip"
    urls = _asset_urls(info)
    try:
        tmp_dir.mkdir(parents=True, exist_ok=True)
        for url in urls:
            if cancel is not None and cancel.is_set():
                log.info("热更新：下载被取消")
                return False
            if _download_one(url, zip_path, info, progress_cb, cancel):
                info.source = url
                return _stage_zip(zip_path, info, progress_cb, cancel)
        log.warning("热更新：%d 个源全部下载失败（%s）", len(urls), urls)
        return False
    except Exception as e:
        log.warning("热更新：下载/暂存失败：%s", e)
        return False
    finally:
        try:
            zip_path.unlink(missing_ok=True)
        except Exception:
            pass


def _write_json(path, obj):
    """原子写 JSON（临时文件 + os.replace，防半截文件）。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, path)


# ---------------------------------------------------------------- 崩溃计数与 GC

def mark_boot_ok():
    """主窗口成功显示后调用：清崩溃计数（证明当前版本起得来）+ GC 旧版本。

    机制：boot.py 每次启动对当前版本 boot_count +1；连续 2 次没等到本函数
    清零（= 新版本连续起不来）→ boot 自动把指针回退到上一版。
    """
    if not FROZEN:
        return
    try:
        _write_json(UPDATE_STATE, {"version": current_version(), "count": 0})
        gc_versions()
    except Exception as e:
        log.info("热更新：mark_boot_ok 失败（忽略）：%s", e)


def mark_worker_ok():
    """worker 子进程起来了：抵消本次 worker 启动给"崩溃计数"加的那一分。

    2026-10-28 事故：boot 对每个进程（含 --worker）都 +1 计数，只有 GUI 会
    mark_boot_ok 清零 → GUI 一次成功之后只要再起 2 次 worker（= 跑两轮定时
    任务），下次 GUI 启动就被误判"该版本连续 2 次起不来"→ 无辜回滚上一版。
    boot.py 编在 exe 里（不随热更），所以在 worker 侧抵消是当前立即生效的
    止血手段；boot 侧也已改成 worker 不计数（下次打包才生效，双保险）。
    只清计数、不做 gc_versions（版本回收留给 GUI）。
    """
    if not FROZEN:
        return
    try:
        _write_json(UPDATE_STATE, {"version": current_version(), "count": 0})
    except Exception as e:
        log.info("热更新：mark_worker_ok 失败（忽略）：%s", e)


def gc_versions(keep=KEEP_VERSIONS):
    """版本目录只留最近 keep 版；当前版与 pending 版永远不删。"""
    try:
        cur = current_version()
        pend = pending_version()
        vers = []
        for d in VERSIONS_DIR.iterdir():
            if d.is_dir() and not d.name.startswith(".") and version_key(d.name):
                vers.append(d.name)
        vers.sort(key=version_key)
        protected = {cur, pend}
        removable = [v for v in vers if v not in protected]
        for v in removable[:max(0, len(vers) - keep)]:
            shutil.rmtree(VERSIONS_DIR / v, ignore_errors=True)
            log.info("热更新：清理旧版本目录 %s", v)
    except Exception as e:
        log.info("热更新：版本 GC 失败（忽略）：%s", e)


# ---------------------------------------------------------------- 重启

def manual_download_hint():
    """网络全不通时给用户的手动兜底说明（设置页 tooltip / 失败提示用）。"""
    zips = [GH_RELEASE_BASE + "/", "https://gh-proxy.com/" + GH_RELEASE_BASE + "/",
            "https://ghfast.top/" + GH_RELEASE_BASE + "/",
            JSDELIVR_TEMPLATE.format(name="")]
    lines = ["自动更新失败时的手动办法（任选其一）：", "",
             "① 让维护者把 code-*.zip 发给你，放到下面这个目录后重启：",
             f"     {LOCAL_UPDATE_DIR}",
             "② 浏览器直接下载（多试几个，哪个能开用哪个）："]
    lines += [f"     {u}" for u in zips]
    return "\n".join(lines)


def restart_app():
    """立即重启（新进程起来后 boot 会应用 pending 版本）。调用方负责退出自己。"""
    if not FROZEN:
        return False
    try:
        subprocess.Popen([str(Path(sys.executable).resolve())], cwd=str(ROOT),
                         close_fds=True)
        return True
    except Exception as e:
        log.warning("热更新：重启失败：%s", e)
        return False
