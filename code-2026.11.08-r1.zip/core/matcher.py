import logging
import threading
import time
from pathlib import Path

import cv2

from core import imgio

log = logging.getLogger("matcher")


class Matcher:
    """从 assets/images 加载模板图，在屏幕截图中做模板匹配。

    模板名即文件名（不含扩展名），例如 背包.png → "背包"。
    assets/images 下可按功能建子目录（login/ anchors/ tasks/ gui/），
    加载时递归索引，引用只写文件名，全目录不重名即可。

    掩码控制（掩码文件与模板同目录）：
      - 手工掩码：放置 name.mask.png（白色=参与比对，黑色=忽略）
      - 强制无掩码：放置 name.nomask 空文件（实心按钮专用，纯 CCOEFF 最可靠）
      - 缺省自动掩码：忽略模板暗色像素（适合半透明线条图标）
    有掩码时使用 TM_CCORR_NORMED（OpenCV 仅该方法支持掩码），
    并用未掩码 CCOEFF 对候选点做二次验证（ccoeff_floor）。
    """

    def __init__(self, assets_dir, threshold=0.85, auto_mask=True, ccoeff_floor=0.5):
        self.assets_dir = Path(assets_dir)
        self.threshold = threshold
        self.auto_mask = auto_mask
        self.ccoeff_floor = ccoeff_floor
        self._cache = {}
        self._paths = None
        self._index_lock = threading.Lock()

    def _index(self):
        """递归索引 assets_dir 下全部模板（子目录按功能分类，引用只用文件名）。

        模板名即文件名（不含扩展名），全目录唯一，重名直接报错。
        多线程共享 Matcher（GUI 每账号一线程）时首次索引会并发触发，
        必须加锁：否则一个线程刚把 _paths 置为 {} 还没填完，另一个线程
        就会拿到空索引报"模板图不存在"。
        """
        if self._paths is not None:
            return
        with self._index_lock:
            if self._paths is not None:
                return
            paths = {}
            for p in sorted(self.assets_dir.rglob("*.png")):
                if p.name.endswith(".mask.png"):
                    continue
                if p.stem in paths:
                    raise ValueError(f"模板重名: {p.stem}（{paths[p.stem]} 与 {p}）")
                paths[p.stem] = p
            self._paths = paths

    def has_template(self, name):
        self._index()
        return name in self._paths

    def _load(self, name):
        if name not in self._cache:
            self._index()
            path = self._paths.get(name)
            if path is None:
                raise FileNotFoundError(f"模板图不存在: {self.assets_dir}/**/{name}.png")
            tpl = imgio.imread(path)
            if tpl is None:
                raise ValueError(f"模板图读取失败: {path}")
            mask_path = path.with_name(f"{name}.mask.png")
            nomask_path = path.with_name(f"{name}.nomask")
            if mask_path.exists():
                mask = imgio.imread(mask_path)
                mask = cv2.cvtColor(mask, cv2.COLOR_BGR2GRAY)
            elif nomask_path.exists():
                mask = None
            elif self.auto_mask:
                gray = cv2.cvtColor(tpl, cv2.COLOR_BGR2GRAY)
                mask = (gray >= 100).astype("uint8") * 255
                if cv2.countNonZero(mask) < mask.size * 0.05:
                    mask = None  # 有效像素过少，掩码反而有害
            else:
                mask = None
            self._cache[name] = (tpl, mask)
        return self._cache[name]

    def find(self, screen, name, threshold=None, region=None, ccoeff_floor=None):
        """在截图中找模板，返回 (cx, cy, score)；找不到返回 None。

        region: 可选 (x, y, w, h)，限定搜索范围，加快匹配并减少误判。
        ccoeff_floor: 掩码路径的 CCOEFF 二次验证下限，缺省用实例值；
                      锚点小区域搜索可传更低值（如 0.45）。
        """
        tpl, mask = self._load(name)
        th = threshold if threshold is not None else self.threshold
        floor = ccoeff_floor if ccoeff_floor is not None else self.ccoeff_floor
        img, ox, oy = screen, 0, 0
        if region is not None:
            x, y, w, h = region
            img = screen[y:y + h, x:x + w]
            ox, oy = x, y
        if img.shape[0] < tpl.shape[0] or img.shape[1] < tpl.shape[1]:
            return None
        if mask is not None:
            res = cv2.matchTemplate(img, tpl, cv2.TM_CCORR_NORMED, mask=mask)
            verify = cv2.matchTemplate(img, tpl, cv2.TM_CCOEFF_NORMED)
            # 掩码 CCORR 在亮色/复杂背景上假阳性很高（实测误判 0.93~0.97，
            # 甚至高于真按钮），需遍历候选点，用未掩码 CCOEFF 二次验证：
            # 真按钮相关性高（>0.6），假点趋近于 0
            best = None
            for _ in range(8):
                _, max_val, _, max_loc = cv2.minMaxLoc(res)
                if max_val < th:
                    break
                if verify[max_loc[1], max_loc[0]] >= floor:
                    best = (max_loc, max_val)
                    break
                # 压制该假点邻域，继续找下一个候选
                y0, y1 = max(0, max_loc[1] - 10), max_loc[1] + 10
                x0, x1 = max(0, max_loc[0] - 10), max_loc[0] + 10
                res[y0:y1, x0:x1] = 0
            if best is None:
                return None
            max_loc, max_val = best
        else:
            res = cv2.matchTemplate(img, tpl, cv2.TM_CCOEFF_NORMED)
            _, max_val, _, max_loc = cv2.minMaxLoc(res)
            if max_val < th:
                return None
        th_h, th_w = tpl.shape[:2]
        return ox + max_loc[0] + th_w // 2, oy + max_loc[1] + th_h // 2, max_val

    def find_all(self, screen, name, threshold=None, region=None, max_hits=20):
        """找模板的全部出现位置，返回 [(cx, cy, score)] 按分数降序。

        多目标场景不走掩码（CCORR 掩码只支持单目标验证逻辑），
        直接用未掩码 CCOEFF，适合实心小图标（如货币图标）。
        """
        tpl, _ = self._load(name)
        th = threshold if threshold is not None else self.threshold
        img, ox, oy = screen, 0, 0
        if region is not None:
            x, y, w, h = region
            img = screen[y:y + h, x:x + w]
            ox, oy = x, y
        if img.shape[0] < tpl.shape[0] or img.shape[1] < tpl.shape[1]:
            return []
        res = cv2.matchTemplate(img, tpl, cv2.TM_CCOEFF_NORMED)
        th_h, th_w = tpl.shape[:2]
        out = []
        for _ in range(max_hits):
            _, max_val, _, max_loc = cv2.minMaxLoc(res)
            if max_val < th:
                break
            out.append((ox + max_loc[0] + th_w // 2,
                        oy + max_loc[1] + th_h // 2, max_val))
            # 压制命中点邻域（NMS），继续找下一个
            cv2.rectangle(res,
                          (max(0, max_loc[0] - th_w // 2), max(0, max_loc[1] - th_h // 2)),
                          (max_loc[0] + th_w // 2, max_loc[1] + th_h // 2), -1, -1)
        return out

    def wait_for(self, device, name, timeout=10, interval=0.6, **kwargs):
        """轮询截图直到模板出现或超时，返回 find 的结果或 None。"""
        deadline = time.time() + timeout
        while time.time() < deadline:
            hit = self.find(device.screenshot(), name, **kwargs)
            if hit:
                return hit
            time.sleep(interval)
        log.warning("等待超时，未找到模板: %s", name)
        # 输入层失败信号（整窗失灵看门狗）：这一个窗口该出现的模板就是没出现，
        # 可能真是"这一步没办到"，也可能是客户端已经不收点击了。此处只记账，
        # 由 runner 跨任务统计后再判定（见 core/device.py::note_input_miss）。
        try:
            device.note_input_miss("template_timeout", name)
        except AttributeError:
            pass   # 桩/假设备没有这个方法时不阻断（自检脚本用）
        return None

    def find_and_click(self, device, name, timeout=10, **kwargs):
        """等待模板出现并点击其中心，成功返回 True。"""
        hit = self.wait_for(device, name, timeout=timeout, **kwargs)
        if hit is None:
            return False
        log.info("点击 [%s] @ (%d, %d) score=%.3f", name, hit[0], hit[1], hit[2])
        device.click(hit[0], hit[1])
        return True
