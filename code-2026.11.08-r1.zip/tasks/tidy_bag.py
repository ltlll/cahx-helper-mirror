import logging
import random
import time

from core import ocr
from tasks.base import Task

log = logging.getLogger("task.tidy_bag")

# 以下均为 405x720 客户区坐标
ZHENGLI_REGION = (270, 600, 110, 55)   # 背包页底部"整理"按钮
SELL_TAB_REGION = (130, 600, 120, 55)  # 背包页底部"出售"按钮
SELL_MARK_REGION = (10, 50, 130, 45)   # "物品出售"面板标题
SELL_BTN_REGION = (130, 565, 150, 55)  # 出售面板底部"出售"按钮
SELL_CLOSE_POS = (385, 75)             # 出售面板右上角 X


class TidyBag(Task):
    """整理背包：背包 → 整理 → 出售 → 物品出售框点"出售"（自动选择已勾选
    可卖杂物）→ 关闭面板返回主界面。

    用途：背包满会买不了道具导致跑商交不了订单。出售框无可卖物品时
    点"出售"只会弹提示，无副作用。
    """

    name = "tidy_bag"
    title = "整理背包"
    category = "备战任务"

    def _try_once(self):
        self.dismiss_popups()
        if not self.open_backpack():
            return False
        # 背包页加载慢：底栏按钮渲染出来不等于可交互，先等加载再稳一拍
        deadline = time.time() + 10
        while time.time() < deadline:
            if ocr.find_text(self.device.screenshot(), "整理",
                             region=ZHENGLI_REGION, min_similarity=1.0):
                break
            time.sleep(0.6)
        else:
            log.warning("背包底栏未加载")
            # 留下背包面板现状再放弃（任务失败截图是回主界面后拍的，看不到面板状态）
            self.save_debug_screenshot("tidy_bag_panel")
            return False
        time.sleep(random.uniform(1.5, 2.2))
        if not self._click("整理", ZHENGLI_REGION):
            return False
        time.sleep(random.uniform(1.2, 1.8))
        # 点"出售"打开出售面板；面板没开就再点（只在背包页底栏还在时重试，
        # 防止面板已开但 OCR 漏检时误点面板里的物品格子）
        for i in range(3):
            if not self._click("出售", SELL_TAB_REGION):
                return False
            state = self._wait_sell_panel()
            if state == "empty":
                log.info("没有可出售的杂物，直接关闭")
                self.device.click(*SELL_CLOSE_POS)
                return True
            if state:
                log.info("点击 [出售] @ (%d, %d)", state[0], state[1])
                self.device.click(state[0], state[1])
                r = self._handle_sell_dialogs(state)
                if r == "no_pwd":
                    # 未设置二级密码：出售环节跳过（整理已完成，算任务完成）
                    log.info("未设置二级密码，出售跳过")
                    self.device.click(*SELL_CLOSE_POS)
                    time.sleep(random.uniform(0.8, 1.2))
                    return True
                time.sleep(random.uniform(1.0, 1.6))  # 出售成功的提示连弹
                self.device.click(*SELL_CLOSE_POS)
                time.sleep(random.uniform(0.8, 1.2))
                return True
            log.warning("出售面板未打开，重试 (%d/3)", i + 1)
            if not ocr.find_text(self.device.screenshot(), "整理",
                                 region=ZHENGLI_REGION, min_similarity=1.0):
                log.warning("已不在背包页，放弃重试")
                return False
        return False

    def _wait_sell_panel(self, timeout=8):
        """等出售面板打开。返回 出售按钮 (x, y) / "empty"（无可卖杂物）/ None。

        面板标题"物品出售"用模板匹配（固定 UI 文字，OCR 跨进程不稳定）；
        面板打开但没有"出售"按钮 = 没有可卖的杂物（空态不显示按钮）。
        """
        deadline = time.time() + timeout
        while time.time() < deadline:
            screen = self.device.screenshot()
            if self.matcher.find(screen, "物品出售", region=SELL_MARK_REGION,
                                 threshold=0.8):
                hit = ocr.find_text(screen, "出售", region=SELL_BTN_REGION,
                                    min_similarity=1.0)
                if hit:
                    return hit
                return "empty"
            time.sleep(0.6)
        self.save_debug_screenshot("sell_panel_timeout")  # 留下超时瞬间的画面
        return None

    def _handle_sell_dialogs(self, sell_pos, timeout=15):
        """点"出售"后可能先后弹两种框（也可能都不弹）：
        安全锁-验证二级密码（验证只是关掉弹窗，出售被中断，要补点一次出售）；
        出售确认-输入验证码（输完即成交，不用补点）。
        返回 "no_pwd" = 账号未设二级密码（调用方跳过出售）。
        """
        from core import dialogs
        reclick = False
        deadline = time.time() + timeout
        while time.time() < deadline:
            screen = self.device.screenshot()
            r = dialogs.handle_security_lock(self.device, screen,
                                             self.account.get("pwd2", ""))
            if r == "no_pwd":
                return "no_pwd"
            if r:
                reclick = True
                time.sleep(1.5)
                continue
            if dialogs.handle_captcha(self.device, screen):
                time.sleep(1.5)
                continue
            if reclick:
                log.info("二级密码已验证，补点出售")
                self.device.click(*sell_pos)
                reclick = False
                time.sleep(1.5)
                continue
            return None
        log.warning("出售弹窗处理超时")
        return None

    def _click(self, text, region):
        hit = ocr.find_text(self.device.screenshot(), text,
                            region=region, min_similarity=1.0)
        if not hit:
            log.warning("未找到 [%s]", text)
            return False
        log.info("点击 [%s] @ (%d, %d)", text, hit[0], hit[1])
        self.device.click(hit[0], hit[1])
        time.sleep(random.uniform(1.0, 1.6))
        return True
