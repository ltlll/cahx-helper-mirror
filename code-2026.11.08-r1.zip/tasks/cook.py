import logging
import random
import re
import time

from core import ocr
from tasks.base import PANEL_BACK_POS, Task

log = logging.getLogger("task.cook")

# 以下均为 405x720 客户区坐标（已按真机截图校准）
PLUS_REGION = (350, 585, 55, 55)           # 主界面右下角十字功能图标（模板"功能展开"，小区域限定）
LIFE_BTN_REGION = (150, 350, 160, 100)     # 功能列表中"生活"（文字在 (198,382)，点文字无效，要点下方图标）
LIFE_ICON_OFFSET = 28                      # "生活"文字 → 图标本体的 y 偏移
LIFE_TITLE_REGION = (20, 10, 120, 45)      # "生活技能"面板标题（左上）
VITALITY_REGION = (230, 50, 175, 40)       # 面板顶部"活力: 1152/1200"
CARD_BTN_REGIONS = {                       # 生活技能面板左右卡的底部按钮
    "cooking": (55, 450, 130, 55),         # 左卡"烹饪"
    "alchemy": (245, 450, 130, 55),        # 右卡"炼制"
}
CARD_BTN_TEXT = {"cooking": "烹饪", "alchemy": "炼制"}
CRAFT_TITLE = {"cooking": "烹饪技巧", "alchemy": "炼药之术"}   # 制作页标题（已进入判定）
CRAFT_TITLE_REGION = (150, 115, 130, 45)
CRAFT_BTN_TEXT = {"cooking": "烹饪", "alchemy": "炼药"}        # 制作页右下大按钮
CRAFT_BTN_REGION = (235, 525, 150, 55)
CONFIRM_MARK_REGION = (100, 235, 220, 55)  # 确认弹窗"是否消耗以下材料"
CONFIRM_BTN_REGION = (230, 435, 130, 55)   # 确认弹窗"确认"按钮
# 制作页中部状态按钮（实测中心 (221,531)）：制作中显示"中止"，完成后变成"领取"——
# 与右下大按钮位置不同，别用 CRAFT_BTN_REGION 找"领取"（会漏检）
CLAIM_BTN_REGION = (140, 500, 150, 60)

VITALITY_LIMIT = 1200   # 活力高于上限才继续制作（溢出部分消耗掉）
MAX_CRAFTS = 12         # 单次任务制作轮数上限（防读数异常死循环）
MODE_LABEL = {"cooking": "烹饪", "alchemy": "炼药"}

# 制作过程中的两类"到头"弹窗（2026-10-23 用户说明）：
# - 每天可做 5 或 7 次，做满后再点制作会弹「今日已经做菜 n 次」→ 判定成功，
#   点「确定」收工（OCR 会把"已经"读别字，正则放宽；计数也可能拆框）；
# - 「材料不足」→ 没法再做，直接判已完成收工。
DAILY_LIMIT_RE = re.compile(r"今日已.{0,2}做菜|做菜\s*\d+\s*次")


class Cook(Task):
    """做烹饪/炼药：主界面右下角十字 → 功能列表"生活" → 生活技能面板，
    活力 > 1200 时反复制作（烹饪=左卡，炼药=右卡，config 里 mode 单选，
    无配置=烹饪；兼容旧版 modes 列表取首个），直到活力降到 1200 以下回主界面。

    制作流程：点卡片按钮进制作页 → 点右下大按钮 → 确认弹窗点"确认"
    （制作数量用弹窗默认值，不动）→ 活力立即扣除，进度条"烹饪进度:n/12"
    跑约十几秒 → 中部按钮由"中止"变"领取"才算完成 → 点"领取"弹"恭喜获得"
    网格弹窗 → 点空白关闭 → 返回生活技能面板重新读活力。活力读不出走任务级
    重试；制作后活力未减少（材料不足等）不判失败，直接收工。
    """

    name = "cook"
    title = "做烹饪"
    category = "收尾任务"

    def _try_once(self):
        mode = self._resolve_mode()
        log.info("制作模式: %s", MODE_LABEL[mode])
        self.dismiss_popups()
        return self._craft_mode(mode)

    def _resolve_mode(self):
        """config 的 mode 单值（cooking/alchemy）；兼容旧版 modes 列表（取首个），
        无配置=烹饪。"""
        mode = self.config.get("mode")
        if mode is None:
            legacy = self.config.get("modes")
            if isinstance(legacy, (list, tuple)) and legacy:
                mode = legacy[0]
        if mode not in CARD_BTN_REGIONS:
            if mode:
                log.warning("未知制作类型 %r，按烹饪处理", mode)
            mode = "cooking"
        return mode

    def _craft_mode(self, mode):
        if not self._open_life_panel():
            return False
        vitality = self._read_vitality(self.device.screenshot())
        if vitality is None:
            log.warning("活力数值读不出")
            return False
        if vitality <= VITALITY_LIMIT:
            log.info("活力 %d 未超过 %d，无需制作", vitality, VITALITY_LIMIT)
            return True
        self._daily_finished = False   # 弹窗判定的收工标志，见 _handle_craft_popup
        for i in range(MAX_CRAFTS):
            self._check_stop()
            log.info("活力 %d > %d，第 %d 轮%s", vitality, VITALITY_LIMIT,
                     i + 1, MODE_LABEL[mode])
            if not self._craft_once(mode):
                return False
            if self._daily_finished:
                # 「今日已经做菜 n 次」/「材料不足」弹窗已处理：今日到头，
                # 判成功收工（剩余活力明天再说，不留在任务里硬做）
                log.info("今日%s已到头（弹窗判定），收工", MODE_LABEL[mode])
                return True
            new_v = self._read_vitality(self.device.screenshot())
            if new_v is None:
                log.warning("制作后活力读不出")
                return False
            if new_v >= vitality:
                # 活力没降：材料不足或制作未生效，属于正常收尾，不算失败
                log.info("制作后活力未减少（%d → %d），材料可能不足，收工",
                         vitality, new_v)
                return True
            vitality = new_v
            if vitality <= VITALITY_LIMIT:
                break
        log.info("制作结束，当前活力 %d", vitality)
        return True

    def _open_life_panel(self):
        """主界面 → 十字功能列表 → 生活技能面板。点击可能被吞，各步带重试。
        已停在生活技能面板时（多类型连做的后续类型）直接复用不重点导航。"""
        screen = self.device.screenshot()
        if (ocr.find_text(screen, "生活技能", region=LIFE_TITLE_REGION,
                          min_similarity=0.9)
                and self._read_vitality(screen) is not None):
            return True
        hit = None
        for i in range(3):
            screen = self.device.screenshot()
            hit = ocr.find_text(screen, "生活", region=LIFE_BTN_REGION,
                                min_similarity=1.0)
            if hit:
                break
            if not self.matcher.find_and_click(self.device, "功能展开",
                                               region=PLUS_REGION, threshold=0.88,
                                               ccoeff_floor=0.45):
                return False
            deadline = time.time() + 6
            while time.time() < deadline:
                hit = ocr.find_text(self.device.screenshot(), "生活",
                                    region=LIFE_BTN_REGION, min_similarity=1.0)
                if hit:
                    break
                time.sleep(0.6)
            if hit:
                break
            log.warning("功能列表未打开，重试点十字 (%d/3)", i + 1)
        if not hit:
            log.warning("功能列表多次点击未打开")
            return False
        # 点"生活"文字无效（实测），要点文字下方的图标本体；点击可能被吞，带重试
        for i in range(3):
            log.info("点击 [生活图标] @ (%d, %d)", hit[0], hit[1] + LIFE_ICON_OFFSET)
            self.device.click(hit[0], hit[1] + LIFE_ICON_OFFSET)
            deadline = time.time() + 8
            while time.time() < deadline:
                screen = self.device.screenshot()
                if (ocr.find_text(screen, "生活技能", region=LIFE_TITLE_REGION,
                                  min_similarity=0.9)
                        and self._read_vitality(screen) is not None):
                    log.info("生活技能面板已打开")
                    return True
                time.sleep(0.6)
            log.warning("生活技能面板未打开，重试点生活 (%d/3)", i + 1)
            # 功能列表可能已收起：重新展开再找"生活"
            screen = self.device.screenshot()
            hit = ocr.find_text(screen, "生活", region=LIFE_BTN_REGION,
                                min_similarity=1.0)
            if not hit:
                if not self.matcher.find_and_click(self.device, "功能展开",
                                                   region=PLUS_REGION,
                                                   threshold=0.88,
                                                   ccoeff_floor=0.45):
                    return False
                deadline = time.time() + 6
                while time.time() < deadline:
                    hit = ocr.find_text(self.device.screenshot(), "生活",
                                        region=LIFE_BTN_REGION, min_similarity=1.0)
                    if hit:
                        break
                    time.sleep(0.6)
                if not hit:
                    return False
        log.warning("生活技能面板多次点击未打开")
        return False

    @staticmethod
    def _read_vitality(screen):
        """读面板顶部"活力: 1327/1200"，返回当前活力值；读不出返回 None。"""
        text = "".join(ocr.dump_texts(screen, VITALITY_REGION))
        m = re.search(r"(\d+)\s*/\s*(\d+)", text)
        if not m:
            return None
        cur, cap = int(m.group(1)), int(m.group(2))
        if cap < 100 or cur > cap + 2000:
            # 位数明显异常（OCR 粘连多读一位等），不可信
            log.warning("活力读数异常: %s", text)
            return None
        return cur

    def _craft_once(self, mode):
        """制作一轮：卡片按钮 → 制作页 →（有遗留成品先领取）→ 大按钮 → 确认
        → 等进度条跑完（"中止"变"领取"）→ 点居中"领取" → 关"恭喜获得"弹窗
        → 回生活技能面板。一轮到此才算结束。"""
        label = MODE_LABEL[mode]
        screen = self.device.screenshot()
        hit = ocr.find_text(screen, CARD_BTN_TEXT[mode],
                            region=CARD_BTN_REGIONS[mode], min_similarity=1.0)
        if not hit:
            # 卡片显示"领取"= 上次中断留下的成品：照样点，进制作页先领取
            hit = ocr.find_text(screen, "领取", region=CARD_BTN_REGIONS[mode],
                                min_similarity=1.0)
        if not hit:
            log.warning("生活技能面板找不到 %s 卡按钮", label)
            return False
        log.info("点击 [%s卡] @ (%d, %d)", label, hit[0], hit[1])
        self.device.click(hit[0], hit[1])
        deadline = time.time() + 8
        while time.time() < deadline:
            if ocr.find_text(self.device.screenshot(), CRAFT_TITLE[mode],
                             region=CRAFT_TITLE_REGION, min_similarity=0.9):
                break
            time.sleep(0.6)
        else:
            log.warning("%s页未打开", CRAFT_TITLE[mode])
            return False
        # 有遗留成品（上次中断）先领取，否则大按钮位置是"领取"不是制作按钮
        if ocr.find_text(self.device.screenshot(), "领取",
                         region=CLAIM_BTN_REGION, min_similarity=1.0):
            log.info("发现有遗留成品，先领取")
            if not self._claim_finished(mode):
                return False
        hit = ocr.find_text(self.device.screenshot(), CRAFT_BTN_TEXT[mode],
                            region=CRAFT_BTN_REGION, min_similarity=1.0)
        if not hit:
            log.warning("%s页找不到 [%s] 大按钮", CRAFT_TITLE[mode],
                        CRAFT_BTN_TEXT[mode])
            return False
        log.info("点击 [%s] @ (%d, %d)", CRAFT_BTN_TEXT[mode], hit[0], hit[1])
        self.device.click(hit[0], hit[1])
        # 大按钮点击后弹的不一定是确认弹窗：做满当天会弹「今日已经做菜 n 次」
        deadline = time.time() + 8
        while time.time() < deadline:
            screen = self.device.screenshot()
            if self._handle_craft_popup(screen):
                return True
            if ocr.contains_text(screen, "是否消耗",
                                 region=CONFIRM_MARK_REGION):
                break
            time.sleep(0.6)
        else:
            log.warning("确认弹窗未弹出")
            return False
        hit = ocr.find_text(self.device.screenshot(), "确认",
                            region=CONFIRM_BTN_REGION, min_similarity=1.0)
        if not hit:
            log.warning("确认弹窗找不到 [确认] 按钮")
            return False
        log.info("点击 [确认] @ (%d, %d)（数量用默认值）", hit[0], hit[1])
        self.device.click(hit[0], hit[1])
        # 活力在确认时立即扣除；制作进度条（"烹饪进度:n/12 [中止]"）约十几秒，
        # 跑完中部按钮变成"领取"。不能拿标题出现当完成——进度期间标题就在（实测教训）。
        # 等待期间也可能弹「材料不足」/「今日已经做菜 n 次」——一并判定收工。
        deadline = time.time() + 120
        while time.time() < deadline:
            self._check_stop()
            screen = self.device.screenshot()
            if self._handle_craft_popup(screen):
                return True
            if ocr.find_text(screen, "领取",
                             region=CLAIM_BTN_REGION, min_similarity=1.0):
                break
            time.sleep(1.0)
        else:
            log.warning("等制作完成超时（进度条未跑完）")
            return False
        log.info("本轮%s制作完成，领取成品", label)
        if not self._claim_finished(mode):
            return False
        time.sleep(random.uniform(0.8, 1.2))
        # 返回生活技能面板（点左下返回箭头）
        for _ in range(3):
            self.device.click(*PANEL_BACK_POS)
            deadline = time.time() + 6
            while time.time() < deadline:
                screen = self.device.screenshot()
                if ocr.find_text(screen, "生活技能", region=LIFE_TITLE_REGION,
                                 min_similarity=0.9):
                    return True
                time.sleep(0.6)
        log.warning("返回生活技能面板失败")
        return False

    def _handle_craft_popup(self, screen):
        """制作过程中的两类"到头"弹窗（2026-10-23 用户说明）：

        - 「今日已经做菜 n 次」：每天可做 5 或 7 次，做满后再点制作就弹它
          ——**判定成功**，点「确定」收工；
        - 「材料不足」：没法再做，直接判已完成，点「确定」关掉收工。
        返回 True=处理过（self._daily_finished 已置位，调用方应立即收工）。
        """
        texts = ocr.dump_texts(screen)
        daily = any(DAILY_LIMIT_RE.search(t) for t in texts)
        no_material = any("材料不足" in t for t in texts)
        if not (daily or no_material):
            return False
        self._daily_finished = True
        if daily:
            log.info("今日做菜次数已满（弹窗提示），判定成功")
        else:
            log.info("材料不足，无法继续制作，直接判已完成")
        hit = ocr.find_text(screen, "确定", min_similarity=0.8)
        if hit:
            log.info("点击 [确定] @ (%d, %d) 关闭提示", hit[0], hit[1])
            self.device.click(hit[0], hit[1])
            time.sleep(random.uniform(1.0, 1.6))
        else:
            log.warning("没找到 [确定] 按钮，按 ESC 兜底关弹窗")
            self.device.press_esc()
        return True

    def _claim_finished(self, mode):
        """点制作页中部"领取"收成品 → 关"恭喜获得"弹窗（点空白）→
        校验回到制作页初始态（右下大按钮重新出现）。中途返回不丢成品，
        但没领取前大按钮位置一直是"领取"，无法开新一轮。"""
        for _ in range(3):
            hit = ocr.find_text(self.device.screenshot(), "领取",
                                region=CLAIM_BTN_REGION, min_similarity=1.0)
            if not hit:
                return True  # 没有可领取的（异常时已不在完成态），不纠缠
            log.info("点击 [领取] @ (%d, %d)", hit[0], hit[1])
            self.device.click(hit[0], hit[1])
            time.sleep(random.uniform(1.2, 1.8))
            self.close_reward_popup(timeout=6)  # "恭喜获得"网格弹窗 → 点空白关闭
            time.sleep(random.uniform(0.6, 1.0))
            if ocr.find_text(self.device.screenshot(), CRAFT_BTN_TEXT[mode],
                             region=CRAFT_BTN_REGION, min_similarity=1.0):
                log.info("成品已领取，回到制作页初始态")
                return True
        log.warning("领取后未回到制作页初始态")
        return False
