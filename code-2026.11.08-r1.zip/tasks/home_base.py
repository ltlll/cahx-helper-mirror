import logging
import random
import time

from core import ocr
from tasks.base import Task

log = logging.getLogger("task.home")

# 以下均为 405x720 客户区坐标（按用户真机截图校准）。
# 本模块是**家园类任务的公共基类**（种菜 zhongcai / 喂猫 weimao 共用）：
# 主界面 → 功能面板"家园" → 家园名片"回家" → 家园场景的导航、
# 家园开场随机弹窗清理、以及"离开家园回主界面"。

# ---- 主界面 → 功能面板 ----
PLUS_REGION = (350, 585, 55, 55)           # 主界面右下角十字"功能展开"（模板"功能展开"，cook 共用）
# ---- 功能面板 → 家园 ----
JIATIN_REGION = (150, 410, 170, 118)       # "家园"磁贴（模板"家园"，小区域限定）
# ---- 家园名片 → 回家 ----
HUIJIA_REGION = (148, 510, 175, 72)        # "回家"按钮（模板"回家"）
HUIJIA_POS = (223, 549)                    # "回家"按钮兜底点击位（模板失手时用）
HOME_CARD_MARK = "家园名片"                 # 家园名片页特征文字（用于判断"点回家后没跳转"）
HOME_CARD_REGION = (120, 60, 285, 50)      # 上面这行字的区域（实测 (202,82)，限定区避免全图 OCR）
# 等家园场景加载的超时。**账号间加载速度差异很大**：实测账号4 点「回家」后 >8s
# 仍停在家园名片页（14级世外桃源Ⅱ / 拜访 / 回家 / 同居），导致旧版 8s 超时误报
# garden_hud_timeout → 触发多余的"复位视角"（还连带 no_leave_button/leave_failed 误报）。
GARDEN_HUD_TIMEOUT = 14

# ---- 家园开场「旅行吧喵喵」礼物弹窗 ----
# 进家园场景后常弹出该窗（"喵喵在神术谷带回来的礼物，请收下"），它**正好盖住路牌**，
# 不处理会导致后面全线找不到指向标（实测踩过）。按用户要求：点「赠送」走一遍分享，
# 再关掉好友分享面板；若弹出"恭喜获得…点击空白处关闭"则点空白关掉。
YAOMIAO_KEYWORDS = ("旅行吧喵喵", "请收下", "带回来的礼物")
YAOMIAO_GIFT_REGION = (60, 380, 300, 220)  # 弹窗按钮区（"收下"/"赠送"，实测文字中心 ≈(202,487)）
SHARE_PANEL_KEYWORDS = ("分享给一同付出",)
SHARE_CLOSE_POS = (375, 160)               # 好友分享面板右上角关闭 X（实测）
REWARD_BLANK_POS = (202, 260)              # "点击空白处关闭"的奖励结算面板

# ---- 家园开场「彩虹打卡点」引导弹窗（第二种开场弹窗）----
# 实测 16:41 那次：进家园后弹出它（顶部角色立绘 + "哇，还是被你找到了…请一起摆出此动作
# 拍照：比心" + 底部「盛景同游打卡」大按钮），**一个巨大的半透明面板糊住整个画面（含路牌）**，
# 导致指向标/美食/制作全线失败。它没有文字关闭按钮，只有右上角白色圆形 X。
# 打卡要双人组队摆动作，与种菜无关 → 直接关掉。
CHECKIN_KEYWORDS = ("彩虹打卡点", "盛景同游打卡")
CHECKIN_CLOSE_POS = (347, 228)             # 弹窗右上角关闭 X（紫 X 像素重心实测）

# ---- 家园/菜园右缘「离开」 ----
LEAVE_REGION = (335, 440, 72, 130)         # "离开"（圆形箭头图标 + 下方文字）。⭐ 家园场景的
                                           # 按钮比菜园**偏上**（实测账号7 图标 y≈455-500，
                                           # 菜园文字中心 y≈530），region 要同时覆盖两个场景；
                                           # 旧值 (340,480,66,90) 在家园会漏检（实测误报）
LEAVE_POS = (383, 510)                     # 图标中心（**文字正上方约 20px**）——实测点文字 (382,530)
                                           # 无效、点 (383,510) 生效；再往下 (382,554) 会点到「角色」

GARDEN_MARK_REGION = (0, 0, 405, 60)       # 家园/菜园顶部 HUD（"XX的家园" / "总美观度"），判定已进家园

# ---- 家园场景：指向标（粉红路牌「我在菜园 很想你」）----
# ⚠️ 这块路牌是场景里的物件，会随角色视角移动；且"指向标"模板带自动掩码，
# 掩码路径在小 region 上 CCOEFF 归一化基准会变、分数骤降（实测缩到 (0,235,180,160)
# 直接匹配不到，放开就 0.958）。所以**一律全图搜索**，再叠 OCR 文字兜底。
# 实测：复位进家园后路牌稳定出现在左侧中部，模板 score ≈0.96（两次实测 (76,215)/(108,236)）。
SIGNPOST_THRESHOLD = 0.85
SIGNPOST_CCOEFF_FLOOR = 0.35


def is_garden_scene(matcher, screen):
    """家园/菜园场景判定：指向标（路牌）模板全图命中，或顶部 HUD 出现
    「XX的家园」/「总美观度」。主界面（云梦长安）、功能面板、家园名片、制作台都不会命中。
    （顶部 HUD 的 OCR 在个别截图上会整行漏检，故以指向标模板为主判据。）"""
    if matcher.find(screen, "指向标", threshold=SIGNPOST_THRESHOLD,
                    ccoeff_floor=SIGNPOST_CCOEFF_FLOOR):
        return True
    for t in ocr.scan(screen, region=GARDEN_MARK_REGION):
        if "家园" in t[0] or "美观度" in t[0]:
            return True
    return False


class HomeTask(Task):
    """家园类任务公共基类：进家园、清开场弹窗、离开家园回主界面。

    子类（zhongcai 种菜 / weimao 喂猫）只需实现自己的家园内操作。
    重要约定（用户规则）：**家园任务结束时必须点右缘「离开」回主界面**——
    家园里角色会走动，路牌/猫等场景物件的可见性随视角漂移，回主界面后
    重新进家园才能复位到起始视角（下一个家园任务依赖这一点）。
    """

    def _open_garden(self):
        """主界面 → 十字 → 功能面板"家园" → 家园名片"回家" → 家园场景。"""
        screen = self.device.screenshot()
        if self._on_garden_scene(screen):
            log.info("已在家园场景")
            return True
        if not self._click_template("功能展开", PLUS_REGION, timeout=6,
                                    threshold=0.88, ccoeff_floor=0.45):
            self.report_unknown("no_plus_icon", note="主界面右下角未找到十字功能图标")
            return False
        if not self._click_template("家园", JIATIN_REGION, timeout=8, threshold=0.85):
            self.report_unknown("no_home_tile", note="功能面板未打开或未找到「家园」磁贴")
            return False
        time.sleep(random.uniform(1.2, 2.0))
        # 家园名片 → "回家"（部分账号可能直接进场景，找不到名片也不判失败）
        if self._click_template("回家", HUIJIA_REGION, timeout=6, threshold=0.85):
            time.sleep(random.uniform(1.5, 2.5))
        else:
            log.info("未见家园名片「回家」，可能已直达家园场景")
        # 等家园场景真正加载完成（顶部 HUD 出现「XX的家园」/「总美观度」，或指向标模板出现）
        if not self._wait_garden_scene(GARDEN_HUD_TIMEOUT):
            # 慢账号兜底：超时后若仍停在家园名片页，说明「回家」这一次没点上（或跳转慢），
            # 补点一次再等一轮。实测账号4 就是这种情形（>8s 仍在名片页）。
            if ocr.contains_text(self.device.screenshot(), HOME_CARD_MARK,
                                 region=HOME_CARD_REGION):
                log.info("等 %ds 仍未进家园且仍在家园名片页，补点一次「回家」重等",
                         GARDEN_HUD_TIMEOUT)
                if not self._click_template("回家", HUIJIA_REGION, timeout=5, threshold=0.85):
                    self.device.click(*HUIJIA_POS)
                time.sleep(random.uniform(1.5, 2.5))
                if self._wait_garden_scene(GARDEN_HUD_TIMEOUT):
                    log.info("已进入家园场景（补点后）")
                else:
                    self.report_unknown(
                        "garden_hud_timeout",
                        note="补点「回家」后 %ds 内仍未见家园 HUD，仍按已进入继续"
                             % GARDEN_HUD_TIMEOUT)
            else:
                self.report_unknown(
                    "garden_hud_timeout",
                    note="点「回家」后 %ds 内未见家园 HUD 且不在家园名片页，仍按已进入继续"
                         % GARDEN_HUD_TIMEOUT)
        else:
            log.info("已进入家园场景")
        # 家园开场常弹「旅行吧喵喵」礼物窗，正好盖住路牌 → 必须先清掉
        self._handle_home_popup()
        return True

    def _wait_garden_scene(self, timeout):
        """轮询等家园场景加载完成（顶部 HUD 或指向标模板命中），返回是否已进入。"""
        deadline = time.time() + timeout
        while time.time() < deadline:
            self._check_stop()
            if self._on_garden_scene(self.device.screenshot()):
                return True
            time.sleep(0.6)
        return False

    def _handle_home_popup(self):
        """清掉家园开场的随机弹窗（已实测两种 + 两种衍生面板）。

        1. 「旅行吧喵喵」礼物窗（"喵喵在神术谷带回来的礼物，请收下"）——**正好压在路牌上**，
           按用户要求点「赠送」走一遍分享 → 关掉好友分享面板。
        2. 「彩虹打卡点」引导窗（"哇，还是被你找到了…请一起摆出此动作拍照：比心" + 底部
           「盛景同游打卡」）——**整块半透明面板糊住画面**，点右上角 X 关闭（打卡要双人组队，
           与种菜无关）。
        3. 好友分享面板 → 右上角 X；4. "恭喜获得…点击空白处关闭" → 点空白。
        """
        for _ in range(8):
            self._check_stop()
            screen = self.device.screenshot()
            texts = [t[0] for t in ocr.scan(screen)]
            if any(k in x for k in SHARE_PANEL_KEYWORDS for x in texts):
                log.info("关闭好友分享面板 @ %s", SHARE_CLOSE_POS)
                self.device.click(*SHARE_CLOSE_POS)
                time.sleep(random.uniform(1.2, 2.0))
                continue
            if any("点击空白处关闭" in x for x in texts):
                log.info("关闭奖励结算面板（点空白）")
                self.device.click(*REWARD_BLANK_POS)
                time.sleep(random.uniform(1.2, 2.0))
                continue
            if any(k in x for k in CHECKIN_KEYWORDS for x in texts):
                log.info("关闭「彩虹打卡点」引导窗 @ %s（打卡要双人组队，与种菜无关）",
                         CHECKIN_CLOSE_POS)
                self.device.click(*CHECKIN_CLOSE_POS)
                time.sleep(random.uniform(1.2, 2.0))
                continue
            if any(k in x for k in YAOMIAO_KEYWORDS for x in texts):
                if self._click_text("赠送", YAOMIAO_GIFT_REGION, timeout=3,
                                    min_similarity=0.85):
                    log.info("已点礼物窗「赠送」，进入分享流程")
                    time.sleep(random.uniform(1.5, 2.5))
                    continue
                self.report_unknown("yaomiao_no_gift_btn",
                                    note="礼物窗未见「赠送/收下」按钮，改为点空白关闭")
                self.device.click(*REWARD_BLANK_POS)
                time.sleep(1.5)
                continue
            break
        return True

    def _reset_garden_view(self):
        """角色跑偏、场景物件（路牌/猫）不在视野时复位：关面板 → 离开回主界面 → 重新进家园。

        实测（账号5 皇家园林12级）：重新进家园后角色回到起始视角，路牌稳定出现在
        左侧中部（模板"指向标" score ≈0.96）。另外「回家」按钮在**已经处于家园
        场景时点击无反应**（用户说明），此时要靠 ESC 关掉家园名片面板。
        """
        log.info("复位家园视角：ESC 关面板 →（必要时）离开 → 重新进家园")
        self.device.press_esc()
        time.sleep(random.uniform(1.2, 1.8))
        # _leave_home 内部会先判断"是否仍在家园场景"：ESC 有时会直接把人送出家园
        # （实测账号4：ESC 关掉面板后已在云梦长安），此时再点「离开」就是在主界面上
        # 瞎点，会误报 no_leave_button / leave_failed。
        self._leave_home()
        if not self._on_main_loose(self.device.screenshot()):
            log.warning("复位失败：点「离开」后仍不在主界面")
            return False
        return self._open_garden()

    def _on_main_loose(self, screen):
        """宽松主界面判定：锚点模板命中 **或** 左上角地图名已是「云梦长安」。

        实测（账号4）：点「离开」后画面确实已回到云梦长安，但主界面锚点模板
        （活动/玩法/商城/背包）因界面布局或遮挡偶发不命中 → on_main_screen 返回 False，
        误报 leave_failed 并多走一轮 ESC 兜底（白耗十几秒）。左上角地图名是更稳的兜底判据。
        """
        return bool(self.on_main_screen(screen)) or self._on_yunmeng(screen)

    def _leave_home(self):
        """点右缘「离开」回主界面。

        「离开」是"圆形箭头图标 + 下方文字"，实测**文字中心 (382,530) 点不到**，
        要点图标中心 (383,510)——故用 click_pos 固定坐标点击。
        点完**轮询等主界面**（场景切换实测 ≥5s，固定 sleep 1.5~2.5s 会误判失败）。
        """
        # 只有**确认在主界面**才跳过「离开」（ESC 已送出 / 上一轮已离开）。
        # ⚠️ 不能用"不在家园场景"当跳过条件：制作台/打卡弹窗等面板盖住家园时
        # is_garden_scene 判 False，会误跳过「离开」把角色滞留在家园——
        # 2026-10-11 账号4/6 事故：zhongcai 收尾时返回箭头没生效，制作台还开着
        # 就被误判"已不在家园"，之后所有任务都在家园里 ESC/离开 死循环空转。
        screen = self.device.screenshot()
        if self._on_main_loose(screen):
            log.info("已在主界面，跳过「离开」")
            return True
        if not self._on_garden_scene(screen):
            # 家园被面板盖住（HUD/路牌都看不见）：先 ESC 关一层面板再点「离开」
            log.info("未见家园 HUD/路牌且不在主界面（疑有面板遮挡），先 ESC 再点「离开」")
            self.device.press_esc()
            time.sleep(random.uniform(1.0, 1.5))
        if not self._click_text("离开", LEAVE_REGION, timeout=5, min_similarity=0.85,
                                click_pos=LEAVE_POS):
            # 「离开」文字小且半透明，OCR 漏检是常态（家园/菜园按钮位置还不同，
            # 详见 LEAVE_REGION 注释）。兜底坐标实测有效，先降级为 info 点击；
            # 只有兜底也没回主界面才报问题（见下面的 leave_failed）。
            log.info("右缘未识别到「离开」，按兜底坐标 %s 点击", (LEAVE_POS,))
            self.device.click(*LEAVE_POS)
        deadline = time.time() + 12
        while time.time() < deadline:
            self._check_stop()
            if self._on_main_loose(self.device.screenshot()):
                return True
            time.sleep(0.8)
        self.report_unknown("leave_failed", note="点「离开」后 12s 内未回主界面，转 ESC 兜底")
        self.back_to_home()
        return self._on_main_loose(self.device.screenshot())

    def ensure_main_screen(self, max_esc=8):
        """覆盖基类：家园/菜园场景要用右缘「离开」回主界面。

        基类实现只按 ESC（家园不是面板，ESC 退不出去），失败后还会走「特殊场景」
        与「世界地图传送」兜底，**实测白耗约 70 秒仍回不去**（家园顶部是"XX的家园"、
        没有地图名，两套兜底都不适用）。这里先识别家园/菜园，直接点「离开」。
        """
        screen = self.device.screenshot()
        if self._on_main_loose(screen):
            return True
        if self._on_garden_scene(screen):
            log.info("当前在家园/菜园场景，点右缘「离开」回主界面")
            for _ in range(3):
                if self._leave_home():
                    log.info("已从家园场景回到主界面")
                    return True
        return super().ensure_main_screen(max_esc)

    # ---------- 公共 ----------

    def _click_template(self, name, region, timeout=8, threshold=None, ccoeff_floor=None):
        """等模板出现并点击其中心，成功返回 True。"""
        hit = self.matcher.wait_for(self.device, name, timeout=timeout, region=region,
                                    threshold=threshold, ccoeff_floor=ccoeff_floor)
        if hit is None:
            return False
        log.info("点击 [%s] @ (%d, %d) score=%.3f", name, hit[0], hit[1], hit[2])
        self.device.click(hit[0], hit[1])
        return True

    def _click_text(self, text, region, timeout=8, min_similarity=0.9, click_pos=None):
        """等 OCR 文字出现并点击；click_pos 非空时只用 OCR 判定存在、点击固定坐标
        （用于文字框中心与按钮中心不重合的按钮，如制作台的「制作」）。"""
        deadline = time.time() + timeout
        while time.time() < deadline:
            self._check_stop()
            hit = ocr.find_text(self.device.screenshot(), text, region=region,
                                min_similarity=min_similarity)
            if hit:
                pos = click_pos or (hit[0], hit[1])
                log.info("点击 [%s] @ (%d, %d)%s", text, pos[0], pos[1],
                         "" if click_pos is None else "（固定坐标，OCR 中心 %d,%d）" % (hit[0], hit[1]))
                self.device.click(pos[0], pos[1])
                return True
            time.sleep(0.5)
        return False

    def _on_garden_scene(self, screen):
        """家园/菜园场景判定，见模块级 is_garden_scene()。"""
        return is_garden_scene(self.matcher, screen)
