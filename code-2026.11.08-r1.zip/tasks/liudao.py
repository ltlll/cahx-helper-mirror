import logging
import random
import re
import time

from core import ocr, teamup
from tasks.base import Task, TaskSkipped

log = logging.getLogger("task.liudao")

# 以下均为 405x720 客户区坐标（按实操记录标定）
LIUDAO_NODE_POS = (280, 520)              # 玩法地图上的六道法门节点（位置固定）
GO_REGION = (140, 455, 130, 55)           # 六道法门详情卡的"前往"按钮
COUNT_REGION = (120, 245, 130, 45)        # 详情卡"次数：n/3"
CHALLENGE_REGION = (130, 380, 150, 55)    # 场景面板"前往挑战"
START_REGION = (120, 500, 165, 70)        # Boss 面板"开始挑战"
BATTLE_ROUND_REGION = (150, 0, 130, 40)   # 战斗画面顶部"第X回合"
BATTLE_AUTO_POS = (368, 683)              # 战斗右下角"自动"
DONE_REGION = (270, 100, 135, 100)        # 追踪面板"完成挑战"（全部 3 次打完的标志）
DONE_REGION2 = (120, 540, 160, 80)        # 追踪面板底部的"完成挑战"条目（兜底）
LEAVE_REGION = (340, 300, 65, 80)         # 副本场景右缘"离开"图标
LEAVE_POS = (380, 340)

MAX_RUNS = 3              # 六道法门每天 3 次（一次"开始挑战"自动连打 3 场）
CHAIN_TIMEOUT = 1800      # 3 场连打最长等待（秒）
MEMBER_GIVEUP = 2100      # 队员端等副本结果的最长时长


class Liudao(Task):
    """六道法门（日常副本，5 人组队）：队长点一次"开始挑战"，自动连打 3 场。

    前置：zudui 组队成功（team_success=True），否则全队跳过。
    队长端：玩法→六道法门节点→详情卡（"次数:n/3"，已满 3 次直接收工）→前往
    →场景面板"前往挑战"→Boss 面板"开始挑战"→（通知队员）进战斗点"自动"
    →等追踪面板出现"完成挑战"（3 场连打全自动，中途无需操作）→点"离开"。
    队员端：等挑战信号→进战斗点"自动"→等"完成挑战"→**不点"离开"**
    （切场景/换地图全归队长，队员跟随；只收拾自己的结算弹窗和赐福令卡）。
    无需准备面板；奖励自动进包；赐福令卡一律点 X。
    """

    name = "liudao"
    title = "六道法门"
    category = "日常副本"

    def _try_once(self):
        coord = teamup.coordinator()
        if not coord.begun:
            log.info("非 GUI 5 开并行模式（协调器未初始化），跳过六道法门")
            raise TaskSkipped("协调器未初始化（非 5 开并行模式），六道法门未执行")
        if coord.dungeon_result(self.name) is not None:
            # 结果已定（重试尝试短路）：如实回报——成了算成功，败了算失败
            if coord.dungeon_result(self.name) is not True:
                raise TaskSkipped("组队已判负，六道法门未执行")
            return True
        # 上一个组队副本任务队长端失败后自动改选了队长：先重建队伍
        if coord.reteam_pending():
            self.reteam_if_requested(coord, self.title)
        # 队长按协调器判定（不是账号库静态标记）：自动改选后新队长立即接管
        me_is_captain = (coord.captain_id == self.account.get("id"))
        if coord.team_success is not True:
            log.info("组队未成功，六道法门按失败计入小结")
            if me_is_captain:
                coord.dungeon_finish(self.name, False)
            raise TaskSkipped("组队未成功")
        if me_is_captain:
            return self._captain_flow(coord)
        return self._member_flow(coord)

    # ---- 队长端 ----

    def _captain_flow(self, coord):
        if not self._enter_scene():
            log.warning("进六道法门场景失败")
            self.captain_fail_finish(coord, "进六道法门场景失败")
            return False
        count = self._run_count()
        if count is not None and count >= MAX_RUNS:
            log.info("今日次数已用完（%d/3），不再挑战", count)
            self._leave_scene()
            coord.dungeon_finish(self.name, True)
            return True
        if not self._start_challenge(coord):
            self.captain_fail_finish(coord, "发起挑战失败", retry_in_place=False)
            return False
        self._fight_until_done()
        self._leave_scene()
        coord.dungeon_finish(self.name, True)
        return True

    def _enter_scene(self):
        """玩法 → 六道法门节点 → 详情卡"前往" → 场景面板（有"前往挑战"）。

        2026-10-17：入口失败不再"点两下就判负"。实测这条链最容易在**刚打完
        上一个副本**时挂（run c03345：海市蜃楼第二场收尾那条「OCR 未读出离开，
        按固定位置点 [离开]」之后立刻进六道法门 → 详情卡一直不弹），此时人可能
        还留在上一个副本场景里。故失败后先清浮层 + 退特殊场景再重来一遍。
        """
        for attempt in range(2):
            if attempt:
                log.warning("六道法门入口失败，清浮层/退特殊场景后重试（第 %d 次）",
                            attempt + 1)
                self.dismiss_popups()
                self._escape_special_scene()
            if not self.open_wanfa():
                continue
            for i in range(2):
                self.device.click(*LIUDAO_NODE_POS)
                hit = self._wait_text("前往", GO_REGION, timeout=8)
                if hit:
                    count = self._run_count()
                    if count is not None and count >= MAX_RUNS:
                        return True  # 已满：不用再点前往，队长流程会直接收工
                    log.info("点击 [前往] @ (%d, %d)", hit[0], hit[1])
                    self.device.click(hit[0], hit[1])
                    # 30s：点「前往」是自动寻路，人还留在上一个副本场景时
                    # 要先走出来再走到入口，场景面板只在**到达后**弹出
                    # （2026-10-18 run 188ac5：3/5 号两任队长都在 15s 等待
                    # 内判负，实际人已经在路上/已到场景）
                    if self._wait_text("前往挑战", CHALLENGE_REGION, timeout=30):
                        return True
                log.warning("六道法门详情卡/场景面板未弹出，重试 (%d/2)", i + 1)
        self.report_unknown("liudao_entry_fail",
                            note="详情卡/场景面板两次重试均未弹出", ai=False)

    def _run_count(self):
        """详情卡"次数：n/3"解析已用次数；读不出返回 None。"""
        for text in ocr.dump_texts(self.device.screenshot(), COUNT_REGION):
            m = re.search(r"(\d)\s*/\s*3", text)
            if m:
                return int(m.group(1))
        return None

    def _start_challenge(self, coord):
        """场景面板"前往挑战" → Boss 面板"开始挑战" → 通知队员。"""
        hit = self._wait_text("前往挑战", CHALLENGE_REGION, timeout=5)
        if not hit:
            log.warning("场景面板无前往挑战按钮")
            return False
        log.info("点击 [前往挑战] @ (%d, %d)", hit[0], hit[1])
        self.device.click(hit[0], hit[1])
        hit = self._wait_text("开始挑战", START_REGION, timeout=10)
        if not hit:
            log.warning("Boss 面板未弹出")
            return False
        log.info("点击 [开始挑战] @ (%d, %d)", hit[0], hit[1])
        self.device.click(hit[0], hit[1])
        coord.dungeon_start_round(self.name)
        coord.dungeon_wait_ready(self.name, 3, self._check_stop)  # 队员纯被动、无需准备，稍等同步即可
        return True

    # ---- 队员端 ----

    def _member_flow(self, coord):
        """队员端：**纯被动**——只等队长的副本结果，不做任何 OCR / 点击
        （用户规则 2026-10-13：六道法门队员不需要点确认，进入战斗即自动
        连打 3 场，识别与操作全交给队长）。

        队员端只做一件事：阻塞等 coord.dungeon_result（队长点"离开"后本号
        自动跟随回主界面）。战斗中客户端自动接管，无需点"自动"、无需收拾
        结算弹窗、无需开自动——这些都是抢鼠标/抢 OCR 开销的无用动作。"""
        deadline = time.time() + MEMBER_GIVEUP
        me_id = self.account.get("id")
        log.info("队员端：只等队长信号，不做识别/不抢鼠标（被动模式）")
        while time.time() < deadline:
            self._check_stop()
            # 队长端失败自动改选后，新队长可能就是本号——而本号线程此刻正
            # 睡在这个等待循环里。2026-10-18 run 7792f4 实测：3 号改选 5 号、
            # 5 号改选 6 号后，新队长都在队员等待里干等，**无人跑队长流程**，
            # 全队干等到 MEMBER_GIVEUP 超时还被记成"任务完成"（zudui 的
            # 队员等待早有同款接管，这里补齐）。
            if (coord.dungeon_result(self.name) is None
                    and me_id == coord.captain_id):
                log.warning("原队长失败，本号被改选为队长，接管六道法门队长流程")
                return self._captain_flow(coord)
            if coord.dungeon_result(self.name) is not None:
                ok = coord.dungeon_result(self.name)
                log.info("副本已结束（%s）", "完成" if ok else "失败")
                if not ok:
                    # 队长端判负 = 本号也没打成，如实计失败（不"没打也算成功"）
                    raise TaskSkipped("队长端六道法门失败，本号未参与完成")
                if not coord.in_current_team(me_id):
                    # 全队结果 ≠ 本号参战：改选重建队伍后被排除的号读到的也是
                    # 同一份 result（2026-10-18 run 188ac5：4 号不在重建后的
                    # 4 人队里，却把钟馗捉鬼记成"完成"）
                    raise TaskSkipped("本号不在当前队伍（重建后未接受邀请），"
                                      "六道法门未参与")
                return True
            time.sleep(2)
        log.warning("等待副本结果超时")
        # 2026-10-18 改判：超时 = 没拿到队长结果 = 副本没完成。旧写法
        # `return True` 让全队没打的副本全记成功（run 7792f4 的 liudao/zhongkui
        # 就是这么被掩盖的），违反"只认正向证据"铁律——如实计失败。
        raise TaskSkipped("等待六道法门副本结果超时（%ds），本号未参与完成"
                          % MEMBER_GIVEUP)

    # ---- 公共 ----

    def _fight_until_done(self):
        """开自动后等追踪面板出现"完成挑战"（3 场连打全自动）。

        正向证据二（2026-10-18 补跑二期实测）：3 场打完游戏会弹「你已完成
        六道法门，是否继续前往钟馗捉鬼?」接续弹窗——弹窗出现本身就等于
        打完了；只认"完成挑战"四个字时，弹窗正好盖住追踪面板、dismiss
        取消后面板又切走，会白等满 CHAIN_TIMEOUT（26 分钟全队干等）。
        """
        deadline = time.time() + CHAIN_TIMEOUT
        while time.time() < deadline:
            self._check_stop()
            screen = self.device.screenshot()
            texts = ocr.scan(screen)
            if (ocr.find_text(screen, "完成挑战", region=DONE_REGION,
                              min_similarity=1.0)
                    or ocr.find_text(screen, "完成挑战", region=DONE_REGION2,
                                     min_similarity=1.0)):
                log.info("完成挑战（3 场连打结束）")
                return True
            for t, *_ in texts:
                if "已完成六道" in t or "继续前往" in t:
                    log.info("接续弹窗出现（%r）= 六道已打完", t)
                    self.dismiss_popups(screen)
                    return True
            if self.dismiss_popups(screen):
                continue
            time.sleep(3)
        log.warning("等待完成挑战超时")
        return False

    def _wait_text(self, text, region, timeout, min_similarity=1.0):
        deadline = time.time() + timeout
        while time.time() < deadline:
            hit = ocr.find_text(self.device.screenshot(), text,
                                region=region, min_similarity=min_similarity)
            if hit:
                return hit
            time.sleep(0.6)
        return None

    def _leave_scene(self):
        """关赐福令卡和接续弹窗，点副本场景右缘"离开"。"""
        self.dismiss_item_cards()
        self.dismiss_popups()
        screen = self.device.screenshot()
        hit = ocr.find_text(screen, "离开", region=LEAVE_REGION,
                            min_similarity=0.75)
        if hit:
            log.info("点击 [离开] @ (%d, %d)", hit[0], hit[1])
            self.device.click(hit[0], hit[1])
            time.sleep(random.uniform(2.5, 3.5))
