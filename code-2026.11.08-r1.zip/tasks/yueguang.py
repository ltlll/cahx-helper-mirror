import logging
import time

from core import ocr
from tasks.base import Task

log = logging.getLogger("task.yueguang")

# 以下均为 405x720 客户区坐标
ICON_ROW_REGION = (40, 460, 330, 90)    # 主界面中部图标行：高度固定，横向图标数量/位置每天会变
GOTO_BTN_REGION = (220, 420, 150, 55)   # 提示弹窗“前往”按钮（避开右侧宗门任务的“前往”）
CLAIM_BTN_REGION = (130, 500, 145, 60)  # 宝盒旁的“领取”按钮


class YueguangBox(Task):
    """领取月光宝盒：主界面"月光"图标 → 提示弹窗点"前往"（自动寻路）
    → 走到宝盒旁点"领取" → 点空白关闭奖励弹窗 → 返回主界面。

    图标行横向位置/数量不固定，用 OCR 找图标下方"月光"文字定位；
    图标不存在说明今日已领或未刷新，直接跳过（不算失败）。
    """

    name = "yueguang"
    title = "领取月光宝盒"

    def _try_once(self):
        self.dismiss_popups()
        # "月光"图标文字是艺术字且位置每天变，单次截图漏检不能就当已领：
        # 连扫几秒、允许单字误识（"月关/月差"）都找不到才跳过
        hit = None
        deadline = time.time() + 6
        while time.time() < deadline:
            hit = ocr.find_text(self.device.screenshot(), "月光",
                                region=ICON_ROW_REGION, min_similarity=0.8)
            if hit:
                break
            time.sleep(0.8)
        if not hit:
            log.info("主界面无“月光”图标（今日已领或未刷新），跳过")
            return True
        # "月光"文字在图标正下方，点文字上方约 12px 的图标本体
        log.info("点击 [月光] @ (%d, %d)", hit[0], hit[1] - 12)
        self.device.click(hit[0], hit[1] - 12)
        if not self._click_goto():
            return False
        if not self._click_claim():
            return False
        self.close_reward_popup(timeout=10)
        self.exit_panel_to_home()
        return True

    def _click_goto(self, timeout=8):
        """点图标后弹出提示"宝盒已经准备好报酬啦"，点"前往"。"""
        deadline = time.time() + timeout
        while time.time() < deadline:
            hit = ocr.find_text(self.device.screenshot(), "前往",
                                region=GOTO_BTN_REGION, min_similarity=1.0)
            if hit:
                log.info("点击 [前往] @ (%d, %d)", hit[0], hit[1])
                self.device.click(hit[0], hit[1])
                return True
            time.sleep(0.6)
        log.warning("未等到“前往”提示弹窗")
        return False

    def _click_claim(self, timeout=45):
        """前往后自动寻路数秒（实测约 10~15s），走到宝盒旁出现"领取"按钮。"""
        deadline = time.time() + timeout
        while time.time() < deadline:
            screen = self.device.screenshot()
            if self.dismiss_popups(screen):
                continue
            hit = ocr.find_text(screen, "领取",
                                region=CLAIM_BTN_REGION, min_similarity=1.0)
            if hit:
                log.info("点击 [领取] @ (%d, %d)", hit[0], hit[1])
                self.device.click(hit[0], hit[1])
                return True
            time.sleep(0.8)
        log.warning("等待“领取”按钮超时（寻路被打断？）")
        return False
