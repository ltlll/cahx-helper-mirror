import logging
import random
import re
import time

from core import ocr
from tasks.base import (BATTLE_AUTO_POS, BATTLE_MARK_REGION, Task,
                        DIALOG_OPT_BAN_TTL)

log = logging.getLogger("task.zongmen")

# 以下均为 405x720 客户区坐标
TASK_TAB_REGION = (270, 75, 90, 40)       # 主界面右上"任务"页签（旁边是"队伍"）
ENTRY_SCAN_REGION = (260, 115, 145, 195)  # 任务追踪面板扫描区（含条目下方一行，用于区分提示弹窗）
ENTRY_MAX_Y = 260                         # 追踪条目只接受 y < 此值的匹配（往下是"可领取"提示弹窗）
SUMMARY_REGION = (60, 150, 285, 80)       # 结束画面"奖励总览"标题
SUMMARY_BLANK_POS = (200, 640)            # 奖励总览点下方空白处关闭
SKIP_REGION = (330, 595, 75, 60)          # 任务链剧情/战斗右下"跳过"按钮（点它加速）
ROUND_REGION = (120, 0, 170, 40)          # 战斗画面顶部居中"第N回合"（战斗判定兜底：
                                          # 宗门战斗读不到"战况"，2026-10-14 实测把战斗
                                          # 当成无选项对话、绕 AI 兜底空耗 ~50 分钟/号）
DIALOG_OPTION_REGION = (60, 290, 290, 180)  # 宗门剧情对话选项（【括号】风格或无括号
                                            # 胶囊多选项，见 _find_dialog_option）：
                                            # 选项会卡住任务链且"跳过"跳不动，必须点选
DIALOG_ADVANCE_POS = (200, 605)           # 底部居中对话框的文字区：无选项/无"跳过"的
                                          # 对话不会自动推进，需点击对话本身（实测）

# 机关验证小游戏（2026-10-18 run 7792f4 实测「图纸还原」拼图：帒倒计时、
# 拖动方块填满上方图纸；用户确认还有"开宝箱机关"同类场景）。脚本不玩解谜：
# **点左下角返回图标退出 → 点右上角任务进度条目重新进入任务 → 变成战斗模式
# （强行破解机关）**（用户规则 2026-10-18）。连续 3 次退不掉才判失败。
# 小游戏说明文字"拖动下面的方块，填满上方图纸" @ (202,382) 恰落在
# DIALOG_OPTION_REGION 内，会被当成对话选项连点——一并排除（见
# _find_dialog_option 的 PUZZLE_WORDS 过滤）。
PUZZLE_TITLE_REGION = (20, 55, 170, 50)   # 「图纸还原」标题 @ (90,80)
PUZZLE_COUNT_REGION = (230, 100, 150, 55) # 「倒计时：N秒」 @ (300,131)
PUZZLE_EXIT_POS = (33, 683)               # 左下角返回图标（同「玩法」面板出口）
PUZZLE_WORDS = ("图纸还原", "倒计时", "拖动")

# 死胡同面板（2026-10-21 早 run 实测 7 号）：宗门链子步骤「寻找宗门三宝」把角色
# 带进**九霄塔布阵页**（顶部标题"九霄塔10层…"，整页阵容布阵+强袭按钮，没有任何
# 对话/选项可点）或**妖灵渡口订单面板**（AI 兜底点加速/获取/收取都推不动）。
# 这类页面不是对话、没有任务条目，催动与假选项检测全部失效，只能干等到判负
# （7 号两次尝试共白耗 645 秒）。识别左上角标题后点左下角返回箭头退出，再点
# 任务条目重进链路重新寻路。两个面板左下是同款返回箭头，圆心取两图交集。
DEADEND_TITLE_REGION = (0, 0, 260, 75)    # 九霄塔标题@y14 / 妖灵渡口标题@(60,58)
DEADEND_EXIT_POS = (36, 682)              # 左下角返回箭头（塔页圆心(35,687)∩渡口(46,670)）
DEADEND_MAX_EXITS = 3                     # 连续退出超过该次数仍被带进去 → 判失败

# 任务链"无进展"判定：追踪条目文字连续这么久没变（催动 3 次无效）就判卡死，
# 提前收工走重试/失败，不再干等满 CHAIN_TIMEOUT（2026-10-13 实测：假选项循环
# 让 4 个账号各空耗 ~53 分钟）。正常链 10 轮约 10 分钟，5 分钟纹丝不动必是卡死。
STUCK_ABORT = 300

# 剧情战斗准备页（2026-10-31 run e5ee47，5 号实测截图
# debug/unknown/ai_zongmen__dialog_no_option__1793411576.png）：宗门链走到
# 剧情战斗时是**一整屏战斗准备画面 + 中央一个圆形「战」按钮**，没有「战况」/
# 「第N回合」（`_in_battle` 认不出），也没有对话选项和「跳过」→ 老逻辑落到
# "追踪面板 30 秒不可见 → 点底部对话框" 分支空转，直到 dialog_no_option 判负，
# AI 兜底也只点一次没生效就弃权。这里认出「战」直接点开打。
FIGHT_START_REGION = (150, 295, 105, 95)  # 圆形「战」按钮所在区域
FIGHT_START_POS = (200, 340)              # 按钮圆心（OCR 读不到时的兜底）

# 同一个"对话选项"坐标连点这么多次、期间又没有任何实质进展 → 判假选项循环，早退。
# 2026-10-16 事故：`_find_dialog_option` 把画面中部的**场景/副本名标签**误判成
# 对话选项（失败截图 debug/1792115544_zongmen_fail.png：账号其实在主界面，追踪面板
# 展开、根本没有对话），同一坐标被连点 159 次；更糟的是选项分支走 `continue`
# **绕过了下面所有催动/卡死检测** → 单次尝试干耗满 CHAIN_TIMEOUT(25 分钟)，
# 3/4 号各 51 分钟；队长为等它们到齐白等 600 秒×2 → 组队判负 →
# haishi/liudao/zhongkui 三个组队任务全灭，整轮从 1 小时拖到 3.5 小时。
OPT_LOOP_ABORT = 5


# 名牌判定已提升为共享工具（core/ocr.name_tag_like）——宗门任务、登录兜底、
# settle_scene 兜底阶梯都踩过"把玩家头顶名牌当对话选项"这个坑，统一实现。
_name_tag_like = ocr.name_tag_like


class Zongmen(Task):
    """宗门任务：主界面右上"任务"页签 → 点"宗门任务"条目 → 任务链全自动推进
    （对话自动继续、交道具 3 秒自动上交、战斗自动打）→ 等到"奖励总览"
    结束画面 → 点空白关闭 → 返回主界面。

    任务条目不存在说明今日已完成，跳过不算失败。
    10 轮任务链实测约 10 分钟，CHAIN_TIMEOUT 给足余量。
    """

    name = "zongmen"
    title = "宗门任务"

    CHAIN_TIMEOUT = 1500  # 任务链最长等待（秒）

    def _try_once(self):
        self.dismiss_popups()
        self._dismiss_dialogue()  # 清理上次链中断遗留的剧情对话（选项/跳过）
        screen = self.device.screenshot()
        # 上次尝试可能被链路拖进死胡同面板（九霄塔布阵/妖灵渡口，2026-10-21
        # 7 号实测）：先退出来，否则 on_main_screen 判负白烧一次尝试
        self._exit_deadend_panel(screen)
        if not self.on_main_screen(self.device.screenshot()):
            log.warning("不在主界面，无法判定宗门任务状态")
            return False
        self._restore_quest_view()
        entry = None
        panel_visible = False
        for _ in range(4):
            screen = self.device.screenshot()
            entry = self._find_entry(screen)
            if entry:
                break
            # 追踪面板已展开（有条目就有"前往XX"描述）但没有宗门任务
            # → 今日已完成。注意不能无条件点"任务"页签：面板已展开时点
            # 已激活页签会收起面板，下轮截图条目消失，误判成"今日已完成"。
            if ocr.contains_text(screen, "前往", region=ENTRY_SCAN_REGION):
                panel_visible = True
                break
            tab = ocr.find_text(screen, "任务", region=TASK_TAB_REGION,
                                min_similarity=1.0)
            if tab:
                log.info("追踪面板未展开，点击 [任务页签]")
                self.device.click(tab[0], tab[1])
            time.sleep(random.uniform(1.0, 1.5))
        if not entry:
            if not panel_visible:
                # 面板没展开（不在主界面/在特殊场景，如被卡链拖进副本场景）：
                # 读不到任何条目，不能据此判"今日已完成"（实测卡链超时后重试
                # 被误判完成）。返回 False 走重试/失败报警。
                log.warning("追踪面板未展开（不在主界面或特殊场景？），"
                            "无法判定宗门任务是否完成")
                return False
            # ⚠️ 「面板已展开」是靠区域里出现「前往」判的，别的条目也有这个词
            # （天之将倾的"前往副本·神遗都"），所以它不能当"宗门任务已完成"的
            # 正向证据——2026-10-31 补跑 4 号链停在 8/10 时就是这样被判"已完成"的。
            # 但**不能改成"有条目就判失败"**：宗门任务的自动寻路在脚本放弃后仍会
            # 继续推进（同日 5 号从 5/10 一路走到 6/10 就是旁证），链走完条目自然
            # 消失，此时追踪面板里照样挂着天之将倾/妖灵渡口 → 会把每天的"已完成"
            # 全判成失败。折中：结论照旧，但**留一张存证截图**（不触发 AI），
            # 下次怀疑假完成时能直接回看当时面板。
            self.save_debug_screenshot("zongmen_done_unverified")
            log.info("任务列表无“宗门任务”（今日已完成），跳过（已存证截图）")
            return True
        log.info("点击 [宗门任务] @ (%d, %d)，启动任务链", entry[0], entry[1])
        self.device.click(entry[0], entry[1])
        time.sleep(random.uniform(1.5, 2.5))
        return self._wait_chain_done()

    @staticmethod
    def _find_entry(screen):
        """找追踪面板里的"宗门任务"条目，返回 (cx, cy, 归一化文本)；找不到返回 None。

        条目文字可能与左侧图标文字粘连，用包含匹配。主界面"宗门任务 可领取
        [取消|前往]"提示弹窗的标题也含"宗门任务"：其正下方紧跟"可领取"，
        而追踪条目下方是"前往掌门处接取任务"，以此排除。
        """
        texts = ocr.scan(screen, ENTRY_SCAN_REGION, min_score=0.5)
        for text, cx, cy, _ in texts:
            if "宗门任务" not in text or cy >= ENTRY_MAX_Y:
                continue
            if any("可领取" in t and abs(x - cx) < 60 and 5 < y - cy < 45
                   for t, x, y, _ in texts):
                continue  # 提示弹窗标题，不是追踪条目
            return cx, cy, text.replace(" ", "")
        return None

    @staticmethod
    def _in_battle(screen):
        """战斗画面判定："战况"角标或顶部"第N回合"任一命中。

        只认"战况"不够——宗门任务的战斗界面没有"战况"二字（2026-10-14
        实测：被当成 dialog_no_option 卡死场景，白耗 50 分钟）。

        ⚠️ 顶部那行必须用 `contains_text`（子串包含匹配），不能用
        `find_text`——find_text 走 SequenceMatcher 相似度，"第1回合" vs
        "回合" 只有 0.4，会被相似度闸门拒掉返回 None（2026-10-14 实测
        截图验证：OCR 明明读出了"第1回合" 0.98 分，find_text 却找不到）。
        """
        if ocr.contains_text(screen, "战况", region=BATTLE_MARK_REGION):
            return True
        return ocr.contains_text(screen, "回合", region=ROUND_REGION)

    def _wait_chain_done(self):
        """任务链全自动：轮询等"奖励总览"结束画面，期间清理系统弹窗、
        点掉剧情/战斗的"跳过"按钮加速、点选对话选项（形如【告诉对方刚刚的
        情况】，会卡住任务链且"跳过"跳不动）。

        链可能卡死（缺道具的寻找环、寻路被打断等）：进度条目文字 60 秒没
        变化就点一下进度条目催动（参考 xunbao 的卡链处理）；连续 3 次催动
        仍无变化判卡死，提前收工（STUCK_ABORT，2026-10-13 起不再干等满
        CHAIN_TIMEOUT——假选项循环曾让 4 个账号各空耗 ~53 分钟）。
        还有一类卡死：无选项、无"跳过"的剧情对话不会自动推进，需要点击
        对话本身（实测卡死 13 分钟——追踪面板被对话框遮挡读不到条目，
        既无催动日志也无跳过点击，纯静默等待）。追踪面板 30 秒不可见
        且不在战斗中，就点底部对话框文字区催动。

        进度的唯一信标是**追踪条目文字变化**：点选项/催动本身不重置计时
        （2026-10-13 教训——假选项命中时把计时一次次重置，卡死检测全废）；
        战斗中的等待不计入（战况可见时冻结计时）。

        "静止卡死"（2026-10-14 用户报）：画面里既没战斗也没对话，自动寻路
        突然停住不动，任务链纹丝不动静置到人工点右上角任务进度条目才复活。
        进度条目 30 秒没变化就点它催动——**点进度条目就是重新激活自动寻路
        的开关**；连续 3 次无进展才判卡死重试。

        **假选项循环**（2026-10-16）：`_find_dialog_option` 把画面中部的场景/
        副本名标签当成了对话选项，而选项分支的 `continue` 会绕过上面所有催动
        与卡死检测 → 同一坐标连点 159 次、单次尝试干耗 25 分钟。现在有两道
        兜底：①循环顶部 `last_progress` 全局看门狗（非战斗时 STUCK_ABORT 秒
        无实质进展即退）；②同一选项坐标连点 OPT_LOOP_ABORT 次即判假选项退出。
        两者都走 `report_unknown` 存档，方便回看当时画面。"""
        deadline = time.time() + self.CHAIN_TIMEOUT
        last_text, last_change = None, time.time()
        last_progress = time.time()  # **真进展**信标：只有条目文字变化/进战斗才算
        last_opt, opt_repeat = None, 0
        opt_bans = 0             # 已拉黑的假选项坐标数（连点无进展的那些）
        me = self._self_name()   # 排除玩家头顶名牌（见 _find_dialog_option）
        no_entry_since = None
        nudges = 0               # 同一条目文字下已催动的次数
        reported = False
        auto_on = False          # 本场战斗已点过"自动"
        puzzle_exits = 0         # 机关小游戏强退次数（防死循环）
        fight_clicks = 0         # 剧情战斗准备页点「战」次数（防死循环）
        deadend_exits = 0        # 死胡同面板（九霄塔/妖灵渡口）退出次数
        while time.time() < deadline:
            self._check_stop()  # 长循环：响应 GUI 停止
            screen = self.device.screenshot()
            if self.dismiss_popups(screen):
                continue
            in_battle = self._in_battle(screen)
            # 全局无进展看门狗：**任何分支都绕不过去**，尤其选项分支。
            # 老逻辑的催动/卡死判定全挂在"走不到 entry 分支"的前提上，一旦
            # `_find_dialog_option` 持续假命中，`continue` 就把它整条跳过，
            # 于是同一坐标能连点到 CHAIN_TIMEOUT（2026-10-16 上游事故）。
            # 这里只在非战斗时计时：战斗耗时不算卡链。
            if not in_battle and time.time() - last_progress > STUCK_ABORT:
                log.warning("任务链连续 %d 秒无实质进展（无条目变化/无战斗），"
                            "判定卡死，提前收工重试", STUCK_ABORT)
                self.report_unknown("chain_stuck", screen,
                                    note="任务链长时间无实质进展")
                return False
            if in_battle:
                last_change = time.time()  # 战斗耗时不算卡链
                last_progress = time.time()
                last_opt, opt_repeat = None, 0
                if not auto_on:
                    # 进战斗点右下角圆形"自动"按钮开自动战斗（否则战斗
                    # 停在手动模式永远打不完；每场只点一次，反复点会把
                    # 自动切回手动）
                    log.info("检测到战斗画面，点 [自动] 开自动战斗")
                    self.device.click(*BATTLE_AUTO_POS)
                    auto_on = True
            elif auto_on:
                auto_on = False  # 战斗结束，下场战斗重新点
            # 剧情战斗准备页：中央「战」按钮（认不出就空转到 dialog_no_option）
            if not in_battle and fight_clicks < 3:
                prompt = self._fight_prompt_hit(screen)
                if prompt:
                    fight_clicks += 1
                    log.info("剧情战斗准备页：点击中央「战」开战 @ (%d, %d)"
                             "（第 %d 次）", prompt[0], prompt[1], fight_clicks)
                    self.device.click(*prompt)
                    time.sleep(random.uniform(1.5, 2.2))
                    last_progress = time.time()  # 开战算一次推进（战斗随即开始）
                    last_opt, opt_repeat = None, 0
                    continue
            # 机关验证小游戏（图纸还原/开宝箱机关等）：不玩解谜，点左下角
            # 返回退出 → 点右上角任务进度重进任务 → 变成战斗模式强攻
            #（用户规则 2026-10-18；不处理会一直挂到 STUCK_ABORT 判卡死）
            if not in_battle and self._puzzle_hit(screen):
                puzzle_exits += 1
                if puzzle_exits > 3:
                    log.warning("机关小游戏退出 %d 次仍在，判失败", puzzle_exits)
                    self.report_unknown("puzzle_stuck", screen,
                                        note="机关小游戏反复弹出")
                    return False
                log.info("检测到机关小游戏（第 %d 次强退）：点返回退出 → "
                         "重进任务强攻", puzzle_exits)
                self.device.click(*PUZZLE_EXIT_POS)
                time.sleep(random.uniform(1.5, 2.2))
                screen2 = self.device.screenshot()
                entry = self._find_entry(screen2)
                if entry:
                    log.info("点击 [任务进度] @ (%d, %d) 重新进入任务", *entry[:2])
                    self.device.click(entry[0], entry[1])
                last_progress = time.time()
                last_opt, opt_repeat = None, 0
                time.sleep(random.uniform(2.0, 3.0))
                continue
            # 死胡同面板（九霄塔布阵页/妖灵渡口，2026-10-21 7 号实测）：链路
            # 子步骤把角色带进去后无对话无条目，催动全失效。识别标题 → 点
            # 左下返回箭头退出 → 点任务条目重进链路重新寻路（同机关小游戏
            # 的"退出重进"套路）；反复被带进去超过上限才判失败。
            if not in_battle and self._deadend_title(screen):
                deadend_exits += 1
                if deadend_exits > DEADEND_MAX_EXITS:
                    log.warning("死胡同面板退出 %d 次仍被带进去，判失败",
                                deadend_exits)
                    self.report_unknown("deadend_stuck", screen,
                                        note="九霄塔/妖灵渡口面板反复出现")
                    return False
                self._exit_deadend_panel(screen)
                screen2 = self.device.screenshot()
                entry = self._find_entry(screen2)
                if entry:
                    log.info("点击 [任务进度] @ (%d, %d) 重新进入任务",
                             *entry[:2])
                    self.device.click(entry[0], entry[1])
                last_progress = time.time()
                last_opt, opt_repeat = None, 0
                time.sleep(random.uniform(2.0, 3.0))
                continue
            if ocr.find_text(screen, "奖励总览", region=SUMMARY_REGION,
                             min_similarity=0.8):
                log.info("宗门任务链完成，点空白关闭奖励总览")
                self.device.click(*SUMMARY_BLANK_POS)
                time.sleep(random.uniform(1.2, 1.8))
                return True
            opt = self._find_dialog_option(screen, me)
            if opt:
                # 同一坐标连点 = 假选项（真选项点一次就消失）。按 8px 网格聚类，
                # 容忍 OCR 抖动（实测同一按钮读成 207/208/209,374）。
                key = (opt[0] // 8, opt[1] // 8)
                opt_repeat = opt_repeat + 1 if key == last_opt else 1
                last_opt = key
                log.info("点击对话选项 @ (%d, %d)", *opt)
                self.device.click(*opt)
                # 注意：不在这里重置卡链计时——选项是否真推进了剧情，由
                # 条目文字变化（下面的 entry 分支）统一确认
                time.sleep(random.uniform(0.8, 1.2))
                if opt_repeat >= OPT_LOOP_ABORT:
                    log.warning("同一对话选项 @ (%d, %d) 连点 %d 次、无任何进展，"
                                "判定假选项，拉黑该坐标 %d 秒（本轮继续跑，"
                                "交给「跳过」/催动分支）",
                                opt[0], opt[1], opt_repeat, DIALOG_OPT_BAN_TTL)
                    # 2026-10-18 run 7792f4：只收工不拉黑，第 2 次尝试还在原地
                    # 连点 5 次。拉黑后候选过滤阶段直接跳过该坐标。
                    # 2026-10-25 改进：**拉黑后不再立刻 return False**——今天
                    # 4 个号都是被名牌假选项（"倾天一外买点到手额"）连点后直接
                    # 判负，而画面上本来就有可读的「跳过」，把这一轮白白废掉。
                    # 现在拉黑后继续跑，让后面的「跳过」分支接手；真拉不回来
                    # 才由下面的计数（3 次不同假选项）或全局看门狗收工。
                    banned = getattr(self, "_dlg_opt_banned", {})
                    banned[key] = time.time() + DIALOG_OPT_BAN_TTL
                    self._dlg_opt_banned = banned
                    opt_bans += 1
                    last_opt, opt_repeat = None, 0
                    if opt_bans >= 3:
                        self.report_unknown("dialog_option_loop", screen,
                                            note="同一对话选项连点无进展"
                                                 f"（已拉黑 {opt_bans} 个坐标）")
                        return False
                    continue
                continue
            entry = self._find_entry(screen)
            if entry:
                no_entry_since = None
                cx, cy, text = entry
                if text != last_text:
                    last_text, last_change = text, time.time()
                    last_progress = time.time()
                    nudges = 0
                    last_opt, opt_repeat = None, 0
                elif time.time() - last_change > 30:
                    # 条目 30 秒没变化：点条目催动自动寻路（含**静止卡死**——
                    # 自动寻路偶尔会停住，画面里没战斗、没对话，只有点一下
                    # 右上角任务进度条目才会重新激活，2026-10-14 实测 5 号
                    # 账号静置到人工点它才继续）。60 秒太晚：静止期不算战斗/
                    # 对话，白等一分钟还得三催才收工，改成 30 秒就催、催满
                    # 3 次仍不动才判卡死。
                    log.info("任务链进度 30 秒未变化（%s），点击进度条目催动自动寻路",
                             text)
                    self.device.click(cx, cy)
                    last_change = time.time()  # 重置计时，防连点
                    nudges += 1
                    if nudges >= 3:
                        log.warning("任务链连续 %d 次催动无进展（%s），判定卡死，"
                                    "提前收工重试", nudges, text)
                        return False
            elif not in_battle:
                # 追踪面板被对话遮挡且非战斗：点底部对话框推进剧情
                # （战斗中面板同样不可见，必须排除——点屏幕会干扰自动战斗）
                if no_entry_since is None:
                    no_entry_since = time.time()
                elif time.time() - no_entry_since > 30:
                    log.info("追踪面板 30 秒不可见，点击底部对话框推进剧情")
                    if not reported:
                        self.report_unknown("dialog_no_option", screen,
                                            note="无选项对话卡住任务链")
                        reported = True
                    self.device.click(*DIALOG_ADVANCE_POS)
                    no_entry_since = time.time()  # 重置计时，每次催动间隔 30 秒
                    time.sleep(random.uniform(0.8, 1.2))
                    continue
            hit = ocr.find_text(screen, "跳过", region=SKIP_REGION,
                                min_similarity=1.0)
            if hit:
                log.info("点击 [跳过] 加速任务链 @ (%d, %d)", hit[0], hit[1])
                self.device.click(hit[0], hit[1])
                time.sleep(random.uniform(0.8, 1.2))
                continue
            time.sleep(5)
        log.warning("等待任务链结束超时")
        return False

    def _self_name(self):
        """本账号角色名（用于排除玩家头顶「称号+角色名」名牌）。"""
        acc = getattr(self, "account", None) or {}
        return str(acc.get("character") or "").replace(" ", "").strip()

    def _puzzle_hit(self, screen):
        """画面是否为机关验证小游戏（「图纸还原」标题或「倒计时：N秒」）。"""
        return bool(
            ocr.find_text(screen, "图纸还原", region=PUZZLE_TITLE_REGION,
                          min_similarity=0.7)
            or ocr.find_text(screen, "倒计时", region=PUZZLE_COUNT_REGION,
                             min_similarity=0.7))

    @staticmethod
    def _fight_prompt_hit(screen):
        """剧情战斗准备页的圆形「战」按钮，返回中心坐标；没有返回 None。

        只认**单个字**「战」且落在画面中部的圆形按钮区（FIGHT_START_REGION）：
        聊天栏的"战令/战功"、战斗界面里的"战况"都是更长的词，不会误命中；
        真战斗画面由 `_in_battle` 处理，走不到这里。
        """
        for t, cx, cy, _ in ocr.scan(screen, FIGHT_START_REGION, min_score=0.5):
            if t.replace(" ", "").strip("丨|[]") in ("战", "戦"):
                return (cx, cy)
        return None

    @staticmethod
    def _deadend_title(screen):
        """识别死胡同面板（九霄塔布阵页/妖灵渡口订单面板），返回面板名。

        九霄塔标题 OCR 常把"霄"读错（实测读成"九适塔10层"），用 九?塔
        模糊匹配；妖灵渡口用稳定前缀"妖灵渡"。
        """
        for t, cx, cy, _ in ocr.scan(screen, DEADEND_TITLE_REGION,
                                     min_score=0.45):
            if cy > 70:
                continue
            if re.search(r"九.塔", t):
                return "九霄塔"
            if "妖灵渡" in t:
                return "妖灵渡口"
        return None

    def _exit_deadend_panel(self, screen):
        """检测到死胡同面板就点左下返回箭头退出。返回 True=处理过（调用方
        应重扫画面再继续），False=画面正常。"""
        name = self._deadend_title(screen)
        if not name:
            return False
        log.info("检测到%s面板：点左下返回箭头退出", name)
        self.device.click(*DEADEND_EXIT_POS)
        time.sleep(random.uniform(1.5, 2.2))
        return True

    def _find_dialog_option(self, screen, me=""):
        """宗门剧情对话的选项按钮。两类（2026-10-12 实测）：

        - 【告诉对方刚刚的情况】全角括号风格（OCR 能完整读出括号）；
        - 无括号的胶囊按钮风，可多个（如"滚出十万大山"/"不许劫掠"并排——
          **有选项未选时"跳过"无效**，必须点选，实测卡死 20 分钟）。

        扫描区域限画面中上部（避开底部对话框/聊天栏/奖励总览）；说话人标签
        与左侧元素靠左（cx≈90），选项胶囊居中（150≤cx≤260），追踪面板条目
        靠右（cx>260），以此排除。返回最靠上的一个选项 (cx, cy)。

        **必须排除任务悬浮横幅**（2026-10-13 实测）：链进行中底部中央会悬浮
        当前步骤文案（如"宗门任务 7/10 / 前往广场·修炼日 (0/1)"），位置恰与
        真选项同高（y≈374、cx≈208），被当成选项连点一整小时——点它不推进
        剧情，还把卡链计时一次次重置。横幅特征：含"宗门任务"/"前往"开头/
        带进度 n/m，真选项（【…】或胶囊按钮按钮文案）不会有这些。

        **必须排除玩家头顶名牌**（2026-10-16 实测，比横幅更常见的元凶）：
        主界面上玩家头顶的「称号+角色名」浮字会被读成一条文本，位置也在
        cx≈206/cy≈374，与真选项同列同高——

            "做天一外卖点到手版"(cx=206, cy=374) = 称号「傲天一」+ 角色名
            "倾天一奶茶朝夕相伴"(cx=206, cy=374) = 称号「倾天一」+ 角色名

        实测同一坐标被连点 159 次、单次尝试干耗 25 分钟（见 `OPT_LOOP_ABORT`）。
        名牌必含**本账号角色名**，故用 `me` 参数排除（默认空 = 不过滤，兼容
        老的自检调用）。注意 name_tag_like 是 0.8 重合率，OCR 把名字读错
        2 字时会漏判（2026-10-18："外卖点到手颤"→"外买点到手额"，0.67）——
        漏网之鱼由同坐标连点拉黑（`_dlg_opt_banned`）兜底，见主循环。

        **候选过滤阶段剔除假选项黑名单**（2026-10-18）：拉黑要在挑选前生效，
        否则每轮仍会挑中同一个假坐标去点（与 base._handle_dialog 同款机制）。

        **非括号选项必须先确认"对话框真的开着"**（2026-10-31 run e5ee47）：
        主城里**别的玩家**头顶的「称号+角色名」名牌也落在本扫描区
        （cx≈150~260 / cy≈320~390，与真选项同列同高），而 `_name_tag_like`
        只认**本账号**名字 → 3/4/5 号同时把别人的名牌当选项连点。点击落到
        地面＝角色被拉过去跑，自动寻路原地打转 300 秒判卡死（三个号合计白烧
        ~15 分钟，宗门任务全灭）。而且 OCR 抖动 ±6px 会不断换网格 key，
        OPT_LOOP_ABORT 的同坐标连点计数被绕过，拉黑兜底也失效。
        所以：**括号风格（【…】）直接认**（只有剧情对话会这么渲染），
        胶囊按钮则要求 `_dialog_open`（有「跳过」或左栏被整屏盖住）。
        """
        if isinstance(self, Task):
            now = time.time()
            banned = {k: exp for k, exp in
                      getattr(self, "_dlg_opt_banned", {}).items() if exp > now}
            self._dlg_opt_banned = banned
        else:
            # 未绑定/桩调用（老自检传 self=None）：没有实例状态，跳过拉黑表
            banned = {}
        dialog_open = None
        opts = []
        for text, cx, cy, _ in ocr.scan(
                screen, region=DIALOG_OPTION_REGION, min_score=0.5):
            if len(text) < 3 or not 150 <= cx <= 260:
                continue
            if (cx // 8, cy // 8) in banned:
                continue  # 已确认的假选项坐标（连点无进展拉黑）
            norm = text.replace(" ", "")
            if ("宗门任务" in norm or norm.startswith("前往")
                    or re.search(r"\d+\s*/\s*\d+", norm)):
                continue  # 任务横幅/进度文案，不是对话选项
            if any(w in norm for w in PUZZLE_WORDS):
                continue  # 机关小游戏说明文字（"拖动下面的方块…" @ 202,382）
            if _name_tag_like(norm, me):
                continue  # 玩家头顶「称号+角色名」名牌，不是对话选项
            if not ("【" in norm or "】" in norm):
                # 非括号候选：可能是别的玩家的名牌 → 必须确认对话开着
                if dialog_open is None:
                    dialog_open = (not isinstance(self, Task)
                                   or self._dialog_open(screen))
                if not dialog_open:
                    continue
            opts.append((cx, cy))
        return min(opts, key=lambda p: p[1]) if opts else None

    def _dialog_open(self, screen):
        """画面上是否真的有剧情对话框（决定要不要把中部文字当选项）。

        真对话的特征二选一：右下角有「跳过」；或主界面左栏被整屏对话盖住
        （`on_main_screen` 全锚点 miss）。主城里左栏图标清晰可见 → 没对话 →
        中部那些"选项"其实是别人的头顶名牌（2026-10-31 三号同时中招）。
        """
        if ocr.contains_text(screen, "跳过", region=SKIP_REGION):
            return True
        return not self.on_main_screen(screen)

    def _dismiss_dialogue(self, max_clicks=8):
        """清理上次链中断遗留的剧情对话：对话选项必须点选（"跳过"跳不动选项），
        有"跳过"点跳过，无选项无跳过的对话点对话框本身推进，回到主界面就算清完。"""
        for _ in range(max_clicks):
            screen = self.device.screenshot()
            if self.on_main_screen(screen):
                return
            opt = self._find_dialog_option(screen, self._self_name())
            if opt:
                log.info("清理遗留对话选项 @ (%d, %d)", *opt)
                self.device.click(*opt)
                time.sleep(random.uniform(0.8, 1.2))
                continue
            hit = ocr.find_text(screen, "跳过", region=SKIP_REGION,
                                min_similarity=1.0)
            if hit:
                log.info("点击 [跳过] 退出遗留剧情 @ (%d, %d)", hit[0], hit[1])
                self.device.click(hit[0], hit[1])
                time.sleep(random.uniform(0.8, 1.2))
                continue
            if self._in_battle(screen):
                # 战斗中不点对话框（点屏幕会干扰手动战斗），交给主循环处理
                return
            # 无选项/无跳过的遗留对话：点对话框文字区推进（战斗中绝不点）
            log.info("遗留对话无选项/跳过，点击对话框推进")
            self.device.click(*DIALOG_ADVANCE_POS)
            time.sleep(random.uniform(0.8, 1.2))
