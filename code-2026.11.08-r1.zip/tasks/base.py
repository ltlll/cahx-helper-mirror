import logging
import random
import re
import time
from difflib import SequenceMatcher

from core import dialogs, ocr, pace
from core.logsetup import log_problem
from core.login_flow import MAIN_SCREEN_ANCHORS
from core.paths import DEBUG_DIR, UNKNOWN_DIR

log = logging.getLogger("task")

# 主界面"背包"按钮锚点区域（半透明图标，必须小区域限定匹配）
BEIBAO_REGION = (340, 520, 80, 100)

# 主界面 活动/玩法/商城 锚点的小区域（半透明图标，必须限定范围匹配）
MAIN_ANCHOR_REGIONS = {
    name: (max(0, cx - 37), max(0, cy - 32), 75, 64)
    for name, (cx, cy) in MAIN_SCREEN_ANCHORS.items()
}
HUODONG_REGION = MAIN_ANCHOR_REGIONS["活动"]  # "活动"入口锚点区域

# **宽松区域（2026-11-02 事故）**：左列图标不是永远在标称位置——出副本/战斗/
# 活动场景回来后整列会**上移约 14px**（实测 活动/玩法/商城 中心 y=175/220/355
# → 161/206/341；对比图：顶部多一行"节日时令司"活动横幅时图标整体下沉）。
# 窄区域 cy-32 上边只留 7px 余量，图标一上移模板就被裁掉 → 满屏"不在主界面，
# 按 ESC 返回"+ "未找到模板: 玩法" → 活跃/战令/六道/捉鬼收尾连环失败
# （11-02 早轮 4 个号 8 项失败，硬数据：窄区域三个锚点全 None，放宽后 0.9725
# 命中）。用法：**先窄区域（精度优先），全 miss 再用宽松区域复测**——不要
# 直接把窄区域改大，那会让相邻图标互相误中（活动/玩法中心只差 45px）。
MAIN_ANCHOR_REGIONS_LOOSE = {
    name: (max(0, cx - 45), max(0, cy - 46), 90, 92)
    for name, (cx, cy) in MAIN_SCREEN_ANCHORS.items()
}

# 各面板通用元素（405x720 客户区）
REWARD_POPUP_REGION = (60, 330, 285, 200)  # "点击空白处关闭"文字区域
BLANK_CLICK_POS = (200, 150)               # 奖励弹窗外侧的空白点（小弹窗：弹窗上方）
BLANK_CLICK_MARGIN = 170                   # 空白点相对提示文字的偏移量（见 reward_blank_pos）
PANEL_BACK_POS = (33, 683)                # 面板左下角通用返回箭头
GUILD_BACK_POS = (45, 688)                # 帮会/编队面板左下返回箭头（圆盘中心，
                                          # 2026-11-06 截图实测比通用点更居中）
# 帮会/编队面板的判别区（2026-11-06）：页签行「成员 编队 新闻」+ 帮会资金/队伍需求。
# ⚠️ 这块面板会**盖住左列图标但保留顶部 HUD**，`on_main_screen` 会误判成主界面
# （实测命中「商城」锚点 @ (33,331)）→ exit_panel_to_home 直接 return、面板根本没关，
# 紧接着的队伍人数识别就落在这块面板上（详见 tasks/zudui.py `_team_status_from`）。
GUILD_PANEL_REGION = (0, 170, 405, 125)
GUILD_PANEL_TABS = ("成员", "编队", "新闻")
GUILD_PANEL_MARKS = ("帮会资金", "队伍需求", "一键组队", "查看编队")


def reward_blank_pos(screen, margin=BLANK_CLICK_MARGIN, hit=None):
    """按"点击空白处关闭"提示的**实际位置**算出该点哪里；读不到提示返回 None。

    `hit` 可传入调用方已经算好的 `ocr.find_text(...)` 结果（判弹窗在不在时本来
    就要识别一次，别为算坐标再扫一遍 —— OCR ≈1 次/秒，重复识别是白花钱）。

    2026-10-27 修（海市蜃楼 run 3da16c）：大格奖励弹窗（7 格/副本结算）会把
    「恭喜获得」顶到 y≈174，固定 BLANK_CLICK_POS (200,150) **落在弹窗内部**，
    点等于没点；而提示文字本身在 y≈469，下方 y≈640 才是空白 —— dishu 硬编码
    (200,640)、huoyue 注释"顶部会盖住 base.BLANK_CLICK_POS"都是同一个坑。
    规则：提示在下半屏 → 点它下方；在上半屏 → 点它上方。读不到提示返回 None，
    由调用方退回固定点（不要瞎猜坐标）。
    """
    if hit is None:
        hit = ocr.find_text(screen, "点击空白处关闭", region=REWARD_POPUP_REGION)
        if hit is None:
            hit = ocr.find_text(screen, "点击空白处关闭")
    # 读不到坐标（None / 桩里被替成 True 之类的非坐标值）→ 不猜坐标，交调用方兜底
    if not isinstance(hit, (tuple, list)) or len(hit) < 2:
        return None
    cx, cy = hit[0], hit[1]
    y = cy + margin if cy >= 360 else cy - margin
    return (min(380, max(20, cx)), min(700, max(40, y)))

# 战斗画面判定（攻城夺宝等强制战斗会把在线玩家直接拉进战斗，ESC 无效）
BATTLE_MARK_REGION = (20, 615, 90, 50)    # 战斗画面左下角"战况"（主界面同位置是"协助"，不会误中）
BATTLE_AUTO_POS = (368, 683)              # 战斗右下角"自动"按钮
BATTLE_TOP_REGION = (120, 0, 180, 46)     # 战斗画面顶部"第X回合/阶段"（dishu 同款）

# 剧情对话（全场景扫描用）：右下角"跳过"（OCR 常读成"→跳过"）、无括号胶囊选项、
# "点击空白处继续"提示（同 login_flow/zongmen 的实测教训）
DIALOG_SKIP_REGION = (260, 590, 145, 80)   # 右下角"跳过"按钮
DIALOG_OPTION_REGION = (60, 290, 290, 180)  # 剧情选项区（胶囊按钮中心 150≤cx≤260）
DIALOG_CONTINUE_REGION = (40, 590, 325, 100)  # "点击空白处/任意处继续"提示
# 同一"选项"坐标连点这么多次仍无进展 → 判假选项，不再点它（改走跳过/点空白）。
# 真选项点一次就消失；同一坐标反复出现说明命中的是背景固定文字（玩家头顶名牌、
# 追踪面板条目）。2026-10-16：名牌 @(206,335) 一天被点 26 次。
DIALOG_OPT_REPEAT_ABORT = 3
# 判为假选项后拉黑该坐标多久（秒）。**不能只是把计数器清零**：清零后下一轮又
# 从 0 开始数，等于"同一坐标每 4 轮再点一次"的无限循环（2026-10-16 3 号滞留
# 家园期间 (206,335) 被点 20+ 次）。带 TTL 是为了不永久误伤"真选项恰好也落在
# 同一坐标"的情况——真选项间距稳定，180s 足够让剧情推进到下一屏了。
DIALOG_OPT_BAN_TTL = 180

# 帮会相关（帮会任务共用）
BANGHUI_REGION = (0, 515, 90, 85)          # 主界面左下角"帮会"图标锚点
GUILD_BTN_REGION = (220, 585, 180, 70)     # 帮会面板底部"职位/回帮"按钮区（都没有=未加入帮会）
GUILD_JOIN_REGION = (60, 100, 285, 480)    # 帮会面板正文区（未入帮时显示"加入帮会"列表）
GUILD_TAB_REGION = (320, 660, 85, 60)      # 帮会面板底部"活动"页签
GUILD_TAB_POS = (364, 686)
GUILD_MAP_REGION = (20, 140, 150, 50)      # 帮会活动页左侧"战利品："文字，判定已进入活动页
                                           # （"累计获得"在 RapidOCR 里检测不稳定，勿用）

# 玩法面板（玩法类任务共用）
WANFA_REGION = (0, 188, 75, 64)            # 主界面左侧"玩法"图标锚点
# 同上（宽松版）：图标上移 14px 时窄区域会裁掉模板（2026-11-02 实测窄区域
# 全 miss / 宽松区域 0.9725 命中）。先窄后宽，见 MAIN_ANCHOR_REGIONS_LOOSE。
WANFA_REGION_LOOSE = (0, 168, 90, 84)
# OCR 小裁剪容易因贴边漏检，判定文字的区域要留足边距（实测教训）
WANFA_MARK_REGION = (0, 0, 405, 60)        # 玩法面板顶部"今日经验"，判定面板已打开

# 主界面右下角待使用道具卡（历妖嘉奖等，会遮挡右侧信息）
ITEM_CARD_USE_REGION = (270, 490, 125, 60)  # 卡的"使用"按钮
ITEM_CARD_TITLE_REGION = (270, 380, 125, 60)  # 卡的标题区（海市赐福令等特殊卡识别用）
ITEM_CARD_X_POS = (375, 405)                # 卡的右上角 X

# 场景保证（所有任务都要求主界面在云梦长安背景）
MAP_LABEL_REGION = (0, 0, 120, 50)          # 左上角小地图的场景名
MAP_ICON_POS = (45, 55)                     # 左上角小地图（点开场景选择面板）
WORLD_BTN_REGION = (130, 555, 160, 80)      # 场景选择面板底部"世界"按钮（面板高度随 NPC 数量变，按钮位置会漂，边距留足）
WORLD_MAP_REGION = (30, 0, 140, 50)         # 世界地图标题
YUNMENG_SEARCH_REGION = (0, 60, 405, 560)   # 世界地图上找"云梦长安"标签的范围
SPECIAL_LEAVE_REGION = (280, 250, 125, 160)  # 特殊场景（副本/活动场景）右缘"离开"按钮（海市 (368,320)/六道 (380,340)/狮王守卫 (380,339)）
YIREDO_RETURN_POS = (33, 683)               # 堕神遗都唯一出口：左下角「返回」按钮（右缘无「离开」；用户 2026-10-18 指认）
# ⚠️ 宽度必须 ≥ 约 105px：PP-OCR 的检测模型在**窄裁剪**上会整体失效（不是识别
# 错，是**一条文本都检不出**）。2026-10-16 实测同一张「狮王守卫」截图：
#   裁剪 (330,260,75,140)  -> scan() 返回 0 条
#   裁剪 (300,250,105,160) -> 命中 离开@(380,338,0.911)
#   裁剪 (280,250,125,160) -> 命中 离开@(380,339,0.993)
# 旧的 75px 宽区域 = ensure_yunmeng/settle_scene 在这类场景里**永远读不到「离开」**
# → 只能靠下面 SPECIAL_LEAVE_POS 兜底，而那条兜底又被 on_main_screen() 掐掉
# （见 _on_city_hud 注释）→ 账号被困副本、任务全灭。
SPECIAL_LEAVE_POS = (375, 320)              # "离开"小图标 OCR 不稳定时的固定兜底位置
LEAVE_CONFIRM_REGION = (230, 400, 130, 90)  # 离开副本的确认框"确定"（"是否要结束本次探索…[取消|确定]"，实测按钮中心 y=446，边距要留足）
# 家园场景（顶部 HUD「XX的家园/总美观度」）：ESC 关不掉，
# 也不在 SPECIAL_LEAVE_REGION（y 260~400）里——家园的「离开」图标在 (383,510)、
# 文字中心 (382,530) 点了无效，必须点图标中心（详见 home_base.LEAVE_POS；
# base 不能 import home_base 会循环依赖，这里复制坐标并保持同步）。
# （2026-10-11 账号4/6 滞留家园、后续任务全部空转的事故）
#
# ⚠️ 家园判定**不能**再要求"左上角地图名读不到"（旧写法，2026-10-16 已删）：
# 家园里地图名同样是「云梦长安」——3 号滞留家园时 Home 帧 OCR 稳定命中
# 「云梦长安」@(50,14) sc=0.99，而顶部 HUD 又被金色家园横幅 + 「六道赐福令」
# 道具卡挡得**时读时不读**。旧前置 = 把家园整个排除 → 家园里 ESC 无效、
# 右缘「离开」也走不到 → 兜底阶梯空转满 300s 才 report_unknown（3 号
# 23:30:23→23:35:14 实测 291s 白烧，期间还把人群名牌当选项点了 20+ 次）。
# 主城顶部没有「家园/美观度」字样，去掉前置不会把主城误判成家园。
HOME_HUD_REGION = (0, 0, 405, 60)           # 家园顶部 HUD：「XX的家园」「总美观度」
HOME_LEAVE_POS = (383, 510)                 # 家园右缘「离开」图标中心
HOME_LEAVE_REGION = (350, 420, 55, 180)     # OCR 定位「离开」文字的右缘扫描区（x 350~405, y 420~600）


def is_home_screen(screen):
    """顶部 HUD 出现「XX的家园 / 总美观度」即判为家园（不看地图名，理由见上）。"""
    return any("家园" in t or "美观度" in t
               for t, *_ in ocr.scan(screen, region=HOME_HUD_REGION))

# 队伍面板（退出队伍/5开组队共用）
# 页签固定槽位（实机截图量得）：任务≈(310,92)、队伍≈(366,92)——OCR 漏读时的
# 兜底点击坐标。注意两者是"任务在左、队伍在右"，别点反（368,92 是队伍页签，
# 在队伍视图点它会收起面板，2026-10-11 实测教训）。
TEAM_TAB_REGION = (330, 75, 75, 40)         # 主界面右上"队伍"页签（旁边是"任务"，也是收起/展开开关）
TEAM_TAB_POS = (368, 92)                    # "队伍"页签固定槽位（OCR 漏读时兜底点击）
QUEST_TAB_REGION = (270, 75, 90, 40)        # 主界面右上"任务"页签
QUEST_TAB_POS = (310, 92)                   # "任务"页签固定槽位（OCR 漏读兜底）
MEMBER_LIST_REGION = (275, 105, 130, 190)   # 队伍页签下的队员名字列表区（单人时显示"创建队伍/前往组队"）
# 队员**名单行**区：只覆盖 4~5 行队员名，比 MEMBER_LIST_REGION 矮。
# 2026-10-16 实测（debug/1792162049_zudui_fail.png）：190px 高的整块会把面板
# 下方的背景场景文字（「六道法门」等）一起框进来，同一支队伍每帧识别出的人数
# 在 1~6 之间乱跳 → 组队判负（zudui 904s 失败，连带 3 个组队任务全灭）。
# 按钮类查询（创建队伍/前往组队）仍用 MEMBER_LIST_REGION，只有"数成员/认名字"
# 用这个窄区域。
TEAM_MEMBER_ROWS_REGION = (275, 105, 130, 125)
TEAM_PANEL_MARK_REGION = (220, 160, 110, 45)  # 队伍面板的"招募"按钮（判定队伍面板已打开）
LEAVE_TEAM_BTN_REGION = (60, 600, 130, 55)  # 队伍面板左下角"离队"按钮


class TaskStopped(Exception):
    """用户在 GUI 点了停止：立即中止（不是失败，不重试、不计入异常）。"""


# 单项任务硬超时（秒）：超过则中止该任务 → 先回主界面 → 再继续下一项；0 = 不限时。
# 值取自任务条目 `timeout`（config.yaml 顶层 `task_timeout` 作为各任务的默认值）。
# 家园类任务场景多变、容易卡住（用户规则：喂猫/种菜 10 分钟 = 600 秒未完成即放弃）。
DEFAULT_TASK_TIMEOUT = 0


def _ai_call_limit(task_name=""):
    """每个任务实例最多允许调用几次 AI 兜底（config.yaml 的 ai.max_calls_per_task）。

    个别任务可在 ai.max_calls_overrides 里单独放宽/收紧（键=任务名）。
    2026-10-23：zongmen 连续多天触顶后仍靠任务级重试才成功，单独放宽到 4。
    """
    try:
        from core import aihelper
        cfg = aihelper.config()
        base = max(0, int(cfg.get("max_calls_per_task") or 3))
        if not task_name:
            return base
        overrides = cfg.get("max_calls_overrides")
        if isinstance(overrides, dict) and task_name in overrides:
            try:
                return max(0, int(overrides.get(task_name)))
            except (TypeError, ValueError):
                return base
        return base
    except Exception:
        return 3


class TaskTimeout(Exception):
    """单项任务超过硬超时上限仍未完成：中止本任务（不再重试），
    先回主界面，再由调度器继续下一项。会留存截图与「问题」日志说明为什么没完成。"""


# AI 兜底禁止进入的「死胡同面板」（2026-11-02）：这些面板进去只能加速/收取，
# 没有回主界面的出口，任务会一直卡在里面直到超时。
#   妖灵渡口 = 收益页签下的宠物/妖灵送货面板（huoyue/zhanling 卡住时模型会点
#   任务追踪里的「妖灵渡口」@(328,160)，11-02 早轮 3/4/6 号全被它拖死；
#   用户看到的就是"捉鬼期间客户端莫名其妙点进宠物界面"）；
#   九霄塔布阵页 = zongmen 自己都要专门退出（见 tasks/zongmen.py 的
#   DEADEND_TITLE_REGION）。
AI_DEADEND_WORDS = ("妖灵渡口", "妖灵", "九霄塔")
AI_DEADEND_TITLE_REGION = (0, 0, 260, 75)   # 与 zongmen.DEADEND_TITLE_REGION 同源
# 这几个任务本身就以妖灵/宠物面板为目标，不拦（shouyi 的订单流程全在妖灵渡口）
AI_DEADEND_ALLOW_TASKS = {"shouyi"}


# 每日一次型任务（core/dailydone.py 记录，每天 5:00 刷新）：今天做过就跳过
DAILY_ONCE_TASKS = {"eat_cooking", "eat_pet_food", "weimao"}


# 多阶段任务组：同一个玩法拆成几个阶段、在 GUI 上合并成**一个条目**展示
# （任务页画一张只读阶段卡，向导清单里不再单独出现）。任务类只需标
# `stage_group`（组 id）+ `stage_index`（阶段序号，从 1 起）+ `stage_desc`；
# 组的显示名 / 徽章 / 提示 / 一句话说明在这里唯一定义，避免各处重复。
#
# `available=False` 的任务 = 流程还没定稿：GUI 置灰不可勾选，调度器
# （core/scheduler.py）与账号线程（gui.py::_account_worker）都会跳过它，
# 防止半成品流程误跑动到真账号的资产。
STAGE_GROUPS = {
    "lingshu": {
        "title": "灵珠收集",
        "badge": "待完善",
        "note": "暂不可选",
        "desc": "各号把背包里的灵珠先集中到一个收集号，再逐个号提交给系统；"
                "数量不足时的收尾规则待补充",
    },
}


class AccountKicked(Exception):
    """账号被顶号（游戏弹"被迫下线"提示）：不是任务失败，不重试；
    调度层捕获后跳过该账号剩余任务，并从组队协调器减员。"""


class TaskSkipped(Exception):
    """任务被主动跳过且**应计入失败**（如组队副本在组队失败后未执行）。

    与 return True（当成功）的区别：调度层/账号线程捕获后把它记入失败清单、
    小结如实反映"没跑成"；与 return False（触发重试）的区别：跳过是定局，
    重试也没有意义，直接继续下一个任务。
    """


class Task:
    """任务基类。子类设置 name 并实现 run()。

    编写原则：每一步都基于当前截图判断状态，不要假设上一步一定成功；
    关键操作要有超时与兜底（找不到就 back_to_home 重来）。
    """

    name = "base"
    title = "基础任务"
    category = "日常任务"   # 任务分类（GUI 分组显示用）：备战任务 / 日常任务 / 帮会任务 / 日常副本 / 收尾任务
    max_retries = 2
    # 跟随任务：本任务执行完后强制执行的任务名序列（调度器/GUI 执行前展开进
    # 任务序列，如 huoyue 领完奖励固定接 tidy_bag 防背包爆满）。空 = 无跟随。
    FOLLOWUPS = ()
    # 多阶段任务：同一个玩法的不同阶段（如「灵珠收集」= 提交灵珠 + 接收灵珠）。
    # stage_group 相同的任务在 GUI 任务页合并成一张只读阶段卡、不生成可勾选
    # 芯片（见 base.STAGE_GROUPS）；空 = 普通单阶段任务。
    stage_group = ""
    stage_index = 0    # 组内阶段顺序（从 1 起），GUI 步骤条按它排序
    stage_desc = ""    # 本阶段一句话说明（阶段胶囊的 tooltip）
    # False = 流程未定稿：GUI 置灰、不可勾选；调度器与账号线程一律跳过
    # （即使 config.yaml 被手工改成 enabled: true）。定稿后改回 True 即恢复可选。
    available = True

    def __init__(self, device, matcher, config, account=None):
        self.device = device
        self.matcher = matcher
        self.config = config
        # 当前窗口配对的账号记录（含 role 职业分类 / is_captain 队长），
        # 无配对（如命令行 main.py 未配库）时为 {}
        self.account = account or {}
        # threading.Event，由 GUI 注入；set 后任务在下一次尝试边界中止
        self.stop_event = None
        # 单项任务硬超时相关（见 _begin_timeout / _check_stop / _handle_timeout）
        self._timeout = 0          # 本任务超时上限（秒），0 = 不限
        self._deadline = None      # 超时时刻（time.time() 基准），None = 不限
        self._task_started = 0.0   # 本任务开始时刻
        self._attempt = 0          # 当前第几次尝试（日志用）
        self._stage = ""           # 当前阶段（子类在各步骤设置，超时日志用来说明卡在哪）
        # AI 兜底（core/aihelper）：本任务最多调用几次模型，见 ai_recover
        self._ai_calls = 0
        self._ai_max_calls = _ai_call_limit(getattr(self, "name", ""))
        # 场景失联标记（2026-11-08 7 号事故）：settle_scene 判负时置 True，
        # 供 core/clientwatch.py 的「连续 N 任务死于未识别场景 → 换新客户端」
        # 判据使用。这类故障画面完全无法识别（如全屏聊天面板盖住 HUD），
        # 输入存活探针在非主界面必然放行，必须走独立判据
        self._scene_lost = False

    @property
    def role(self):
        """职业分类：封印 / 奶妈 / 输出。"""
        return self.account.get("role", "")

    @property
    def is_captain(self):
        return bool(self.account.get("is_captain"))

    def _check_stop(self):
        """任务内的统一"打断点"：GUI 停止 → TaskStopped；单项任务硬超时 → TaskTimeout。

        任务里所有长等待循环都调用它，这样「用户停止」与「任务超时」才能及时生效。
        """
        if self.stop_event is not None and self.stop_event.is_set():
            raise TaskStopped()
        if self._deadline is not None and time.time() > self._deadline:
            raise TaskTimeout(self._timeout_reason())

    def _timeout_reason(self):
        """超时原因的一行说明（含任务名/已用时/上限/第几次尝试/最后阶段）。"""
        return ("任务 %s 运行 %.0f 秒超过上限 %.0f 秒仍未完成"
                "（第 %d 次尝试，最后阶段：%s）"
                % (self.name, time.time() - self._task_started, self._timeout,
                   self._attempt, self._stage or "未知"))

    def _begin_timeout(self):
        """读取本任务的超时上限（条目 `timeout`，缺省 DEFAULT_TASK_TIMEOUT）并起算。"""
        try:
            timeout = float(self.config.get("timeout") or DEFAULT_TASK_TIMEOUT)
        except (TypeError, ValueError):
            timeout = float(DEFAULT_TASK_TIMEOUT)
        self._timeout = max(0.0, timeout)
        self._task_started = time.time()
        self._deadline = ((self._task_started + self._timeout)
                          if self._timeout > 0 else None)
        if self._deadline is not None:
            log.info("本任务设硬超时 %.0f 秒（未完成即中止本任务→回主界面→继续下一项）",
                     self._timeout)

    def _handle_timeout(self):
        """任务硬超时中止的收尾：留存截图 + 打「问题」日志（说明为什么没完成）+ 回主界面。

        ⚠️ 先把 _deadline 清掉，否则回主界面的循环会再次立刻抛 TaskTimeout。
        """
        reason = self._timeout_reason()
        self._deadline = None
        log.warning("%s —— 已中止本任务，准备回主界面继续下一项", reason)
        self.report_unknown("timeout", note=reason + "；见截图（卡在该画面）")
        try:
            if not self.ensure_main_screen():
                self.back_to_home()
            # 超时画面常带着各种弹窗/对话，同样要清干净再交下一项
            self.settle_home(do_exit=False)
        except TaskStopped:
            raise
        except Exception:
            log.exception("超时中止后回主界面失败（不影响调度器继续下一项）")

    def _daily_key(self):
        """每日一次任务的账号标识：优先账号 id，其次角色名，最后窗口句柄
        （main.py 命令行无账号库时用 hwnd 区分同机多号）。"""
        return (self.account.get("id") or self.account.get("character")
                or f"hwnd:{self.device.hwnd}")

    def run(self):
        """模板方法：每次尝试前先确保在主界面（不在则 ESC 退回），
        成功后统一退回主界面。子类只需实现 _try_once()（返回 True/False）。

        DAILY_ONCE_TASKS 里的任务（吃烹饪等）每天 5 点刷新前只做一遍：
        已完成记录命中直接跳过，成功后才记录（失败不记录，下次还会跑）。

        组队副本的**队员端**例外（_is_following_member）：只等协调器信号，
        不做任何场景操作（不回主界面、不导航、不离开副本）——用户规则
        "队员不切场景，队长点离开后全队自动跟随"。
        """
        from core import dailydone
        if self.name in DAILY_ONCE_TASKS:
            if dailydone.is_done(self._daily_key(), self.name):
                log.info("%s 今天已做过（每日 5 点刷新），跳过", self.name)
                return
        self._begin_timeout()
        try:
            self._run_attempts()
        except TaskTimeout:
            # 单项任务硬超时（见 _begin_timeout）：中止本任务（不重试）、先回主界面，
            # 再由调度器继续下一项；已留存截图与「问题」日志说明为什么没完成。
            self._handle_timeout()
            raise

    def _run_attempts(self):
        """实际的重试循环（run() 的超时包裹之内）。"""
        from core import dailydone               # run() 里 is_done 已 import；这里 mark_done 还要用
        if self._is_following_member() and self._deadline is not None:
            # 队员端只等队长信号（耗时由全队进度决定），不适用单项任务超时
            self._deadline = None
            log.info("队员端等待队长信号，本次不做任务超时限制")
        for attempt in range(1, self.max_retries + 1):
            self._attempt = attempt
            self._stage = ""
            self._check_stop()
            log.info("第 %d 次尝试", attempt)
            # `follow` 必须每次尝试重算：队长端第 1 次失败后可能被自动改选降级为
            # 队员（见 captain_fail_finish 的 _failed_over_wait），此时不能再跑
            # 开场复位——opening_reset 会 leave_team 把队伍拆散。
            follow = self._is_following_member() or getattr(
                self, "_failed_over_wait", False)
            if follow and self._deadline is not None:
                self._deadline = None
                log.info("改选后转队员端等待，本次不做任务超时限制")
            # 省电模式（客户端休眠）会让后续所有模板/OCR 失灵（截图读的是
            # 变暗画面），每次尝试前先滑动解锁（实测挂机后常见）
            from core import dialogs
            dialogs.handle_sleep_mode(self.device, self.device.screenshot())
            if follow:
                # 队员端：不导航、不退出场景，只清理道具卡后等队长信号
                log.info("队员端：只等队长信号，不做场景导航/离场操作")
                self.dismiss_item_cards()
            else:
                # **先退队、再切场景**：队员状态下点地图切场景不生效，
                # 登录后还挂着上一轮的队伍时会一直卡在"去云梦长安"（用户反馈）。
                self.opening_reset()
                self.ensure_yunmeng()
                self.dismiss_item_cards()
            if self._try_once():
                if not follow:
                    # 任务收尾 = 回主界面 + 清扫残留弹窗（用户规则 2026-10-13：
                    # 每个任务结束时必须维持"长安无弹窗"，否则挡住下一个任务）
                    self.settle_home()
                if self.name in DAILY_ONCE_TASKS:
                    dailydone.mark_done(self._daily_key(), self.name)
                return
            log.warning("%s 第 %d/%d 次尝试失败%s", self.name, attempt, self.max_retries,
                        "" if follow else "，回主界面重试")
            self._check_stop()
            if not follow:
                self.back_to_home()
        self.save_debug_screenshot(f"{self.name}_fail")
        # 多次尝试仍失败：给 AI 最后一次机会（用户规则 2026-10-12：除了
        # report_unknown 的"未知画面"，任务反复失败时也要让 AI 看一眼卡在哪）
        if not follow:
            self.ai_recover("retry_fail", note=f"{self.max_retries} 次尝试全部失败")
        log.error("%s 多次尝试失败（已保存 %s_fail.png 调试截图）", self.name, self.name)
        raise RuntimeError(f"{self.name} 多次尝试失败")

    def opening_reset(self):
        """开场复位：**全场景扫描** → 回主界面 → **退出残留队伍**。登录后、
        跑本轮第一个任务前调用一次。

        顺序很关键（用户规则 2026-10-12）：登录后角色可能在战斗/家园/副本/
        剧情对话/残留队伍里，必须**先判断当前场景**（settle_scene：战斗等打完
        ——不计超时、家园/副本点「离开」、对话跳过/点空白），再退队，再回长安。
        队员状态下点地图切场景不生效（2026-10-11 用户反馈：登录后若还挂着
        上一轮的队伍，第一个任务会一直卡在"去云梦长安"）。这里只处理"上一轮
        残留的队伍"：本轮的队伍由 zudui（5开组队）在任务序列里重建，那时
        **两种组队方式都会先让全员离队再组队**（用户规则 2026-10-11：只要执行
        组队操作，一律先离队，由队长从零组队；auto 一键组队与 manual 手动组队
        共用同一前置，队员端 _leave_and_report / 队长端 _ensure_clean_team）。

        例外：
        - 队员端（_is_following_member）不做任何场景操作（用户规则）；
        - 日常副本类任务保留当前队伍（离队由组队流程统一处理：全员离队是
          zudui 的硬前置）。
        """
        if self._is_following_member():
            log.info("开场复位：队员端跳过（等信号前不做场景操作/不退队）")
            return
        self.settle_scene(tag="开场复位")
        if self.category == "日常副本":
            log.info("开场复位：本项是组队副本，保留当前队伍（组队流程自行离队）")
            return
        self.leave_team()
        # 离队流程会点"队伍"页签展开组队面板；偶发切不回任务视图时面板挡住
        # 主界面（实测 2026-10-10 账号4：no_plus_icon 失败），补一次主界面兜底
        self.ensure_main_screen()

    def _is_following_member(self):
        """组队副本里跟随队长的队员端（非队长、且属日常副本类）。

        队员端只等协调器信号（点准备/自动/关结算），绝不自行做场景操作。
        2026-10-10 事故：队员在副本里被执行前导的 ensure_yunmeng 拉去开
        世界地图（副本场景没有"云梦长安"地图名），传送失败后世界地图一直
        开着 → 看不到准备面板、点不动任何东西 → 整队空等（日志可见多次
        "未出现准备面板（可能超时），按已准备处理"）。队长负责带队寻路
        与离开副本（队长点"离开"后全队自动跟随）。
        """
        return self.category == "日常副本" and not self.is_captain

    def _try_once(self):
        raise NotImplementedError

    def ensure_main_screen(self, max_esc=8):
        """任务开始时若不在主界面（面板/阵容页等），连按 ESC 退回主界面。

        "点击空白处关闭"类奖励弹窗不吃 ESC，遇到时先点空白关掉。
        战斗画面（攻城夺宝等强制拉入的战斗）ESC 无效：点"自动"加速并等
        战斗结束（最多 3 分钟），不占 ESC 次数。
        """
        esc = 0
        battle_since = None
        from core import dialogs
        while esc < max_esc:
            self._check_stop()   # 长循环里响应"用户停止/任务超时"
            screen = self.device.screenshot()
            if self.on_main_screen(screen):
                return True
            # 休眠画面（省电模式）on_main_screen 必失败，会空转 ESC：先滑动解锁
            if dialogs.handle_sleep_mode(self.device, screen):
                continue
            hit = ocr.find_text(screen, "点击空白处关闭", region=REWARD_POPUP_REGION)
            if hit:
                log.info("关闭奖励弹窗")
                self.device.click(*(reward_blank_pos(screen, hit=hit)
                                    or BLANK_CLICK_POS))
                pace.wait(0.8, 1.2)
                continue
            if ocr.contains_text(screen, "战况", region=BATTLE_MARK_REGION):
                self._check_stop()  # 战斗等待可能较长：响应 GUI 停止
                if battle_since is None:
                    battle_since = time.time()
                    log.info("检测到战斗画面（ESC 无效），点 [自动] 并等待战斗结束")
                    self.device.click(*BATTLE_AUTO_POS)
                elif time.time() - battle_since > 180:
                    log.warning("战斗超过 3 分钟未结束")
                    return False
                pace.wait(3)
                continue
            battle_since = None
            log.info("不在主界面，按 ESC 返回")
            self.device.press_esc()
            esc += 1
            pace.wait(0.8, 1.2)
        log.warning("按 ESC 多次仍不在主界面")
        return False

    @staticmethod
    def _in_battle_any(screen):
        """战斗画面判定（双标记）：左下角"战况" 或 顶部"第X回合/阶段"。
        战斗中左侧主界面锚点全被遮，ESC 无效，只能等打完。"""
        if ocr.contains_text(screen, "战况", region=BATTLE_MARK_REGION):
            return True
        return any(re.search(r"回合|阶段", t)
                   for t in ocr.dump_texts(screen, BATTLE_TOP_REGION))

    # ---- 活动面板进度（"捉鬼那套"正向证据的通用版，2026-10-23 新增） ----
    # 用户说明：玩法面板可直接识别进度的玩法有 捉鬼/寻宝/海市/竞技/六道
    # （n/m 计数），向右滑动一屏还能看到跑商（完成后显示"已完成"）。
    # 关键词 → 任务名归一（OCR 会把"馗"读别字，跑商可能读成"跑离"等）。
    ACTIVITY_PROGRESS_KEYWORDS = {
        "zhongkui": r"捉鬼|钟.捉",
        "xunbao": r"寻宝",
        # "海市楼必做" 竖排常被读成"市厨楼必做"（海→市、市→厨），单字容错
        "haishi": r"海市|市楼|市厨",
        "jingji": r"竞技",
        "liudao": r"六道",
        "paoshang": r"跑[商离高]",
    }
    # ⚠️ 进度在**玩法面板**（左列「玩法」，顶部"今日经验"），不在活动面板
    # （福赠/战令/活动/珍阁 那套是运营活动，里面没有这些进度）。2026-10-23
    # 实机确认：活动面板的「活动」页是神兽/结缘推广页，全无 n/m 进度。
    #
    # 玩法面板是横向滚动的地图：一屏约 2 列灯笼卡，跑商在第二屏。
    # 每张卡=一盏灯笼，**标题竖排在灯笼右侧、状态居中在灯笼下方**，
    # 所以状态相对标题固定偏左下（dx≈-45、dy≈+50，405x720 实测）。
    WANFA_STAT_DY = (18, 82)         # 状态框相对标题框的纵向范围
    WANFA_STAT_DX = (-95, 30)        # 横向范围（标题在右、状态在左）
    # 整屏一次 OCR 会漏小字"已完成"（钟馗捉鬼那条整屏扫不到，分带扫 0.99 命中），
    # 所以分 3 条横带扫。带间留 25px 重叠，防止卡片刚好跨带被切断。
    WANFA_PROGRESS_BANDS = ((0, 60, 405, 210), (0, 245, 405, 210), (0, 430, 405, 200))
    WANFA_SWIPE_Y = 400              # 横向滚动的地图区（避开顶部状态条与底部导航）

    @classmethod
    def _wanfa_texts(cls, screen):
        """读玩法面板所有文字（分带 OCR → 去重 → 竖排标题拼接）。"""
        raw = []
        for band in cls.WANFA_PROGRESS_BANDS:
            raw.extend((t.replace(" ", ""), cx, cy)
                       for t, cx, cy, _ in ocr.scan(screen, region=band,
                                                    min_score=0.5))
        return cls._merge_vertical_texts(cls._dedup_texts(raw))

    @staticmethod
    def _dedup_texts(texts):
        """去掉横带重叠造成的重复框：同一位置、文本相同或互为子串只留最长的那条。

        三条带之间有 25px 重叠，跨带的卡片会被相邻两条带各读一次
        （"钟道捉鬼" + "钟道捉鬼鬼"、"已完成"×2），不去重会让拼接逻辑
        把同一个标题粘成"鬼鬼"这种噪声。
        """
        kept = []
        for t, cx, cy in sorted(texts, key=lambda v: -len(v[0])):
            if any(abs(kx - cx) <= 16 and abs(ky - cy) <= 20
                   and (t in kt or kt in t) for kt, kx, ky in kept):
                continue
            kept.append((t, cx, cy))
        return kept

    @staticmethod
    def _merge_vertical_texts(texts):
        """把被 OCR 拆开的竖排标题按同一列纵向拼接（"帮"+"会跑商"→"帮会跑商"）。

        竖排标题字号大、字数多时 RapidOCR 会切成立柱两段；不拼的话
        "帮会跑商" 只剩 "会跑商"（关键词仍命中）或只剩 "帮"（命中不了）。
        只拼**同列、纵向相邻、都是短文本、且不含状态词**的框——状态文本
        在标题左下，横向就错开了，不会被粘进来。
        """
        if not texts:
            return texts
        merged = []
        for t, cx, cy in sorted(texts, key=lambda v: (v[1], v[2])):
            if merged:
                pt, pcx, pcy = merged[-1]
                gap = cy - pcy
                status_like = re.compile(r"^[已完成次数不限\d/:：.\s]+$")
                if (abs(pcx - cx) <= 14 and 12 <= gap <= 32
                        and len(t) <= 6 and len(pt) <= 6
                        and not (status_like.match(t) and status_like.match(pt))):
                    merged[-1] = (pt + t, (pcx + cx) // 2, (pcy + cy) // 2)
                    continue
            merged.append((t, cx, cy))
        return merged

    @classmethod
    def _scan_activity_progress(cls, screen, texts=None):
        """单帧读玩法面板的今日进度：{任务名: (done,total)|"done"}。

        texts 可传入已算好的 `_wanfa_texts()` 结果（翻页时复用，省一次 OCR）。
        状态框可以是"已完成"、"0/4"、"次数：0/2"；按"标题左下"的固定偏移
        就近配对（距离加权取最近的，避免左右两张卡的状态串台）。
        读不到的键不出现在结果里（缺键=未知，调用方不得当作完成）。
        """
        if texts is None:
            texts = cls._wanfa_texts(screen)
        stats = []
        for t, cx, cy in texts:
            if t.startswith("已完成"):
                stats.append((True, None, cx, cy))
                continue
            m = re.search(r"(\d+)\s*/\s*(\d+)", t)
            if m and len(t) <= 12:
                stats.append((False, (int(m.group(1)), int(m.group(2))), cx, cy))
        out = {}
        dy_lo, dy_hi = cls.WANFA_STAT_DY
        dx_lo, dx_hi = cls.WANFA_STAT_DX
        for key, pat in cls.ACTIVITY_PROGRESS_KEYWORDS.items():
            best = None
            for t, cx, cy in texts:
                if not re.search(pat, t) or len(t) > 24:
                    continue
                m = re.search(r"(\d+)\s*/\s*(\d+)", t)   # 计数与标题粘在一起
                if m:
                    best = (0, (True, (int(m.group(1)), int(m.group(2)))))
                    break
                for is_done, val, sx, sy in stats:
                    dy, dx = sy - cy, sx - cx
                    if not (dy_lo <= dy <= dy_hi and dx_lo <= dx <= dx_hi):
                        continue
                    dist = abs(dy - 50) + abs(dx + 45)
                    if best is None or dist < best[0]:
                        best = (dist, (is_done, val))
            if best:
                is_done, val = best[1]
                out[key] = "done" if is_done else val
        return out

    def read_activity_progress(self, names, max_swipes=3):
        """读玩法面板里指定玩法的今日进度，返回 {任务名: (done,total)|"done"}。

        判"是否完成"的正向证据（同捉鬼 _read_day_progress 的铁律）：
        **读不到的键=进度未知，调用方绝不能当成已完成**。"已完成"记作 "done"。
        玩法面板是横向滚动的地图，跑商在右滑一屏之后；内容不再变化=已到底，
        提前收手。读完按返回箭头回主界面（失败也保证退面板）。
        """
        result = {}
        want = [n for n in names if n in self.ACTIVITY_PROGRESS_KEYWORDS]
        if not want:
            return result
        if not self.open_wanfa():
            log.warning("玩法面板打不开，进度读取失败（%s）", "、".join(want))
            return result

        def scan_once():
            """取一帧 → 解析 → 并入 result，返回该帧文字指纹（用于判"到底了"）。"""
            screen = self.device.screenshot()
            texts = self._wanfa_texts(screen)
            found = self._scan_activity_progress(screen, texts=texts)
            for key in list(want):
                if key in found:
                    result[key] = found[key]
                    want.remove(key)
            return frozenset(t for t, *_ in texts)

        def swipe(forward):
            """forward=True 右滑（内容左移，看下一屏）；False 往左滑回上一屏。"""
            x1, x2 = (0.82, 0.20) if forward else (0.20, 0.82)
            self.device.drag(self._ai_px(x1, 405), self.WANFA_SWIPE_Y,
                             self._ai_px(x2, 405), self.WANFA_SWIPE_Y)
            pace.wait(1.0, 1.4)

        try:
            prev_sig = scan_once()
            moved = False
            for i in range(max_swipes):
                self._check_stop()   # 长流程：响应 GUI 停止
                if not want:
                    break
                log.info("玩法面板右滑找剩余进度（第 %d/%d 次，缺：%s）",
                         i + 1, max_swipes, "、".join(want))
                swipe(True)
                sig = scan_once()
                if sig == prev_sig:
                    log.info("玩法面板滑到底（内容未再变化），停止翻页")
                    break
                moved = True
                prev_sig = sig
            if want and not moved:
                # 一开面板就在最右屏（面板会记住上次滚动位置）——往左滑回去补读，
                # 否则第一屏的玩法永远读不到（缺键=未知，会让任务白等）。
                log.info("面板初始不在最左屏，往左滑回补读（缺：%s）", "、".join(want))
                for i in range(max_swipes + 1):
                    self._check_stop()
                    if not want:
                        break
                    swipe(False)
                    sig = scan_once()
                    if sig == prev_sig:
                        break
                    prev_sig = sig
        finally:
            self.exit_panel_to_home()
        log.info("玩法进度：%s",
                 "、".join("%s=%s" % (k, v if isinstance(v, str)
                                      else "%d/%d" % v)
                          for k, v in result.items()) or "（一个都没读到）")
        return result

    def _skip_story_dialog(self, screen):
        """画面右下角有「跳过」就点掉，返回 True=点过。

        剧情/过场对话出现时主界面全被遮住，右缘「离开」、小地图、任务入口
        全都点不到，唯一出路就是「跳过」。OCR 常把按钮读成「>跳过」
        （2026-10-25 实测 0.86 分），所以相似度门槛放到 0.6。
        """
        hit = ocr.find_text(screen, "跳过", region=DIALOG_SKIP_REGION,
                            min_similarity=0.6)
        if not hit:
            return False
        log.info("剧情对话：点击 [跳过] @ (%d, %d)", hit[0], hit[1])
        self.device.click(hit[0], hit[1])
        return True

    def _handle_dialog(self, screen):
        """剧情对话处理：右下角"跳过" → 无括号胶囊选项（点最上面一个）→
        "点击空白处/任意处继续"提示点空白。有动作返回 True。

        只在 ESC 失效后的兜底阶梯里调用（调用方控制），避免正常面板上
        选项区误命中（面板居中文字可能落在选项坐标过滤内）。

        **必须排除玩家头顶名牌**（2026-10-16 实测，与宗门任务同源）：
        主界面「称号+角色名」浮字会被读成一条文本，位置 cx≈206/cy≈335~374，
        与真选项同列同高。今天这条兜底触发了 46 次，其中 **26 次是同一个坐标
        (206,335)**——点它毫无反应，每次白烧一帧 OCR + 一次点击，把
        settle_scene 的兜底阶梯拖满。名牌必含**本账号角色名**，用
        `ocr.name_tag_like` 排除。

        另外加"同坐标连点"计数：真选项点一次就消失，同一坐标连点仍无进展
        = 假选项，直接放弃点选项改走"跳过/点空白"，避免重演宗门那次
        "同一假选项连点 159 次"的事故。
        """
        if self._skip_story_dialog(screen):
            return True
        me = str((self.account or {}).get("character") or "").replace(" ", "")
        # 假选项黑名单（key → 解禁时间戳）：见 DIALOG_OPT_BAN_TTL 注释。
        # 拉黑要在**候选过滤阶段**生效，否则每轮仍会挑中同一个假坐标去点。
        now = time.time()
        banned = {k: exp for k, exp in
                  getattr(self, "_dlg_opt_banned", {}).items() if exp > now}
        self._dlg_opt_banned = banned
        opts = [(cx, cy) for t, cx, cy, _sc in
                ocr.scan(screen, DIALOG_OPTION_REGION, min_score=0.5)
                if len(t) >= 3 and 150 <= cx <= 260
                and (cx // 8, cy // 8) not in banned
                and not ocr.name_tag_like(t.replace(" ", ""), me)]
        if opts:
            x, y = min(opts, key=lambda p: p[1])  # 最靠上的选项
            key = (x // 8, y // 8)  # 同坐标聚类（8px 网格容忍 OCR 抖动）
            if key == getattr(self, "_dlg_opt_key", None):
                self._dlg_opt_repeat = getattr(self, "_dlg_opt_repeat", 0) + 1
            else:
                self._dlg_opt_key, self._dlg_opt_repeat = key, 1
            if self._dlg_opt_repeat > DIALOG_OPT_REPEAT_ABORT:
                log.warning("剧情选项 @ (%d, %d) 已连点 %d 次无进展，判定假选项，"
                            "拉黑该坐标 %d 秒（改走跳过/点空白）",
                            x, y, self._dlg_opt_repeat, DIALOG_OPT_BAN_TTL)
                banned[key] = now + DIALOG_OPT_BAN_TTL
                self._dlg_opt_key, self._dlg_opt_repeat = None, 0
            else:
                log.info("剧情对话带选项，点最上面的选项 @ (%d, %d)", x, y)
                self.device.click(x, y)
                return True
        if any("点击" in t and ("空白" in t or "任意" in t or "继续" in t)
               for t in ocr.dump_texts(screen, DIALOG_CONTINUE_REGION)):
            log.info("剧情对话：按提示点击空白处继续")
            self.device.click(*BLANK_CLICK_POS)
            return True
        return False

    # ---- 全屏聊天面板（2026-11-08 7 号事故）----
    # 全屏聊天界面（左列 消息/好友/帮会/世界/学舍/金兰/招募/系统/好友圈 页签
    # 列）盖住主 HUD → on_main_screen=False、ESC 与右缘盲点全落在面板内，
    # 7 号整轮陷在里面 4.5h、拖死 12 例组队连坐。**代码从未有过该面板的
    # 处理**（git 全历史无记录）——以前任务流程的正常点击恰好常落在面板外
    # 所以"都能退出"。关闭路径用户 2026-11-08 指认：**点面板外空白（顶部
    # 场景区）或按 ESC 均可收起**。
    CHAT_TAB_REGION = (0, 95, 58, 570)     # 左列页签列窄区
    CHAT_TAB_MARKS = ("消息", "好友", "帮会", "世界", "学舍",
                      "金兰", "招募", "系统", "好友圈")
    CHAT_BLANK_POS = (150, 42)   # 面板外顶部场景空白（用户红框区，点击=收起）

    def is_chat_panel(self, screen):
        """判全屏聊天面板：左列窄区 OCR 命中 ≥3 个聊天专属页签词。

        主界面左下只有 帮会/好友 等零星图标，不会 3 个以上同时出现在该
        窄区内，误判风险低；真主城在循环顶部 on_main_screen 就 return 了。
        """
        try:
            texts = [t for t, *_ in ocr.scan(screen, self.CHAT_TAB_REGION,
                                             min_score=0.6)]
        except Exception:
            return False
        hits = sum(1 for m in self.CHAT_TAB_MARKS
                   if any(m in t for t in texts))
        return hits >= 3

    def handle_chat_panel(self, screen, round_idx=0):
        """收起全屏聊天面板，识别命中并已动手返回 True。

        关闭动作交替：偶数轮点面板外空白、奇数轮按 ESC（用户确认两条路
        都有效，交替防单路径偶发失灵）。收起后由调用方下一帧复核。
        """
        if not self.is_chat_panel(screen):
            return False
        if round_idx % 2 == 0:
            log.info("聊天面板：点面板外空白 @ (%d, %d) 收起",
                     *self.CHAT_BLANK_POS)
            self.device.click(*self.CHAT_BLANK_POS)
        else:
            log.info("聊天面板：按 ESC 收起")
            self.device.press_esc()
        pace.wait(1.2, 1.8)
        return True

    def settle_scene(self, max_wait=300, tag="场景复位"):
        """全场景扫描复位到主界面（用户规则 2026-10-12）：登录后/组队前/任务前
        **先判断当前场景**，再做退队/回长安等后续操作。

        场景分支（每帧按序判定）：
        - 战斗中：点 [自动] 加速并**等战斗结束**（ESC 无效；等待时间向后顺延
          任务超时Deadline——"战斗中等待不算入超时时间"）；
        - 家园场景（顶部 HUD「家园/美观度」，ESC 无效）：点右缘「离开」图标；
        - 副本/特殊场景（左上角无地图名）：点右缘「离开」（含确认框）；
        - 奖励/结算弹窗（"点击空白处关闭"）：点空白；
        - 系统弹窗（内存优化/二级密码/验证码/变身卡/提示卡等）：dismiss_popups；
        - 兜底阶梯：ESC ×2 → 面板返回箭头 → 剧情对话（跳过/选项/点空白）。

        返回 True=已在主界面；max_wait 秒仍未回主界面则 report_unknown 后返回
        False（战斗等待不计入这 max_wait）。
        """
        from core import dialogs
        start = time.time()
        battle_since = None      # 当前这场战斗的开始等待时刻
        battle_waited = 0.0      # 已累计的战斗等待秒数（不计入 max_wait）
        stuck = 0                # 连续"无任何分支命中"的轮数（兜底阶梯用）
        chat_round = 0           # 聊天面板收起动作轮次（点空白/ESC 交替）
        while True:
            self._check_stop()
            # 绝对看门狗（2026-10-15 事故新增）：旧代码只在"兜底阶梯"分支
            # 检查 max_wait，奖励弹窗/布置模式/家园/特殊场景/dismiss_popups
            # 等静默 continue 的分支命中时永远绕过超时检查——账号 7 在竞技
            # 任务开场复位里冻结 1 小时+ 无日志。除战斗等待外，任何路径
            # 累计超时都上报并返回 False，由重试/任务硬超时接手。
            if battle_since is None and time.time() - start - battle_waited > max_wait:
                # 场景失联信号（2026-11-08 7 号聊天面板事故）：供看门狗判
                # 「连续 N 任务死于未识别场景 → 换新客户端」，见 _scene_lost
                try:
                    self.device.note_input_miss("settle_scene", tag)
                except Exception:
                    pass
                self._scene_lost = True
                self.report_unknown(
                    "settle_scene_fail",
                    note=f"{tag}：{time.time() - start:.0f}s 未回主界面"
                         f"（静默循环，含战斗等待 {battle_waited:.0f}s）")
                return False
            screen = self.device.screenshot()
            if self.on_main_screen(screen):
                if battle_since is not None:
                    log.info("%s：战斗结束，已回主界面", tag)
                return True
            if dialogs.handle_sleep_mode(self.device, screen):
                continue
            if dialogs.handle_kicked(self.device, screen):
                raise AccountKicked(
                    f"账号被顶号（被迫下线）: {self.account.get('character', '')}")
            # 战斗中：点自动并等结束（等待不计入任务超时——Deadline 随等待顺延）
            if self._in_battle_any(screen):
                if battle_since is None:
                    battle_since = time.time()
                    log.info("%s：检测到战斗画面（ESC 无效），点 [自动] 并等待"
                             "战斗结束（等待不计入超时）", tag)
                    self.device.click(*BATTLE_AUTO_POS)
                if self._deadline is not None:
                    self._deadline += 3  # 与等待同步顺延
                pace.wait(3)
                continue
            if battle_since is not None:
                battle_waited += time.time() - battle_since
                log.info("%s：战斗结束（等待 %.0f 秒），继续场景复位",
                         tag, time.time() - battle_since)
                battle_since = None
                continue  # 战斗刚结束可能有结算弹窗，下一帧统一处理
            # 奖励/结算弹窗
            hit = ocr.find_text(screen, "点击空白处关闭", region=REWARD_POPUP_REGION)
            if hit:
                log.info("%s：关闭奖励弹窗", tag)
                self.device.click(*(reward_blank_pos(screen, hit=hit)
                                    or BLANK_CLICK_POS))
                pace.wait(0.8, 1.2)
                stuck = 0
                continue
            # 剧情/过场对话：右下角「跳过」是唯一出路（2026-10-25 6 号寻宝
            # 连续 4 次 escape_scene_fail，画面就是纯剧情对话——点「离开」
            # 全被对话吃掉）。放在靠前的位置，比等兜底阶梯空转快得多。
            if self._skip_story_dialog(screen):
                stuck = 0
                pace.wait(0.8, 1.2)
                continue
            # 家园布置/场景编辑模式：右缘是「退出」不是「离开」，ESC 无效——
            # 必须先退布置，否则下面家园分支点 (383,510) 永远出不去
            if dialogs.handle_decor_exit(self.device, screen):
                stuck = 0
                continue
            # 顶部 HUD 一次扫（家园 / 玩法面板共用同一区域 (0,0,405,60)）
            hud_texts = ocr.scan(screen, region=HOME_HUD_REGION)
            # 玩法面板（"经验/今日经验"顶部栏，全屏面板把左列锚点全遮住 →
            # on_main_screen=False，而 ESC 实测关不掉）：点左下角返回箭头退出。
            # 2026-10-16 7 号在 jingji 开场复位里困在玩法面板，硬熬满 300s
            # 触发看门狗 → AI 兜底又去调模型（几十秒）→ 整条账号线程停摆。
            if any("今日经验" in t for t, *_ in hud_texts):
                log.info("%s：在玩法面板（顶部今日经验栏），点返回箭头退出", tag)
                self.device.click(*PANEL_BACK_POS)
                stuck = 0
                pace.wait(1.0, 1.5)
                continue
            # 全屏聊天面板（2026-11-08 7 号事故）：识别靠左列页签列，收起
            # 点面板外空白/ESC 交替。放在兜底阶梯前——ESC 盲按对它时灵时
            # 不灵（输入框焦点），盲点右缘全落在面板内
            if self.handle_chat_panel(screen, round_idx=chat_round):
                chat_round += 1
                stuck = 0
                continue
            # 家园场景（ESC 无效，离开图标也不在副本的 SPECIAL_LEAVE_REGION 里）
            # 判定只看顶部 HUD（不看地图名，理由见 HOME_HUD_REGION 注释）
            if any("家园" in t or "美观度" in t for t, *_ in hud_texts):
                # 家园里的模态礼物弹窗（「旅行吧喵喵」等）会把右缘「离开」和
                # 一切点击吃掉——必须先收下礼物再点离开（2026-10-31 3 号：
                # 点「离开」23 次全无效，开场复位 304s 判负 → 跑商硬超时）
                if dialogs.handle_pet_travel_gift(self.device, screen):
                    stuck = 0
                    pace.wait(1.2, 1.8)
                    continue
                # 先 OCR 定位右缘「离开」，找不到才用固定兑底坐标：家园布局/浮层
                # 可能让固定坐标点空（2026-10-15 用户实机：明明有离开按钮却卡在
                # 家园出不去）。⚠️ 文字中心点了无效（2026-10-11 实测），必须
                # 上移 ~20px 点图标中心。
                leave = ocr.find_text(screen, "离开", region=HOME_LEAVE_REGION,
                                      min_similarity=0.75)
                pos = (leave[0], leave[1] - 20) if leave else HOME_LEAVE_POS
                log.info("%s：在家园场景，点右缘「离开」图标 (%d, %d)%s",
                         tag, pos[0], pos[1], "" if leave else "（兑底坐标）")
                self.device.click(*pos)
                pace.wait(2.5, 3.5)
                stuck = 0
                continue
            # 副本/特殊场景：右缘"离开"（含离开确认框）。海市/六道等场景左上角
            # 无地图名；帮派领地**有地图名**（"帮派领地"）且 ESC 无效、离开按钮
            # 同在右缘（380,325 在 SPECIAL_LEAVE_REGION 内）——所以不以"无地图名"
            # 为前置，只要不在主界面就先试右缘"离开"（该区域无"离队"等近似文字，
            # 主界面/常规面板不会误中）
            hit = ocr.find_text(screen, "离开", region=SPECIAL_LEAVE_REGION,
                                min_similarity=0.75)
            if hit:
                log.info("%s：特殊场景，点击 [离开] @ (%d, %d)",
                         tag, hit[0], hit[1])
                self.device.click(hit[0], hit[1])
                deadline = time.time() + 4
                while time.time() < deadline:
                    cfm = ocr.find_text(self.device.screenshot(), "确定",
                                        region=LEAVE_CONFIRM_REGION,
                                        min_similarity=1.0)
                    if cfm:
                        log.info("点击 [确定-离开副本] @ (%d, %d)",
                                 cfm[0], cfm[1])
                        self.device.click(cfm[0], cfm[1])
                        break
                    pace.wait(0.5)
                pace.wait(2.0, 3.0)
                stuck = 0
                continue
            # 系统弹窗（内存优化/二级密码/验证码/变身卡/提示卡/组队邀请等）
            if self.dismiss_popups(screen):
                stuck = 0
                continue
            # 兜底阶梯：ESC ×2 → 面板返回箭头 → 盲点右缘「离开」 → 剧情对话
            if stuck < 2:
                log.info("%s：不在主界面，按 ESC 返回", tag)
                self.device.press_esc()
            elif stuck == 2:
                log.info("%s：ESC 未生效，试点面板返回箭头", tag)
                self.device.click(*PANEL_BACK_POS)
            elif stuck in (3, 4):
                # 识别不出场景时的"盲点出口"：右缘两个「离开」候选位
                # （家园 (383,510) / 副本·活动场景 (375,320)）。这两处在云梦长安
                # 主城和其它常规面板上都是空白（点了无害，且主城早在循环顶部
                # `on_main_screen` 就 return 了，根本走不到这里），而在家园/副本里
                # 它们是**唯一**的逃生出口。2026-10-16 3 号滞留家园 291s 就是
                # "顶部 HUD 被金色横幅+道具卡挡住 → 家园判定 miss → ESC 无效"
                # 三条识别路全断造成的，盲点出口能兜住这一整类故障。
                pos = HOME_LEAVE_POS if stuck == 3 else SPECIAL_LEAVE_POS
                log.info("%s：连续 %d 轮识别不出场景，盲点右缘「离开」候选位 %s",
                         tag, stuck, (pos,))
                self.device.click(*pos)
                pace.wait(1.5, 2.5)
            else:
                if not self._handle_dialog(screen):
                    log.info("%s：未识别场景，按 ESC 兜底", tag)
                    self.device.press_esc()
            stuck += 1
            if stuck > 16 or time.time() - start > max_wait:
                try:
                    self.device.note_input_miss("settle_scene", tag)
                except Exception:
                    pass
                self._scene_lost = True
                self.report_unknown(
                    "settle_scene_fail",
                    note=f"{tag}：{time.time() - start:.0f}s 未回主界面"
                         f"（连续 {stuck} 轮未识别场景）")
                return False
            pace.wait(0.8, 1.2)

    def dismiss_item_cards(self, max_use=5):
        """主界面右下角的待使用道具卡（历妖嘉奖等，会遮挡右侧信息）：
        有"使用"就直接点用掉；用后弹"恭喜获得"则点空白关；没能用掉
        （"使用"还在且没弹窗）说明有问题，点 X 关闭卡片。
        特例：海市赐福令卡一律点 X 关闭（不使用，用户明确要求）。"""
        for _ in range(max_use):
            screen = self.device.screenshot()
            if ocr.find_text(screen, "赐福令", region=ITEM_CARD_TITLE_REGION,
                             min_similarity=0.75):
                log.info("关闭海市赐福令卡（不使用）")
                self.device.click(*ITEM_CARD_X_POS)
                pace.wait(1.0)
                continue
            hit = ocr.find_text(screen, "使用", region=ITEM_CARD_USE_REGION,
                                min_similarity=1.0)
            if not hit:
                return
            log.info("使用待使用道具 @ (%d, %d)", hit[0], hit[1])
            self.device.click(hit[0], hit[1])
            pace.wait(1.2, 1.8)
            if ocr.find_text(self.device.screenshot(), "点击空白处关闭",
                             region=REWARD_POPUP_REGION):
                self.close_reward_popup(timeout=3)
                continue
            if ocr.find_text(self.device.screenshot(), "使用",
                             region=ITEM_CARD_USE_REGION, min_similarity=1.0):
                log.warning("道具未能使用，点 X 关闭卡片")
                self.device.click(*ITEM_CARD_X_POS)
                pace.wait(1.0)
                return

    def back_to_home(self):
        """兜底：连按几次 ESC 退回主界面。"""
        log.info("返回主界面")
        for _ in range(3):
            self.device.press_esc()

    @staticmethod
    def _on_yunmeng(screen):
        """左上角地图名判定当前是否在云梦长安场景。"""
        return bool(ocr.find_text(screen, "云梦长安", region=MAP_LABEL_REGION,
                                  min_similarity=0.75))

    def leave_team(self):
        """单人状态保证：在队伍中则退出（队员可能被拉进别的队伍，
        会影响单人任务的寻路和最后的 5 开组队）。失败只告警不阻断。

        队伍页签下显示"创建队伍/前往组队"= 单人；显示角色名 = 组队中。
        组队时**再点一次"队伍"页签**打开队伍面板，点面板左下角"离队"即可
        （不点队员名字——名字顺序不固定，之前"第一个是自己"的假设是错的）。
        切不到队伍视图时绝不盲点，防止点到任务视图的"天之将倾"条目被
        自动寻路进堕神遗都（实测教训）。
        """
        # _leave_confirmed：本方法返回 True 一律表示"不阻断"，但只有 True 才等于
        # **已确认单人**（"solo"）。调用方（zudui._leave_and_report）需要的是后者：
        # 之前它拿到 True 后又跑一遍 _ensure_team_view() 复查，等于把这里刚做的
        # 校验原样再做一次（每次 ~5~10 秒，5 个号并发 = 队长白等 10 秒起步；实测
        # 队员离队 37 秒里 9.7 秒是这一次重复校验）。改成发布结论让调用方直接采用。
        self._leave_confirmed = False
        markers = self._ensure_team_view()
        if markers is None:
            return True  # 追踪面板都没展开（异常画面），不处理
        if markers == "solo":
            self._restore_quest_view()
            self._leave_confirmed = True
            return True
        if markers is not True:
            log.warning("队伍视图状态不明，跳过离队检查")
            return True
        # 组队中：再点一次"队伍"页签，打开队伍面板
        screen = self.device.screenshot()
        tab = ocr.find_text(screen, "队伍", region=TEAM_TAB_REGION,
                            min_similarity=0.9)
        if not tab:
            # 2026-10-13 实测（组队 70 秒大头的根因）：5 开并发时"队伍"二字
            # 频繁漏读，旧代码直接 return True = **静默跳过离队**，队员连点都
            # 没点，白白重试 3 轮（每轮 pace.wait(6)）才失败。页签槽位固定，
            # 确认在主界面就按它盲点（不在主界面不能盲点，会点到别的面板）。
            if not self.on_main_screen(screen):
                return True
            tab = TEAM_TAB_POS
            log.info("OCR 未读到「队伍」页签，按固定槽位 %s 打开队伍面板",
                     TEAM_TAB_POS)
        log.info("点击 [队伍页签] 打开队伍面板 @ (%d, %d)", tab[0], tab[1])
        self.device.click(tab[0], tab[1])
        hit = None
        deadline = time.time() + 8
        while time.time() < deadline:
            screen = self.device.screenshot()
            # "离队"按钮位置不固定：左下面板或成员角色卡弹窗（面板旁漂浮，
            # 实测 @ (227,177)）都出现过，先按旧区域找，再全屏精确匹配兜底
            hit = (ocr.find_text(screen, "离队", region=LEAVE_TEAM_BTN_REGION,
                                 min_similarity=1.0)
                   or ocr.find_text(screen, "离队", min_similarity=1.0))
            if hit:
                break
            if not ocr.find_text(screen, "招募", region=TEAM_PANEL_MARK_REGION,
                                 min_similarity=1.0):
                pace.wait(0.6)  # 面板还没开，继续等
                continue
            pace.wait(0.6)
        if not hit:
            log.warning("队伍面板未打开（或无离队按钮）")
            self.exit_panel_to_home()
            return False
        log.info("点击 [离队] @ (%d, %d)", hit[0], hit[1])
        self.device.click(hit[0], hit[1])
        # 等离队生效（多开拥挤时点击/界面响应有延迟，且可能弹确认框）：
        # 确认框点"确认/确定"；底部 离队/暂离 双按钮都消失即面板已关闭
        deadline = time.time() + 8
        while time.time() < deadline:
            screen = self.device.screenshot()
            still = ocr.find_text(screen, "离队", region=(60, 620, 340, 55),
                                  min_similarity=0.9)
            if not still:
                break
            cfm = (ocr.find_text(screen, "确认", region=(140, 380, 130, 60),
                                 min_similarity=0.9)
                   or ocr.find_text(screen, "确定", region=(140, 380, 130, 60),
                                    min_similarity=0.9))
            if cfm:
                log.info("点击 [确认-离队] @ (%d, %d)", cfm[0], cfm[1])
                self.device.click(cfm[0], cfm[1])
            pace.wait(0.8)
        self.exit_panel_to_home()
        # 校验：回到队伍视图看到单人标记才算退成功
        ok = self._ensure_team_view() == "solo"
        self._restore_quest_view()
        if ok:
            self._leave_confirmed = True
            log.info("已退出队伍")
            return True
        log.warning("离队后仍是组队状态")
        self.save_debug_screenshot("leave_team_fail")
        return False

    @staticmethod
    def _team_view_open(screen):
        """追踪面板是否停在「队伍视图」（创建队伍/前往组队任一可见）。"""
        return bool(ocr.find_text(screen, "创建队伍", region=MEMBER_LIST_REGION,
                                  min_similarity=0.75)
                    or ocr.find_text(screen, "前往组队", region=MEMBER_LIST_REGION,
                                     min_similarity=0.75))

    def _restore_quest_view(self):
        """追踪面板若被留在队伍视图（单人标记可见），切回任务视图。

        任务进度条目（寻宝罗盘9/10等）只在任务视图显示——之前留在队伍视图
        会导致 xunbao 误判"寻宝链未启动"（实测 5 个号连环失败）。

        2026-10-23 增强（run c7e254 根因修复）：**点完必须校验**。旧版点一次
        「任务页签」就走人、不复查，点击被吞时面板留在队伍视图（创建队伍/
        前往组队挡在主界面右侧），后续「挑战」「活动」点击全被挤歪 →
        jingji/zhanling 连环判负。现在：最多点 3 次「任务页签」；仍不成就点
        「队伍页签」把面板**整个收起**（收起也是干净状态，队伍视图下点它=
        收面板，实测教训注释见 TEAM_TAB_POS）；收不起来才告警 + 存图，
        返回 False（调用方目前不依赖返回值，重试逻辑在函数内自足）。
        """
        for attempt in range(3):
            screen = self.device.screenshot()
            if not self._team_view_open(screen):
                if attempt:
                    log.info("队伍侧栏已切回任务视图")
                return True
            tab = ocr.find_text(screen, "任务", region=QUEST_TAB_REGION,
                                min_similarity=1.0)
            if tab:
                log.info("点击 [任务页签] 切回任务视图")
                self.device.click(tab[0], tab[1])
            else:
                # 组队面板开着时页签必在固定槽位（面板只盖中部，不盖右上页签）；
                # OCR 漏读就按固定槽位 (310, 92) 切回任务视图，别把组队面板留着
                # 挡主界面（实测教训；此前误用 (368,92)=队伍页签，会把面板收起）
                log.info("OCR 未读到「任务」页签，按固定槽位 (310, 92) 切回任务视图")
                self.device.click(*QUEST_TAB_POS)
            pace.wait(0.8, 1.2)
        # 任务页签点了 3 次队伍视图还在 → 点「队伍页签」把面板整个收起
        screen = self.device.screenshot()
        if not self._team_view_open(screen):
            return True
        tab = ocr.find_text(screen, "队伍", region=TEAM_TAB_REGION,
                            min_similarity=0.9)
        if tab or self.on_main_screen(screen):
            pos = (tab[0], tab[1]) if tab else TEAM_TAB_POS
            log.warning("任务页签 %d 次未切回任务视图，点 [队伍页签] 收起面板 @ %s",
                        3, pos)
            self.device.click(*pos)
            pace.wait(0.8, 1.2)
        if not self._team_view_open(self.device.screenshot()):
            log.info("队伍面板已收起（侧面干净，继续后续流程）")
            return True
        log.warning("队伍侧栏仍未收起（切回任务视图失败）")
        self.save_debug_screenshot("quest_view_restore_fail")
        return False

    def _ensure_team_view(self, fallback_pos=None):
        """确保追踪面板停在"队伍"视图，返回 _team_panel_markers 结果
        （"solo"=单人 / True=有队员名 / None=切不到队伍视图）。

        面板收起（None）**或停在任务视图（False）**时都点右上"队伍"页签
        展开/切换——点页签是安全的（绝不盲点列表区，任务视图同位置是
        "天之将倾"条目，点了会自动寻路，实测教训）。页签文字 OCR 不中
        （多开拥挤/光照）时按固定槽位 TEAM_TAB_POS 兜底点击——仅当确认在主
        界面时（其它页面该位置不是页签，不能盲点），实测组队任务并发时
        OCR 连续数轮读不出"队伍"二字导致建队/离队连环失败。

        fallback_pos：调用方确认"当前场景该槽位就是队伍页签"时传入（如打地鼠
        队长停在帮会领地——那里 on_main_screen 的锚点判定不可靠，但右上页签
        槽位与主界面一致），此时不再用 on_main_screen 做前置校验。
        """
        markers = None
        for _ in range(4):
            screen = self.device.screenshot()
            markers = self._team_panel_markers(
                screen, own_name=(self.account or {}).get("character"))
            # 帮会/编队面板（一键组队后的场景）会盖住右侧队伍侧栏，它自己也显示
            # "队长+成员"，_team_panel_markers 会当成队伍视图返回 True。只在判成
            # "在队伍中"时复核（solo/None 的情况本就不会误判，省一次 OCR）。
            if markers is True and self.on_guild_panel(screen):
                log.info("队伍识别前发现画面停在帮会/编队面板，先关面板回主界面")
                self.exit_panel_to_home()
                continue
            if markers is not None and markers is not False:
                return markers  # "solo" 或 True：已是队伍视图
            tab = ocr.find_text(screen, "队伍", region=TEAM_TAB_REGION,
                                min_similarity=0.9)
            if not tab:
                if fallback_pos is not None:
                    tab = fallback_pos  # 调用方已确认该槽位是"队伍"页签
                elif not self.on_main_screen(screen):
                    return None  # 不在主界面，固定槽位不能盲点
                else:
                    tab = TEAM_TAB_POS
            log.info("点击 [队伍页签] @ (%d, %d)", tab[0], tab[1])
            self.device.click(tab[0], tab[1])
            pace.wait(1.0, 1.5)
        return markers

    @staticmethod
    def _team_panel_markers(screen, own_name=None):
        """队伍视图内容判定："solo"=单人（创建队伍/前往组队），True=在队伍中
        （有队员名，**或看到自己名字——单人队伍（自建队/队友全退后剩自己）的
        面板显示自己名字+招募位、没有"创建队伍/前往组队"，旧逻辑会误判 solo，
        导致离队假确认、邀请弹窗永远到不了（实测连环教训）**），
        False=不是队伍视图，None=判不出（没有任何正证据——**绝不能当"在队伍中"**）。

        solo 判定必须先于"前往"包含检查：单人队伍视图的两个按钮
        "创建队伍/前往组队"本身就含"前往"，OCR 稍读偏（sim<0.75）就会
        掉进"前往"分支被误判成任务视图 False → 调用方再点一次"队伍"页签
        把面板点回收起（实测 _create_team 因此失败）。两个短语用
        包含+相似度 0.7 模糊匹配；任务视图条目（"前往本：堕神遗都"等）
        与"前往组队"相似度仅 ~0.3，不会误中。
        """
        texts = [t for t, *_ in ocr.scan(screen, MEMBER_LIST_REGION,
                                         min_score=0.5)]

        def _like(t, phrase):
            if len(t) < 2:
                return False
            if phrase in t:
                # token 比短语长（含粘连/带后缀，如"创建队伍 前往组队"）→ 算命中
                return True
            if t in phrase:
                # token 比短语短（2026-10-21 事故）：「赛季等级提升 灵光点+1」
                # 弹窗恰好悬浮在 MEMBER_LIST_REGION 内，它的「前往」按钮只有
                # 2 个字、被"前往组队"包含 → 整个队员列表区被误判成 solo 视图
                # → 队长端每次读队伍都静默返回 0 人 → 判"邀请没发出去"把
                # 组好的 4 人队解散（run 5e0d6d 中午地鼠 5 号全跳过）。
                # 短于短语 2 字以上的残词不参与包含判定。
                return len(t) >= len(phrase) - 1
            return SequenceMatcher(None, t, phrase).ratio() >= 0.7

        if own_name and any(len(t) >= 2 and (own_name in t or t in own_name or
                             SequenceMatcher(None, t, own_name).ratio() >= 0.65)
                            for t in texts):
            # 看到自己名字=在队伍里（单人队伍显示自己名字+招募位，优先级高于
            # 下面的按钮判定——无队伍的单人视图从不显示自己名字）
            return True
        if any(_like(t, "创建队伍") or _like(t, "前往组队") for t in texts):
            return "solo"
        # 任务视图的条目描述都含"前往"
        if any("前往" in t for t in texts):
            return False
        # 2026-10-16：兜底**不能**再无脑 return True。追踪面板停在"任务"视图、
        # 且任务条目里没出现"前往"二字时（实测读到「狮王守卫 / 第十一层 /
        # 今日奖励次数已耗尽」），旧代码返回 True = 谎报"在队伍中"，害得队长
        # 建队流程认为"必须单人"永远不满足 → 60s×3 白等 → 组队判负（zhongkui
        # 全灭），还把 5 个号都留在坏状态、连后面的 huoyue 也一起失败。
        # 真正的队伍视图一定看得到**自己的名字**（1 人队伍也显示自己），上面
        # own_name 分支已覆盖；这里只认另一个正证据——"成员行带等级数字"
        # （109/Lv109 等）。拿不到正证据就返回 None（未知）而不是 True，
        # 交给 _ensure_team_view 再点一次页签 / 或者由调用方按"状态不明"处理。
        if any(re.search(r"\d", t) for t in texts):
            return True
        return None

    def _clear_map_overlay(self, attempt):
        """点左上角小地图前清掉可能遮挡它的浮层（ensure_yunmeng 用）。

        面板背着（不在主界面）时点小地图没反应（实测，故原先只按 1 次 ESC）。
        2026-10-13 队长端事故：4 号已在主界面（on_main_screen=True）仍连点 2 次
        小地图都打不开场景选择面板，随后被判"进六道法门场景失败"→组队副本队长端
        全队连锁判负。这里把"打不开"的应对加强：首轮轻清（1 次 ESC），后续加码
        （2 次 ESC + 点底部中央空白，关"点击空白处关闭"类弹窗）。只清遮挡、不碰
        功能按钮，最坏是被清的那层再弹回来，由下一轮继续。
        """
        rounds = 1 if attempt == 0 else 2
        for _ in range(rounds):
            self.device.press_esc()
            pace.wait(0.6, 1.0)
        if attempt >= 1:
            # 模态提示弹窗（邮箱容量等）ESC 关不掉、还会吞点击（2026-10-18
            # 补跑实测：场景选择面板 4 轮全打不开，根因还是邮箱弹窗）
            if self.dismiss_popups():
                return
            self.device.click(200, 640)   # 底部中央空白：关结算/提示类弹窗
            pace.wait(0.8, 1.2)

    def reteam_if_requested(self, coord, tag):
        """组队副本任务：若队长端失败后请求了「自动改选重建队伍」，先重建队伍。

        2026-10-13 新增（配合 teamup.failover_captain）：某组队副本任务队长端
        进场景失败后自动改选队长，并请后续组队副本任务重建队伍——游戏内队长是
        "发邀请的人"，只改协调器不改队伍没用，必须真的重组。队长端复用 Zudui
        的组队流程（先离队→发邀请→等接受），队员端复用其队员流程（离队→等邀请
        →接受）；队员端靠协调器组队结果退出。返回 True=做了重建队伍（调用方随后
        按 coord.team_success 判定是否继续），False=无需重建。

        异常/失败一律兜底：清掉重建标记并放行，绝不让"重建队伍"本身阻断后续任务。
        """
        if not coord.reteam_pending():
            return False
        me_id = self.account.get("id")
        is_cap = (coord.captain_id == me_id)
        log.warning("%s：检测到队长端失败后的自动改选，重建队伍（本号%s）",
                    tag, "为队长" if is_cap else "为队员")
        from tasks.zudui import Zudui   # 延迟导入（zudui 反过来 import base）
        helper = Zudui(self.device, self.matcher, self.config, self.account)
        try:
            if is_cap:
                ok = helper._captain_flow(coord)
                coord.clear_reteam()
                if not ok:
                    log.warning("%s：自动改选后重建队伍失败", tag)
            else:
                helper._member_flow(coord)
        except Exception as exc:   # noqa: BLE001 — 兜底：重建队伍失败不阻断后续
            coord.clear_reteam()
            log.warning("%s：自动改选后重建队伍异常：%s", tag, exc)
        return True

    def captain_fail_finish(self, coord, reason, retry_in_place=True):
        """队长端某组队副本任务失败：记一次失败并尝试自动改选队长，再如实判负。

        2026-10-17 两段式（配合 teamup.dungeon_captain_retry）：
        - 本项**还能再试一次**且队里还有别的号可当队长 → 只改选队长、**不判负**
          （队伍没散，进副本入口失败时谁都没进副本），返回 False 让重试循环用
          新队长再进一次入口。旧写法立刻 dungeon_finish(False)，下一次尝试被
          "组队已判负"短路 → 改选队长只对**下个**副本生效，本项对全队白丢
          （run c03345 的 liudao/zhongkui 就是这么全灭的）。
        - 重试次数已用尽 / 无号可换 → 回落原逻辑：改选队长（供下个副本用）+
          如实判负。
        """
        coord.note_captain_fail(self.account.get("id"))
        if retry_in_place and coord.dungeon_captain_retry(
                self.name, "%s %s" % (self.title, reason)):
            # 本号已降级成队员：下一次尝试只等新队长的信号——绝不能跑
            # 开场复位（会 leave_team 把队伍拆散），也必须免掉单项任务超时。
            self._failed_over_wait = True
            self._deadline = None
            return False
        if coord.failover_captain("%s %s" % (self.title, reason)) is not None:
            log.warning("%s 队长端失败（%s）：已自动改选队长，"
                        "后续组队副本任务将重建队伍后重试", self.title, reason)
        coord.dungeon_finish(self.name, False)

    def _on_city_hud(self, screen):
        """主城 HUD 判定：**只看左列 活动/玩法/商城**（故意不看「背包」）。

        `on_main_screen()` 为兼容组队（左列会因队伍而变，三个锚点全 miss）
        把「背包」当兜底锚点；但**副本/活动场景右缘也有个背包图标**——实测
        「狮王守卫 第十一层」截图上 `背包` 在 (376,566) 命中 0.97，左列三个
        锚点全 miss，于是 `on_main_screen()` 在副本里返回 True。旧代码拿它当
        "别乱点固定位"的闸门 → 在副本里把「点右缘离开」这条唯一逃生路掐掉
        （2026-10-16 liudao「进六道法门场景失败」+ huoyue「未找到模板: 玩法」
        同一根因）。这里只用左列锚点：它们在副本里必然不出现。
        """
        loose_hits = 0
        for name in ("活动", "玩法", "商城"):
            # 窄区域命中即可（精度优先）
            region = MAIN_ANCHOR_REGIONS.get(name)
            if region and self.matcher.find(screen, name, region=region,
                                            threshold=0.88, ccoeff_floor=0.45):
                return True
            # 图标整列上移 14px 时窄区域全 miss（2026-11-02）。这里**要求宽松
            # 区域命中 ≥2 个**才认：本函数决定"要不要盲点右缘离开"，误判成
            # 主城会把唯一逃生路掐掉，所以比 on_main_screen 更严——真主城里
            # 三个图标是整列一起移的，不会只中一个。
            region = MAIN_ANCHOR_REGIONS_LOOSE.get(name)
            if region and self.matcher.find(screen, name, region=region,
                                            threshold=0.88, ccoeff_floor=0.45):
                loose_hits += 1
        return loose_hits >= 2

    def _escape_special_scene(self, retries=3):
        """点右缘「离开」退出特殊场景（副本/活动场景）。**唯一的离开实现**。

        返回 True = 已确认回到云梦长安；False = 没退出去（读不到「离开」、
        或点了没生效）。**不以 `on_main_screen()` 作提前返回**——副本 HUD
        与主界面相似（背包图标误中），判成主界面会把这条唯一的逃生路掐掉
        （2026-10-16 复核）。判定正证据：`SPECIAL_LEAVE_REGION` 里 OCR 到
        「离开」就点它；读不到且**不像在主城 HUD**、也不在战况中时，按固定位
        `SPECIAL_LEAVE_POS` 兜底（该小图标 OCR 不稳，实测同一画面时读时不读）。

        2026-10-16 事故：账号被困在「狮王守卫 第十一层」副本（放大截图
        debug/1792085896_huoyue_fail.png，右缘「离开」清晰在 ≈(380,339)），
        副本无小地图 → 场景选择面板永远点不开 → 任务入口模板（huoyue 的
        「玩法」、liudao 的六道法门入口）全找不到 → liudao 队长端
        「进六道法门场景失败」+ huoyue「未找到模板: 玩法」，两条失败同一根因。
        """
        for i in range(retries):
            screen = self.device.screenshot()
            if self._on_yunmeng(screen):
                return True
            # 驻留型弹窗（邮箱容量提示等）会吞掉「离开」的点击（2026-10-18
            # 补跑实测：弹窗挂着时点 3 次离开全无效，白耗 2.5 分钟才在
            # open_wanfa 的清场里被关掉）——每轮先清一次
            if self.dismiss_popups(screen):
                continue
            # 全屏聊天面板（2026-11-08 7 号事故）：面板盖住 HUD 时右缘
            # 「离开」读不到/点不到，先收起再走正常逃逸
            if self.handle_chat_panel(screen, round_idx=i):
                continue
            # 剧情/过场对话挡在前面时「离开」图标根本点不动（2026-10-25 6 号
            # 寻宝连续 4 次 escape_scene_fail：截图就是纯剧情对话，右下角
            # 「跳过」明明可读（0.86 分），这段代码只找「离开」→ 点固定位 →
            # 白点 3 轮）。先点「跳过」把对话过掉再看场景。
            if self._skip_story_dialog(screen):
                pace.wait(0.8, 1.2)
                continue
            hit = ocr.find_text(screen, "离开", region=SPECIAL_LEAVE_REGION,
                                min_similarity=0.75)
            pos = (hit[0], hit[1]) if hit else None
            if pos is None and ocr.contains_text(screen, "遗都",
                                                 region=MAP_LABEL_REGION):
                # 堕神遗都（天之将倾副本场景）右缘**没有**「离开」图标，唯一
                # 出口是左下角「返回」按钮（与「玩法」面板返回箭头同位）。
                # 2026-10-18 补跑 4 号在此打转 25 分钟（点 离开×9+世界地图×8
                # 全无效）；出口位置用户 2026-10-18 指认。地图名 OCR 常把
                # 「堕」读错（塑/堕互换），只认稳定的「遗都」二字。
                pos = YIREDO_RETURN_POS
                log.info("堕神遗都：点左下角 [返回] %s 退出（第 %d/%d 次）",
                         pos, i + 1, retries)
            elif (pos is None and not self._on_city_hud(screen)
                    and not ocr.contains_text(screen, "战况",
                                              region=BATTLE_MARK_REGION)):
                pos = SPECIAL_LEAVE_POS
            if pos is None:
                log.info("右缘没读到 [离开]（第 %d/%d 次），不做退出尝试",
                         i + 1, retries)
                return False
            log.info("特殊场景：点击 [离开] @ (%d, %d) 退出（第 %d/%d 次）",
                     pos[0], pos[1], i + 1, retries)
            self.device.click(*pos)
            # 部分副本离开有确认框（"是否要结束本次探索…[取消|确定]"）
            deadline = time.time() + 4
            while time.time() < deadline:
                hit2 = ocr.find_text(self.device.screenshot(), "确定",
                                     region=LEAVE_CONFIRM_REGION,
                                     min_similarity=1.0)
                if hit2:
                    log.info("点击 [确定-离开副本] @ (%d, %d)", hit2[0], hit2[1])
                    self.device.click(hit2[0], hit2[1])
                    break
                pace.wait(0.5)
            deadline = time.time() + 8
            while time.time() < deadline:
                if self._on_yunmeng(self.device.screenshot()):
                    return True
                pace.wait(0.4)
        # 全部轮次点完仍没回到云梦长安：存一张现场图（这正是"堕神遗都式
        # 迷失"的取证点——2026-10-18 补跑 4 号在不明场景点 离开×3 + 世界
        # 地图×4 全无效，却没有留下任何画面证据），下次据此补出口分支
        self.report_unknown("escape_scene_fail", note="点右缘离开%d次仍未回云梦长安"
                            % retries, ai=False)
        return False

    def ensure_yunmeng(self):
        """确保当前场景是云梦长安，不在则经 小地图→世界→世界地图 传送过去。

        所有任务都要求主界面在云梦长安背景（图鉴/NPC/图标位置才稳定）。
        世界地图上云梦长安不在视野内时向左拖拽内容露出右侧（实测它在
        西凉州方向右侧），几轮找不到再反向拖。失败只告警返回 False，
        不阻断任务（各任务自己的状态判定会兜底重试）。
        """
        screen = self.device.screenshot()
        if self._on_yunmeng(screen):
            return True
        # 家园场景（顶部 HUD「XX的家园/总美观度」）：ESC 关不掉，且家园的「离开」
        # 图标 (383,510) 不在下方 SPECIAL_LEAVE_REGION（y 260~400）里、文字中心又
        # 点不动 → 单独点图标中心（2026-10-11 账号4/6 滞留家园事故）。
        # 判定只看顶部 HUD（不看地图名，理由见 HOME_HUD_REGION 注释）
        if is_home_screen(screen):
            log.info("在家园场景（顶部 HUD），点右缘「离开」图标 %s 回主界面",
                     (HOME_LEAVE_POS,))
            self.device.click(*HOME_LEAVE_POS)
            deadline = time.time() + 4
            while time.time() < deadline:
                screen = self.device.screenshot()
                if self._on_yunmeng(screen) or self.on_main_screen(screen):
                    return True
                pace.wait(0.3)
            log.info("点家园「离开」后仍未回主界面，转世界地图兜底")
        # 特殊场景（副本场景等，左上角没有地图图标/地图名）：点地图没反应，
        # 画面右缘有"离开"按钮时先点离开退出场景，再走世界地图流程
        if not ocr.dump_texts(screen, MAP_LABEL_REGION):
            if self._escape_special_scene():
                return True
        log.info("当前不在云梦长安，打开世界地图传送")
        hit = None
        for attempt in range(4):
            self._check_stop()
            # 点小地图前先清遮挡（面板背着时点它没反应，实测）：首轮轻清，
            # 后续加码（多次 ESC + 点底部空白关"点击空白处关闭"类弹窗）。
            self._clear_map_overlay(attempt)
            self.device.click(*MAP_ICON_POS)
            deadline = time.time() + 10
            while time.time() < deadline:
                hit = ocr.find_text(self.device.screenshot(), "世界",
                                    region=WORLD_BTN_REGION, min_similarity=1.0)
                if hit:
                    break
                pace.wait(0.6)
            if hit:
                break
            log.info("场景选择面板未打开，清理遮挡后重试（第 %d/4 次）", attempt + 1)
            pace.wait(0.8, 1.4)
        if not hit:
            log.warning("场景选择面板未打开（已重试 4 次）")
            self._close_world_map()
            # 2026-10-16 事故兜底：特殊场景（副本/活动场景，**没有小地图**）里
            # 左上角有别的文字被 OCR 读出来 → 上面 `not ocr.dump_texts(
            # MAP_LABEL_REGION)` 判为非空，于是跳过了"点右缘离开退出场景"
            # 那条分支，直接去点**根本不存在的小地图** → 4 次都打不开 → 任务
            # 判失败。实测（debug/1792085896_huoyue_fail.png）账号被困在
            # 「狮王守卫 第十一层」副本，右缘 [离开] 清晰可见；liudao 队长端
            # 「进六道法门场景失败」与 huoyue「未找到模板: 玩法」是同一根因
            # （队长不在云梦长安，任务入口模板全找不到 → 整队被拖下水）。
            # 地图打不开时再给正证据驱动的逃生一次机会：只要右缘读得到
            # 「离开」就点它退出特殊场景。
            if self._escape_special_scene():
                log.info("小地图打不开，但已通过右缘 [离开] 退出特殊场景")
            return False
        log.info("点击 [世界] @ (%d, %d)", hit[0], hit[1])
        self.device.click(hit[0], hit[1])
        deadline = time.time() + 10
        while time.time() < deadline:
            if ocr.find_text(self.device.screenshot(), "世界地图",
                             region=WORLD_MAP_REGION, min_similarity=0.8):
                break
            pace.wait(0.6)
        else:
            log.warning("世界地图未打开")
            self._close_world_map()
            return False
        target = None
        for i in range(6):
            self._check_stop()
            target = ocr.find_text(self.device.screenshot(), "云梦长安",
                                   region=YUNMENG_SEARCH_REGION, min_similarity=0.75)
            if target:
                break
            log.info("世界地图未见云梦长安，滑动地图 (%d/6)", i + 1)
            if i < 4:
                self.device.drag(300, 350, 100, 350)  # 内容左移，露出右侧
            else:
                self.device.drag(100, 350, 300, 350)  # 反向兜底
            pace.wait(1.0)
        if not target:
            log.warning("世界地图上找不到云梦长安")
            self._close_world_map()
            return False
        log.info("点击 [云梦长安] @ (%d, %d)", target[0], target[1])
        self.device.click(target[0], target[1])
        deadline = time.time() + 20
        while time.time() < deadline:
            self._check_stop()
            if self._on_yunmeng(self.device.screenshot()):
                log.info("已传送到云梦长安")
                return True
            pace.wait(1)
        log.warning("传送云梦长安超时")
        self._close_world_map()
        return False

    def _close_world_map(self):
        """把停在"世界地图/场景选择面板"的画面关掉，别把账号丢在纯地图界面。

        2026-10-10 事故：ensure_yunmeng 传送失败后世界地图一直开着，队员
        看不到准备面板、点不到任何东西 → 整队空等。ESC 关掉即可；若当前并
        不在地图界面（传送其实已生效/正在加载）则不动，避免误操作。
        """
        for _ in range(3):
            screen = self.device.screenshot()
            if not (ocr.find_text(screen, "世界地图", region=WORLD_MAP_REGION,
                                  min_similarity=0.8)
                    or ocr.find_text(screen, "世界", region=WORLD_BTN_REGION,
                                     min_similarity=1.0)):
                return
            log.info("关闭世界地图/场景选择面板（避免停在纯地图界面）")
            self.device.press_esc()
            pace.wait(0.8, 1.2)

    def close_fuka_card(self, screen=None):
        """画面里有含"赐福令"的道具卡就点 X 关掉（用户要求：含"赐福令"
        三字的道具提示框一律直接点 X，避免遮挡 OCR）。有动作返回 True。"""
        screen = screen if screen is not None else self.device.screenshot()
        if ocr.find_text(screen, "赐福令", region=ITEM_CARD_TITLE_REGION,
                         min_similarity=0.75):
            log.info("关闭赐福令道具卡")
            self.device.click(*ITEM_CARD_X_POS)
            return True
        return False

    def dismiss_popups(self, screen=None):
        """处理游戏中途随机弹出的系统弹窗（顶号"被迫下线"→ 抛 AccountKicked /
        休眠省电模式 → 滑动解锁 / "内存优化"/"二级密码"/"出售验证码"/
        "变身卡用完"提示等）。

        任务的关键步骤（打开面面前、循环等待中）都应调用；
        已有当前截图时传入 screen 避免重复截图。
        """
        from core import dialogs
        screen = screen if screen is not None else self.device.screenshot()
        texts = ocr.scan(screen, dialogs.DIALOG_SCAN_REGION)
        if dialogs.handle_kicked(self.device, screen, texts):
            raise AccountKicked(
                f"账号被顶号（被迫下线）: {self.account.get('character', '')}")
        if dialogs.handle_sleep_mode(self.device, screen, texts):
            return True
        if dialogs.handle_memory_dialog(self.device, screen, texts):
            return True
        if dialogs.handle_security_lock(self.device, screen,
                                        self.account.get("pwd2", ""), texts):
            return True
        if dialogs.handle_captcha(self.device, screen, texts):
            return True
        if any(k in t for t, *_ in texts for k in dialogs.TRANSFORM_KEYWORDS):
            # 先存截图再点 X：便于回看弹窗样式
            self.save_debug_screenshot("bianshen_popup")
        if dialogs.handle_transform_dialog(self.device, screen, texts):
            return True
        if dialogs.handle_dungeon_continue(self.device, screen, texts):
            return True
        # 队长长时间无操作的转让弹窗：点"不同意"（模态挡住一切点击，
        # 不处理会卡住等待/任务流程；绝不能点"同意"——队伍结构会乱）
        if dialogs.handle_captain_transfer(self.device, screen, texts):
            return True
        # 月光宝盒领取后的灵珠吞噬展示弹窗（"今天灵珠已经吃饱啦"）：
        # 点「关闭"，不是"点击空白处关闭"类型，点空白清不掉
        if dialogs.handle_orb_full(self.device, screen, texts):
            return True
        # 邮箱容量接近上限提示（驻留型模态，反复弹出；2026-10-18 run 7792f4：
        # 4 号被它从 05:52 挡到 08:06，liyao/jingji/haishi/huoyue 连环失败）
        if dialogs.handle_mailbox_full(self.device, screen, texts):
            return True
        # 军需官「消耗经验/铜币兑换属性」弹窗（2026-10-20 run 796973：4 号
        # 宗门任务被它挡住追踪面板判失败，随后 xunbao 两次尝试同样被挡）
        if dialogs.handle_merchant_exchange(self.device, screen, texts):
            return True
        # 「赛季等级提升 灵光点+1」通知条（2026-10-21 新赛季驻留弹窗：悬浮在
        # MEMBER_LIST_REGION 内，其「前往」按钮曾把队员列表区误判成 solo 视图）
        if dialogs.handle_season_popup(self.device, screen, texts):
            return True
        # 订单刷新确认弹窗（2026-10-21 妖灵渡口：点「取消」保孤品订单）
        if dialogs.handle_order_refresh_confirm(self.device, screen, texts):
            return True
        # 「同袍节」活动介绍弹窗（2026-10-25 新活动：三个按钮正好落在对话
        # 选项区，宗门任务会把它们当剧情选项连点 → 4 个号当天全挂）
        if dialogs.handle_tongpao_popup(self.device, screen, texts):
            return True
        # 家园「旅行吧喵喵」猫带礼物回来的模态弹窗（2026-10-31 3 号事故：
        # 挂着时家园右缘「离开」点 23 次全被吞，跑商开场复位 304s 判负）
        if dialogs.handle_pet_travel_gift(self.device, screen, texts):
            return True
        # 入队申请无响应提示弹窗（2026-11-08 6 号 xunbao：寻宝申请入队无人
        # 接受后弹出，驻留模态吞掉「点右缘离开」→ 连点 10 次判负 1041s）
        if dialogs.handle_team_apply_confirm(self.device, screen, texts):
            return True
        # ---- 以下 4 项是"低概率但必须处理"的专项检查：家园布置模式（AI 误点
        # 「布置」等误入，ESC 无效、右缘无「离开」，唯一出口是右缘「退出」+确认
        # 框——2026-10-13 账号5 卡死一上午的根因）/ 右侧
        # 任务提示卡 / 组队邀请弹窗 / 赐福令道具卡）。它们原先各自做一次区域
        # OCR，而 5 开并发下每次 OCR 调用的**固定开销**约 1 秒级——实测这条路
        # 单机预热就 5.2s，实机组队里一次 dismiss_popups 烧掉 17.4s。
        # 现在先用**一次**批量 OCR 把这些小区域一起探一遍，命中才调用原处理器：
        # 检查项一个没少（min_score 反而放宽到 0.4，比原处理器的 0.85 更宽容），
        # 而这 4 个弹窗都是**驻留型**（不点掉不会自己消失），漏一帧下一轮循环
        # 立刻补上，不会造成"整轮错过"。
        probe = ocr.scan_regions(screen, self.POPUP_PROBE_REGIONS, min_score=0.4)
        if any("观度" in t or "家园" in t for t, *_ in probe.get("hud", ())):
            if dialogs.handle_decor_exit(self.device, screen):
                return True
        if ocr.any_match(probe.get("hint", ()), "取消", 1.0):
            if dialogs.handle_hint_card(self.device, screen):
                return True
        if ocr.any_match(probe.get("invite_title", ()), "组队邀请", 0.8):
            # 标题已由批量探路确认，把结论直接传进处理器，省掉它重新截图 + OCR
            if self._accept_team_invite(screen, probe=(True, None)):
                return True
        if ocr.any_match(probe.get("fuka", ()), "赐福令", 0.75):
            if self.close_fuka_card(screen):
                return True
        # 未知弹窗通用兜底（2026-10-20 用户规则）：所有专项处理器都没命中时，
        # 找「返回」文字按钮或右上角 X 圆钮关闭。必须放在最后——它没有弹窗
        # 身份校验。军需官弹窗实测 X(347,221) 与「返回」(202,492) 均可退回主界面。
        if dialogs.handle_unknown_exit(self.device, screen, texts,
                                       matcher=self.matcher):
            return True
        return False

    # 「组队邀请」弹窗（标题 @ (202,265)，按钮「拒绝」(115,425) /「接受」(296,425)，
    # 与 zudui.ACCEPT_REGION 同源）。挂着不处理会挡住准备面板和一切点击。
    TEAM_INVITE_TITLE_REGION = (60, 240, 290, 60)
    TEAM_INVITE_ACCEPT_REGION = (235, 380, 120, 60)

    # dismiss_popups 里 4 个"顺带看一眼"的小区域，合并成一次 OCR（见该方法注释）。
    # 键名 → 对应处理器：hud=家园布置、hint=任务提示卡、invite_title=组队邀请、
    # fuka=赐福令道具卡。区域一律引用各处理器内部用的同一常量，不再抄字面量。
    POPUP_PROBE_REGIONS = [
        ("hud", dialogs.DECOR_HUD_REGION),
        ("hint", dialogs.HINT_CARD_CANCEL_REGION),
        ("invite_title", TEAM_INVITE_TITLE_REGION),
        ("fuka", ITEM_CARD_TITLE_REGION),
    ]
    TEAM_INVITE_ACCEPT_POS = (296, 425)   # "接受"兜底固定点（OCR 漏读时盲点）

    # 「组队邀请」弹窗的**快速探针**：标题 + 按钮两个区域，一次 OCR 同时看。
    # 等邀请是热路径（队员端要连续轮询几十秒），详见 probe_team_invite 注释。
    TEAM_INVITE_PROBE_REGIONS = [
        ("title", TEAM_INVITE_TITLE_REGION),
        ("accept", TEAM_INVITE_ACCEPT_REGION),
    ]

    def probe_team_invite(self, screen):
        """一次 OCR 判「组队邀请」弹窗，返回 ``(标题在否, 接受按钮坐标或 None)``。

        等等待邀请是**热路径**：队员端在"队长发邀请"前后要连续轮询几十秒，
        原实现每轮都要走一遍完整 ``dismiss_popups``（DIALOG_SCAN 大区域 +
        4 区域批量探路 = 2 次 OCR），进来后再单独读「组队邀请」「接受」，
        一轮共 3~4 次 OCR。5 开并发时每次 OCR 有 1~2 秒**固定开销**，于是
        轮询周期被撑到 5~8 秒——2026-10-13 实测队员端"队长播报邀请 →
        点掉接受"要 5~14 秒，根因就在这里（不是点击慢）。

        这里把标题区和按钮区拼成一张图只调一次引擎，命中路径从 3~4 次
        OCR 降到 1 次（``debug/_verify_invite_probe.py`` 用实机帧比对）。
        """
        probe = ocr.scan_regions(screen, self.TEAM_INVITE_PROBE_REGIONS,
                                 min_score=0.5)
        title_up = ocr.any_match(probe.get("title", ()), "组队邀请", 0.8)
        hit = None
        for text, cx, cy, _score in probe.get("accept", ()):
            if ocr.any_match((text,), "接受", 0.6):
                hit = (cx, cy)
                break
        return title_up, hit

    def _accept_team_invite(self, screen, probe=None):
        """有未处理的「组队邀请」弹窗且协调器在跑 → 点「接受」，
        **弹窗消失才算接受成功**（最多点 3 次）。

        队员接受邀请的点击偶发失效（窗口置前失败/弹窗动画），弹窗会一直挂在
        屏幕上：该队员收不到副本邀请、看不到准备面板，整队少人
        （2026-10-12 实测 6 号因此缺席海市蜃楼）。协调器运行期间见到邀请
        一律接受（5 开流程里只可能是队长的邀请）。

        2026-10-13：判定从"按钮文字消失"改为"**弹窗标题消失**"——按钮文字
        OCR 会整批漏读（5 开并发时常见），漏读≠弹窗没了，误判成功会让弹窗
        继续挂着；漏读时按固定坐标盲点"接受"。

        2026-10-13 二次优化：改用 `probe_team_invite()`（一次 OCR 看标题+按钮），
        不再每次重新截图 + 两次区域 OCR；调用方已经探过时通过 `probe` 传入，
        连这一次都省掉。
        """
        from core import teamup
        if not teamup.coordinator().begun:
            return False

        if probe is None:
            probe = self.probe_team_invite(screen)
        title_up, hit = probe
        if not title_up:
            return False
        for attempt in range(1, 4):
            pos = hit if hit else self.TEAM_INVITE_ACCEPT_POS
            if hit:
                log.info("发现未处理的组队邀请弹窗，点击 [接受] #%d @ (%d, %d)",
                         attempt, *pos)
            else:
                # 弹窗在（标题已确认）但"接受"二字 OCR 漏读 → 固定坐标盲点
                log.info("组队邀请弹窗在但「接受」OCR 未命中，按固定坐标盲点 @ (%d, %d)",
                         *pos)
            self.device.click(*pos)
            # 用户规则 2026-10-13：不要拟人化长停顿——只等界面响应，轮询复查
            pace.wait(0.35, 0.6)
            title_up, hit = self.probe_team_invite(self.device.screenshot())
            if not title_up:
                return True  # 弹窗消失 = 接受成功
        log.warning("组队邀请点 3 次接受弹窗仍未消失")
        return True  # 已尽力点过，占用本轮弹窗处理（下帧 dismiss 还会再来）

    def open_backpack(self, timeout=8):
        """从主界面打开背包（公共入口，多个任务复用）。成功返回 True。"""
        return bool(self.matcher.find_and_click(
            self.device, "背包", timeout=timeout,
            region=BEIBAO_REGION, ccoeff_floor=0.45))

    def open_wanfa(self, timeout=8):
        """从主界面打开玩法面板（公共入口）。点击可能被吞，打不开就再点，最多 3 次。

        注意盲点（实测连环中招）：点击生效后面板打开会盖住左侧"玩法"图标，
        重试时图标模板必然找不到（报"未找到模板: 玩法"误判失败）——所以每轮
        先查"今日经验"标记，面板已开直接成功，确认没开才点击。

        2026-10-17 补：图标找不到**不能只原地再点**。实测两处"未找到模板: 玩法"
        （5 号 zhongkui 组队刚回主界面 / 5 号 liyao 第 2 次）都是主界面残留浮层
        （结算、提示、赐福令卡）或人还在副本场景里——左列图标被盖住/本就不存在。
        现在每轮失败先 `dismiss_popups()` 清浮层，仍不在主城就 `_escape_special_scene()`
        退出副本，再重试。
        """
        for i in range(3):
            if self.matcher.find(self.device.screenshot(), "今日经验",
                                 region=WANFA_MARK_REGION, threshold=0.8):
                return True  # 面板已打开（上次点击其实生效了）
            hit = self._find_wanfa_icon(timeout=timeout)
            if not hit:
                # 图标都找不到：面板可能已打开挡住了，最后再确认一次标记
                if self.matcher.find(self.device.screenshot(), "今日经验",
                                     region=WANFA_MARK_REGION, threshold=0.8):
                    return True
                log.warning("未找到「玩法」图标（第 %d/3 次），清浮层/退特殊场景后重试",
                            i + 1)
                self.dismiss_popups()
                self._escape_special_scene()
                continue
            log.info("点击 [玩法] @ (%d, %d) score=%.3f", hit[0], hit[1], hit[2])
            self.device.click(hit[0], hit[1])
            deadline = time.time() + timeout
            while time.time() < deadline:
                if self.matcher.find(self.device.screenshot(), "今日经验",
                                     region=WANFA_MARK_REGION, threshold=0.8):
                    return True
                pace.wait(0.6)
            log.warning("玩法面板未打开，重试点击 (%d/3)", i + 1)
        log.warning("玩法面板多次点击未打开")
        return False

    def probe_input_alive(self, timeout=4, settle=3.0):
        """轻量探针：本窗口**还收不收得动点击**（2026-10-29 整窗失灵看门狗）。

        判据不用"画面有没有变化"——主城一直在动（NPC 行走/水波/宠物跟随），
        画面 hash 必然变化，会误判成"活着"；也不用" wondered open_wanfa()"
        （它带清场+退场景，最坏要一分多钟，当探针太重）。这里只做最小动作：
        点主界面必定存在的「玩法」图标，看玩法面板（"今日经验"标记）开不开。

        **只在确认处于主界面时才下结论**：不在主界面（副本/面板/对话中）说明
        不了问题，一律返回 True（宁可不判死，绝不误杀正常账号——误关正常
        客户端要重登几分钟，代价远大于让一个号多跑几个失败任务）。
        """
        try:
            screen = self.device.screenshot()
            if not self.on_main_screen(screen):
                return True
            if self.matcher.find(screen, "今日经验", region=WANFA_MARK_REGION,
                                 threshold=0.8):
                return True   # 面板本来就开着
            hit = self._find_wanfa_icon(screen=screen)
            if not hit:
                return True   # 图标都找不到（浮层遮挡/不在主城）→ 不判死
            log.info("探针：点击 [玩法] @ (%d, %d) score=%.3f",
                     hit[0], hit[1], hit[2])
            self.device.click(hit[0], hit[1])
            opened_by_me = False
            deadline = time.time() + settle
            while time.time() < deadline:
                if self.matcher.find(self.device.screenshot(), "今日经验",
                                     region=WANFA_MARK_REGION, threshold=0.8):
                    opened_by_me = True
                    break
                pace.wait(0.5)
            if not opened_by_me:
                return False
            # 探针自己点开的面板要关掉，别把状态丢给下一个任务（点返回箭头，
            # 顺带二次确认"点击确实生效"）
            self.device.click(*PANEL_BACK_POS)
            pace.wait(0.8, 1.2)
            return True
        except Exception:
            log.exception("输入存活探针异常，按存活处理")
            return True

    def find_anchor(self, screen, name, threshold=0.88, ccoeff_floor=0.45):
        """匹配主界面左列锚点（活动/玩法/商城）：**先窄区域，全 miss 再放宽**。

        2026-11-02：图标整列上移 14px 时窄区域会裁掉模板（窄全 None / 宽松
        0.9725），旧代码因此在主界面里判"不在主界面"。精度优先，所以只在
        窄区域失败后才用宽松区域复测。
        """
        for regions in (MAIN_ANCHOR_REGIONS, MAIN_ANCHOR_REGIONS_LOOSE):
            region = regions.get(name)
            if not region:
                continue
            hit = self.matcher.find(screen, name, region=region,
                                    threshold=threshold,
                                    ccoeff_floor=ccoeff_floor)
            if hit:
                return hit
        return None

    def _find_wanfa_icon(self, timeout=8, screen=None):
        """等「玩法」图标出现，返回 (cx, cy, score)；找不到返回 None。

        区域策略同 `find_anchor`：窄区域优先，miss 后用 `WANFA_REGION_LOOSE`
        复测（图标上移 14px 的实测场景）。`screen` 传入则只用这一帧、
        不重复截图（调用方已有现成截图时省一次抓屏）。
        """
        deadline = time.time() + timeout
        while True:
            cur = screen if screen is not None else self.device.screenshot()
            for region in (WANFA_REGION, WANFA_REGION_LOOSE):
                hit = self.matcher.find(cur, "玩法", region=region,
                                        threshold=0.88, ccoeff_floor=0.45)
                if hit:
                    return hit
            if screen is not None or time.time() >= deadline:
                return None
            pace.wait(0.4)

    def on_guild_panel(self, screen=None):
        """画面是否停在**帮会/编队面板**（会盖住左列图标、保留顶部 HUD）。

        2026-11-06 事故：一键组队后 exit_panel_to_home 把这块面板误判成主界面
        （左列「商城」锚点在面板左缘仍能匹配到 @ (33,331)），于是面板一直开着；
        随后队长端在 (275,105,130,125) 读「队伍人数」，读到的全是帮会徽章旁的
        服务器名「荣耀·天极12」和「等待回复」，人数 1~2 → 判 4 人缺席 →
        把**真的组好了**的 5 人队解散重来 → 手动建队又卡住 → 组队判负，
        haishi/liudao/zhongkui/打地鼠 连环失败（11-05、11-06 全天）。

        判定用「成员/编队/新闻 三个页签里命中 ≥2」或编队页专属字样
        （帮会资金/队伍需求/一键组队/查看编队），主界面上不会同时出现。
        """
        screen = self.device.screenshot() if screen is None else screen
        try:
            texts = [t for t, *_ in ocr.scan(screen, GUILD_PANEL_REGION,
                                             min_score=0.55)]
        except Exception:
            return False
        joined = " ".join(texts)
        if sum(1 for k in GUILD_PANEL_TABS if k in joined) >= 2:
            return True
        return any(m in joined for m in GUILD_PANEL_MARKS)

    def on_main_screen(self, screen):
        """主界面判定：活动/玩法/商城/背包任一锚点命中即可。

        红点角标或遮挡会让单个图标偶发匹配失败（实测活动带红点时
        CCOEFF 二次验证 0.439 < 0.45 被拒），所以多个锚点任一命中即算。
        **背包是兜底锚点：在队伍中时左列会变（"活动"隐藏、"玩法/商城"
        移位带红点），三个左列锚点全 miss，但背包图标恒定——不兜底的后果是
        ensure_main_screen 在主界面死循环按 ESC、永远走不到 leave_team
        （2026-10-10 实测：组队后跑收尾任务，活跃奖励/整理背包连环失败）**。
        """
        for name in MAIN_ANCHOR_REGIONS:
            # find_anchor 内部：窄区域优先，miss 后放宽（图标上移 14px 的实测场景）
            if self.find_anchor(screen, name):
                return True
        return bool(self.matcher.find(screen, "背包", region=BEIBAO_REGION,
                                      threshold=0.88, ccoeff_floor=0.45))

    def close_blank_popup(self, screen=None, rounds=3):
        """关掉**当前画面上**的"点击空白处关闭"类奖励/结算弹窗（已有一帧截图
        时可传入复用，省一次识别）。

        - 点击位置按提示文字实际坐标动态算（`reward_blank_pos`），不再写死
          BLANK_CLICK_POS —— 大弹窗会把它盖住（2026-10-27 海市结算事故）；
        - 连锁弹窗（关掉第一个立刻弹第二个，月光宝盒实测）要连点几轮。
        返回是否点过（画面上本来就没这类弹窗 → False）。
        """
        acted = False
        cur = screen if screen is not None else self.device.screenshot()
        for _ in range(rounds):
            hit = ocr.find_text(cur, "点击空白处关闭", region=REWARD_POPUP_REGION)
            if not hit:
                break
            pos = reward_blank_pos(cur, hit=hit) or BLANK_CLICK_POS
            log.info("点空白关闭奖励/结算弹窗 @ (%d, %d)", *pos)
            self.device.click(*pos)
            acted = True
            pace.wait(1.0, 1.5)
            cur = self.device.screenshot()
        return acted

    def close_reward_popup(self, timeout=8):
        """等"点击空白处关闭"弹窗出现，点空白关掉；没弹窗则直接返回。"""
        deadline = time.time() + timeout
        screen = None
        hit = None
        while time.time() < deadline:
            screen = self.device.screenshot()
            hit = ocr.find_text(screen, "点击空白处关闭",
                                region=REWARD_POPUP_REGION)
            if hit:
                break
            screen, hit = None, None
            pace.wait(0.5)
        if screen is None:
            log.warning("未等到奖励弹窗")
            return False
        clicks = 0
        while clicks < 8:
            self.device.click(*(reward_blank_pos(screen, hit=hit)
                                or BLANK_CLICK_POS))
            clicks += 1
            pace.wait(1.0, 1.6)
            screen = self.device.screenshot()
            hit = ocr.find_text(screen, "点击空白处关闭",
                                region=REWARD_POPUP_REGION)
            if hit:
                continue
            # 弹窗消失后可能**立刻弹出下一个连锁奖励弹窗**（月光宝盒实测：
            # 关掉第一个马上弹第二个），稍等再确认一次，还在就继续点
            pace.wait(0.8, 1.2)
            if not ocr.find_text(self.device.screenshot(), "点击空白处关闭",
                                 region=REWARD_POPUP_REGION):
                return True
        log.warning("奖励弹窗关不掉（已点 %d 次空白）", clicks)
        return False

    def exit_panel_to_home(self):
        """点面板左下角返回箭头回主界面，失败按 ESC 兜底。

        "点击空白处关闭"类弹窗会挡住返回箭头，遇到先点空白关掉。
        **帮会/编队面板必须先单独关掉**（2026-11-06）：它保留顶部 HUD、左缘还能
        匹配到「商城」锚点，`on_main_screen` 会误判成主界面直接 return —— 面板
        留在屏上，后面所有"队伍人数/页签"识别都读在这块面板上，一键组队组好的
        5 人队被当成 1~2 人解散（11-05/11-06 组队副本全灭的直接原因）。
        """
        for _ in range(4):
            screen = self.device.screenshot()
            if self.on_main_screen(screen):
                # 帮会/编队面板会被 on_main_screen 误判成主界面（左缘还能匹配到
                # 「商城」锚点）——主界面判定为真时必须再确认一次，否则面板
                # 会一直挂在屏上，后面的队伍识别全读错。
                if not self.on_guild_panel(screen):
                    log.info("已返回主界面")
                    return
                log.info("画面是帮会/编队面板（会被 on_main_screen 误判成主界面），"
                         "点左下返回箭头关闭")
                self.device.click(*GUILD_BACK_POS)
                pace.wait(1.0, 1.5)
                if self.on_guild_panel():
                    self.device.click(*PANEL_BACK_POS)
                    pace.wait(1.0, 1.5)
                continue
            hit = ocr.find_text(screen, "点击空白处关闭", region=REWARD_POPUP_REGION)
            if hit:
                self.device.click(*(reward_blank_pos(screen, hit=hit)
                                    or BLANK_CLICK_POS))
                pace.wait(1.0, 1.5)
                continue
            self.device.click(*PANEL_BACK_POS)
            pace.wait(1.0, 1.5)
        log.warning("返回箭头未生效，按 ESC 兜底")
        self.back_to_home()

    def settle_home(self, rounds=4, do_exit=True):
        """任务收尾：回主界面并**清扫残留弹窗**，保证"长安无弹窗"再交给下一项
        （用户规则 2026-10-13：每个任务的最后必须维持无弹窗状态）。

        exit_panel_to_home 的主界面判定靠左列图标锚点——弹窗盖在主界面上时
        锚点照样命中（2026-10-13 02:05 月光宝盒领取后实测：日志"已返回主界面"
        但弹窗还挂着，挡住下一个任务）。所以到达主界面后还要连扫几轮：
        通用弹窗（dismiss_popups）+ 奖励弹窗（点空白），直到一整轮既没有弹窗
        被处理、也没有"点击空白处关闭"字样才算干净；连扫 rounds 轮仍有弹窗
        则存截图留证据（settle_home_popup）。
        """
        if do_exit:
            self.exit_panel_to_home()
        cleaned = False
        for _ in range(rounds):
            screen = self.device.screenshot()
            if self.dismiss_popups(screen):
                cleaned = True
                pace.wait(0.8, 1.2)
                continue
            hit = ocr.find_text(screen, "点击空白处关闭", region=REWARD_POPUP_REGION)
            if hit:
                log.info("任务收尾：发现残留奖励弹窗，点空白关闭")
                self.device.click(*(reward_blank_pos(screen, hit=hit)
                                    or BLANK_CLICK_POS))
                cleaned = True
                pace.wait(1.0, 1.6)
                continue
            if cleaned:
                log.info("任务收尾：残留弹窗已清完，主界面无弹窗")
            return
        self.save_debug_screenshot("settle_home_popup")
        log.warning("问题：任务收尾连续 %d 轮仍有弹窗关不完，已存截图 "
                    "settle_home_popup（下个任务开始前还会再处理一轮）", rounds)

    def enter_guild_activity(self, timeout=10):
        """主界面 → 帮会面板 → 活动页（帮会地图）。帮会类任务的公共入口。

        点"帮会"可能被吞（面板没开），等不到打开标志就再点，最多 3 次。
        必须区分"面板没打开"和"面板打开但未入帮"（实测：被顶号/点击被吞时
        面板根本没打开过，不能据此下未入帮结论）。返回 True / "no_guild" / False：
        - 面板打开且看到"新闻"页签或"回帮"按钮 → 在帮，继续进活动页；
        - 面板打开但显示"加入帮会"界面 → "no_guild"；
        - 3 次点击后面板都没打开 → False（走任务级重试）。
        """
        self.dismiss_popups()
        panel_open = False
        in_guild = False
        for i in range(3):
            if not self.matcher.find_and_click(self.device, "帮会", timeout=8,
                                               region=BANGHUI_REGION, ccoeff_floor=0.45):
                return False
            deadline = time.time() + timeout
            while time.time() < deadline:
                # 在帮会的判定：顶部"新闻"页签（各页都有）或"回帮"按钮（只有
                # 成员页有——面板会记住上次停留页签，编队页没有回帮，只看
                # 回帮会把在帮误判成未入帮，实测队长号中招）
                screen = self.device.screenshot()
                if (ocr.find_text(screen, "新闻", region=(190, 170, 90, 45),
                                  min_similarity=1.0)
                        or ocr.find_text(screen, "回帮", region=GUILD_BTN_REGION,
                                         min_similarity=1.0)):
                    panel_open = in_guild = True
                    break
                if ocr.contains_text(screen, "加入帮会", region=GUILD_JOIN_REGION):
                    panel_open = True  # 面板开着但停在加入帮会界面 = 未入帮
                    break
                pace.wait(0.6)
            if panel_open:
                break
            log.warning("帮会面板未打开，重试点帮会 (%d/3)", i + 1)
        if not panel_open:
            log.warning("帮会面板多次点击仍未打开，无法判定入帮状态")
            return False
        if not in_guild:
            log.info("未加入帮会（面板显示加入帮会界面），跳过帮会任务")
            self.exit_panel_to_home()
            return "no_guild"
        # 活动页签切换 + 地图加载可能较慢，给足等待
        deadline = time.time() + timeout + 5
        clicked_fallback = False
        while time.time() < deadline:
            screen = self.device.screenshot()
            if self.matcher.find(screen, "战利品", region=GUILD_MAP_REGION,
                                 threshold=0.8):
                log.info("已进入帮会活动页")
                return True
            hit = ocr.find_text(screen, "活动", region=GUILD_TAB_REGION,
                                min_similarity=1.0)
            if hit:
                log.info("点击 [帮会活动页签] @ (%d, %d)", hit[0], hit[1])
                self.device.click(hit[0], hit[1])
                pace.wait(1.5, 2.2)  # 地图加载可能慢，靠下一轮轮询等条件
                continue
            elif not clicked_fallback:
                clicked_fallback = True
                self.device.click(*GUILD_TAB_POS)
            pace.wait(0.8, 1.2)
        log.warning("进入帮会活动页超时")
        return False

    def save_debug_screenshot(self, tag):
        DEBUG_DIR.mkdir(exist_ok=True)
        path = DEBUG_DIR / f"{int(time.time())}_{tag}.png"
        from core import imgio
        imgio.imwrite(path, self.device.screenshot())
        log.info("已保存调试截图: %s", path)
        return path

    def report_unknown(self, tag, screen=None, note="", ai=True):
        """遇到脚本无法判定的场景 / 该出现的图案没出现 / 疑似卡死时调用。

        统一做三件事（不抛异常、不改变控制流，只做"上报"）：
          1. 把当前画面存到 debug/unknown/<任务名>__<tag>__<时间戳>.png（不覆盖、可追溯）；
          2. 以 WARNING 级打「问题：…（需要确认）」日志 —— 可被
             `python tools/logdigest.py --problems` 汇总，也会进该账号的
             debug/accounts/<标签>.log；
          3. 返回截图路径，方便调用方继续用。

        `tag` 用简短的英文/拼音场景名（如 no_signpost / no_tool_bubble /
        make_button_gone），`note` 写人看得懂的补充说明（含坐标、相似度等）。
        用户看到日志里的「需要确认」后，看图说明该怎么处理，再把分支补进任务。

        **AI 兜底（2026-10-12）**：若 config.yaml 配好了 `ai.enabled` + `api_key`，
        这里会先把画面交给多模态模型看一眼，能在白名单内处理就直接处理掉——存一张
        `ai_` 前缀的存档图 + INFO 日志，**不进「问题」清单、不惊动人**；模型没帮上
        忙才走上面的老路。本函数的契约不变（不抛异常、不改变控制流），只是「需要人
        介入」的场景变少了。`ai=False` 可关掉单次尝试（调试用）。
        """
        img = self.device.screenshot() if screen is None else screen
        if ai and self.ai_recover(tag, screen=img, note=note):
            path = self._save_unknown(tag, img, prefix="ai_")
            log.info("「%s」待确认场景 %s 已由 AI 兜底处理（存档 %s）",
                     self.title, tag, path)
            return path
        path = self._save_unknown(tag, img)
        log_problem(log, "「%s」遇到待确认场景 %s%s；截图 %s",
                    self.title, tag, ("（" + note + "）") if note else "", path)
        return path

    def _save_unknown(self, tag, screen, prefix=""):
        """把画面存到 debug/unknown/ 并返回路径（存图失败不影响任务主流程）。"""
        UNKNOWN_DIR.mkdir(parents=True, exist_ok=True)
        path = UNKNOWN_DIR / f"{prefix}{self.name}__{tag}__{int(time.time())}.png"
        try:
            from core import imgio
            imgio.imwrite(path, screen)
        except Exception as e:
            log.warning("留存未知场景截图失败: %s", e)
        return path

    def ai_recover(self, tag, screen=None, note="", extra_rules=""):
        """把「脚本认输」的画面交给多模态模型，并在白名单内代做操作。

        返回 True = AI 确实动了手（画面可能已推进）；False = 没帮上忙
        （未配置 / 到调用上限 / 网络失败 / 模型也看不懂）。

        ⚠️ 调用方**不要**依赖返回值改变控制流：AI 只是「帮忙把画面理回正轨」，
        之后原有的重试与兜底逻辑照旧生效——这样即使模型判断错了也不会更糟。

        队员端（_is_following_member）一律不调用：用户规则要求队员只等队长信号。

        ## 2026-10-14 四项增强（用户要求"把路线 A 做出来"）

        1. **战斗优先判定**：进 AI 之前先跑 `_in_battle_any()`（战况 OR 顶部
           "第N回合/阶段"）。战斗中直接返回 False——不当场叫模型，而是让调用方
           原逻辑去点"自动"/等打完。今天实测：模型会把战斗画面误判成"该点任务
           按钮"，白烧 3 步。
        2. **动作历史**：本次兜底已试过、且画面没推进的动作拼进提示词
           （`attempts`），并落进 `_ai_tried` 做本地拦截——从根上治"原地绕圈"
           （今天 huoyue/zhanling 反复点同一个"任务"按钮）。
        3. **重复动作拦截**：同一动作签名（click_text:文字 / click_pos:坐标格）
           试过 2 次就拒绝再执行，逼模型换思路或 give_up。
        4. **click_pos 兜底增强**：模型漏给 x/y 或给 `near`（旁边文字）时，
           用 OCR 找到那段文字、按相对比例微调落点，比纯比例坐标可靠得多。
        """
        from core import aihelper
        if self._is_following_member():
            return False
        if not aihelper.available():
            return False
        if self._ai_calls >= self._ai_max_calls:
            log.info("AI 兜底：本任务已达调用上限（%d 次），跳过", self._ai_max_calls)
            return False
        cfg = aihelper.config()
        allowed = aihelper.allowed_actions()
        try:
            max_steps = max(1, int(cfg.get("max_steps") or 3))
        except (TypeError, ValueError):
            max_steps = 3
        try:
            budget = time.time() + max(10.0, float(cfg.get("total_timeout") or 90))
        except (TypeError, ValueError):
            budget = time.time() + 90.0
        img = self.device.screenshot() if screen is None else screen
        # ① 战斗优先：战斗中不叫模型（会把战斗误判成"该点任务按钮"）
        if self._in_battle_any(img):
            log.info("AI 兜底：当前是战斗画面，跳过 AI（交给原逻辑点自动/等打完）")
            return False
        handled = False
        tried = []            # 已试过且无进展的动作签名（跨 step 累积）
        tried_desc = []       # 给模型看的动作描述
        try:
            for step in range(1, max_steps + 1):
                self._check_stop()        # 用户停止 / 任务超时优先于 AI
                if time.time() > budget:
                    log.warning("AI 兜底：整体超时，停止（已动手 %d 步）", step - 1)
                    return handled
                texts = [t for t, *_ in ocr.scan(img, min_score=0.6)][:40]
                self._ai_calls += 1
                res = aihelper.analyze(img, task_title=self.title, tag=tag, note=note,
                                       stage=self._stage, texts=texts,
                                       extra_rules=extra_rules, attempts=tried_desc)
                if res is None:
                    return handled
                action = str(res.get("action") or "").strip().lower()
                log.info("AI 兜底[%d/%d]：画面=「%s」｜判断=「%s」｜动作=%s（模型用时 %ss）",
                         step, max_steps, res.get("scene") or "?",
                         res.get("reasoning") or "?", action or "?", res.get("_elapsed"))
                if action in ("", "none", "give_up"):
                    log.info("AI 兜底：模型表示处理不了，交给人工兜底")
                    return handled
                if action not in allowed:
                    log.warning("AI 兜底：动作 %r 不在白名单（%s）内，拒绝执行",
                                action, "、".join(allowed))
                    return handled
                # ③ 重复动作拦截：同一动作签名试过 2 次仍无进展，拒绝再执行，
                # 逼模型（下一轮）换思路或 give_up——治"原地绕圈"。
                sig = self._ai_action_sig(action, res)
                if sig and tried.count(sig) >= 2:
                    log.warning("AI 兜底：动作 %s 已重复 %d 次仍无进展，拒绝再执行"
                                "（防原地绕圈）", sig, tried.count(sig))
                    tried_desc.append(f"{sig}（已重复 {tried.count(sig)} 次，无效）")
                    return handled
                before = img
                # 死胡同面板（妖灵渡口/九霄塔）拦截：点进去出不来，
                # 2026-11-02 早轮 3/4/6 号全被它拖死
                block = self._ai_deadend_guard(res, img)
                if block:
                    return True if block == "escaped" else handled
                if not self._apply_ai_action(action, res, img):
                    return handled
                handled = True
                if sig:
                    tried.append(sig)
                    tried_desc.append(f"{sig} → 未见效")
                self._check_stop()
                time.sleep(random.uniform(0.8, 1.5))
                img = self.device.screenshot()
                # 画面没变也算"无进展"：把这一步记进历史，下一轮提示模型换招
                if before is not None and self._ai_same_screen(before, img) and sig:
                    log.info("AI 兜底：第 %d 步动作后画面无变化（%s），记入无效动作",
                             step, sig)
        except (TaskStopped, TaskTimeout):
            raise                          # 用户停止 / 任务超时：立即生效，不吞
        except Exception as e:             # 其它异常一律不影响任务主流程
            log.warning("AI 兜底：执行出错已跳过（%s: %s）", type(e).__name__, e)
        return handled

    @staticmethod
    def _ai_action_sig(action, res):
        """动作签名：用于判"是否在重复同一个动作"。
        click_text 用文字（归一化去空格）；click_pos 用 10x10 网格格位；
        drag/esc/wait 直接按动作名。拿不到关键字段时返回 None（不拦）。"""
        if action == "click_text":
            t = "".join(str(res.get("target") or "").split())
            return f"click_text:{t}" if t else None
        if action in ("click_pos", "drag"):
            try:
                x, y = float(res.get("x")), float(res.get("y"))
            except (TypeError, ValueError):
                # 只给了 near（旁边文字）时，用 near 做签名
                near = "".join(str(res.get("near") or "").split())
                return f"{action}:near:{near}" if near else None
            return f"{action}:{int(x * 10)},{int(y * 10)}"
        return action or None

    @staticmethod
    def _ai_same_screen(a, b, sample=48):
        """两张截图是否"基本没变"（粗粒度采样比对，防光照微抖）。
        用于判断"这一步动作有没有让画面推进"。"""
        try:
            import numpy as np
            ga = np.asarray(a)[::sample, ::sample].astype("int16")
            gb = np.asarray(b)[::sample, ::sample].astype("int16")
            if ga.shape != gb.shape:
                return False
            return float(np.abs(ga - gb).mean()) < 6.0
        except Exception:
            return False

    def _ai_deadend_guard(self, res, screen=None):
        """拦住把画面点进「死胡同面板」的 AI 动作（2026-11-02）。

        两类拦截：
        1. 动作目标（target/near）里含死胡同面板名 → 直接拒绝执行（模型最爱点
           任务追踪里的「妖灵渡口」，那就是宠物界面，进去出不来）；
        2. 画面**已经**停在妖灵渡口/九霄塔面板（只认左上角标题区，不认全屏
           文字——主城任务追踪里也常挂着「妖灵渡口/前往」，全屏匹配会误判成
           "人在面板里"）→ 不管模型想点什么，先按 ESC 退出去（继续在里面点
           加速/收取只是白烧 AI 调用额度）。

        `shouyi`（妖灵渡口订单）等任务用 AI_DEADEND_ALLOW_TASKS 放行。
        返回 "refuse"（只拒绝，没动手）/ "escaped"（已按 ESC 退出）/ ""（放行）。
        """
        if self.name in AI_DEADEND_ALLOW_TASKS:
            return ""
        blob = " ".join(str(res.get(k) or "") for k in ("target", "near", "text"))
        for word in AI_DEADEND_WORDS:
            if word and word in blob:
                log.warning("AI 兜底：目标「%s」命中死胡同面板「%s」，拒绝点击"
                            "（进去回不到主界面）", blob.strip(), word)
                return "refuse"
        if screen is not None:
            texts = [t.replace(" ", "")
                     for t, *_ in ocr.scan(screen, AI_DEADEND_TITLE_REGION,
                                           min_score=0.6)]
            if any(w in t for t in texts for w in ("妖灵渡", "九霄塔")):
                log.warning("AI 兜底：画面停在妖灵渡口/九霄塔面板，先按 ESC 退出")
                self.device.press_esc()
                pace.wait(0.8, 1.2)
                return "escaped"
        return ""

    def _apply_ai_action(self, action, res, screen):
        """执行模型给的动作（调用前已过白名单）。返回是否真的执行了操作。"""
        from core import aihelper
        h, w = screen.shape[:2]
        if action == "click_text":
            target = str(res.get("target") or "").strip()
            if not target:
                log.warning("AI 兜底：click_text 没给 target，放弃")
                return False
            for word in aihelper.forbid_targets():
                if word and word in target:
                    log.warning("AI 兜底：目标「%s」命中禁用词「%s」，拒绝点击", target, word)
                    return False
            hit = ocr.find_text(screen, target, min_similarity=0.7)
            if hit:
                log.info("AI 兜底：OCR 定位到「%s」@ (%d, %d)（相似度 %.2f），点击",
                         target, hit[0], hit[1], hit[2])
                self.device.click(hit[0], hit[1])
                return True
            log.warning("AI 兜底：OCR 没能在画面上定位「%s」，改用模型给的比例坐标", target)
            return self._ai_click_pos(res, w, h)
        if action == "click_pos":
            return self._ai_click_pos(res, w, h)
        if action == "drag":
            try:
                x, y = float(res.get("x")), float(res.get("y"))
                x2, y2 = float(res.get("x2")), float(res.get("y2"))
            except (TypeError, ValueError):
                log.warning("AI 兜底：drag 坐标缺失或非法，放弃")
                return False
            if not all(0.0 <= v <= 1.0 for v in (x, y, x2, y2)):
                log.warning("AI 兜底：drag 坐标 (%s,%s)→(%s,%s) 超出 0~1，拒绝",
                            res.get("x"), res.get("y"), res.get("x2"), res.get("y2"))
                return False
            self.device.drag(self._ai_px(x, w), self._ai_px(y, h),
                             self._ai_px(x2, w), self._ai_px(y2, h))
            log.info("AI 兜底：滑动 (%.2f,%.2f) → (%.2f,%.2f)", x, y, x2, y2)
            return True
        if action == "esc":
            log.info("AI 兜底：按一次 ESC")
            self.device.press_esc()
            return True
        if action == "wait":
            try:
                sec = float(res.get("seconds") or 3)
            except (TypeError, ValueError):
                sec = 3.0
            sec = min(15.0, max(0.5, sec))
            log.info("AI 兜底：等待 %.1f 秒", sec)
            time.sleep(sec)
            return True
        return False

    @staticmethod
    def _ai_px(ratio, size):
        """把 0~1 的比例坐标换算成客户区像素（夹在画面内，避免点到边缘外）。"""
        return max(2, min(int(size) - 3, int(round(float(ratio) * int(size)))))

    def _ai_click_pos(self, res, w, h):
        """按模型给的比例坐标点击（click_text 定位失败 / 纯图标时的兜底路径）。

        2026-10-14 增强（治"click_pos 缺 x/y 就放弃"——今天 zudui/huoyue 各踩
        一次，模型明明给了判断却因为漏一个字段直接放弃）：
        - 有 `near`（旁边文字标签）→ 用 OCR 找到那段文字，再按 x/y 相对它微调
          （比纯比例坐标可靠得多；这也是提示词里推荐给纯图标的写法）；
        - 缺 x/y 但有 near → 直接点那段文字（图标通常就在文字旁/上）；
        - 缺 x/y 且无 near → **弃权**（2026-10-23 起）：旧版点客户区中心
          "碰运气"，当天实测 9 次 0 收益（全是无效动作还可能点错东西），
          改为返回 False 交给任务级重试。
        - x/y 超界 → 夹回边界而不是拒绝。
        """
        near = str(res.get("near") or "").strip()
        try:
            x, y = float(res.get("x")), float(res.get("y"))
            has_xy = True
        except (TypeError, ValueError):
            has_xy = False
        if has_xy and not (0.0 <= x <= 1.0 and 0.0 <= y <= 1.0):
            log.warning("AI 兜底：比例坐标 (%s, %s) 超出 0~1，夹回边界",
                        res.get("x"), res.get("y"))
            x = min(1.0, max(0.0, x))
            y = min(1.0, max(0.0, y))
        if near:
            hit = ocr.find_text(self.device.screenshot(), near, min_similarity=0.7)
            if hit:
                ax, ay = hit[0], hit[1]
                if has_xy:
                    # x/y 相对"near 文字"的位置微调：把 near 当锚点，图标一般
                    # 在它左上/右上。这里用 x/y 的横向偏移（-0.1~0.1）做小修正。
                    dx = int(round((x - 0.5) * 80))
                    dy = int(round((y - 0.5) * 80))
                    cx = max(2, min(w - 3, ax + dx))
                    cy = max(2, min(h - 3, ay + dy))
                    log.info("AI 兜底：以「%s」@ (%d,%d) 为锚点微调(%+d,%+d) → 点击 (%d,%d)",
                             near, ax, ay, dx, dy, cx, cy)
                else:
                    cx, cy = ax, ay
                    log.info("AI 兜底：按 near「%s」定位（模型未给坐标）→ 点击 (%d,%d)",
                             near, cx, cy)
                self.device.click(cx, cy)
                return True
            log.warning("AI 兜底：near「%s」在画面上没找到，回退比例坐标", near)
        if has_xy:
            cx, cy = self._ai_px(x, w), self._ai_px(y, h)
            log.info("AI 兜底：按比例坐标 (%.3f, %.3f) → 客户区 (%d, %d)", x, y, cx, cy)
            self.device.click(cx, cy)
            return True
        # 2026-10-23：点客户区中心兜底**禁用**——当天 run c7e254 实测 9 次
        # 点中心全部无效（0 收益，还可能点错东西白烧步数）。改为直接弃权
        # （返回 False），这一步不计入"已动手"，由任务级重试接手。
        log.warning("AI 兜底：OCR 未定位、模型又没给可用坐标（x/y/near 均缺），"
                    "弃权这一步（点中心兜底已禁用：实测 0 收益）")
        return False
