import logging
import random
import time

from core import ocr
from tasks.base import Task, TaskSkipped

log = logging.getLogger("task.paoshang")

# 以下均为 405x720 客户区坐标（帮会入口/活动页切换在 tasks/base.py 的 enter_guild_activity）
CAMEL_POS = (100, 390)                    # 帮会地图上的跑商骆驼（建筑位置固定）
CAMEL_LABEL_REGION = (20, 420, 160, 60)   # 骆驼下方"领取订单"气泡（兜底定位用）
ORDER_BTN_REGION = (120, 540, 165, 55)    # "领取订单"弹窗按钮 / "领取奖励"弹窗"领取"按钮
REWARD_CLAIM_POS = (202, 571)             # "领取奖励"弹窗「领取」固定坐标（OCR 失效兜底，2026-10-25 截图标定）
REWARD_MARK_KEYWORDS = ("已完成跑商订单", "跑商报酬")  # 报酬弹窗小标题（按钮读不出时的正向证据）
REWARD_MARK_REGION = (40, 330, 330, 130)  # 上面两行小标题所在横条（实测 y=382「已完成跑商订单」/430「跑商报酬」）
ORDER_PANEL_REGION = (20, 180, 370, 370)  # 订单物品网格（找"可提交"）
SUBMIT_REGION = (260, 565, 130, 55)       # 订单面板右下"提交"/"出发"按钮
SHANGJIAO_REGION = (130, 420, 145, 55)    # 任务道具弹窗"上交"
DETAIL_SUBMIT_REGION = (210, 465, 130, 55)  # 缺货物品详情弹窗的"提交"
DETAIL_MARK_REGION = (60, 465, 130, 55)     # 缺货物品详情弹窗的"求助"（判定用）
GET_GO_REGION = (230, 340, 130, 85)       # 获取途径弹窗"交易市场"行的"前往"（弹窗位置会微漂，实测文字中心可贴到 y=370，边距必须留足）
GET_GO_SCAN_REGION = (60, 320, 300, 170)  # 获取途径弹窗整体扫描区（含 交易市场/坊市购买/钟馗捉鬼 行）
BUY_REGION = (230, 460, 130, 55)          # 购买确认弹窗"购买"

# 坊市购买页：锚点全走 OCR 文字（不新增模板图），坐标是按含标题栏窗口截图
# 换算为客户区后的近似值，仅作兜底与区域限定用
MARKET_TITLE_REGION = (10, 10, 110, 50)      # 左上角"坊市"标题
MARKET_BOTTOM_REGION = (0, 590, 405, 70)     # 底部栏：刷新倒计时 / 页码 / 购买·出售·交易行导航
MARKET_PAGENO_REGION = (180, 590, 225, 70)   # 底部"n/20"页码（右箭头在其右侧约 90px）
MARKET_GRID_REGION = (10, 215, 385, 390)     # 商品网格（找卡片右上角绿色"需求"角标）
REFRESH_CONFIRM_REGION = (200, 400, 190, 90)  # "是否花费100元宝刷新货物"弹窗的"确认"
MARKET_REFRESH_FALLBACK_POS = (24, 593)      # 刷新图标兜底坐标（"后自动"文字左侧约 80px）
MARKET_NEXT_FALLBACK_POS = (357, 593)        # 翻页右箭头兜底坐标
MARKET_BACK_POS = (33, 683)                  # 坊市左下返回箭头（退出市场用）


class Paoshang(Task):
    """跑商：帮会 → 活动页 → 跑商骆驼 → 领取订单 → 提交已有物品
    → 出发时缺货则经坊市购买补齐（购买弹窗会自动轮换缺货物品；商品全部
    售罄时购买弹窗不再弹出，需翻页找"需求"卡或点左下刷新图标手动刷新商店）
    → 再提交 → 出发 → 领取奖励 → 返回主界面。

    有未完成订单时点骆驼会直接打开订单面板（无"领取订单"弹窗），直接续跑。
    上交完最后一项后游戏可能直接弹出缺货详情弹窗盖住面板，此时"出发"会
    被 OCR 透过变暗背景误读、点击落在弹窗遮罩上，必须先识别弹窗走缺货流程。

    未加入帮会的账号（帮会面板没有"回帮"按钮）直接跳过，不算失败；
    骆驼点不出订单面板说明今日已跑完，同样跳过。
    """

    name = "paoshang"
    title = "跑商"
    category = "帮会任务"

    def _try_once(self):
        # 坊市连续缺货止损（2026-10-18 run 7792f4：商品售罄+刷新无货是游戏侧
        # 缺货，重试 Buy 也买不到，旧逻辑 3 轮 × 2 次尝试硬耗 19 分钟）。
        # 连续 2 轮坊市买不到货 → 直接跳过计失败，不再空耗。
        if getattr(self, "_market_starve", 0) >= 2:
            raise TaskSkipped("坊市连续 %d 轮缺货（售罄且刷新无货），"
                              "订单无法补齐" % self._market_starve)
        r = self.enter_guild_activity()
        if r == "no_guild":
            return True
        if not r:
            return False
        r = self._open_orders()
        if r == "done":
            return True
        if not r:
            log.info("骆驼未弹出领取订单（今日已跑完），跳过")
            self.exit_panel_to_home()
            return True
        if not self._do_orders():
            return False
        self.exit_panel_to_home()
        return True

    def _open_orders(self, timeout=8):
        """点跑商骆驼，等"领取订单"弹窗并点领取，进入订单面板。

        若弹出的是"领取奖励"（订单已完成但奖励未领），直接领取并关闭面板；
        有未完成订单时骆驼直接打开订单面板（无弹窗），返回 True 续跑；
        什么都没弹（今日已跑完）返回 False。
        """
        self.device.click(*CAMEL_POS)
        deadline = time.time() + timeout
        while time.time() < deadline:
            screen = self.device.screenshot()
            hit = ocr.find_text(screen, "领取订单", region=ORDER_BTN_REGION,
                                min_similarity=1.0)
            if hit:
                log.info("点击 [领取订单] @ (%d, %d)", hit[0], hit[1])
                self.device.click(hit[0], hit[1])
                return self._wait_order_panel()
            hit = ocr.find_text(screen, "领取", region=ORDER_BTN_REGION,
                                min_similarity=1.0)
            if hit:
                log.info("订单已完成，直接领取奖励 @ (%d, %d)", hit[0], hit[1])
                self.device.click(hit[0], hit[1])
                self.close_reward_popup()
                self.exit_panel_to_home()
                return "done"
            if self._order_panel_visible(screen):
                log.info("订单面板已打开，继续未完成的订单")
                return True
            time.sleep(0.6)
        # 兜底：骆驼下方有"领取订单"气泡时按气泡位置偏移再点一次
        hit = ocr.find_text(self.device.screenshot(), "领取订单",
                            region=CAMEL_LABEL_REGION, min_similarity=1.0)
        if hit:
            log.info("按气泡位置补点骆驼")
            self.device.click(hit[0] + 35, hit[1] - 65)
            time.sleep(2)
            screen = self.device.screenshot()
            hit = ocr.find_text(screen, "领取订单",
                                region=ORDER_BTN_REGION, min_similarity=1.0)
            if hit:
                self.device.click(hit[0], hit[1])
                return self._wait_order_panel()
            if self._order_panel_visible(screen):
                log.info("订单面板已打开，继续未完成的订单")
                return True
        return False

    @staticmethod
    def _order_panel_visible(screen):
        return (ocr.find_text(screen, "提交", region=SUBMIT_REGION, min_similarity=1.0)
                or ocr.find_text(screen, "出发", region=SUBMIT_REGION, min_similarity=1.0))

    @staticmethod
    def _detail_popup_visible(screen):
        """缺货物品详情弹窗：右下"提交"，左下"求助 n/2"（带计数，不能精确匹配）。"""
        return (ocr.find_text(screen, "提交", region=DETAIL_SUBMIT_REGION, min_similarity=1.0)
                or ocr.find_text(screen, "求助", region=DETAIL_MARK_REGION,
                                 min_similarity=0.5))

    def _wait_order_panel(self, timeout=8):
        deadline = time.time() + timeout
        while time.time() < deadline:
            if self._order_panel_visible(self.device.screenshot()):
                return True
            time.sleep(0.6)
        log.warning("订单面板未打开")
        return False

    def _do_orders(self):
        """提交 → 出发 →（缺货则购买补齐，再来一轮）→ 领取奖励。"""
        for round_ in range(3):
            self._submit_all()
            # 上交完最后一项后游戏可能直接弹出缺货详情（甚至闪跳获取途径），
            # 弹窗遮罩会吞掉"出发"的点击
            screen = self.device.screenshot()
            if self._detail_popup_visible(screen) or self._find_buy_go(screen):
                log.info("缺货详情弹窗已打开（第 %d 轮购买补齐）", round_ + 1)
                if not self._buy_missing():
                    self._market_starve = getattr(self, "_market_starve", 0) + 1
                    return False
                continue
            if not self._click_depart():
                return False
            # 出发后弹窗有动画延迟，轮询等结果：领奖 / 缺货详情 / 未知
            # 2026-10-25：10 秒不够——报酬弹窗晚到（日志里出现"出发后出现
            # 未知画面"+截图就是「领取奖励/已完成跑商订单/领取」），放宽到
            # 20 秒，并用标题文字作正向证据（按钮 OCR 偶发读不出）。
            outcome = None
            hit = None
            deadline = time.time() + 20
            while time.time() < deadline:
                screen = self.device.screenshot()
                hit = ocr.find_text(screen, "领取", region=ORDER_BTN_REGION,
                                    min_similarity=1.0)
                if hit:
                    outcome = "reward"
                    break
                if any(k in t for t, *_ in ocr.scan(screen, REWARD_MARK_REGION)
                       for k in REWARD_MARK_KEYWORDS):
                    outcome = "reward"
                    hit = REWARD_CLAIM_POS
                    log.info("报酬弹窗已出现（按钮文字未读到，按固定坐标领取）")
                    break
                if self._detail_popup_visible(screen) or self._find_buy_go(screen):
                    outcome = "missing"
                    break
                time.sleep(0.7)
            if outcome == "reward":
                log.info("点击 [领取奖励] @ (%d, %d)", hit[0], hit[1])
                self.device.click(hit[0], hit[1])
                self.close_reward_popup(timeout=10)
                return True
            if outcome == "missing":
                log.info("存在缺货物品（第 %d 轮购买补齐）", round_ + 1)
                if not self._buy_missing():
                    self._market_starve = getattr(self, "_market_starve", 0) + 1
                    return False
                continue
            self.save_debug_screenshot("paoshang_unknown")
            log.warning("出发后出现未知画面")
            return False
        log.warning("跑商轮数达到上限仍未完成")
        return False

    def _submit_all(self, max_rounds=12):
        """循环 提交→上交，直到没有"可提交"项。上交弹窗偶有延迟，轮询等待。"""
        for i in range(max_rounds):
            screen = self.device.screenshot()
            if self._detail_popup_visible(screen):
                log.info("缺货详情弹窗已打开，停止提交")
                return
            if not ocr.find_text(screen, "可提交", region=ORDER_PANEL_REGION,
                                 min_similarity=1.0):
                log.info("没有可提交项了")
                return
            hit = ocr.find_text(screen, "提交", region=SUBMIT_REGION,
                                min_similarity=1.0)
            if not hit:
                log.warning("有可提交项但找不到提交按钮")
                return
            log.info("第 %d 轮：点击 [提交]", i + 1)
            self.device.click(hit[0], hit[1])
            hit2 = None
            for _ in range(6):
                time.sleep(0.8)
                screen = self.device.screenshot()
                hit2 = ocr.find_text(screen, "上交", region=SHANGJIAO_REGION,
                                     min_similarity=1.0)
                if hit2:
                    break
                # 上交最后一项后弹的可能是缺货详情/获取途径而非"上交"，
                # 命中则直接返回，让主循环走缺货流程，不要空转到上限
                if (self._detail_popup_visible(screen)
                        or self._find_buy_go(screen)):
                    log.info("提交后弹出缺货流程弹窗，转入购买补齐")
                    return
            if not hit2:
                # 交最后一项后游戏有时**直接弹「领取奖励」报酬弹窗**（没有
                # 「上交」这一步）——2026-10-25 日志里 40 次"上交弹窗未出现，
                # 重试"多数属于这种：其实已经提交成功，白等 5 秒再空转一轮。
                if any(k in t for t, *_ in ocr.scan(screen, REWARD_MARK_REGION)
                       for k in REWARD_MARK_KEYWORDS):
                    log.info("提交后直接弹出跑商报酬，提交完成")
                    return
                log.warning("上交弹窗未出现，重试")
                continue
            log.info("点击 [上交] @ (%d, %d)", hit2[0], hit2[1])
            self.device.click(hit2[0], hit2[1])
            time.sleep(random.uniform(1.5, 2.2))
        log.warning("提交轮数达到上限")

    def _click_depart(self):
        hit = ocr.find_text(self.device.screenshot(), "出发",
                            region=SUBMIT_REGION, min_similarity=1.0)
        if not hit:
            log.warning("未找到出发按钮")
            return False
        log.info("点击 [出发] @ (%d, %d)", hit[0], hit[1])
        self.device.click(hit[0], hit[1])
        return True

    @staticmethod
    def _find_buy_go(screen):
        """获取途径弹窗里购买途径行的"前往"按钮位置，找不到返回 None。

        弹窗布局随物品变化：单行（坊市购买）或两行（交易市场 + 钟馗捉鬼）。
        按行标签定位同行的"前往"，避免误点钟馗捉鬼（点了会进战斗玩法）。
        找不到购买行标签时退回 GET_GO_REGION 内精确匹配"前往"（旧行为，
        该区域下沿刻意不覆盖钟馗捉鬼行）。
        """
        texts = ocr.scan(screen, GET_GO_SCAN_REGION, min_score=0.5)
        gos = [(cx, cy) for text, cx, cy, _ in texts if text.strip() == "前往"]
        for text, cx, cy, _ in texts:
            if "交易市场" in text or "坊市购买" in text:
                row = [g for g in gos if abs(g[1] - cy) < 25]
                if row:
                    return row[0]
        return ocr.find_text(screen, "前往", region=GET_GO_REGION,
                             min_similarity=1.0)

    def _buy_missing(self):
        """缺货物品详情弹窗 → "提交" →（有存货先上交，没存货进获取途径）
        → 交易市场"前往" → 坊市购买（_market_buy_loop：购买弹窗自动轮换时
        反复点"购买"；商品售罄时翻页找"需求"卡/手动刷新商店）。

        购买流程卡死时不直接判失败：先退市场回订单面板，回不去则
        回帮会点骆驼续跑（有未完成订单时骆驼直接打开订单面板）。
        """
        # 详情弹窗点"提交"：有存货进任务道具弹窗，没存货进获取途径
        entered = False
        for _ in range(3):
            # 弹窗刚弹出时动画未稳定，单次 OCR 漏检不能立即放弃，轮询几秒。
            # 注意：缺货物品持有 0 且求助次数用尽时，详情弹窗会短暂显示后
            # 自动跳转"获取途径"弹窗，此时直接认"前往"，不必等"提交"。
            hit = None
            deadline = time.time() + 4
            while time.time() < deadline:
                screen = self.device.screenshot()
                if self._find_buy_go(screen):
                    entered = True  # 已自动进入获取途径弹窗
                    break
                hit = ocr.find_text(screen, "提交",
                                    region=DETAIL_SUBMIT_REGION, min_similarity=1.0)
                if hit:
                    break
                if not self._detail_popup_visible(self.device.screenshot()):
                    break  # 弹窗确实已关闭
                time.sleep(0.5)
            if entered:
                break
            if not hit:
                self.save_debug_screenshot("buy_missing_no_submit")
                log.warning("缺货详情弹窗的“提交”未识别到，区域原文: %s",
                            ocr.dump_texts(self.device.screenshot(), DETAIL_SUBMIT_REGION))
                # 详情弹窗一闪而过：可能已自动跳进获取途径/坊市购买页，再确认一次
                screen = self.device.screenshot()
                if self._find_buy_go(screen) or self._market_page_visible(screen):
                    entered = True
                    break
                # 详情弹窗已关：若已回订单面板，交给主循环继续；否则骆驼续跑恢复
                if self._wait_order_panel(timeout=3):
                    return True
                return self._resume_via_camel()
            self.device.click(hit[0], hit[1])
            time.sleep(1.5)
            screen = self.device.screenshot()
            hit = ocr.find_text(screen, "上交", region=SHANGJIAO_REGION,
                                min_similarity=1.0)
            if hit:  # 有存货：先上交，回到详情继续点提交
                self.device.click(hit[0], hit[1])
                time.sleep(random.uniform(1.5, 2.2))
                continue
            if self._find_buy_go(screen):
                entered = True
                break
        if not entered:
            log.warning("未进入获取途径弹窗")
            return False
        hit = self._find_buy_go(self.device.screenshot())
        if hit:
            log.info("点击 获取途径 [前往] @ (%d, %d)", hit[0], hit[1])
            self.device.click(hit[0], hit[1])
            time.sleep(random.uniform(1.5, 2.2))
        elif not self._market_page_visible(self.device.screenshot()):
            log.warning("获取途径弹窗的“前往”未识别到")
            return False
        # 详情弹窗闪跳场景可能已直接在坊市购买页，此时无需点"前往"
        if self._market_buy_loop():
            return True
        log.warning("坊市购买未完成，尝试退出市场回订单面板")
        if self._exit_market_to_orders():
            return True
        return self._resume_via_camel()

    @staticmethod
    def _market_page_visible(screen):
        """坊市购买页判定：底部"后自动"倒计时 / "交易行"导航 / 左上"坊市"标题任一命中。"""
        return (ocr.contains_text(screen, "后自动", region=MARKET_BOTTOM_REGION)
                or ocr.contains_text(screen, "交易行", region=MARKET_BOTTOM_REGION)
                or ocr.contains_text(screen, "坊市", region=MARKET_TITLE_REGION))

    def _market_buy_loop(self, timeout=120, max_refresh=6):
        """坊市购买统一处理循环（售罄场景：翻页找"需求"卡 → 售罄则刷新商店）。

        三种状态轮转：回订单面板=买完收工；购买确认弹窗在=点"购买"
        （连续 2 次读不到才算弹窗消失，单次 OCR 漏检不能当消失）；
        坊市购买页在=购买弹窗不再自动弹出，自己翻页找货/刷新。
        """
        deadline = time.time() + timeout
        refreshes = 0
        miss_buy = 0
        while time.time() < deadline:
            self._check_stop()
            screen = self.device.screenshot()
            if self._order_panel_visible(screen):
                log.info("购买完成，已回到订单面板")
                return True
            hit = ocr.find_text(screen, "购买", region=BUY_REGION,
                                min_similarity=1.0)
            if hit:
                miss_buy = 0
                log.info("点击 [购买] @ (%d, %d)", hit[0], hit[1])
                self.device.click(hit[0], hit[1])
                time.sleep(random.uniform(1.8, 2.4))
                continue
            miss_buy += 1
            if miss_buy < 2:
                time.sleep(0.7)
                continue
            if not self._market_page_visible(screen):
                time.sleep(0.8)
                continue
            if self._market_find_and_buy(screen):
                continue  # 购买弹窗已弹出，下一轮点"购买"
            # 刷新要花 100 元宝，动手前最后确认购买弹窗不是刚好轮换回来
            if ocr.find_text(self.device.screenshot(), "购买",
                             region=BUY_REGION, min_similarity=1.0):
                continue
            refreshes += 1
            if refreshes > max_refresh:
                log.warning("坊市刷新次数用尽（%d 次）", max_refresh)
                return False
            self._refresh_market(refreshes)
        log.warning("坊市购买超时（%ds）", timeout)
        return False

    def _market_find_and_buy(self, screen):
        """从当前页开始逐页找"需求"卡并点开。返回 True=购买弹窗已弹出；
        False=扫完全部页都买不到（售罄），转刷新。"""
        seen = set()
        for _ in range(21):  # 页码上限 n/20，留一格冗余
            self._check_stop()
            if ocr.find_text(screen, "购买", region=BUY_REGION,
                             min_similarity=1.0):
                return True  # 购买弹窗还在（自动轮换中），回主循环点购买
            r = self._try_need_card(screen)
            if r is not None:
                return r
            page = self._page_no(screen)
            key = page[0] if page else f"?{len(seen)}"
            if key in seen:
                log.info("页码 %s 已扫过，全部页翻完", key)
                return False
            seen.add(key)
            pos = self._page_next_pos(page)
            log.info("本页无需求卡，翻下一页 @ (%d, %d)", pos[0], pos[1])
            self.device.click(pos[0], pos[1])
            time.sleep(random.uniform(1.0, 1.5))
            screen = self.device.screenshot()
            page2 = self._page_no(screen)
            if page and page2 and page2[0] == page[0]:
                log.info("翻页后页码仍为 %s，已到最后一页", page[0])
                return self._try_need_card(screen) is True
        log.warning("翻页次数超限")
        return False

    def _try_need_card(self, screen):
        """当前页找"需求"卡并点击。True=购买弹窗已弹出；False=点开无购买
        弹窗（卡其实售罄，OCR 误读或刚好被抢）；None=本页没有需求卡。"""
        card = self._find_need_card(screen)
        if not card:
            return None
        log.info("点击需求卡 @ (%d, %d)", card[0], card[1])
        self.save_debug_screenshot("paoshang_need_buy")
        self.device.click(card[0], card[1])
        deadline = time.time() + 3
        while time.time() < deadline:
            if ocr.find_text(self.device.screenshot(), "购买",
                             region=BUY_REGION, min_similarity=1.0):
                return True
            time.sleep(0.4)
        log.warning("需求卡点开未出现购买弹窗（售罄或被抢）")
        self.save_debug_screenshot("paoshang_need_soldout")
        return False

    @staticmethod
    def _find_need_card(screen):
        """网格区找卡片右上角绿色"需求"角标（= 当前订单需要的物品），
        返回卡片中心点击坐标：角标左约 45px、下约 60px。"""
        for text, cx, cy, _ in ocr.scan(screen, MARKET_GRID_REGION, min_score=0.5):
            if "需求" in text:
                return max(cx - 45, 10), min(cy + 60, 700)
        return None

    @staticmethod
    def _page_no(screen):
        """底部栏"n/20"页码文本，返回 (文本, cx, cy)，找不到返回 None。"""
        for text, cx, cy, _ in ocr.scan(screen, MARKET_PAGENO_REGION, min_score=0.5):
            if "/" in text:
                return text, cx, cy
        return None

    @staticmethod
    def _page_next_pos(page):
        """翻页右箭头在页码文本右侧约 90px 同一高度；无页码用兜底坐标。"""
        if page:
            return min(page[1] + 90, 400), page[2]
        return MARKET_NEXT_FALLBACK_POS

    @staticmethod
    def _refresh_icon_pos(screen):
        """刷新图标在左下绿色倒计时"后自动"文字左侧约 80px 同一高度。"""
        for text, cx, cy, _ in ocr.scan(screen, MARKET_BOTTOM_REGION, min_score=0.5):
            if "后自动" in text:
                return max(cx - 80, 10), cy
        return MARKET_REFRESH_FALLBACK_POS

    def _refresh_market(self, n):
        """点刷新图标手动刷新商店，处理"是否花费100元宝刷新货物"确认弹窗
        （弹窗有"本次登录不再提示"复选框，已确认过时不再弹出）。"""
        pos = self._refresh_icon_pos(self.device.screenshot())
        log.info("商品售罄，点击刷新图标（第 %d 次）@ (%d, %d)", n, pos[0], pos[1])
        self.save_debug_screenshot("paoshang_refresh")
        self.device.click(pos[0], pos[1])
        time.sleep(2.5)
        deadline = time.time() + 4
        while time.time() < deadline:
            hit = ocr.find_text(self.device.screenshot(), "确认",
                                region=REFRESH_CONFIRM_REGION, min_similarity=1.0)
            if hit:
                log.info("点击 刷新确认 [确认] @ (%d, %d)", hit[0], hit[1])
                self.device.click(hit[0], hit[1])
                time.sleep(random.uniform(1.5, 2.2))
                return
            time.sleep(0.5)
        log.info("刷新确认弹窗未出现（本次登录可能已勾选不再提示）")
        time.sleep(random.uniform(1.0, 1.5))

    def _exit_market_to_orders(self):
        """购买流程卡死后退出市场：左下返回箭头逐层退，ESC 兜底。"""
        for _ in range(3):
            self._check_stop()
            self.device.click(*MARKET_BACK_POS)
            time.sleep(1.2)
            if self._order_panel_visible(self.device.screenshot()):
                log.info("已退出市场回到订单面板")
                return True
        self.device.press_esc()
        return self._wait_order_panel(timeout=5)

    def _resume_via_camel(self):
        """最终恢复手段：回主界面 → 重新进帮会活动页 → 点骆驼。
        有未完成订单时骆驼直接打开订单面板，主循环可继续 提交→出发。"""
        log.info("尝试回帮会点骆驼恢复订单面板")
        self.back_to_home()
        if self.enter_guild_activity() is not True:
            log.warning("恢复失败：无法进入帮会活动页")
            return False
        self.device.click(*CAMEL_POS)
        time.sleep(1.5)
        if self._wait_order_panel(timeout=5):
            log.info("已恢复到订单面板，继续跑商")
            return True
        log.warning("恢复失败：骆驼未打开订单面板")
        return False
