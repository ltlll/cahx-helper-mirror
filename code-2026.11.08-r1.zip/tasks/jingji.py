import logging
import random
import re
import time

from core import ocr
from tasks.base import (BATTLE_MARK_REGION, BATTLE_TOP_REGION,
                        REWARD_POPUP_REGION, Task)

log = logging.getLogger("task.jingji")

# 以下均为 405x720 客户区坐标
JINGJI_NODE_POS = (75, 390)               # 玩法地图"每日竞技"节点
ARENA_MARK_REGION = (150, 480, 110, 45)   # 竞技场页"换一批"（OCR 会拆成"换一|批"，宽松匹配）
FREE_COUNT_REGION = (285, 490, 120, 40)   # "免费挑战次数: n/4"
CHALLENGE_REGION = (150, 330, 110, 55)    # 中间对手的"挑战"按钮（三个对手点中间的）
BATTLE_BTN_REGION = (130, 650, 150, 60)   # 阵容页"战斗"
MANUAL_MARK_REGION = (60, 400, 260, 75)   # 战斗中手动模式的"下达指令"技能菜单标题（位置随宠物名/面板漂移，实测 y 430~454，边距留足）
AUTO_BTN_POS = (368, 683)                 # 战斗右下角"自动"
RESULT_REGION = (60, 330, 285, 250)       # 结算弹窗"点击空白处关闭"（竞技结算位置比通用弹窗低）
RESULT_BLANK_POS = (200, 620)             # 结算弹窗点空白关闭
KEY_REGION = (10, 508, 75, 28)            # 左下角参战奖励钥匙计数 n/3
CHEST_POS = (45, 470)                     # 参战奖励宝箱图标
CHEST_KEY_REGION = (170, 550, 90, 40)     # 嘉赏面板"开启"按钮上方的剩余钥匙计数 n/3（开箱生效校验用）
OPEN_BTN_REGION = (140, 575, 130, 50)     # 竞技嘉赏"开启"按钮；抽满后同位置变成灰的"已全部抽取"
FINAL_REWARD_REGION = (145, 252, 120, 50)  # 抽满后顶部"最终奖励"宝箱下方的说明文字（宝箱图标在其上方约 53px）
FINAL_REWARD_POS = (198, 225)             # "最终奖励"宝箱图标中心（文字 OCR 失败时的兜底点击位）
FINAL_REWARD_TIMEOUT = 12                 # 领取最终奖励后等转盘刷新的超时
RETRY_GAP = 6                             # 领取点击被吞时的补点间隔（一轮循环 2~4 次 OCR）
JINGJI_BATTLE_TIMEOUT = 300               # 单场战斗等待上限（秒）：低战力号打满 20 回合会 >180s


class Jingji(Task):
    """每日竞技（宗门竞技）：玩法 → 每日竞技 → 用完 4 次免费挑战（点中间对手的
    挑战 → 阵容页点战斗）→ 参战奖励：钥匙够 3/3 就开竞技嘉赏宝箱、抽满后先领
    "最终奖励"让转盘刷新 → 返回主界面。

    跳过战斗复选框只有至尊月卡才有，但文字始终存在（勾没勾 OCR 分不出），
    所以不做预判、统一行为检测：点战斗后若直接出结算弹窗=跳过模式；
    若出现"下达指令"技能菜单=手动模式，点右下角"自动"。
    免费次数从"免费挑战次数: n/4" OCR 解析，解析失败时按本场已打 4 次兜底。
    """

    name = "jingji"
    title = "每日竞技"

    def _try_once(self):
        self.dismiss_popups()
        # 队伍侧栏没收起时「挑战」点击会被挤歪（2026-10-23 run c7e254 根因：
        # 复位流程点完「任务页签」不校验，面板留在队伍视图挡住主界面）
        if self._team_view_open(self.device.screenshot()):
            log.warning("队伍侧栏仍停在队伍视图，先收起再进竞技")
            self._restore_quest_view()
        if not self.open_wanfa():
            return False
        self.device.click(*JINGJI_NODE_POS)
        if not self._wait_arena():
            return False
        fought = 0
        for _ in range(5):  # 免费 4 次，5 次兜底
            cnt = self._parse_count(FREE_COUNT_REGION)
            if cnt and cnt[0] >= 10 and cnt[0] > cnt[1]:
                # OCR 把标签尾号粘到计数前（"次数:3"+"3/4"→"33/4"），取个位
                cnt = (cnt[0] % 10, cnt[1])
            if cnt and cnt[0] >= cnt[1]:
                log.info("免费挑战次数已用完（%d/%d）", *cnt)
                break
            if fought >= 4:
                log.info("已打满 4 场（次数解析失败的兜底）")
                break
            if not self._fight_once(cnt):
                return False
            fought += 1
        self._open_chests()
        return True

    def _wait_arena(self, timeout=8):
        deadline = time.time() + timeout
        while time.time() < deadline:
            if ocr.find_text(self.device.screenshot(), "换一批",
                             region=ARENA_MARK_REGION, min_similarity=0.75):
                return True
            time.sleep(0.6)
        log.warning("宗门竞技页未打开")
        return False

    def _parse_count(self, region):
        """OCR 解析区域里的 n/m 计数，失败返回 None。
        逐条文本匹配：拼接会把标签尾号和分数粘在一起（"次数:3"+"3/4"→"33/4"）。"""
        for text, *_ in ocr.scan(self.device.screenshot(), region=region, min_score=0.5):
            m = re.search(r"(\d+)\s*/\s*(\d+)", text)
            if m:
                return int(m.group(1)), int(m.group(2))
        return None

    def _find_challenge(self):
        """找中间对手的「挑战」按钮，返回 (x, y) 或 None。"""
        return ocr.find_text(self.device.screenshot(), "挑战",
                             region=CHALLENGE_REGION, min_similarity=1.0)

    def _wait_battle_btn(self, timeout=10):
        """等阵容页的「战斗」按钮出现，返回 (x, y) 或 None。"""
        deadline = time.time() + timeout
        while time.time() < deadline:
            hit = ocr.find_text(self.device.screenshot(), "战斗",
                                region=BATTLE_BTN_REGION, min_similarity=1.0)
            if hit:
                return hit
            time.sleep(0.6)
        return None

    def _fight_once(self, before_cnt=None):
        # 开打前自查队伍侧栏（2026-10-23 实测：面板留在队伍视图时「挑战」
        # 点击两次全被挤歪，阵容页永远打不开）——每场都查，开销只是一次 OCR
        if self._team_view_open(self.device.screenshot()):
            log.warning("队伍侧栏挡在主界面，先收起再点挑战")
            self._restore_quest_view()
        # 点「挑战」→ 等「战斗」出现（阵容页）。点击可能被吞：10 秒内没等到
        # 「战斗」且「挑战」仍在原位（说明没进页）→ 补点一次；两次都不行才判
        # 失败（2026-10-13 实测 5 号首点被吞导致整轮回主界面重来，多花 ~1min）。
        hit = None
        for attempt in range(2):
            challenge = self._find_challenge()
            if not challenge:
                if attempt == 0:
                    log.warning("找不到中间对手的挑战按钮")
                    return False
                break  # 首点后「挑战」已消失，无从补点
            log.info("点击 [挑战] @ (%d, %d)%s", challenge[0], challenge[1],
                     "（补点）" if attempt else "")
            self.device.click(challenge[0], challenge[1])
            hit = self._wait_battle_btn(timeout=10)
            if hit:
                break
            log.warning("点击 [挑战] 后 10 秒未见 [战斗] 按钮（第 %d/2 次）",
                        attempt + 1)
        if not hit:
            # 阵容页没开 = 挑战点击没落到按钮上（或本周已打完/对手已换）。
            # 现场信息必须打进日志：下次再遇到能直接判是"次数用尽"还是"点歪"
            cnt = self._parse_count(FREE_COUNT_REGION)
            log.warning("阵容页未打开（竞技场页? %s，免费挑战次数 %s）",
                        bool(ocr.find_text(self.device.screenshot(), "换一批",
                                           region=ARENA_MARK_REGION,
                                           min_similarity=0.75)),
                        f"{cnt[0]}/{cnt[1]}" if cnt else "读不出")
            return False
        log.info("点击 [战斗] @ (%d, %d)", hit[0], hit[1])
        self.device.click(hit[0], hit[1])
        # 行为检测：跳过模式直接出结算；手动模式出技能菜单则点"自动"；
        # 阵容页"战斗"按钮还在说明点击被吞，再点一次
        # 2026-10-31 run e5ee47：5 号两场都卡在 180s 边界（06:16:56 点完自动，
        # 06:19:38 判超时时画面仍在战斗）——低战力号打满 20 回合确实会超过
        # 3 分钟。放宽到 300s（正常场次 30~60s 就结束，多等只是兜底，不会拖慢
        # 正常流程）；超时时存图，便于下次判断是"真在打"还是"自动没点开"。
        deadline = time.time() + JINGJI_BATTLE_TIMEOUT
        auto = False
        battle_seen = False      # 本场是否真的进过战斗（战况/回合/下达指令）
        arena_since = None       # 停在竞技场页的起始时刻（见下）
        arena_retries = 0
        while time.time() < deadline:
            self._check_stop()  # 战斗等待：响应 GUI 停止
            screen = self.device.screenshot()
            if self.dismiss_popups(screen):
                continue
            if ocr.find_text(screen, "点击空白处关闭", region=RESULT_REGION):
                win = ocr.find_text(screen, "战斗胜利") is not None
                log.info("本场结果: %s", "胜利" if win else "失败")
                self.device.click(*RESULT_BLANK_POS)
                time.sleep(random.uniform(1.2, 1.8))
                return True
            if not auto and ocr.contains_text(
                    screen, "下达指令", region=MANUAL_MARK_REGION):
                log.info("手动模式，点击 [自动]")
                self.device.click(*AUTO_BTN_POS)
                auto, battle_seen = True, True
                continue
            if (ocr.contains_text(screen, "战况", region=BATTLE_MARK_REGION)
                    or ocr.contains_text(screen, "回合", region=BATTLE_TOP_REGION)):
                battle_seen = True
                arena_since = None
            hit = ocr.find_text(screen, "战斗", region=BATTLE_BTN_REGION,
                                min_similarity=1.0)
            if hit:
                log.warning("战斗点击被吞，重试 [战斗]")
                self.device.click(hit[0], hit[1])
                time.sleep(random.uniform(1.5, 2.2))
                continue
            # ---- 「回到竞技场页」= 本场已结束（2026-10-25 3 号事故）----
            # 3 号第 2 场打完直接回到对手选择页，既没有"点击空白处关闭"结算
            # 弹窗，也没有 [战斗] 按钮 → 旧逻辑一直轮询到 180 秒超时判负，
            # 白烧 166 秒还连累整任务重试。竞技场页（「换一批」+ 免费次数）
            # 是本场结束的**正向证据**：见过战斗就收工；没见过战斗说明
            # [战斗] 点击被吞，重进一次阵容页；连续两次都没开打才判失败。
            if ocr.find_text(screen, "换一批", region=ARENA_MARK_REGION,
                             min_similarity=0.75):
                if battle_seen:
                    log.info("已回到竞技场页（本场结束，未捕获结算弹窗）")
                    return True
                if arena_since is None:
                    arena_since = time.time()
                elif time.time() - arena_since > 12:
                    if arena_retries >= 1:
                        log.warning("点 [战斗] 后始终停在竞技场页，本场没打起来")
                        return False
                    arena_retries += 1
                    arena_since = None
                    log.warning("竞技场页停留 12 秒且未进战斗，重新点 [挑战] 进阵容页")
                    if not self._reenter_fight():
                        return False
            else:
                arena_since = None
            time.sleep(2)
        log.warning("等待战斗结算超时（%d 秒）", JINGJI_BATTLE_TIMEOUT)
        self.report_unknown("battle_timeout", note="竞技战斗超时未出结算")
        # 2026-11-02：超时后必须回竞技场页**复核免费挑战次数**。11-02 早轮 3 号
        # 连续两次（06:18 / 06:24）都是"点战斗 → 等 180 秒超时 → 判失败"，结果
        # 4 次免费挑战一次没消耗完（游戏里看"还剩 4 次"），整个任务记失败。
        # 次数确实减少 = 这一场真打了（结算没读到但次数已消耗），按已打收工。
        if self._confirm_battle_consumed(before_cnt):
            return True
        return False

    def _confirm_battle_consumed(self, before_cnt, timeout=20):
        """战斗等待超时后，回竞技场页看免费挑战次数是否被消耗。

        返回 True = 次数确实减少（本场已开打并消耗，按已打处理，不再让整个
        任务重试）；False = 无法确认（人还在战斗里 / 没回到竞技场页 / 次数没变）。
        """
        deadline = time.time() + timeout
        while time.time() < deadline:
            self._check_stop()
            self.dismiss_popups()
            cnt = self._parse_count(FREE_COUNT_REGION)
            if cnt:
                if cnt[0] >= cnt[1]:
                    log.info("超时后读到免费挑战次数已用完（%d/%d），按已打处理", *cnt)
                    return True
                if before_cnt and cnt[0] > before_cnt[0]:
                    log.info("超时后免费挑战次数 %d → %d（已消耗一场），按已打处理",
                             before_cnt[0], cnt[0])
                    return True
            time.sleep(2.0)
        log.warning("战斗超时后无法确认次数消耗（可能仍在战斗/未回竞技场页，"
                    "战前次数 %s）", f"{before_cnt[0]}/{before_cnt[1]}"
                    if before_cnt else "读不出")
        return False

    def _reenter_fight(self):
        """[战斗] 点击被吞、人仍在竞技场页时重进阵容页并开打。"""
        challenge = self._find_challenge()
        if not challenge:
            log.warning("重进阵容页：找不到中间对手的挑战按钮")
            return False
        self.device.click(challenge[0], challenge[1])
        hit = self._wait_battle_btn(timeout=10)
        if not hit:
            log.warning("重进阵容页：10 秒未见 [战斗] 按钮")
            return False
        log.info("重进阵容页，点击 [战斗] @ (%d, %d)", hit[0], hit[1])
        self.device.click(hit[0], hit[1])
        time.sleep(random.uniform(1.5, 2.2))
        return True

    def _open_chests(self, max_open=3):
        """参战奖励：开竞技嘉赏宝箱（开战积累钥匙，开一次消耗 3 把）。

        可开次数由开箱前的钥匙计数算术确定（每开一次消耗 cnt[1] 把）。
        每次点击后用面板上的剩余钥匙计数校验是否真开了——奖励遮罩期间
        "开启"按钮可被 OCR 透过遮罩读到，但点击会被吞；计数不变=没开成。
        计数读不出时不能无脑按已开（2026-10-10 实测：点击被吞+计数读不出
        被误判已开，嘉赏宝箱没领到）——以"是否出现过奖励画面"旁证：有奖励
        画面=确实开了；计数和奖励画面都没有=按未开重试（钥匙没扣，明天可
        再开，不会浪费）。

        抽满后顶部"最终奖励"宝箱点亮（红点角标），底部"开启"变成灰的
        "已全部抽取"——此时必须先点宝箱领取、转盘刷新回未抽状态，才能继续
        开箱。领取与钥匙多少无关（可能上次抽满但没领、钥匙又花光了），
        所以无论钥匙是否够 3 把都要开面板：先领最终奖励，再走普通开箱逻辑。
        """
        cnt = self._parse_count(KEY_REGION)
        opens = min(cnt[0] // cnt[1], max_open) if cnt else 0
        log.info("参战钥匙 %s，可开 %d 次", f"{cnt[0]}/{cnt[1]}" if cnt else "解析失败",
                 opens)
        self.device.click(*CHEST_POS)
        if not self._wait_chest_panel(timeout=8):
            log.warning("竞技嘉赏面板未打开")
            return
        self._claim_final_reward()  # 抽满时先领最终奖励，转盘才会刷新
        if opens <= 0:
            log.info("钥匙不足 %d 把，跳过开箱", cnt[1] if cnt else 3)
            return
        hit = self._wait_open_btn(timeout=8)
        if not hit:
            log.info("未找到 [开启] 按钮（可能仍抽满/无钥匙），结束开箱")
            return
        before = self._read_chest_keys()
        for i in range(opens):
            # 已开光检查：一次「开启」可能把剩余钥匙全部消耗（实测 6→0，
            # 计划里 2 次其实一次点完），剩下计划的次数已无钥匙可开，硬点
            # 只会白耗 3×~15s（2026-10-13 账号 3 白耗 48s、账号 7 白耗 62s）
            if self._keys_exhausted():
                log.info("剩余钥匙为 0（本轮已开光），结束开箱")
                return
            for attempt in range(3):
                log.info("点击 [开启]（第 %d/%d 次）@ (%d, %d）", i + 1, opens,
                         hit[0], hit[1])
                self.device.click(hit[0], hit[1])
                time.sleep(random.uniform(1.0, 1.6))
                got_reward = self._dismiss_chest_reward()
                r = self._wait_keys_change(before, timeout=8)
                if r is False:
                    if self._keys_exhausted():
                        log.info("剩余钥匙为 0（本轮已开光），结束开箱")
                        return
                    log.warning("开箱未生效（钥匙计数未变），驱散遮罩重试 (%d/3)",
                                attempt + 1)
                    self.device.click(*RESULT_BLANK_POS)
                    time.sleep(random.uniform(1.0, 1.6))
                    hit = self._wait_open_btn(timeout=4)
                    if not hit:
                        log.warning("开启按钮消失且未开箱，面板可能已关闭")
                        return
                    continue
                if r is not None:
                    log.info("开箱成功，钥匙 %s → %d", before, r)
                    before = r
                elif got_reward:
                    log.info("开箱后计数读不出，但出现过奖励画面，按已开处理")
                else:
                    # 计数读不出且无奖励画面旁证：两种可能——奖励遮罩还没散
                    # （钥匙其实已扣，2026-10-13 实测一口气连"开"三次 6 把钥匙）
                    # 或点击真被吞。先散遮罩复查计数，变了=已开成功，绝不盲目
                    # 补点（补点会把剩余钥匙一次开光还白耗 ~50s/号）；
                    # 复查仍读不出/没变才按未开重试（钥匙没扣，明天可再开）
                    log.warning("开箱后计数读不出且未见奖励画面，散遮罩复查 (%d/3)",
                                attempt + 1)
                    r2 = self._confirm_open_after_overlay(before)
                    if r2 is not None:
                        log.info("开箱成功（复查确认），钥匙 %s → %d", before, r2)
                        before = r2
                        break
                    self.device.click(*RESULT_BLANK_POS)
                    time.sleep(random.uniform(1.0, 1.6))
                    hit = self._wait_open_btn(timeout=4)
                    if not hit:
                        log.warning("开启按钮消失且未开箱，面板可能已关闭")
                        return
                    continue
                break
            else:
                log.warning("连续 3 次开箱点击未生效，停止（剩余钥匙明天再开）")
                return
            # 本次开箱后若已抽满（底部变"已全部抽取"），先领最终奖励再继续
            if self._claim_final_reward():
                log.info("已领取最终奖励，转盘已刷新，继续开箱")
            hit = self._wait_open_btn(timeout=8)
            if not hit:
                if i + 1 < opens:
                    log.warning("开启后未再找到 [开启] 按钮，停止开箱")
                break  # 面板关了或没钥匙了

    def _wait_chest_panel(self, timeout=8):
        """等竞技嘉赏面板就绪：出现"开启"按钮，或抽满后的"已全部抽取"。"""
        deadline = time.time() + timeout
        while time.time() < deadline:
            screen = self.device.screenshot()
            if ocr.find_text(screen, "开启", region=OPEN_BTN_REGION,
                             min_similarity=1.0):
                return True
            if self._is_all_drawn(screen):
                return True
            time.sleep(0.6)
        return False

    def _is_all_drawn(self, screen):
        """嘉赏面板是否已抽满：底部按钮文字变成"已全部抽取"，不再有"开启"。

        注意"全部领取后刷新"提示在面板中间（y≈416），不在按钮区，不会误判。
        """
        if ocr.find_text(screen, "开启", region=OPEN_BTN_REGION, min_similarity=1.0):
            return False
        return any("抽取" in t or "领取" in t
                   for t in ocr.dump_texts(screen, region=OPEN_BTN_REGION))

    def _claim_final_reward(self, timeout=FINAL_REWARD_TIMEOUT):
        """抽满后顶部"最终奖励"宝箱点亮（带红点角标），点它领取 → 转盘刷新。

        只在"已抽满"状态才动手，正常路径返回 False、零影响；领取成功返回 True。
        点击位置取 OCR 到的"最终奖励"文字上方约 53px 的宝箱图标（实测图标中心
        (198, 225)、文字中心 (198, 278)），OCR 读不到文字时用固定坐标兜底。

        顺序必须"先散弹窗再点宝箱"：抽满那一手点"开启"后同样会弹奖励画面，
        遮罩盖住面板时点宝箱会被吞。故每轮先查"点击空白处关闭"并点掉，再点；
        点击被吞时（间隔 RETRY_GAP 秒后仍处抽满态）最多补点一次，其余情况一律
        不重复点，避免转盘刷新后误点到别的东西。
        """
        screen = self.device.screenshot()
        if not self._is_all_drawn(screen):
            return False
        deadline = time.time() + timeout
        clicks, next_click_at = 0, 0.0
        while time.time() < deadline:
            self._check_stop()
            screen = self.device.screenshot()
            if (ocr.find_text(screen, "点击空白处关闭", region=RESULT_REGION)
                    or ocr.find_text(screen, "点击空白处关闭",
                                     region=REWARD_POPUP_REGION)):
                log.info("最终奖励发放中，点空白关闭奖励画面")
                self.device.click(*RESULT_BLANK_POS)
                next_click_at = time.time() + 1.0  # 关掉遮罩后再点，别急着补点
                time.sleep(random.uniform(1.2, 1.8))
                continue
            if ocr.find_text(screen, "开启", region=OPEN_BTN_REGION,
                             min_similarity=1.0):
                log.info("最终奖励已领取，转盘已刷新")
                return True
            if clicks and not self._is_all_drawn(screen):
                log.info("最终奖励已领取，面板已刷新")
                return True
            if clicks < 2 and time.time() >= next_click_at:
                hit = ocr.find_text(screen, "最终奖励", region=FINAL_REWARD_REGION,
                                    min_similarity=1.0)
                pos = (hit[0], hit[1] - 53) if hit else FINAL_REWARD_POS
                log.info("已抽满，点击 [最终奖励] 领取 @ (%d, %d)",
                         pos[0], pos[1])
                self.device.click(*pos)
                clicks += 1
                # 一轮循环要 2~4 次 OCR（每次约 1s），补点间隔给足，避免
                # 状态还没刷新就重复点击
                next_click_at = time.time() + RETRY_GAP
            time.sleep(0.5)
        log.warning("领取最终奖励后未确认到转盘刷新（继续按普通逻辑执行）")
        return True

    def _read_chest_keys(self):
        """读嘉赏面板"开启"按钮上方的剩余钥匙计数（n/3 的 n），读不出返回 None。"""
        cnt = self._parse_count(CHEST_KEY_REGION)
        return cnt[0] if cnt else None

    def _keys_exhausted(self):
        """剩余参战钥匙是否为 0（已开光）。读不出返回 False——绝不因读不出
        而误判提前收工（宁可多试几次，不能少开一次）。"""
        cur = self._read_chest_keys()
        return cur is not None and cur <= 0

    def _wait_keys_change(self, before, timeout=8):
        """等嘉赏面板剩余钥匙计数变化：返回新计数；读不出返回 None（调用方按
        已开处理）；超时仍读得出且没变返回 False（点击被吞）。"""
        deadline = time.time() + timeout
        while time.time() < deadline:
            cur = self._read_chest_keys()
            if cur is not None and (before is None or cur != before):
                return cur
            time.sleep(0.6)
        # 超时：能读出计数但没变 = 被吞；一直读不出 = None
        return False if self._read_chest_keys() is not None else None

    def _confirm_open_after_overlay(self, before, tries=3):
        """散奖励遮罩并复查钥匙计数（"计数读不出且无奖励画面"时的复核）。

        不带提示文字的奖励画面会盖住面板（钥匙计数读不出），点空白驱散后再
        读：计数变了=刚才那下其实开成了，返回新计数；一直读不出或读出但没变
        （=真被吞）返回 None，调用方才去补点。"""
        for _ in range(tries):
            self.device.click(*RESULT_BLANK_POS)
            time.sleep(random.uniform(1.2, 1.8))
            cur = self._read_chest_keys()
            if cur is not None:
                return cur if before is None or cur != before else None
        return None

    def _wait_open_btn(self, timeout=8):
        hit = None
        deadline = time.time() + timeout
        while time.time() < deadline:
            hit = ocr.find_text(self.device.screenshot(), "开启",
                                region=OPEN_BTN_REGION, min_similarity=1.0)
            if hit:
                break
            time.sleep(0.6)
        return hit

    def _dismiss_chest_reward(self, timeout=6):
        """关掉"开启"后的奖励画面，返回 True=过程中确实出现过奖励画面
        （开箱成功的旁证；点击被吞时面板原样、不会有奖励画面）。

        竞技相关弹窗位置比通用弹窗低，REWARD_POPUP_REGION 可能漏检
        "点击空白处关闭"，两个区域都查；实测还存在不带提示文字的奖励画面
        （会盖住面板导致返回箭头失效），超时则点一次空白兜底驱散。
        **先查奖励文字再查面板可用**——奖励遮罩期间"开启"能被 OCR 透过
        遮罩读到，顺序反了会把"有奖励"误判成"面板已可用"（实测教训）。"""
        saw_reward = False
        blank_clicked = False
        deadline = time.time() + timeout
        while time.time() < deadline:
            screen = self.device.screenshot()
            if (ocr.find_text(screen, "点击空白处关闭", region=RESULT_REGION)
                    or ocr.find_text(screen, "点击空白处关闭",
                                     region=REWARD_POPUP_REGION)):
                saw_reward = True
                self.device.click(*RESULT_BLANK_POS)
                blank_clicked = True
                time.sleep(random.uniform(1.2, 1.8))
                continue
            # 面板已可用：能再开箱，或这一手正好抽满（按钮变"已全部抽取"）
            if (ocr.find_text(screen, "开启", region=OPEN_BTN_REGION,
                              min_similarity=1.0)
                    or self._is_all_drawn(screen)):
                return saw_reward
            time.sleep(0.5)
        if not blank_clicked:
            log.warning("未识别到奖励画面，点空白兜底")
            self.device.click(*RESULT_BLANK_POS)
            time.sleep(random.uniform(1.0, 1.6))
        return saw_reward
