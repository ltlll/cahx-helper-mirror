import logging
import random
import time

from core import ocr
from tasks.base import Task

log = logging.getLogger("task.eat_pet_food")

GRID_REGION = (12, 130, 380, 420)   # 物资袋物品网格区域（限定搜索范围防误判）
POPUP_REGION = (40, 150, 330, 480)  # 物品详情弹窗区域
# 三种宝宝菜：没有名字，按图标图形识别（模板掩码已忽略右下角数量）
PET_FOODS = ("宝宝菜_千层饼", "宝宝菜_鲜花饼", "宝宝菜_龙凤卷饼")


class EatPetFood(Task):
    """吃宝宝烹饪：背包 → 物资袋 → 打开 → 烹饪页签 → 逐个点三种宝宝菜使用。

    食物图标没有名字，靠图形模板匹配（背包内顺序不固定不影响）；
    找不到的跳过，视为已食用。吃完按原路返回主界面。
    """

    name = "eat_pet_food"
    title = "吃宝宝烹饪"
    category = "备战任务"

    def _try_once(self):
        self.dismiss_popups()
        if not self.open_backpack():
            return False
        if not self.matcher.find_and_click(self.device, "物资袋", timeout=8):
            return False
        if not self.matcher.find_and_click(self.device, "物资袋打开", timeout=8):
            return False
        # 游戏会记住上次页签：已在烹饪页就不用再点
        time.sleep(random.uniform(0.8, 1.2))
        if self.matcher.find(self.device.screenshot(), "烹饪页签_选中"):
            log.info("已在烹饪页签")
        elif not self.matcher.find_and_click(self.device, "烹饪页签", timeout=8):
            return False

        for food in PET_FOODS:
            self._eat_one(food)

        # 原路返回主界面：物资袋返回 → 背包页 → 背包返回
        self.matcher.find_and_click(self.device, "物资袋返回", timeout=5)
        time.sleep(random.uniform(0.8, 1.5))
        if not self.matcher.find_and_click(self.device, "背包返回", timeout=5):
            log.warning("未找到返回按钮，按 ESC 兜底返回主界面")
            self.back_to_home()
        return True

    def _eat_one(self, food):
        """在网格中找到食物图标点开详情弹窗，点"使用"；找不到就跳过。

        上一个"使用"后的关闭动画可能吞掉点击，弹窗没开时重试一次。
        """
        for attempt in range(2):
            screen = self.device.screenshot()
            hit = self.matcher.find(screen, food, region=GRID_REGION)
            if not hit:
                log.info("%s 未找到，跳过（视为已食用）", food)
                return
            log.info("点击 [%s] @ (%d, %d) score=%.3f", food, hit[0], hit[1], hit[2])
            self.device.click(hit[0], hit[1])
            # 详情弹窗有 2/3 按钮两种布局，"使用"按钮位置不固定，用 OCR 文字定位
            use_hit = None
            deadline = time.time() + 5
            while time.time() < deadline:
                use_hit = ocr.find_text(self.device.screenshot(), "使用", region=POPUP_REGION)
                if use_hit:
                    break
                time.sleep(0.5)
            if use_hit:
                log.info("点击 [使用] @ (%d, %d)", use_hit[0], use_hit[1])
                self.device.click(use_hit[0], use_hit[1])
                log.info("%s 已使用", food)
                time.sleep(random.uniform(1.2, 2.0))
                return
            log.warning("%s 详情弹窗未打开（第 %d 次）", food, attempt + 1)
            self.device.press_esc()
            time.sleep(random.uniform(0.8, 1.2))
        log.warning("%s 多次尝试未成功，跳过", food)
