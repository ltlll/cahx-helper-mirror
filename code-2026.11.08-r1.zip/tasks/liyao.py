import logging
import random
import time

from core import ocr
from tasks.base import REWARD_POPUP_REGION, Task

log = logging.getLogger("task.liyao")

# 以下均为 405x720 客户区坐标
LIYAO_NODE_POS = (75, 230)                # 玩法地图"历妖问道"节点（位置固定）
LIYAO_DONE_REGION = (15, 248, 130, 45)    # 节点下方"已完成"标记（今日已通关则显示）
LIYAO_CLEAR_REGION = (130, 215, 145, 45)  # 挑战页"当前难度已通关"横幅
CHALLENGE_BTN_REGION = (120, 565, 170, 55)  # 挑战页"前往挑战"按钮
BATTLE_BTN_REGION = (130, 655, 150, 60)   # 阵容页"战斗"按钮
MANUAL_MARK_REGION = (60, 400, 260, 75)   # 战斗中手动模式的"请给XX下达指令"技能菜单标题（位置随宠物名长度/面板内容漂移，实测 y 430~454，边距留足）
AUTO_BTN_POS = (368, 683)                 # 战斗右下角"自动"按钮


class Liyao(Task):
    """历妖问道：玩法 → 历妖问道节点 → 前往挑战 → 阵容页点"战斗"
    → 战斗中若是手动模式（出现技能菜单）点右下角"自动" → 等通关奖励弹窗
    （成功通关难度X）→ 点空白关闭 → 返回主界面。

    实测最高难度一战通关即拿全部奖励（完成高难度直接获得低难度奖励）。
    节点点不出"前往挑战"说明今日已完成，跳过不算失败。
    """

    name = "liyao"
    title = "历妖问道"

    BATTLE_TIMEOUT = 600  # 战斗最长等待（秒）

    def _try_once(self):
        self.dismiss_popups()
        if not self.open_wanfa():
            return False
        # 节点下方显示"已完成" = 今日已通关，直接跳过
        if ocr.find_text(self.device.screenshot(), "已完成",
                         region=LIYAO_DONE_REGION, min_similarity=1.0):
            log.info("历妖问道今日已完成（节点显示已完成），跳过")
            return True
        self.device.click(*LIYAO_NODE_POS)
        hit = None
        deadline = time.time() + 8
        while time.time() < deadline:
            screen = self.device.screenshot()
            # 已通关的挑战页也有"前往挑战"，但带"当前难度已通关"横幅，先认横幅
            if ocr.find_text(screen, "已通关", region=LIYAO_CLEAR_REGION,
                             min_similarity=0.8):
                log.info("当前难度已通关，跳过")
                return True
            hit = ocr.find_text(screen, "前往挑战",
                                region=CHALLENGE_BTN_REGION, min_similarity=1.0)
            if hit:
                break
            time.sleep(0.6)
        if not hit:
            log.info("历妖问道无“前往挑战”（今日已完成），跳过")
            return True
        log.info("点击 [前往挑战] @ (%d, %d)", hit[0], hit[1])
        self.device.click(hit[0], hit[1])
        r = self._start_battle(hit[0], hit[1])
        if r == "done":
            return True
        if not r:
            return False
        return self._wait_battle_end()

    def _start_battle(self, gx, gy, timeout=20):
        """阵容页点"战斗"进战斗。点击可能被吞：倒计时内阵容页没开且
        "前往挑战"还在（说明还在挑战页）就再点一次；若出现"当前难度已通关"
        横幅说明今天已打过，返回 "done"。"""
        deadline = time.time() + timeout
        while time.time() < deadline:
            screen = self.device.screenshot()
            hit = ocr.find_text(screen, "战斗",
                                region=BATTLE_BTN_REGION, min_similarity=1.0)
            if hit:
                log.info("点击 [战斗] @ (%d, %d)", hit[0], hit[1])
                self.device.click(hit[0], hit[1])
                return True
            if ocr.find_text(screen, "已通关", region=LIYAO_CLEAR_REGION,
                             min_similarity=0.8):
                log.info("当前难度已通关，跳过")
                return "done"
            if ocr.find_text(screen, "前往挑战",
                             region=CHALLENGE_BTN_REGION, min_similarity=1.0):
                log.warning("阵容页未打开，重试 [前往挑战]")
                self.device.click(gx, gy)
            time.sleep(1.0)
        log.warning("阵容页未打开")
        return False

    def _wait_battle_end(self):
        """进战斗后：手动模式则点"自动"，然后等"恭喜获得"通关弹窗并关闭。

        阵容页"战斗"的点击可能被吞（实测）：等 15 秒还没进战斗（阵容页的
        "战斗"按钮还在）就重点一次。
        """
        deadline = time.time() + self.BATTLE_TIMEOUT
        auto_clicked = False
        last_battle_click = time.time()
        while time.time() < deadline:
            self._check_stop()  # 长循环：响应 GUI 停止
            screen = self.device.screenshot()
            if self.dismiss_popups(screen):
                continue
            if ocr.find_text(screen, "点击空白处关闭",
                             region=REWARD_POPUP_REGION):  # 通关/失败结算弹窗
                return self._close_result()
            if not auto_clicked and ocr.contains_text(
                    screen, "下达指令", region=MANUAL_MARK_REGION):
                log.info("手动模式，点击 [自动]")
                self.device.click(*AUTO_BTN_POS)
                auto_clicked = True
                continue
            if time.time() - last_battle_click > 15:
                hit = ocr.find_text(screen, "战斗", region=BATTLE_BTN_REGION,
                                    min_similarity=1.0)
                if hit:
                    log.warning("战斗未开始（点击被吞？），重点 [战斗]")
                    self.device.click(hit[0], hit[1])
                    last_battle_click = time.time()
            time.sleep(2)
        log.warning("等待战斗结束超时")
        return False

    def _close_result(self):
        """关结算弹窗并判断是否通关（"恭喜获得"=通关，"点击空白处关闭"通用）。"""
        screen = self.device.screenshot()
        win = ocr.find_text(screen, "恭喜获得") is not None
        self.close_reward_popup(timeout=3)  # 弹窗已在，立即点空白关
        if win:
            log.info("历妖问道通关")
            return True
        log.warning("战斗未通关（结算无“恭喜获得”）")
        # 战败后人物留在挑战场景（堕神遗都一带——右缘没有「离开」图标，唯一
        # 出口是左下角返回；2026-10-18 补跑 4 号战败后被困 25 分钟，把重试和
        # 后续组队副本全拖死）——败局确定就立刻传送回云梦长安，别把"人在哪"
        # 的烂摊子留给重试/下一个任务（失败走 ensure_yunmeng 自身告警+逃逸兜底）
        self.ensure_yunmeng()
        return False
