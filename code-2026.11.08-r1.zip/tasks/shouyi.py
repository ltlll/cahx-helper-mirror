import logging
import random
import time

from core import ocr
from tasks.base import BLANK_CLICK_POS, REWARD_POPUP_REGION, Task

log = logging.getLogger("task.shouyi")

# 以下均为 405x720 客户区坐标
SHOUYI_REGION = (0, 240, 75, 75)          # 主界面左侧"收益"图标锚点
TAB_REGION = (130, 660, 280, 60)          # 面板底部 聚灵/收益/祈福 页签
QIFU_TAB_REGION = (300, 660, 90, 60)      # "祈福"页签
QIFU_BTN_REGION = (140, 520, 130, 70)     # 祈福页"祈福"/"领取"按钮
QIFU_CONFIRM_REGION = (220, 420, 150, 55) # 领取确认弹窗"确认"
DUKOU_MARK_REGION = (120, 540, 165, 85)   # 渡口页底部"免费刷新/一键领取"按钮（判定已进入渡口页；按钮中心偏上约 y=560，上边距必须留足）
DUKOU_TITLE_REGION = (5, 30, 140, 70)     # 渡口页左上角"妖灵渡口"标题（兜底判定；实测标题中心 y≈60，画到 y=55 会漏检）
CLAIM_BTN_MIN_X = 280                     # 订单行右侧"领取"按钮的 x 下限（区分底部"一键领取"）
ORDER_LIST_REGION = (10, 215, 380, 360)   # 订单列表区
JULING_TAB_REGION = (140, 660, 130, 60)   # "聚灵"页签
JULING_MARK_REGION = (10, 398, 220, 45)   # 聚灵页"聚灵效率"文字（判定已进入聚灵页；OCR 裁剪要留边距）
BAG_POS = (203, 285)                      # 聚灵袋（点击收取）
FREE_ICON_REGION = (330, 320, 75, 70)     # 聚灵页右侧"免费"加速图标（文字在图标下方）
FREE_CONFIRM_REGION = (230, 375, 130, 55) # 免费加速确认弹窗的"免费"按钮
FREE_CANCEL_REGION = (60, 375, 130, 55)   # 确认弹窗的"取消"（非免费时取消）
STILL_ACCEL_REGION = (50, 380, 160, 75)   # 灵能上限弹窗左侧"仍要加速"按钮
                                          # （"灵能数量即将到达储存上限…"，右侧"前往接取"永远不点，不进此区域）
DISPATCH_MARK_REGION = (90, 495, 130, 40) # 派遣界面"妖灵需求"文字（判定派遣界面）
DISPATCH_BTN_POS = (120, 580)             # 妖灵派遣"一键派遣"（OCR 会把四字拆行，用固定坐标）
DEPART_BTN_POS = (285, 580)               # 妖灵派遣"出发"
DISPATCH_CLOSE_POS = (375, 105)           # 派遣界面右上角 X（灵能不足等情况关窗）
GET_ENERGY_TITLE_REGION = (100, 210, 220, 70)  # "获取灵能"弹窗标题（灵能不足时点"接取"直接弹出，实测标题 (204,244)）
GET_ENERGY_POPUP_REGION = (70, 220, 270, 280)  # "获取灵能"弹窗整体（聚灵-收取/真灵塔-前往两行，"前往"永远不点）

QUALITY_FIRST = ("孤", "珍", "上")  # 优先接取的品质：孤品>珍品>上品（品质标签是竖排，OCR 逐字读出）
QUALITY_LAST = ("凡",)              # 没有免费刷新时才接凡品
QUALITY_COL_REGION = (5, 215, 85, 360)  # 订单列表左列品质标签区（竖排字，独立小区域扫描更稳：
                                         # 大区域扫描会把"上品"合并成一个框或整格漏读，实测）


class Shouyi(Task):
    """收益：主界面"收益"图标 →（祈福页有"祈福"按钮则先祈福：祈福→等动画→领取→确认）
    → 收益页签（妖灵渡口）→ 先领已完成订单 → 接取 孤/珍/上品订单（接取→一键派遣→出发）
    → 剩余订单没有上品及以上、列表还有"接取"且有"免费刷新"时才刷新后重新评估；
      没有免费刷新则凡品也接；列表无可接订单时不刷新
    → 灵能不足（点"接取"直接弹"获取灵能"）时收一次灵能（弹窗聚灵行"收取"——收取后
      自动跳到聚灵页，再用掉免费加速）回渡口继续接，仍不足则停（聚灵袋空防死循环）
    → 聚灵页：点聚灵袋收取，有"免费"图标则用掉免费加速（其余次数收费，不用）
    → 返回主界面。

    订单品质标签是竖排文字：在左列独立小区域扫描 + 包含匹配（大区域扫描会把
    "上品"合并成一个框或整格漏读）；订单列表与品质每天刷新，全部按当前截图
    扫描，不按固定行号。接取期间完成的订单在离开渡口前再领一轮。
    """

    name = "shouyi"
    title = "收益"

    def _try_once(self):
        self.dismiss_popups()
        if not self.matcher.find_and_click(self.device, "收益", timeout=8,
                                           region=SHOUYI_REGION, ccoeff_floor=0.45):
            return False
        if not self._wait_panel():
            return False
        self._do_qifu()
        if not self._goto_dukou():
            return False
        self._collect_completed()
        self._accept_orders()
        # 接取期间可能有进行中的订单完成，离开渡口前再领一轮
        self._collect_completed()
        self._do_juling()
        self.exit_panel_to_home()
        return True

    def _wait_panel(self, timeout=8):
        """等面板打开（底部页签出现）。"""
        deadline = time.time() + timeout
        while time.time() < deadline:
            if ocr.find_text(self.device.screenshot(), "收益",
                             region=TAB_REGION, min_similarity=1.0):
                return True
            time.sleep(0.6)
        log.warning("收益面板未打开")
        return False

    # ---- 祈福 ----

    def _do_qifu(self):
        """祈福页有"祈福"按钮时：祈福 → 等动画 → 领取 → 确认（领取后不能重置）。"""
        # 面板可能停在聚灵/收益页，先点祈福页签再看有没有按钮
        # 页签的可点区域是文字上方的圆形图标，OCR 定位的是文字，上移 20px 点图标
        screen = self.device.screenshot()
        if not ocr.find_text(screen, "祈福", region=QIFU_BTN_REGION, min_similarity=1.0):
            hit = ocr.find_text(screen, "祈福", region=QIFU_TAB_REGION, min_similarity=1.0)
            if hit:
                self.device.click(hit[0], hit[1] - 20)
                time.sleep(random.uniform(1.2, 1.8))
        hit = ocr.find_text(self.device.screenshot(), "祈福",
                            region=QIFU_BTN_REGION, min_similarity=1.0)
        if not hit:
            log.info("今日已祈福（无祈福按钮），跳过")
            return
        log.info("点击 [祈福] @ (%d, %d)", hit[0], hit[1])
        self.device.click(hit[0], hit[1])
        time.sleep(random.uniform(4.0, 5.5))  # 祈福动画
        # 动画播完"领取"才可用：反复点直到弹出确认框
        deadline = time.time() + 20
        while time.time() < deadline:
            hit = ocr.find_text(self.device.screenshot(), "确认",
                                region=QIFU_CONFIRM_REGION, min_similarity=1.0)
            if hit:
                log.info("点击 [确认] @ (%d, %d)", hit[0], hit[1])
                self.device.click(hit[0], hit[1])
                time.sleep(random.uniform(1.2, 1.8))
                # 祈福确认后必弹"恭喜获得"奖励弹窗（"点击空白处关闭"），
                # 它会压暗并挡住底部页签，不关掉 _goto_dukou 扫不到"收益"
                # 页签，30 秒超时判失败回主界面重试（2026-10-11 实测）
                self.close_reward_popup(timeout=6)
                return
            hit = ocr.find_text(self.device.screenshot(), "领取",
                                region=QIFU_BTN_REGION, min_similarity=1.0)
            if hit:
                self.device.click(hit[0], hit[1])
            time.sleep(1.0)
        log.warning("祈福领取失败")

    # ---- 妖灵渡口订单 ----

    def _goto_dukou(self, timeout=30, min_clicks=3):
        """切到收益页签（妖灵渡口）：底部出现 刷新/一键领取 按钮，
        或左上角出现"妖灵渡口"标题（兜底，与订单状态无关）为准。

        订单全部完成待领取时底部是"一键领取"而不是"刷新"，两种都要认；
        全部订单进行中时底部可能什么都没有，靠标题兜底。
        注意：已在渡口页时点"收益"页签会把面板关掉（页签是开关），
        所以必须靠标题/按钮先判定已在渡口，只在确认不在时才点页签。
        5 账号并行时 OCR 只有 2 个引擎槽位，一轮"截图+OCR"高峰约 10 秒：
        timeout 给足 30 秒，且至少发出 min_clicks 次页签点击才允许超时。

        2026-10-10 事故修复：原写 `while time.time() < deadline or
        clicks < min_clicks` 时，"or clicks < min_clicks" 会把 deadline 短路——
        只要 OCR 一直读不到页签（如面板被页签误关后消失），clicks 到不了
        min_clicks，deadline 过了也退不出；而循环体只在命中页签时才打日志，
        于是账号线程**静默死循环**（4 个号卡在收益页近 2 小时，日志全空）。
        现改为：① 绝对硬上限 hard_deadline 兜底；② 每轮无条件打日志；
        ③ 页签找不到且已点过（clicks>0）时若已回到主界面，判定面板被误关，
        点主界面"收益"图标重开面板再继续。
        """
        start = time.time()
        deadline = start + timeout
        hard_deadline = start + timeout + 25  # 绝对上限：无论 clicks 多少都必须退出
        clicks = 0
        while time.time() < hard_deadline and (
                time.time() < deadline or clicks < min_clicks):
            self._check_stop()  # 长循环内响应 GUI 停止
            screen = self.device.screenshot()
            # 祈福/领取残留的"恭喜获得"弹窗会压暗并挡住底部页签，先点空白关掉
            if ocr.find_text(screen, "点击空白处关闭", region=REWARD_POPUP_REGION):
                log.info("奖励弹窗遮挡页签，点空白关闭")
                self.device.click(*BLANK_CLICK_POS)
                time.sleep(random.uniform(0.8, 1.2))
                continue
            texts = [t for t, *_ in ocr.scan(screen, region=DUKOU_MARK_REGION)]
            bottom_ok = any("刷新" in t or "一键领取" in t for t in texts)
            if bottom_ok or ocr.contains_text(screen, "妖灵渡口", region=DUKOU_TITLE_REGION):
                log.info("已进入妖灵渡口")
                return True
            hit = ocr.find_text(screen, "收益", region=TAB_REGION, min_similarity=1.0)
            if hit:
                clicks += 1
                log.info("点击 [收益页签] @ (%d, %d)（第 %d 次，已耗时 %.0fs）",
                         hit[0], hit[1] - 20, clicks, time.time() - start)
                self.device.click(hit[0], hit[1] - 20)  # 点文字上方的图标
            else:
                # 每轮无条件打日志：原实现只在命中页签时打，OCR 读不到就完全静默
                log.info("未进入渡口（已耗时 %.0fs，点击 %d 次）：页签未找到，底部OCR=%s",
                         time.time() - start, clicks, texts)
                # 页签是开关：已点过页签又回到主界面 = 面板被误关 → 重开收益面板
                if clicks > 0 and self.on_main_screen(screen):
                    log.warning("收益面板疑似被误关（已回主界面），点击 [收益] 图标重开")
                    self.matcher.find_and_click(self.device, "收益", timeout=6,
                                                region=SHOUYI_REGION, ccoeff_floor=0.45)
                    time.sleep(random.uniform(1.0, 1.6))
            time.sleep(random.uniform(0.8, 1.2))
        log.warning("进入妖灵渡口超时（等待 %d 秒，点击 %d 次）", timeout, clicks)
        self.save_debug_screenshot("shouyi_dukou_timeout")
        return False

    def _collect_completed(self):
        """已完成订单先领取再接新单：有"一键领取"优先点它；
        没有就逐个点订单行右侧的"领取"按钮。领完列表刷出新订单，
        每领一次重新扫描，直到没有可领。"""
        for _ in range(8):
            screen = self.device.screenshot()
            hit = ocr.find_text(screen, "一键领取", region=DUKOU_MARK_REGION,
                                min_similarity=1.0)
            if hit:
                log.info("点击 [一键领取] @ (%d, %d)", hit[0], hit[1])
            else:
                hit = self._find_claim_btn(screen)
                if not hit:
                    return
                log.info("点击订单 [领取] @ (%d, %d)", hit[0], hit[1])
            self.device.click(hit[0], hit[1])
            self.close_reward_popup(timeout=8)
            time.sleep(random.uniform(1.0, 1.6))

    @staticmethod
    def _find_claim_btn(screen):
        """订单行右侧单独的"领取"按钮（无"一键领取"时的兜底）。"""
        for text, cx, cy, _ in ocr.scan(screen, region=ORDER_LIST_REGION):
            if text == "领取" and cx > CLAIM_BTN_MIN_X:
                return cx, cy
        return None

    def _accept_orders(self, max_rounds=6):
        """先接 孤/珍/上品；剩余订单没有上品及以上、列表还有"接取"按钮、且有
        "免费刷新"时才刷新后重新评估；没有免费刷新则凡品也接。
        列表没有任何可接订单（全部已出发/进行中）时不刷新。
        **刷新前必须先把未领的完成订单领掉**（刷新会替换整个列表，可领的
        订单会被冲掉——先领完再判断品质和刷新）。
        灵能不足时收一次灵能再继续，仍不足则停止。"""
        qualities = QUALITY_FIRST
        recovered = False
        for _ in range(max_rounds):
            status = self._accept_by_quality(qualities)
            if status == "no_energy":
                if recovered or not self._recover_energy():
                    return
                recovered = True
                continue  # 补完灵能重试同一批品质
            if not status:
                return  # 出发失败等，停止接取
            if qualities is not QUALITY_FIRST:
                return  # 凡品轮也接完了
            screen = self.device.screenshot()
            if not self._has_accept_btn(screen):
                log.info("列表无可接订单，不刷新")
                return
            if self._has_claim_btn(screen):
                # 还有可领取的完成订单：先领取（刷新会把可领订单替换掉），
                # 领完列表会刷出新订单，回到循环重新评估品质
                log.info("列表还有可领取的订单，先领取再评估")
                self._collect_completed()
                continue
            hit = ocr.find_text(screen, "免费刷新",
                                region=DUKOU_MARK_REGION, min_similarity=1.0)
            if not hit:
                log.info("无免费刷新，凡品也接")
                qualities = QUALITY_FIRST + QUALITY_LAST
                continue
            log.info("剩余订单无上品及以上，点击 [免费刷新] @ (%d, %d)",
                     hit[0], hit[1])
            self.device.click(hit[0], hit[1])
            time.sleep(random.uniform(1.5, 2.2))
        log.warning("接取轮数达到上限")

    def _has_claim_btn(self, screen):
        """列表里是否还有未领的完成订单（"一键领取"或订单行右侧"领取"）。"""
        if ocr.find_text(screen, "一键领取", region=DUKOU_MARK_REGION,
                         min_similarity=1.0):
            return True
        return self._find_claim_btn(screen) is not None

    @staticmethod
    def _has_accept_btn(screen):
        """订单列表里是否还有"接取"按钮（全部已出发/进行中时列表无接取）。"""
        return any(text == "接取"
                   for text, *_ in ocr.scan(screen, region=ORDER_LIST_REGION))

    def _recover_energy(self):
        """灵能不足：在"获取灵能"弹窗点聚灵行的"收取"（实测收取后自动跳到聚灵页、
        弹窗自关；聚灵袋空则收不到，由调用方的一次性限制防死循环），
        再在聚灵页收聚灵袋/用掉免费加速，最后回渡口。"""
        log.info("灵能不足，领取灵能后继续接单")
        screen = self.device.screenshot()
        if ocr.find_text(screen, "获取灵能", region=GET_ENERGY_TITLE_REGION,
                         min_similarity=0.8):
            hit = ocr.find_text(screen, "收取", region=GET_ENERGY_POPUP_REGION,
                                min_similarity=1.0)
            if not hit:
                log.warning("获取灵能弹窗里没找到收取按钮")
                return False
            log.info("点击 [收取] @ (%d, %d)", hit[0], hit[1])
            self.device.click(hit[0], hit[1])
            time.sleep(random.uniform(1.5, 2.2))  # 收取后自动跳到聚灵页
        self._do_juling()  # 收聚灵袋 + 免费加速（已收过的步骤自动跳过）
        return self._goto_dukou()

    def _accept_by_quality(self, qualities):
        """接取当前列表里所有指定品质的订单，逐个接、每接一个重新扫描。
        返回 True 全部接完；"no_energy" 灵能不足；False 其它出发失败。"""
        for _ in range(8):
            target = self._find_acceptable(qualities)
            if not target:
                return True
            status = self._accept_one(*target)
            if status is not True:
                return status
        return True

    def _find_acceptable(self, qualities):
        """扫描订单列表：品质字先在左列独立小区域扫描（大区域扫描会把"上品"
        合并成一个框或整格漏读——实测同屏两次扫描结果不同），用包含匹配
        （合并框"上品"也能命中"上"），再与"接取"按钮按 y 坐标配对。"""
        screen = self.device.screenshot()
        btns = sorted(((cx, cy) for text, cx, cy, _ in
                       ocr.scan(screen, region=ORDER_LIST_REGION)
                       if text == "接取"), key=lambda b: b[1])
        if not btns:
            return None
        qs = sorted(cy for text, _, cy, _ in
                    ocr.scan(screen, region=QUALITY_COL_REGION)
                    if any(q in text for q in qualities))
        for qy in qs:
            for bx, by in btns:
                if abs(qy - by) < 30:
                    return bx, by
        return None

    def _accept_one(self, bx, by):
        """点"接取"→派遣界面一键派遣→出发。
        返回 True 成功；"no_energy" 灵能不足（弹"获取灵能"，由上层补灵能）；False 其它失败。"""
        log.info("接取订单 @ (%d, %d)", bx, by)
        self.device.click(bx, by)
        deadline = time.time() + 8
        while time.time() < deadline:
            screen = self.device.screenshot()
            # 灵能不足时点"接取"不会进派遣界面，而是直接弹"获取灵能"（实测）
            if ocr.find_text(screen, "获取灵能", region=GET_ENERGY_TITLE_REGION,
                             min_similarity=0.8):
                log.info("灵能不足（弹出获取灵能）")
                return "no_energy"
            if ocr.find_text(screen, "妖灵需求", region=DISPATCH_MARK_REGION,
                             min_similarity=0.8):
                break
            time.sleep(0.6)
        else:
            log.warning("派遣界面未打开")
            return False
        self.device.click(*DISPATCH_BTN_POS)   # 一键派遣
        time.sleep(random.uniform(1.2, 1.8))
        self.device.click(*DEPART_BTN_POS)     # 出发
        time.sleep(random.uniform(1.8, 2.5))
        screen = self.device.screenshot()
        if ocr.find_text(screen, "获取灵能", region=GET_ENERGY_TITLE_REGION,
                         min_similarity=0.8) or \
                ocr.contains_text(screen, "灵能不足"):
            log.info("出发时灵能不足，关闭派遣界面")
            self.device.click(*DISPATCH_CLOSE_POS)
            time.sleep(1.0)
            return "no_energy"
        if ocr.find_text(screen, "妖灵需求", region=DISPATCH_MARK_REGION,
                         min_similarity=0.8):
            log.warning("出发失败，关闭派遣界面")
            self.device.click(*DISPATCH_CLOSE_POS)
            time.sleep(1.0)
            return False
        log.info("订单已出发")
        return True

    # ---- 聚灵 ----

    def _do_juling(self):
        """聚灵页：点聚灵袋收取；有"免费"图标则用掉免费加速（其余次数收费，不用）。"""
        if not self._goto_juling():
            return
        # 收聚灵袋（空的点了也没弹窗，close_reward_popup 会自行跳过）
        log.info("点击聚灵袋收取")
        self.device.click(*BAG_POS)
        self.close_reward_popup(timeout=6)
        # 免费加速：图标文字"免费"在图标本体下方，点文字上方约 20px
        hit = ocr.find_text(self.device.screenshot(), "免费",
                            region=FREE_ICON_REGION, min_similarity=1.0)
        if not hit:
            log.info("无“免费”加速图标，跳过")
            return
        self.device.click(hit[0], hit[1] - 20)
        deadline = time.time() + 8
        while time.time() < deadline:
            screen = self.device.screenshot()
            hit = ocr.find_text(screen, "免费", region=FREE_CONFIRM_REGION,
                                min_similarity=1.0)
            if hit:
                log.info("点击 [免费加速] @ (%d, %d)", hit[0], hit[1])
                self.device.click(hit[0], hit[1])
                self.close_reward_popup(timeout=6)
                return
            # 灵能接近储存上限时弹的不是"免费/取消"，而是"是否先前往接取订单？"
            # ——用户要求点左侧"仍要加速"继续（右侧"前往接取"永远不点）
            hit = ocr.find_text(screen, "仍要加速", region=STILL_ACCEL_REGION,
                                min_similarity=1.0)
            if hit:
                log.info("灵能接近储存上限，点击 [仍要加速] @ (%d, %d)",
                         hit[0], hit[1])
                self.device.click(hit[0], hit[1])
                self.close_reward_popup(timeout=6)
                return
            hit = ocr.find_text(screen, "取消", region=FREE_CANCEL_REGION,
                                min_similarity=1.0)
            if hit:
                # 弹窗里不是"免费"按钮 = 剩余次数收费，取消不用
                log.info("免费次数已用完（其余收费），取消")
                self.device.click(hit[0], hit[1])
                return
            time.sleep(0.6)
        log.warning("免费加速确认弹窗未出现")

    def _goto_juling(self, timeout=10):
        deadline = time.time() + timeout
        while time.time() < deadline:
            screen = self.device.screenshot()
            if ocr.find_text(screen, "聚灵效率", region=JULING_MARK_REGION,
                             min_similarity=0.8):
                log.info("已进入聚灵页")
                return True
            hit = ocr.find_text(screen, "聚灵", region=JULING_TAB_REGION,
                                min_similarity=1.0)
            if hit:
                log.info("点击 [聚灵页签] @ (%d, %d)", hit[0], hit[1] - 20)
                self.device.click(hit[0], hit[1] - 20)  # 点文字上方的图标
            time.sleep(random.uniform(0.8, 1.2))
        log.warning("进入聚灵页超时")
        return False
