import logging
import random
import re
import time

from core import ocr, pace, teamup
from tasks.base import Task, TaskSkipped, reward_blank_pos

log = logging.getLogger("task.haishi")

# 挑战层数（塔层 → Boss 名）：塔面板层列表 11→1 从上到下；1–10 层需上拖列表
# 找到目标层条目点开后原地展开卡片（2026-10-09 实机教学实测，见 _tower_layer_challenge）
LAYERS = ((1, "精英赤霄"), (2, "精英小霸王"), (3, "精英黄金牙"),
          (4, "精英云姬"), (5, "精英沙妖"), (6, "精英鳄霸"),
          (7, "精英敖烈"), (8, "精英辛宁"), (9, "精英夜枭"),
          (10, "赤鳞邪龙"), (11, "狮王守卫"))
CN_NUM = {1: "一", 2: "二", 3: "三", 4: "四", 5: "五", 6: "六",
          7: "七", 8: "八", 9: "九", 10: "十", 11: "十一"}
SUPPORTED_LAYERS = tuple(n for n, _ in LAYERS)   # 可选层（1–11 选层流程通用）
DEFAULT_LAYER = 11                               # 无配置时的默认挑战层（狮王守卫）

# 以下均为 405x720 客户区坐标（按实操记录标定）
HAISHI_NODE_POS = (310, 105)              # 玩法地图上的海市蜃楼节点（位置固定；竖排美术字 OCR 会丢字，不用文字定位）
GO_REGION = (140, 455, 130, 55)           # 海市蜃楼详情卡的"前往"按钮
TOWER_CHALLENGE_REGION = (300, 120, 105, 70)  # 塔面板顶层(11层)展开卡片的"挑战"按钮
TOWER_LIST_REGION = (60, 60, 300, 620)    # 塔面板层数列表（OCR 找目标层条目）
CARD_CHALLENGE_REGION = (250, 100, 155, 540)  # 展开卡片上"挑战"的右缘大区域（卡片随层位置漂移，不定死）
SCENE_ENTRY_REGION = (60, 500, 300, 90)   # 副本场景底部追踪卡"挑战X"入口
COUNT_REGION = (120, 665, 170, 45)        # 塔面板底部"奖励次数：n/2"
EXHAUSTED_REGION = (270, 105, 135, 190)   # 追踪面板"今日奖励次数已耗尽"
BOSS_ENTRY_POS = (180, 545)               # 场景追踪卡兜底固定点（11 层实测）
# 副本场景第 2 场：底部追踪卡入口的候选点击位（按命中概率排序）。第 2 场
# "挑战X"美术字 OCR 常读不到，旧写法只点一个固定位、点空就整项判负
#（2026-10-17 5 号队长端 haishi 第 2 场事故）→ 改为逐点重试：点后未见
#「开始挑战」就换下一个候选位。
SCENE_ENTRY_FALLBACKS = ((180, 545), (200, 545), (205, 560), (168, 560))
SCENE_START_TIMEOUT = 8                   # 每个候选位后等「开始挑战」的秒数
START_REGION = (120, 500, 165, 70)        # Boss 面板"开始挑战"
READY_REGION = (230, 460, 150, 90)        # 队员准备面板的"准备"按钮（左侧是"拒绝"，别点错）
BATTLE_ROUND_REGION = (150, 0, 130, 40)   # 战斗画面顶部"第X回合"
BATTLE_AUTO_POS = (368, 683)              # 战斗右下角"自动"
SETTLE_REGION = (60, 100, 285, 500)       # 结算/领奖弹窗文字区
SETTLE_BLANK_POS = (200, 640)             # 大格"恭喜获得"弹窗下方空白（读不到提示时的兜底点）
SETTLE_KEYWORDS = ("点击空白处关闭", "点击宝箱", "秒后自动", "恭喜获得")
# 战斗结束后等结算/领奖弹窗出现的秒数。2026-10-27 实机（run 3da16c）：打完
# 第 1 场后弹窗**晚到 10 秒以上**（旧写法只 sleep 3 看一帧就收工，弹窗没关
# → 污染后面的场景判定 → 第 2 场整场丢失）。同 2026-10-23 跑商报酬弹窗的坑。
SETTLE_POPUP_WAIT = 18
LEAVE_REGION = (340, 280, 65, 80)         # 副本场景右缘"离开"图标
LEAVE_POS = (368, 320)
TRACKER_BOSS_REGION = (120, 540, 160, 80)  # 追踪面板"挑战X"条目（判定还在副本场景）

MAX_RUNS = 2              # 海市蜃楼每天 2 次
MAX_ATTEMPTS = 4          # 一场最多"发起挑战"次数（含未进入战斗的重试，防死循环）
BATTLE_TIMEOUT = 480      # 单场战斗最长等待（秒）
MEMBER_GIVEUP = 1500      # 队员端等副本结果的最长时长（防队长线程异常后干等）


class Haishi(Task):
    """海市蜃楼（日常副本，5 人组队）：队长带队打 2 次所选塔层 Boss。

    前置：zudui 组队成功（team_success=True），否则全队跳过。
    挑战层数由 config 的 layer 单选（1–11，无配置=默认 11 层狮王守卫）。
    队长端：玩法→海市蜃楼节点→前往→塔面板读"奖励次数:n/2"（2/2 直接收工）
    →选层挑战（11 层打开即在顶部展开直接点"挑战"；其他层上拖列表找到目标层
    条目点开，原地展开卡片后点卡片上的"挑战"）→自动寻路到 Boss→Boss 面板
    "开始挑战"→（通知队员）进战斗点"自动"→等战斗结束→关结算/领奖弹窗，
    打满 2 次后点场景右缘"离开"（第二场点底部追踪卡"挑战+Boss 名"再接）。
    队员端：等挑战信号→点"准备"（赐福令卡遮挡先点 X）→进战斗点"自动"
    →等结束关弹窗→等下一轮；队长点离开后跟随离场。
    """

    name = "haishi"
    title = "海市蜃楼"
    category = "日常副本"

    def _try_once(self):
        coord = teamup.coordinator()
        if not coord.begun:
            log.info("非 GUI 5 开并行模式（协调器未初始化），跳过海市蜃楼")
            raise TaskSkipped("协调器未初始化（非 5 开并行模式），海市蜃楼未执行")
        if coord.dungeon_result(self.name) is not None:
            # 结果已定（重试尝试短路）：如实回报——成了算成功，败了算失败
            if coord.dungeon_result(self.name) is not True:
                raise TaskSkipped("组队已判负，海市蜃楼未执行")
            return True
        # 上一个组队副本任务队长端失败后自动改选了队长：先重建队伍
        if coord.reteam_pending():
            self.reteam_if_requested(coord, self.title)
        # 队长按协调器判定（不是账号库静态标记）：自动改选后新队长立即接管
        me_is_captain = (coord.captain_id == self.account.get("id"))
        if coord.team_success is not True:
            log.info("组队未成功，海市蜃楼按失败计入小结")
            if me_is_captain:
                coord.dungeon_finish(self.name, False)  # 唤醒队员端退出等待
            raise TaskSkipped("组队未成功")
        # 挑战层数（config layer 单选；无配置=默认 11 层狮王守卫）。所选层无效
        # （不在 1–11）时整队跳过，避免误打/干等
        layer = self._target_layer()
        if layer not in SUPPORTED_LAYERS:
            log.warning("海市蜃楼所选 %d 层无效（可选 1–11），本轮跳过", layer)
            if me_is_captain:
                coord.dungeon_finish(self.name, False)  # 唤醒队员端；skip 不算失败
            return True
        log.info("挑战层数: %d层 %s", layer, self._boss_name())
        if me_is_captain:
            return self._captain_flow(coord)
        return self._member_flow(coord)

    def _target_layer(self):
        """本次要打的层数（config layer；无配置/解析失败=默认 11 层）。"""
        return self._selected_layer() or DEFAULT_LAYER

    def _boss_name(self):
        return dict(LAYERS).get(self._target_layer(), "")

    def _selected_layer(self):
        """config.yaml haishi 条目的 layer 单值（int；无配置/解析失败=None，
        由调用方按默认层处理）。兼容旧版 layers 列表（取首个）。"""
        raw = self.config.get("layer")
        if raw is None:
            legacy = self.config.get("layers")
            if isinstance(legacy, (list, tuple)) and legacy:
                raw = legacy[0]
        try:
            return int(raw)
        except (TypeError, ValueError):
            return None

    # ---- 队长端 ----

    def _captain_flow(self, coord):
        # 2026-10-20 修（早上一条龙 run 796973：5 号全报"完成"但只打了 1 场）：
        # 旧写法 `for run in range(1, 3)` 把**循环变量当"已打场数"**，第 1 场
        # "未进入战斗"时只 log 一句就跳到第 2 场 → 当日奖励次数只用了 1/2，
        # 最后还无条件 dungeon_finish(True) 报全队成功。现在：
        #  - played 只统计**真进过战斗**的场次；未进战斗当场重试本场
        #    （挑战被取消时游戏侧不扣次数，重试是安全的）；
        #  - 打不满 2 场且不是"次数已用完" → 交 captain_fail_finish 走两段式
        #    （只改选队长、不判负），让第 2 次尝试由新队长补打；绝不假成功。
        played = 0
        attempts = 0
        exhausted = False   # 游戏侧明确显示"今日奖励次数已耗尽/用完"
        while played < MAX_RUNS:
            self._check_stop()
            if attempts >= MAX_ATTEMPTS:
                log.warning("海市蜃楼已发起 %d 次仍只打成 %d/%d 场，收工",
                            attempts, played, MAX_RUNS)
                break
            attempts += 1
            # 人还在副本场景里（第 2 场 / 上一场被打断后重试）：走底部追踪卡入口；
            # 否则重新走"玩法→海市蜃楼→塔面板"（塔面板还能读到剩余奖励次数）
            in_scene = self._in_dungeon_scene()
            if in_scene:
                if played > 0 and self._count_exhausted():
                    log.info("今日奖励次数已耗尽，不再挑战")
                    exhausted = True
                    break
            else:
                if not self._enter_tower():
                    if played == 0:
                        log.warning("进海市蜃楼塔面板失败")
                        self.captain_fail_finish(coord, "进海市蜃楼塔面板失败")
                        return False
                    # 2026-10-27：已打成 N 场却回不到塔面板，多半是"人其实还在
                    # 副本场景里"（判定被弹窗骗了 / 出口没走通）。按用户规则——
                    # 第 2 场本来就该**留在场景里点底部追踪卡「挑战狮王守卫」**，
                    # 不该退出重进——这里兜底走一次场景内入口，而不是直接收工。
                    log.warning("已打成 %d/%d 场，重新进塔面板失败："
                                "按仍在副本场景处理，直接点追踪卡挑战兜底",
                                played, MAX_RUNS)
                    in_scene = True
                count = self._reward_count()
                if count is not None and count >= MAX_RUNS:
                    log.info("今日奖励次数已用完（%d/2），不再挑战", count)
                    exhausted = True
                    break
            log.info("===== 海市蜃楼 第 %d/%d 场（第 %d 次发起）=====",
                     played + 1, MAX_RUNS, attempts)
            if not self._start_challenge(coord, in_scene=in_scene):
                # 找不到挑战入口时先确认是不是次数本就用完了（改选队长接管后
                # 常见：上一个队长已经把 2/2 打满，这里再点只会点空）
                if self._count_exhausted():
                    log.info("找不到挑战入口且追踪面板显示次数已耗尽，按已完成收工")
                    exhausted = True
                    break
                if played > 0:
                    # 已经打过 N 场、剩下这场点不动：交两段式补打（只打成 N/2），
                    # 不要当成"入口都没进"当场判负（2026-10-27 run 3da16c：
                    # 4 号接管后"发起挑战失败"直接判负，全队白丢第 2 场）
                    log.warning("已打成 %d/%d 场，剩下这场进不去，收工交补打",
                                played, MAX_RUNS)
                    break
                self.captain_fail_finish(coord, "发起挑战失败", retry_in_place=False)
                return False
            if not self._fight_and_settle():
                # 没进战斗 = 这场没打成（准备倒计时过期/挑战被取消），当日次数
                # 没扣 → 清掉残留弹窗后重试本场，绝不能算进 played
                log.warning("第 %d 场未进入战斗，重试本场（不计入已打场数）",
                            played + 1)
                self.dismiss_popups()
                continue
            played += 1
            log.info("海市蜃楼已打成 %d/%d 场", played, MAX_RUNS)
        self._leave_scene()
        if played < MAX_RUNS and not exhausted:
            # 没打满 2 场：走两段式（见 base.captain_fail_finish）——先只改选
            # 队长、不判负，让第 2 次尝试由新队长补打；一场都没打成也走这条路
            # （旧写法无条件 dungeon_finish(True) 报全队成功，是最坑的假成功）
            log.warning("海市蜃楼只打成 %d/%d 场，交第 2 次尝试补打（改选队长）",
                        played, MAX_RUNS)
            self.captain_fail_finish(
                coord, "只打成 %d/%d 场" % (played, MAX_RUNS))
            return False
        coord.dungeon_finish(self.name, True)
        return True

    def _in_dungeon_scene(self):
        """是否还在海市蜃楼副本场景里（右缘有「离开」或底部追踪卡有「挑战」）。

        2026-10-27 修（run 3da16c 第 2 场丢失）：判定前先关一次"点击空白处关闭"
        类奖励弹窗 —— 弹窗会把右缘「离开」和底部追踪卡一起盖住，两个判据同时
        落空 → 误判"人已不在副本" → 改走 `_enter_tower()` 找「玩法」（副本场景
        里根本没有玩法图标）→ 未找到玩法 ×3 后入口重试用尽 → 第 2 场白丢。
        """
        screen = self.device.screenshot()
        if self.close_blank_popup(screen):
            pace.wait(0.8, 1.2)
            screen = self.device.screenshot()
        if ocr.find_text(screen, "离开", region=LEAVE_REGION, min_similarity=0.75):
            return True
        return ocr.contains_text(screen, "挑战", region=TRACKER_BOSS_REGION)

    def _count_exhausted(self):
        """追踪面板显示"今日奖励次数已耗尽"（第二场开打前判定）。"""
        return ocr.contains_text(self.device.screenshot(), "今日奖励次数已耗尽",
                                 region=EXHAUSTED_REGION)

    def _enter_tower(self):
        """玩法 → 海市蜃楼节点 → 详情卡"前往" → 塔面板（顶层有"挑战"）。

        2026-10-17：失败后先清浮层 + 退特殊场景再重来一遍（同 zhongkui/liudao，
        入口阶段被残留浮层或"人还在上一个副本场景"打穿是常态）。
        """
        for attempt in range(2):
            if attempt:
                log.warning("海市蜃楼入口失败，清浮层/退特殊场景后重试（第 %d 次）",
                            attempt + 1)
                self.dismiss_popups()
                self._escape_special_scene()
            if not self.open_wanfa():
                continue
            for i in range(2):
                self.device.click(*HAISHI_NODE_POS)
                hit = self._wait_text("前往", GO_REGION, timeout=8)
                if hit:
                    log.info("点击 [前往] @ (%d, %d)", hit[0], hit[1])
                    self.device.click(hit[0], hit[1])
                    if self._wait_text("挑战", TOWER_CHALLENGE_REGION, timeout=15):
                        return True
                log.warning("海市蜃楼详情卡/塔面板未弹出，重试 (%d/2)", i + 1)
        return False

    def _reward_count(self):
        """塔面板底部"奖励次数：n/2"解析已用次数；读不出返回 None。"""
        for text in ocr.dump_texts(self.device.screenshot(), COUNT_REGION):
            m = re.search(r"(\d)\s*/\s*2", text)
            if m:
                return int(m.group(1))
        return None

    def _start_challenge(self, coord, in_scene=False):
        """发起一场挑战 → Boss 面板"开始挑战" → 通知队员准备。

        第一场走塔面板：塔打开时 11 层固定在顶部展开（"挑战"直接点）；其他层
        先上拖列表找到目标层条目点开（原地展开卡片），再点卡片上的"挑战"。
        第二场还在副本场景里（没有"玩法"图标，重进塔面板必失败），点底部追踪卡
        的"挑战+Boss 名"入口（11 层兼容旧的固定坐标兜底）。
        """
        if in_scene:
            # 第 2 场在副本场景里：走底部追踪卡「挑战X」入口。赐福令道具卡会挡住
            # 追踪卡 → 先点 X 清一次；入口 OCR 命中优先、其后固定候选位；每个点
            # 后 8 秒没见「开始挑战」就换下一个候选位重点（旧写法只点一次固定位，
            # 点空即判队长端失败 —— 2026-10-17 5 号 haishi 第 2 场事故）。
            self.close_fuka_card()
            cands = []
            hit = self._scene_challenge_pos()
            if hit:
                cands.append(hit)
            cands += [p for p in SCENE_ENTRY_FALLBACKS if p not in cands]
            hit = None
            for i, pos in enumerate(cands):
                log.info("点击场景挑战入口 @ (%d, %d)（候选 %d/%d）",
                         pos[0], pos[1], i + 1, len(cands))
                self.device.click(*pos)
                hit = self._wait_text("开始挑战", START_REGION,
                                      timeout=SCENE_START_TIMEOUT)
                if hit:
                    break
                log.warning("候选位 (%d, %d) 未见 Boss 面板，换位重试", *pos)
            if not hit:
                log.warning("Boss 面板未弹出（已试 %d 个入口）", len(cands))
                return False
        else:
            hit = None
            if self._target_layer() == DEFAULT_LAYER:
                # 11 层打开塔面板即展开在顶部（实测最快路径）
                hit = self._wait_text("挑战", TOWER_CHALLENGE_REGION, timeout=4)
            if hit:
                log.info("点击 [挑战] @ (%d, %d)", hit[0], hit[1])
                self.device.click(hit[0], hit[1])
            else:
                btn = self._tower_layer_challenge()
                if btn is None:
                    log.warning("塔面板未找到目标层挑战按钮")
                    return False
                log.info("点击目标层 [挑战] @ (%d, %d)", *btn)
                self.device.click(*btn)
            hit = self._wait_text("开始挑战", START_REGION, timeout=10)
            if not hit:
                log.warning("Boss 面板未弹出")
                return False
        log.info("点击 [开始挑战] @ (%d, %d)", hit[0], hit[1])
        self.device.click(hit[0], hit[1])
        coord.dungeon_start_round(self.name)
        coord.dungeon_wait_ready(self.name, 40, self._check_stop)  # 给队员点准备的时间
        return True

    def _tower_layer_challenge(self):
        """塔面板翻层选中目标层并返回展开卡片上的"挑战"按钮位置。

        层列表 11→1 从上到下，每上拖一次（内容区按住上滑）约露出 2 层；找到
        目标层条目（Boss 名优先，层数次之）点击后卡片**原地展开**，"挑战"按钮
        位置随层漂移，在右缘大区域内 OCR 定位。找不到返回 None。
        """
        layer = self._target_layer()
        boss = self._boss_name()
        drag_up = layer < DEFAULT_LAYER   # 目标在列表下方=内容上拖；11 层向下拖找回
        deadline = time.time() + 40
        while time.time() < deadline:
            self._check_stop()
            screen = self.device.screenshot()
            hit = None
            if boss:
                hit = ocr.find_text(screen, boss, region=TOWER_LIST_REGION,
                                    min_similarity=0.9)
            if not hit:
                hit = ocr.find_text(screen, f"第{CN_NUM[layer]}层",
                                    region=TOWER_LIST_REGION, min_similarity=0.9)
            if hit:
                log.info("塔面板找到目标层条目 [%s] @ (%d, %d)",
                         boss or f"第{CN_NUM[layer]}层", hit[0], hit[1])
                self.device.click(hit[0], hit[1])
                # 原地展开卡片，等"挑战"出现（展开位置随层漂移，右缘大区域 OCR）
                dl = time.time() + 6
                while time.time() < dl:
                    self._check_stop()
                    btn = ocr.find_text(self.device.screenshot(), "挑战",
                                        region=CARD_CHALLENGE_REGION,
                                        min_similarity=1.0)
                    if btn:
                        return (btn[0], btn[1])
                    time.sleep(0.6)
                log.warning("点层条目后卡片未展开出挑战按钮")
                return None
            if drag_up:
                self.device.drag(200, 430, 200, 160)
            else:
                self.device.drag(200, 180, 200, 440)
            time.sleep(1.0)
        log.warning("塔面板多次翻页未找到 %d 层", layer)
        return None

    def _scene_challenge_pos(self, timeout=8):
        """副本场景底部追踪卡的挑战入口：OCR「挑战+Boss 名」/「挑战」（同一张
        卡，各层通用）。读不到返回 None —— 由 `_start_challenge` 按候选位序列
        逐点重试（旧写法在这里悄悄返回固定兜底位，调用方无从知道是否真命中，
        点空就整项判负）。"""
        boss = self._boss_name()
        deadline = time.time() + timeout
        while time.time() < deadline:
            self._check_stop()
            screen = self.device.screenshot()
            if boss:
                hit = ocr.find_text(screen, f"挑战{boss}", region=SCENE_ENTRY_REGION,
                                    min_similarity=0.85)
                if hit:
                    return (hit[0], hit[1])
            hit = ocr.find_text(screen, "挑战", region=SCENE_ENTRY_REGION,
                                min_similarity=1.0)
            if hit:
                return (hit[0], hit[1])
            time.sleep(0.8)
        return None

    def _fight_and_settle(self):
        """进战斗开自动 → 等结束 → 关结算/领奖弹窗。

        返回 True=真进过战斗（这场算打成）；False=压根没进战斗（挑战被取消/
        准备倒计时过期 —— 当日次数没扣，调用方必须重试本场）。
        旧写法这里静默 return，调用方以为这场打完了 → 2 场变 1 场还报成功。
        """
        if not self._wait_battle_start(60):
            log.warning("未进入战斗")
            return False
        self.device.click(*BATTLE_AUTO_POS)
        log.info("已开自动，等待战斗结束")
        self._wait_battle_end()
        self._settle_popups()
        return True

    # ---- 队员端 ----

    def _member_flow(self, coord):
        me_id = self.account.get("id")
        last = 0
        deadline = time.time() + MEMBER_GIVEUP
        joined = False   # 是否实际参与（见到准备面板或进过战斗）
        while time.time() < deadline:
            self._check_stop()
            # 队长改选接管（2026-10-18 run 7792f4：队长端失败改选后，新队长
            # 线程正睡在队员等待里无人接管，全队干等到超时；见 liudao 同款注释）
            if (coord.dungeon_result(self.name) is None
                    and me_id == coord.captain_id):
                log.warning("原队长失败，本号被改选为队长，接管海市蜃楼队长流程")
                return self._captain_flow(coord)
            if coord.dungeon_result(self.name) is not None:
                log.info("副本已结束（%s）",
                         "完成" if coord.dungeon_result(self.name) else "失败")
                break
            r = coord.dungeon_wait_round(self.name, last, timeout=600,
                                         check_stop=self._check_stop)
            if coord.dungeon_result(self.name) is not None:
                break
            if r == last:
                continue  # 队长还没发起，继续等
            last = r
            if self._ready_up():
                joined = True
            if me_id is not None:
                coord.dungeon_mark_ready(self.name, me_id, r)
            if self._wait_battle_start(60):
                joined = True
                self.device.click(*BATTLE_AUTO_POS)
                self._wait_battle_end()
            self._settle_popups()
        else:
            log.warning("等待副本结果超时")
        if not joined:
            # 队长一次挑战都没发起就结束了副本（今日次数已用完等）→ 全队
            # 本来就无从参与，不是本号掉队，不计失败（2026-10-13 手动轮实测：
            # 队长 2/2 次数用完直接收工，4 个队员全被误记"疑似不在队伍"失败）
            if (coord.dungeon_result(self.name) is True
                    and coord.dungeon_round(self.name) == 0):
                log.info("队长未发起任何挑战即结束副本（次数用完等），"
                         "本号未参与，不计失败")
                return True
            # 全程既没见到准备面板也没进战斗 → 多半不在队伍里（邀请接受失效/
            # 被顶号掉队）。如实计失败，别再"没打也算成功"
            #（2026-10-12 实测 6 号邀请弹窗挂着整场缺席）。
            raise TaskSkipped("全程未见准备面板且未进入战斗（疑似不在队伍），"
                              "海市蜃楼未参与")
        if coord.dungeon_result(self.name) is None:
            # 2026-10-18 改判：参与过但等到超时都没拿到队长结果 = 副本没打完
            # （旧写法按"参与过即成功"，run 7792f4 的假成功就是这么来的）
            raise TaskSkipped("等待海市蜃楼副本结果超时（%ds），副本未完成"
                              % MEMBER_GIVEUP)
        if coord.dungeon_result(self.name) is not True:
            # 队长端判负 = 本号也没打成，如实计失败（2026-10-18 补跑实测漏网：
            # break 出循环后 joined=True 走到 return True，队长判负被记成完成）
            raise TaskSkipped("队长端海市蜃楼失败，本号未参与完成")
        return True  # 拿到队长结果且为成功

    def _ready_up(self, timeout=30):
        """点准备面板的"准备"；赐福令卡遮挡先点 X，挂着「组队邀请」弹窗
        （接受点击曾失效）先点接受——不然准备面板永远出不来。"""
        deadline = time.time() + timeout
        while time.time() < deadline:
            self._check_stop()
            screen = self.device.screenshot()
            hit = ocr.find_text(screen, "准备", region=READY_REGION,
                                min_similarity=1.0)
            if hit:
                log.info("点击 [准备] @ (%d, %d)", hit[0], hit[1])
                self.device.click(hit[0], hit[1])
                return True
            if self._accept_team_invite(screen):
                time.sleep(1.5)
                continue
            if ocr.find_text(screen, "使用", region=(270, 490, 125, 60),
                             min_similarity=1.0):
                self.device.click(373, 405)  # 赐福令卡 X
            time.sleep(1)
        log.warning("未出现准备面板（可能超时），按已准备处理")
        return False

    # ---- 公共 ----

    def _wait_text(self, text, region, timeout, min_similarity=1.0):
        deadline = time.time() + timeout
        while time.time() < deadline:
            hit = ocr.find_text(self.device.screenshot(), text,
                                region=region, min_similarity=min_similarity)
            if hit:
                return hit
            time.sleep(0.6)
        return None

    def _in_battle(self, screen):
        return ocr.contains_text(screen, "回合", region=BATTLE_ROUND_REGION)

    def _wait_battle_start(self, timeout):
        deadline = time.time() + timeout
        while time.time() < deadline:
            self._check_stop()
            if self._in_battle(self.device.screenshot()):
                return True
            time.sleep(1)
        return False

    def _wait_battle_end(self):
        deadline = time.time() + BATTLE_TIMEOUT
        while time.time() < deadline:
            self._check_stop()
            screen = self.device.screenshot()
            if self.dismiss_popups(screen):
                continue
            if not self._in_battle(screen):
                log.info("战斗结束")
                return True
            time.sleep(3)
        log.warning("战斗超时未结束")
        return False

    def _settle_popups(self, rounds=6, wait_popup=SETTLE_POPUP_WAIT):
        """战斗后的结算/领奖弹窗：挑战奖励（2 秒自动领）→恭喜获得→点击空白
        处关闭，逐轮点空白关掉；赐福令卡弹出一并点 X。

        2026-10-27 修（一条龙 run 3da16c，3 号队长只打成 1/2 场）：旧写法固定
        sleep 3 后**只看一帧**，关键词没命中就 return —— 而"恭喜获得/点击空白
        处关闭"常常**晚到 10 秒以上**。弹窗没关就进下一轮循环 → `_in_dungeon_
        scene()` 的「离开」和「挑战」两个判据都被弹窗盖住 → 误判"已不在副本"
        → 改走 `_enter_tower()` 找玩法（副本场景里没有玩法图标）→ 入口重试用尽
        → 第 2 场整场丢失。现在首轮轮询等到弹窗出现（SETTLE_POPUP_WAIT）再逐轮
        点空白关掉；空白点按提示文字实际位置算（大弹窗会盖住固定点）。
        """
        for i in range(rounds):
            if i == 0:
                screen = self._wait_settle_popup(wait_popup)
                if screen is None:
                    return
            else:
                time.sleep(3)
                screen = self.device.screenshot()
            texts = ocr.dump_texts(screen, SETTLE_REGION)
            acted = False
            if any(k in t for t in texts for k in SETTLE_KEYWORDS):
                log.info("关闭结算/领奖弹窗")
                self.device.click(*(reward_blank_pos(screen)
                                    or SETTLE_BLANK_POS))
                acted = True
            if ocr.find_text(screen, "赐福令", region=(270, 380, 125, 60),
                             min_similarity=0.75):
                self.device.click(373, 405)
                acted = True
            if not acted:
                return

    def _wait_settle_popup(self, timeout):
        """等战斗后的结算/领奖弹窗出现（弹窗常晚到），返回截图；超时返回 None。"""
        deadline = time.time() + timeout
        while True:
            self._check_stop()
            screen = self.device.screenshot()
            if any(k in t for t in ocr.dump_texts(screen, SETTLE_REGION)
                   for k in SETTLE_KEYWORDS):
                return screen
            if time.time() >= deadline:
                log.info("战斗结束后 %d 秒内没等到结算/领奖弹窗", timeout)
                return None
            pace.wait(1.0, 1.5)

    def _leave_scene(self):
        """点副本场景右缘"离开"（打完 2 次后）。"""
        self.dismiss_item_cards()
        # 2026-10-27：先关掉残留的结算/领奖弹窗 —— 它会把右缘「离开」盖住，
        # 让这里直接 return "已不在副本场景"，人其实还留在副本里
        self.close_blank_popup()
        screen = self.device.screenshot()
        hit = ocr.find_text(screen, "离开", region=LEAVE_REGION,
                            min_similarity=0.75)
        if hit:
            log.info("点击 [离开] @ (%d, %d)", hit[0], hit[1])
            self.device.click(hit[0], hit[1])
        elif ocr.contains_text(screen, "挑战", region=TRACKER_BOSS_REGION):
            log.info("OCR 未读出离开，按固定位置点 [离开]")
            self.device.click(*LEAVE_POS)
        else:
            return  # 已不在副本场景
        time.sleep(random.uniform(2.5, 3.5))
