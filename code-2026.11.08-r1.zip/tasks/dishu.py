import logging
import random
import threading
import time
from pathlib import Path

import cv2

from core import imgio, ocr, pace, teamup
from tasks.base import (BANGHUI_REGION, BATTLE_AUTO_POS, GUILD_BTN_REGION,
                        GUILD_JOIN_REGION, LEAVE_CONFIRM_REGION,
                        MAP_LABEL_REGION, PANEL_BACK_POS, QUEST_TAB_REGION,
                        REWARD_POPUP_REGION, TEAM_TAB_POS, Task, TaskSkipped)
from tasks.zudui import (BANGHUI_POS, FRIEND_TAB_REGION, SEARCH_TITLE_REGION,
                         Zudui)

log = logging.getLogger("task.dishu")

# 以下均为 405x720 客户区坐标（按用户实操截图换算：客户区 = 截图坐标 - (8, 31)）
NEWS_TAB_REGION = (190, 170, 90, 45)       # 帮会面板"新闻"页签（面板打开判定，同 zudui）
MEMBER_TAB_REGION = (20, 168, 90, 45)      # 帮会面板"成员"页签（编队页没有"回帮"，切回成员页再找）
QUEST_TAB_POS = (310, 92)                  # 右上追踪面板"任务"页签固定槽位（实机截图量得：
                                           # 任务≈(310,92)、队伍≈(366,92)；OCR 漏读时兜底）
DISHU_ENTRY_REGION = (290, 90, 115, 220)   # 追踪面板任务视图"地鼠入侵"条目（图2，留纵向余量防条目下沉）
REMAIN_REGION = (295, 140, 110, 30)        # 条目下"当前地鼠剩余 n只"（观测日志用，读不到不影响流程）
FIGHT_REGION = (125, 480, 145, 60)         # "入侵的地鼠"弹窗"驱赶地鼠"按钮（图3）
MORE_REGION = (125, 465, 145, 60)          # 弹窗"再找一只"按钮（图6；同弹窗下方的"观战"绝不点）
POPUP_BLANK_POS = (40, 400)                # 弹窗外空白（用户规则：还是"再找一只"时点空白关弹窗）
SETTLE_BLANK_POS = (200, 640)              # "恭喜获得"弹窗下方空白（图5 弹窗大，不用 base.BLANK_CLICK_POS）
SETTLE_TITLE_REGION = (60, 150, 285, 120)  # "恭喜获得"标题（图5）
LEAVE_REGION = (340, 285, 65, 85)          # 帮会领地场景右缘"离开"图标
LEAVE_POS = (380, 325)                     # "离开"OCR 不中时的兜底固定点
BATTLE_ROUND_REGION = (150, 0, 130, 40)    # 战斗画面顶部"第X回合"

REFRESH_WAIT = 1500     # 等"地鼠入侵"整点刷新出现的上限（秒）：地鼠 12:00/18:00 准时刷新，
                        # 定时条目应比整点提前 5~10 分钟触发；可用 config 条目 refresh_wait 覆盖
POPUP_WAIT = 45         # 点条目/再找一只后等"入侵的地鼠"弹窗（含自动寻路耗时）
BATTLE_TIMEOUT = 300    # 单场战斗最长等待
MAX_MICE = 30           # 单场地鼠上限（兜底防死循环；正常以"条目消失"收工）
MEMBER_GIVEUP = 2700    # 队员端等副本结果上限（要盖住 等刷新 + 全部战斗）
REINFORCE_INTERVAL = 60  # 队长在帮会领地等待期间，每隔多久核对队伍并补邀一次
                         # （用户规则 2026-10-12：任务开始前可以反复补邀，不离队重组）

# ---- 指纹（模板）加速（用户需求 2026-10-13：打地鼠拼的是手速，怪物要抢，
# OCR 每次调用 ~1s 固定开销扛不住；这几个面板相对固定，用模板匹配替代）----
# 首次由 OCR 确认后自动把按钮/条目裁剪存为模板（data/dishu_fp/，自学习同
# core/charfp 思路），此后每轮先用 cv2.matchTemplate（毫秒级）判定，模板未命中
# 才退回 OCR 重新锚定。准确率可以向低处理：模板阈值放宽到 0.78，误判由
# 下一步"点驱赶地鼠后等战斗"兜底自愈。
FP_DIR = Path("data/dishu_fp")
FP_THRESHOLD = 0.78     # 模板匹配命中阈值（实心按钮 CCOEFF，真命中通常 >0.9）
FP_OCR_INTERVAL = 3.0   # 模板未命中时 OCR 重新锚定的最小间隔（秒）
# 裁剪尺寸：以 OCR 命中中心为准的按钮/条目模板框 (w, h)
FP_CROPS = {
    "fight": (116, 30),   # "驱赶地鼠"按钮
    "more": (116, 30),    # "再找一只"按钮
    "entry": (100, 22),   # 任务视图"地鼠入侵"条目文字
}
# 任务视图判定标记（与 base._team_panel_markers 的"前往"启发式互补：地鼠任务
# 视图只有"组队驱逐入侵的地鼠 / 当前地鼠刷新点 n只"，没有"前往"字样，旧启发式
# 会把任务视图误判成队伍视图→反复点"任务"页签把面板点收起，实测 2026-10-13
# 18:00 触发 quest_tab_fail 连锁：AI 兜底→重进帮会→重补邀请 白耗 2 分钟）
TRACKER_REGION = (280, 85, 125, 240)      # 追踪面板条目区（任务/队伍视图共用）
QUEST_VIEW_MARKERS = ("驱逐", "刷新点")    # 仅任务视图追踪条目会出现的字样
_fp_lock = threading.Lock()

INVITE_POLL = 10        # 队员端等待结果期间探测"补发邀请"的间隔（秒）。
                        # 队员端纯被动（用户规则 2026-10-13），只保留这一个探针


class Dishu(Task):
    """打地鼠（限时副本，每天 12:00/18:00 整点刷新；日常副本，排 zudui 后）。

    前置：zudui 组队成功（team_success=True），否则全队跳过。
    建议用定时任务（打地鼠类型）比整点提前 5~10 分钟触发：触发后先登录组队，
    队长 帮会→回帮 进帮会领地，在任务视图**等"地鼠入侵"条目刷新出现**再开打。

    队长端：帮会面板→"回帮"→帮会领地（左上角地图名判定）→ 等刷新（REFRESH_WAIT
    上限）→ 循环：点任务视图"地鼠入侵"条目→自动寻路→"入侵的地鼠"弹窗：
    有"驱赶地鼠"则点开打（默认自动战斗；读到"下达指令"=手动模式才点"自动"），
    等"回合"消失后关"恭喜获得"（点 (200,640) 空白）；只有"再找一只"则点它寻路下
    一只，还是"再找一只"就点弹窗外空白 (40,400) 关掉，回循环重新点条目（用户规则）。
    任务视图里"地鼠入侵"条目消失（连扫两轮确认，防 OCR 漏检/面板收起误判）
    **且确认不在战斗中**（战斗画面盖住任务视图，条目不可见≠打完，用户实测
    教训）= 打完 → 点场景右缘"离开"回主界面。

    等刷新期间（用户规则 2026-10-12）：每 REINFORCE_INTERVAL 秒核对队伍，
    还没进队的指定队员**反复补邀且不离队重组**——auto 模式重复点「一键组队」，
    manual 模式按名字逐个搜索邀请（见 _reinforce_and_restore）。

    队员端：不做任何导航，等协调器结束信号；被拉进战斗则（手动模式才点"自动"）
    等结束、关自己的"恭喜获得"/赐福令卡；队长点"离开"后自动跟随。队员端永不判失败。

    队长判定按 teamup 协调器的 captain_id（不是账号库的 is_captain）——地鼠轮
    （本轮任务含 dishu）队长被顶号后会随机改选队长，改选出的新队长要能接管导航。
    """

    name = "dishu"
    title = "打地鼠"
    category = "日常副本"

    # ---- 角色判定：按协调器当前队长（支持地鼠轮队长被顶后随机改选） ----

    def _me_is_captain(self, coord):
        if coord.begun:
            me_id = self.account.get("id")
            return me_id is not None and me_id == coord.captain_id
        return self.is_captain

    def _is_following_member(self):
        """队员端判定改用协调器 captain_id：改选出的新队长（db 里不是队长）
        必须走正常导航，不能被 base 当队员跳过场景操作。"""
        coord = teamup.coordinator()
        if coord.begun:
            me_id = self.account.get("id")
            return me_id is not None and me_id != coord.captain_id
        return super()._is_following_member()

    def _try_once(self):
        coord = teamup.coordinator()
        if not coord.begun:
            log.info("非 GUI 5 开并行模式（协调器未初始化），跳过打地鼠")
            raise TaskSkipped("协调器未初始化（非 5 开并行模式），打地鼠未执行")
        me_is_captain = self._me_is_captain(coord)
        if coord.dungeon_result(self.name) is not None:
            # 结果已定（重试尝试短路）：如实回报——成了算成功，败了算失败
            if coord.dungeon_result(self.name) is not True:
                raise TaskSkipped("组队已判负，打地鼠未执行")
            return True
        if coord.team_success is not True:
            log.info("组队未成功，打地鼠按失败计入小结")
            if me_is_captain:
                coord.dungeon_finish(self.name, False)  # 唤醒队员端退出等待
            raise TaskSkipped("组队未成功")
        if me_is_captain:
            return self._captain_flow(coord)
        return self._member_flow(coord)

    # ---- 指纹（模板）加速：OCR 锚定一次，后续毫秒级模板匹配 ----

    @staticmethod
    def _fp_path(kind):
        return FP_DIR / f"{kind}.png"

    def _fp_find(self, screen, kind, region):
        """在 region 内做模板匹配，返回 (cx, cy) 或 None。

        模板来自 data/dishu_fp/<kind>.png（OCR 首次确认时自动学习）；
        模板不存在或读取失败一律返回 None，由调用方退回 OCR。
        搜索区域向四周扩 25px：OCR 命中点可能贴着区域边缘，模板框
        （entry 100x22 / 按钮 116x30）会比常量区域更宽/更高，不扩边
        会把模板边缘裁掉导致自家截图都匹配不上（离屏验证实测）。"""
        path = self._fp_path(kind)
        if not path.exists():
            return None
        tpl = imgio.imread(path)
        if tpl is None:
            return None
        x, y, w, h = region
        sh, sw = screen.shape[:2]
        x0, y0 = max(0, x - 25), max(0, y - 25)
        x1, y1 = min(sw, x + w + 25), min(sh, y + h + 25)
        if x1 - x0 < tpl.shape[1] or y1 - y0 < tpl.shape[0]:
            return None
        img = screen[y0:y1, x0:x1]
        res = cv2.matchTemplate(img, tpl, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)
        if max_val < FP_THRESHOLD:
            return None
        return (x0 + max_loc[0] + tpl.shape[1] // 2,
                y0 + max_loc[1] + tpl.shape[0] // 2)

    def _fp_learn(self, kind, screen, cx, cy):
        """把 OCR 确认命中的按钮/条目裁剪存为模板（自学习，覆盖旧模板）。"""
        w, h = FP_CROPS[kind]
        x0, y0 = cx - w // 2, cy - h // 2
        crop = screen[max(0, y0):y0 + h, max(0, x0):x0 + w]
        if crop.size == 0 or crop.shape[0] < h - 4 or crop.shape[1] < w - 4:
            return
        try:
            with _fp_lock:
                FP_DIR.mkdir(parents=True, exist_ok=True)
                imgio.imwrite(self._fp_path(kind), crop)
        except OSError as e:
            log.debug("指纹模板保存失败 %s: %s", kind, e)

    def _anchor(self, screen, kind, region, text):
        """指纹优先、OCR 兜底的单目标定位。

        返回 (pos, anchored)：pos=(cx,cy) 或 None；anchored=本次是否动用了
        OCR（动了就顺手学习模板，并要求调用方节流）。"""
        hit = self._fp_find(screen, kind, region)
        if hit:
            return hit, False
        hit = ocr.find_text(screen, text, region=region, min_similarity=0.8)
        if hit is None:
            return None, True
        self._fp_learn(kind, screen, hit[0], hit[1])
        return (hit[0], hit[1]), True

    # ---- 队长端 ----

    def _captain_flow(self, coord):
        entered = self._enter_guild_scene()
        if entered == "no_guild":
            log.info("未加入帮会，打地鼠跳过")
            coord.dungeon_finish(self.name, True)
            return True
        if not entered:
            log.warning("进帮会领地失败")
            # 只有最后一次尝试才定局：早先失败立即 dungeon_finish(False) 会让
            # 重试被"dungeon_result 已定"短路（实测 2026-10-12：第 1 次没等到
            # 面板切页，第 2 次直接跳过，2 次尝试形同虚设）
            if self._attempt >= self.max_retries:
                coord.dungeon_finish(self.name, False)
            return False
        # 用户规则 2026-10-12：任务开始前（队长在帮会领地等待期间）把还没进队的
        # 指定队员补进来——**不离队重组**：auto 重复点「一键组队」，manual 逐个邀请
        self._reinforce_and_restore(coord, "进帮后补邀请")
        if not self._wait_refresh(coord):
            # 超过等待上限仍无条目：本场无任务（活动未开/触发太晚），不算失败
            self._leave_scene()
            coord.dungeon_finish(self.name, True)
            return True
        self._fight_loop()
        self._leave_scene()
        coord.dungeon_finish(self.name, True)
        return True

    def _enter_guild_scene(self):
        """主界面 → 帮会面板 → "回帮" → 帮会领地场景（图1→图2）。
        返回 True / "no_guild" / False（面板多次点不开）。"""
        if self._in_guild_scene(self.device.screenshot()):
            return True  # 已在帮会领地（重试时）
        self.dismiss_popups()
        panel_open = False
        for i in range(1, 4):
            if not self.matcher.find_and_click(self.device, "帮会", timeout=3,
                                               region=BANGHUI_REGION,
                                               ccoeff_floor=0.45):
                # 5 开并发时"帮会"模板常等满 timeout 才命中甚至漏检（实测
                # 12~16 秒）：图标位置固定，漏检按坐标盲点（同 zudui._send_invite）
                log.info("「帮会」模板未命中，按固定坐标盲点 @ %s", BANGHUI_POS)
                self.device.click(*BANGHUI_POS)
            deadline = time.time() + 10
            while time.time() < deadline:
                screen = self.device.screenshot()
                if (ocr.find_text(screen, "新闻", region=NEWS_TAB_REGION,
                                  min_similarity=1.0)
                        or ocr.find_text(screen, "回帮", region=GUILD_BTN_REGION,
                                         min_similarity=1.0)):
                    panel_open = True
                    break
                if ocr.contains_text(screen, "加入帮会", region=GUILD_JOIN_REGION):
                    self.exit_panel_to_home()
                    return "no_guild"
                time.sleep(0.6)
            if panel_open:
                break
            log.warning("帮会面板未打开，重试点帮会 (%d/3)", i)
        if not panel_open:
            log.warning("帮会面板多次点击未打开")
            return False
        # 面板记住上次页签：编队页没有"回帮"，找不到先切回成员页。
        # deadline 15s：切页动画+OCR 采样慢，8s 只够 2 次采样（实测 2026-10-12
        # 队长端编队页组队后直接开面板，点 1 次成员页签 2 秒后放弃）
        hit = None
        deadline = time.time() + 15
        while time.time() < deadline:
            hit = ocr.find_text(self.device.screenshot(), "回帮",
                                region=GUILD_BTN_REGION, min_similarity=1.0)
            if hit:
                break
            tab = ocr.find_text(self.device.screenshot(), "成员",
                                region=MEMBER_TAB_REGION, min_similarity=1.0)
            if tab:
                log.info("点击 [成员页签] @ (%d, %d)", tab[0], tab[1])
                self.device.click(tab[0], tab[1])
            time.sleep(random.uniform(0.8, 1.2))
        if not hit:
            log.warning("帮会面板找不到回帮按钮")
            self.report_unknown("guild_no_huibang",
                                note="帮会面板未定位到回帮按钮（15s）")
            return False
        log.info("点击 [回帮] @ (%d, %d)", hit[0], hit[1])
        self.device.click(hit[0], hit[1])
        deadline = time.time() + 30
        while time.time() < deadline:
            self._check_stop()
            if self._in_guild_scene(self.device.screenshot()):
                log.info("已进入帮会领地")
                return True
            time.sleep(1)
        log.warning("点回帮后 30 秒未进入帮会领地")
        self.report_unknown("guild_scene_fail", note="点回帮后未进帮会领地")
        return False

    @staticmethod
    def _in_guild_scene(screen):
        """左上角地图名判定是否在帮会领地。

        地图名实际是「帮派领地」（2026-10-11 18 点场实测：角色已进图，
        OCR 读出"帮派领地"，旧判定找「帮会领地」模糊匹配必败 → 连续 30 秒
        误判"未进入帮会领地"判负，重试传送又超时，18:00:30 整场收工）。
        用「领地」子串判定，帮会/帮派两种叫法通吃。"""
        return any("领地" in t for t in ocr.dump_texts(screen, MAP_LABEL_REGION))

    def _wait_refresh(self, coord):
        """等"地鼠入侵"条目整点刷新出现（12:00/18:00 准时刷新，定时条目应提前
        5~10 分钟触发，此处轮询等待）。出现返回 True；超 refresh_wait 返回 False。

        等待期间每 REINFORCE_INTERVAL 秒核对一次队伍并**补邀**没进队的指定队员
        （用户规则 2026-10-12：任务开始前可以反复补邀，不需要离队重组）。"""
        try:
            wait = float(self.config.get("refresh_wait") or REFRESH_WAIT)
        except (TypeError, ValueError):
            wait = REFRESH_WAIT
        log.info("在帮会领地等地鼠入侵刷新（整点刷新，最长等 %.0f 分钟）...", wait / 60)
        deadline = time.time() + wait
        next_reinforce = time.time() + REINFORCE_INTERVAL
        n = 0
        while time.time() < deadline:
            self._check_stop()
            self.dismiss_popups()
            if self._in_battle(self.device.screenshot()):
                # 等刷新期间被拉进战斗（意外遇怪等）：战斗中看不到条目，
                # 先等打完再继续等刷新，否则会把战斗画面误判成"无条目"
                log.info("等地鼠刷新时发现仍在战斗，先等战斗结束")
                self._wait_battle_over()
                continue
            if self._find_entry():
                log.info("地鼠入侵任务已刷新")
                return True
            if coord is not None and time.time() >= next_reinforce:
                next_reinforce = time.time() + REINFORCE_INTERVAL
                self._reinforce_and_restore(coord, "等待期补邀请")
            n += 1
            if n % 6 == 1:
                self._ensure_quest_view()  # 定期确认停在任务视图（低频，防页签开关来回抖）
            pace.wait(10)
        log.warning("等 %.0f 分钟仍未见地鼠入侵任务（本场无任务或触发太晚）", wait / 60)
        return False

    # ---- 帮会领地等待期间的补邀请（用户规则 2026-10-12）----

    def _reinforce_and_restore(self, coord, tag):
        """补邀还没进队的指定队员，并把画面恢复到帮会领地的任务视图。

        借用 Zudui 的组队能力（同项目既有做法：lingzhu 也借调
        Zudui._goto_friend_search）：**不离队重组**——auto 模式重复点
        「一键组队 → 确定」游戏会自动把剩余队员拉进来；manual 模式按名字
        逐个搜索邀请。补邀会打开帮会面板/关系面板，结束后关掉面板回到
        任务视图继续等地鼠刷新。"""
        r = Zudui._reinforce_team(self, coord, tag, fallback_tab_pos=TEAM_TAB_POS)
        if r is None:
            return          # 队伍构成无法确认（面板打不开），下轮再试
        if r is False:
            # 已补发邀请：等一会儿让队员接受，再关面板回任务视图
            pace.wait(5, 8)
            self._close_invite_panels()
        # 核对队伍时会点开"队伍"页签（追踪面板切到队伍视图），补完要切回任务视图，
        # 否则后续 _find_entry 找不到"地鼠入侵"条目
        self._ensure_quest_view()

    @staticmethod
    def _invite_panel_open(screen):
        """补邀请会打开帮会面板（成员/编队页）或关系/搜索好友面板，
        判定这些面板是否还开着（用于把它们关掉回到帮会领地场景）。"""
        return bool(
            ocr.find_text(screen, "新闻", region=NEWS_TAB_REGION,
                          min_similarity=1.0)
            or ocr.find_text(screen, "回帮", region=GUILD_BTN_REGION,
                             min_similarity=1.0)
            or ocr.find_text(screen, "搜索好友", region=SEARCH_TITLE_REGION,
                             min_similarity=0.8)
            or ocr.find_text(screen, "好友", region=FRIEND_TAB_REGION,
                             min_similarity=1.0))

    def _close_invite_panels(self, tries=3):
        """关掉补邀请打开的面板，回到帮会领地场景。优先点面板左下角返回箭头
        （zudui 的 exit_panel_to_home 同款），3 次仍关不掉才按 ESC 兜底。"""
        for i in range(1, tries + 1):
            screen = self.device.screenshot()
            if not self._invite_panel_open(screen):
                return True
            log.info("关闭补邀请打开的面板（第 %d 次，点面板返回箭头）", i)
            self.device.click(*PANEL_BACK_POS)
            time.sleep(random.uniform(1.0, 1.5))
        log.warning("补邀请后未能关掉面板，按 ESC 兜底")
        self.device.press_esc()
        time.sleep(random.uniform(1.0, 1.5))
        return not self._invite_panel_open(self.device.screenshot())

    def _fight_loop(self):
        """开打阶段：点条目→寻路→弹窗（驱赶地鼠=打 / 再找一只=换目标），
        循环到任务视图里"地鼠入侵"条目消失（打完了）。

        条目消失必须**先确认不在战斗**（顶部"回合"）才算打完：战斗画面盖住
        任务视图，战斗中条目自然不可见（用户实测教训）——在战斗就先等
        _wait_battle_over 再回循环重新确认。"""
        no_popup = 0
        more_streak = 0
        for n in range(1, MAX_MICE + 1):
            self._check_stop()
            self.dismiss_popups()
            entry = self._find_entry()
            if not entry:
                self._ensure_quest_view()
                entry = self._find_entry()
            if not entry:
                time.sleep(3)  # 连扫两轮确认，防 OCR 单次漏检误判"打完"
                entry = self._find_entry()
            if not entry:
                # 战斗中整个任务视图被战斗画面盖住，看不到条目（用户实测教训）：
                # 条目消失不能直接判"打完"，确认不在战斗才可以
                if self._in_battle(self.device.screenshot()):
                    log.info("条目不可见但仍在战斗中，等战斗结束再确认")
                    self._wait_battle_over()
                    continue
                log.info("任务视图已无地鼠入侵条目，本场打完")
                return
            texts = ocr.dump_texts(self.device.screenshot(), REMAIN_REGION)
            log.info("===== 打地鼠 第 %d 只%s =====", n,
                     f"（{''.join(texts)}）" if texts else "")
            log.info("点击 [地鼠入侵] 条目 @ (%d, %d)", entry[0], entry[1])
            self.device.click(entry[0], entry[1])
            kind, pos = self._wait_mouse_popup()
            if kind is None:
                no_popup += 1
                log.warning("点条目后未弹出地鼠弹窗（%d/2）", no_popup)
                if no_popup >= 2:
                    self.report_unknown("no_popup", note="连续 2 次点地鼠入侵条目无弹窗")
                    return
                continue
            no_popup = 0
            if kind == "more":
                log.info("点击 [再找一只] @ (%d, %d)，寻路下一只", *pos)
                self.device.click(*pos)
                kind, pos = self._wait_mouse_popup()
                if kind != "fight":
                    # 用户规则：再找一只后还是再找一只（或没弹窗）→ 点空白关弹窗，
                    # 回循环确认条目还在再点条目
                    more_streak += 1
                    log.info("仍是再找一只，点空白关弹窗后重新点条目（连续 %d 次）",
                             more_streak)
                    self.device.click(*POPUP_BLANK_POS)
                    time.sleep(random.uniform(1.0, 1.5))
                    if more_streak > 10:
                        self.report_unknown(
                            "more_loop", note="再找一只连续 10 次未出驱赶地鼠")
                        more_streak = 0
                    continue
            # kind == "fight"：驱赶地鼠
            more_streak = 0
            log.info("点击 [驱赶地鼠] @ (%d, %d)", *pos)
            self.device.click(*pos)
            self._fight_and_settle()
        log.warning("已达单场上限 %d 只，强制收工", MAX_MICE)

    def _find_entry(self):
        """任务视图里找"地鼠入侵"条目，返回命中中心坐标。

        指纹优先（毫秒级）：entry 模板命中直接返回（模板学习自 OCR 确认的
        真条目，右侧提示卡样式不同匹配不上）；未命中退回 OCR 并学习。
        OCR 路径保留"可领取"排除：提示卡"地鼠入侵 可领取"标题正下方紧跟
        "可领取"，与 zongmen/xunbao 的提示卡误判教训同款。"""
        screen = self.device.screenshot()
        hit = self._fp_find(screen, "entry", DISHU_ENTRY_REGION)
        if hit:
            return hit
        for t, cx, cy, _score in ocr.scan(screen, DISHU_ENTRY_REGION, min_score=0.5):
            if "地鼠入侵" not in t:
                continue
            below = ocr.dump_texts(screen, (cx - 60, cy + 8, 120, 26))
            if any("可领取" in b for b in below):
                continue  # 提示卡，不是追踪面板条目
            self._fp_learn("entry", screen, cx, cy)
            return cx, cy
        return None

    @staticmethod
    def _in_battle(screen):
        """顶部"第X回合"= 正在战斗（战斗中任务视图被盖住，看不到条目/页签）。"""
        return bool(ocr.contains_text(screen, "回合", region=BATTLE_ROUND_REGION))

    def _wait_battle_over(self, timeout=BATTLE_TIMEOUT):
        """等当前这场战斗结束（顶部"回合"消失）并收拾结算弹窗。

        战斗中任务视图被战斗画面盖住——"地鼠入侵条目消失"不能作为打完判据
        （用户实测教训），必须先等战斗结束再回条目判定。"""
        deadline = time.time() + timeout
        while time.time() < deadline:
            self._check_stop()
            screen = self.device.screenshot()
            if self.dismiss_popups(screen):
                continue
            if not self._in_battle(screen):
                log.info("战斗结束")
                self._settle_popups()
                return True
            time.sleep(3)
        log.warning("战斗超过 %d 秒未结束", timeout)
        return False

    def _is_quest_view(self, screen):
        """地鼠场景专用的任务视图判定（2026-10-13 修复 quest_tab_fail 连锁）。

        base._team_panel_markers 靠"前往"字样区分任务/队伍视图，但地鼠任务
        视图的追踪条目是"地鼠入侵 / 组队驱逐入侵的地鼠 / 当前地鼠刷新点 n只"
        ——没有"前往"、也没有成员名，落到兜底分支被误判成队伍视图 → 反复点
        "任务"页签把已打开的面板点收起，3 次全败触发 quest_tab_fail。
        这里改用地鼠任务视图自有标记（"驱逐"/"刷新点"字样）+ entry 指纹：
        任一命中=已是任务视图，绝不碰页签。"""
        texts = ocr.dump_texts(screen, TRACKER_REGION)
        if any(m in t for t in texts for m in QUEST_VIEW_MARKERS):
            return True
        return self._fp_find(screen, "entry", DISHU_ENTRY_REGION) is not None

    def _ensure_quest_view(self, tries=3):
        """确保追踪面板在任务视图：只在确认没有"地鼠入侵"条目时由调用方触发。

        "任务"页签是开关（已展开的任务视图再点会收起面板），绝不盲点：
        先用 _team_panel_markers 判定——条目区读到"前往"类条目 = 已是任务
        视图，不动；否则点一次"任务"页签切过去，点完复核，最多 tries 次。
        页签文字 OCR 不中（多开拥挤/光照，实测第 4 个客户端整个等待期都
        读不出、一直停在队伍视图 → 等地鼠刷新超时直接离开收工）时按固定
        槽位 QUEST_TAB_POS 兜底点击——仅当确认在帮会领地（其它场景该位置
        未必是页签，不能盲点；与 base._ensure_team_view 的固定槽位兜底
        同款教训）。返回 True=已确认在任务视图。
        """
        for i in range(1, tries + 1):
            screen = self.device.screenshot()
            if self._in_battle(screen):
                # 战斗中看不到任务页签（右上是对阵/地鼠入侵横幅），点了也是白点
                log.info("战斗中看不到任务页签，等战斗结束后再切")
                return False
            if self._is_quest_view(screen):
                # 地鼠任务视图没有"前往"字样，通用启发式会误判成队伍视图
                #（见 _is_quest_view 注释），先用地鼠专用标记放行
                if i > 1:
                    log.info("已确认切到任务视图")
                return True
            if self._team_panel_markers(
                    screen,
                    own_name=(self.account or {}).get("character")) is False:
                if i > 1:
                    log.info("已确认切到任务视图")
                return True
            tab = ocr.find_text(screen, "任务", region=QUEST_TAB_REGION,
                                min_similarity=0.9)
            if tab:
                pos = (tab[0], tab[1])
            elif self._in_guild_scene(screen):
                pos = QUEST_TAB_POS
                log.info("OCR 未读到「任务」页签，按固定槽位 (%d, %d) 兜底", *pos)
            else:
                log.warning("OCR 未读到「任务」页签且不在帮会领地，不盲点固定槽位")
                return False
            log.info("点击 [任务页签] @ (%d, %d)（第 %d 次）", pos[0], pos[1], i)
            self.device.click(*pos)
            time.sleep(random.uniform(1.0, 1.5))
        log.warning("连续 %d 次未确认切到任务视图", tries)
        self.report_unknown("quest_tab_fail",
                            note="任务页签点了 %d 次仍未确认进入任务视图" % tries)
        return False

    def _wait_mouse_popup(self):
        """等"入侵的地鼠"弹窗（自动寻路耗时，最长 POPUP_WAIT 秒）。
        返回 ("fight", (x,y)) 驱赶地鼠 / ("more", (x,y)) 再找一只 / (None, None)。

        指纹优先：每 0.5s 一帧，两个按钮各做一次模板匹配（毫秒级，抢怪
        关键路径——OCR 每次 ~1s 固定开销会把判定拖慢数秒，实测点开常已是
        "再找一只"）；模板未命中时节流地退回 OCR 重新锚定并学习新模板。"""
        deadline = time.time() + POPUP_WAIT
        next_ocr = 0.0
        while time.time() < deadline:
            self._check_stop()
            screen = self.device.screenshot()
            if self.dismiss_popups(screen):
                continue
            hit = self._fp_find(screen, "fight", FIGHT_REGION)
            if hit:
                return "fight", hit
            hit = self._fp_find(screen, "more", MORE_REGION)
            if hit:
                return "more", hit
            if time.time() >= next_ocr:
                next_ocr = time.time() + FP_OCR_INTERVAL
                hit = ocr.find_text(screen, "驱赶地鼠", region=FIGHT_REGION,
                                    min_similarity=0.8)
                if hit:
                    self._fp_learn("fight", screen, hit[0], hit[1])
                    return "fight", (hit[0], hit[1])
                hit = ocr.find_text(screen, "再找一只", region=MORE_REGION,
                                    min_similarity=0.8)
                if hit:
                    self._fp_learn("more", screen, hit[0], hit[1])
                    return "more", (hit[0], hit[1])
            time.sleep(0.5)
        return None, None

    def _fight_and_settle(self):
        """驱赶地鼠 → 战斗（默认自动；读到"下达指令"=手动模式才点"自动"）
        → 等"回合"消失 → 关"恭喜获得"弹窗。"""
        if not self._wait_battle_start(30):
            log.warning("点驱赶地鼠后未进入战斗")
            self.save_debug_screenshot("dishu_no_battle")
            return
        # 已自动时再点"自动"会关掉自动；"请给XX下达指令"宠物名随账号变，
        # 整行粘连时相似度匹配必败，用包含匹配（liyao/jingji 同款教训）
        if ocr.contains_text(self.device.screenshot(), "下达指令"):
            self.device.click(*BATTLE_AUTO_POS)
            log.info("手动模式，已点 [自动]")
        log.info("战斗开始，等待结束")
        self._wait_battle_over()

    def _wait_battle_start(self, timeout):
        deadline = time.time() + timeout
        while time.time() < deadline:
            self._check_stop()
            if self._in_battle(self.device.screenshot()):
                return True
            time.sleep(1)
        return False

    def _settle_popups(self, rounds=6):
        """战斗后的"恭喜获得"（图5）：点下方空白 (200,640) 关闭；赐福令卡一并点 X。"""
        for _ in range(rounds):
            time.sleep(2)
            screen = self.device.screenshot()
            acted = False
            if (ocr.find_text(screen, "点击空白处关闭", region=REWARD_POPUP_REGION)
                    or ocr.find_text(screen, "恭喜获得", region=SETTLE_TITLE_REGION)):
                log.info("关闭恭喜获得弹窗")
                self.device.click(*SETTLE_BLANK_POS)
                acted = True
            if self.close_fuka_card(screen):
                acted = True
            if not acted:
                return

    def _leave_scene(self):
        """收工：关道具卡/弹窗 → 点帮会领地右缘"离开" → 等回云梦长安。"""
        self.dismiss_item_cards()
        self.dismiss_popups()
        screen = self.device.screenshot()
        if not self._in_guild_scene(screen):
            log.info("已不在帮会领地，无需点离开")
            return
        hit = ocr.find_text(screen, "离开", region=LEAVE_REGION,
                            min_similarity=0.75)
        pos = (hit[0], hit[1]) if hit else LEAVE_POS
        log.info("点击 [离开] @ (%d, %d)", *pos)
        self.device.click(*pos)
        deadline = time.time() + 4  # 部分场景离开有确认框
        while time.time() < deadline:
            cfm = ocr.find_text(self.device.screenshot(), "确定",
                                region=LEAVE_CONFIRM_REGION, min_similarity=1.0)
            if cfm:
                log.info("点击 [确定-离开] @ (%d, %d)", cfm[0], cfm[1])
                self.device.click(cfm[0], cfm[1])
                break
            time.sleep(0.5)
        deadline = time.time() + 15
        while time.time() < deadline:
            self._check_stop()
            if self._on_yunmeng(self.device.screenshot()):
                log.info("已离开帮会领地回到云梦长安")
                return
            time.sleep(1)
        log.warning("点离开后未回到云梦长安（不影响后续任务自行回主界面）")

    # ---- 队员端 ----

    def _member_flow(self, coord):
        """队员端：**纯被动**——只等队长的副本结果，不做任何 OCR / 点击
        （用户规则 2026-10-13：打地鼠/六道法门/钟馗捉鬼三个组队副本，队员
        不需要点确认，进入战斗自动打，识别与操作全交给队长）。

        背景：组队成功后队员的画面由客户端自动跟随（战斗自动开打、结算弹窗
        不阻塞后续轮次），队员插进去的任何点击都是抢鼠标、抢 OCR 开销——
        打地鼠这种抢怪场景尤其致命。

        保留唯一例外：队长在帮会领地等待期可能**重新补发邀请**（用户规则
        2026-10-12），此时 zudui 已结束，得有人接受邀请，否则队员进不了队；
        这个探针一次 OCR 判完（dismiss_popups 内含 _accept_team_invite），
        低频（每 10s）且不阻塞。队长组队完成后不再重复校验人员，队员真
        中途离队也不理会（用户规则）。

        队伍完成后不再重复校验成员——地鼠开始后实测（2026-10-13）早期实现的
        "等待期补邀请" 在 quest 面板状态错乱时会误把路人当缺员反复邀请。"""
        deadline = time.time() + MEMBER_GIVEUP
        next_invite_check = time.time() + INVITE_POLL
        log.info("队员端：只等队长信号，不做识别/不抢鼠标（被动模式）")
        while time.time() < deadline:
            self._check_stop()
            if coord.dungeon_result(self.name) is not None:
                ok = coord.dungeon_result(self.name)
                log.info("打地鼠已结束（%s）", "完成" if ok else "失败")
                if not ok:
                    # 队长端失败（没进帮会领地/战斗失败）= 本号也没打成，
                    # 如实计失败——不能"没打也算成功"（2026-10-12 实测：队长
                    # 回帮失败全员跳过，队员小结却记 2/2 成功）
                    raise TaskSkipped("队长端打地鼠失败，本号打地鼠未执行")
                return True
            if time.time() >= next_invite_check:
                next_invite_check = time.time() + INVITE_POLL
                # 仅探测「组队邀请」/「组队」浮标（队长等待期补发邀请）；
                # 无邀请则不产生任何动作，也不做战斗/结算类识别
                self.dismiss_popups()
            time.sleep(2)
        log.warning("等待打地鼠结果超时")
        return True  # 队员端永不判失败
