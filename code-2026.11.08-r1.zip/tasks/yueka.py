import logging
import random
import time

from core import ocr
from tasks.base import HUODONG_REGION, Task

log = logging.getLogger("task.yueka")

# 以下均为 405x720 客户区坐标（活动面板布局固定）
YUEKA_PAGE_REGION = (30, 120, 345, 160)       # 月卡页卡面标题/“持续30天”文字区，判定已在月卡页
TAB_REGION = (80, 585, 250, 70)               # 底部 周礼/月卡/秋月礼 页签
ZHOULI_TAB_POS = (135, 615)                   # “周礼”页签固定位置（OCR 失败兜底）
YUEKA_TAB_POS = (200, 615)                    # “月卡”页签固定位置（OCR 失败兜底）
ZHOULI_PAGE_REGION = (5, 220, 110, 40)        # “累计活跃度”文字区，判定已在周礼页
GIFT_BTN_REGION = (250, 150, 145, 65)         # 周礼页“选择礼包”按钮
TIANLU_SELECT_REGION = (150, 310, 110, 55)    # 选择面板上方天禄好礼的“选择”按钮
TIANLU_SELECT_POS = (203, 336)
LEFT_CLAIM_REGION = (30, 440, 150, 80)        # 左卡（超值月卡）按钮区
RIGHT_CLAIM_REGION = (225, 440, 155, 80)      # 右卡（至尊月卡）按钮区
LOTTERY_ENTRY_REGION = (305, 495, 100, 105)   # 月卡页右下角“抽奖”入口
LOTTERY_ENTRY_POS = (365, 540)
LOTTERY_TITLE_REGION = (90, 30, 230, 80)      # 妖尾抽奖面板标题
LOTTERY_BTN_REGION = (135, 285, 135, 110)     # 转盘中间“抽奖”按钮
LOTTERY_BTN_POS = (203, 340)
LOTTERY_CLOSE_POS = (368, 47)                 # 妖尾抽奖面板右上角 X
LETTER_BTN_REGION = (180, 450, 220, 110)      # 天赐福运书信弹窗"开启书信"按钮（实测书信弹窗很大，按钮在 y≈500）

# 活动面板底部导航（2026-10-11 晚 UI 改版实测标定）：点"活动"后默认落在
# 功勋令（战令）页，底部导航变为 福赠(~213)/战令(~275)/活动(~345)，右对齐、
# 间隔固定。旧坐标 (130,688) 在 3 页签布局下是空白处，点了没反应。
# 偶发 4 页签布局（福赠/战令/活动/珍藏）：整排左移一格，福赠 ≈ (145,690)。
# 不用 OCR 定位：底部聊天气泡常盖住"福赠"等字，OCR 不可靠（用户确认），
# 一律固定坐标 + 点完验证页签是否出现。
ACT_NAV_POS = (213, 690)                       # 3 页签布局的"福赠"图标
ACT_NAV_POS_4TAB = (145, 690)                  # 4 页签布局的"福赠"图标


class Yueka(Task):
    """领月卡：主界面活动 → 周礼页选礼包（未选过时选天禄好礼）→ 月卡页领取左右两卡
    每日奖励 →（右卡已领时）妖尾抽奖 → 返回主界面。

    面板内文字均随充值状态变化（领取/金额/已领取），全部用 OCR 定位；
    只有主界面"活动"入口用模板（固定锚点小区域匹配）。
    """

    name = "yueka"
    title = "领月卡"

    def _try_once(self):
        self.dismiss_popups()
        if not self._open_activity():
            return False
        self._choose_zhouli()
        if not self._switch_tab("月卡", YUEKA_TAB_POS, self._on_yueka_page):
            return False
        right_claimed = self._claim_all()
        if right_claimed:
            self._lottery()
        self.exit_panel_to_home()
        return True

    def _open_activity(self):
        """点主界面"活动"图标打开活动面板，再确保切到周礼/月卡页。

        2026-10-11 晚起，点"活动"默认落在功勋令（战令）页：需点底部导航
        "福赠"切到周礼/月卡页（3 页签位置不中再试 4 页签位置，见
        ACT_NAV_POS 注释）。面板打开后"活动"图标被盖住，**不要**再点"活动"。
        """
        for i in range(3):
            if not self.matcher.find_and_click(self.device, "活动", timeout=8,
                                               region=HUODONG_REGION, threshold=0.88,
                                               ccoeff_floor=0.45):
                return False
            if self._wait_tabs(4):
                return True
            for pos in (ACT_NAV_POS, ACT_NAV_POS_4TAB):
                log.info("点底部导航 [福赠] @ %s 切到周礼/月卡页", pos)
                self.device.click(*pos)
                if self._wait_tabs(6):
                    return True
            log.warning("活动面板未切到周礼/月卡页，重试点击 (%d/3)", i + 1)
        return False

    def _wait_tabs(self, timeout):
        """等活动面板底部出现周礼/月卡页签。

        天赐福运活动期间，点"活动"后先弹出书信弹窗：点"开启书信"进福运面板，
        本轮等不到页签会超时返回，外层再点底部福赠图标（ACT_NAV_POS）进入
        周礼/月卡页，下一轮 _wait_tabs 即可命中。

        底部对话框（聊天/系统气泡）常盖住"周礼/月卡"文字（用户确认），
        所以除页签文字外，**页面正文命中**（周礼页"累计活跃度"/月卡页
        "超值月卡"等，都在上半屏，气泡盖不到）也当已到页。
        """
        deadline = time.time() + timeout
        while time.time() < deadline:
            screen = self.device.screenshot()
            hit = ocr.find_text(screen, "开启书信", region=LETTER_BTN_REGION,
                                min_similarity=0.75)
            if hit:
                log.info("检测到天赐福运书信，点击 [开启书信] @ (%d, %d)", hit[0], hit[1])
                self.device.click(hit[0], hit[1])
                time.sleep(random.uniform(1.5, 2.2))
                continue
            if (ocr.find_text(screen, "月卡", region=TAB_REGION, min_similarity=1.0)
                    or ocr.find_text(screen, "周礼", region=TAB_REGION, min_similarity=1.0)):
                return True
            if self._on_zhouli_page(screen) or self._on_yueka_page(screen):
                return True
            time.sleep(0.6)
        return False

    def _switch_tab(self, tab, tab_pos, on_page, timeout=40, min_clicks=5):
        """切到指定页签（已在该页则不点）。on_page: 判定函数，参数为当前截图。

        5 账号并行时 OCR 只有 2 个引擎槽位，一轮"截图+OCR"高峰约 10 秒：
        timeout 给足 40 秒，且至少发出 min_clicks 次页签点击才允许超时返回，
        防止 OCR 竞争下一个点击都没发出去就超时（实测 timeout=20 只够点 1~2 次）。

        2026-10-10 事故修复：与 shouyi._goto_dukou 同源缺陷——原写
        `while time.time() < deadline or clicks < min_clicks` 会把 deadline 短路，
        且固定位置兜底只 +1 次点击（点击次数永远到不了 min_clicks=5），只要 OCR
        长期读不到页签就**静默死循环**。现加绝对硬上限 hard_deadline 兜底，并
        每轮无条件打日志（含已耗时与点击次数）。
        """
        start = time.time()
        deadline = start + timeout
        hard_deadline = start + timeout + 25  # 绝对上限：无论 clicks 多少都必须退出
        clicked_fallback = False
        clicks = 0
        while time.time() < hard_deadline and (
                time.time() < deadline or clicks < min_clicks):
            self._check_stop()  # 长循环内响应 GUI 停止
            screen = self.device.screenshot()
            if self.dismiss_popups(screen):
                continue
            if on_page(screen):
                log.info("已进入%s页", tab)
                return True
            hit = ocr.find_text(screen, tab, region=TAB_REGION, min_similarity=1.0)
            if hit:
                clicks += 1
                # 页签可点区域是文字上方的图标，OCR 定位的是文字，上移 20px
                log.info("点击 [%s页签] @ (%d, %d)（第 %d 次，已耗时 %.0fs）",
                         tab, hit[0], hit[1] - 20, clicks, time.time() - start)
                self.device.click(hit[0], hit[1] - 20)
            elif not clicked_fallback:
                clicked_fallback = True
                clicks += 1
                log.warning("OCR 未找到%s页签，点固定位置兜底", tab)
                self.device.click(*tab_pos)
            else:
                # 每轮无条件打日志：原实现 OCR 读不到页签时完全静默
                log.info("未进入%s页（已耗时 %.0fs，点击 %d 次）：页签未找到",
                         tab, time.time() - start, clicks)
            time.sleep(random.uniform(0.8, 1.2))
        log.warning("切换%s页超时（等待 %d 秒，点击 %d 次）", tab, timeout, clicks)
        self.save_debug_screenshot("yueka_tab_timeout")
        screen = self.device.screenshot()
        log.warning("页签区 OCR: %s", ocr.dump_texts(screen, TAB_REGION))
        log.warning("月卡页判定区 OCR: %s", ocr.dump_texts(screen, YUEKA_PAGE_REGION))
        return False

    def _choose_zhouli(self):
        """周礼页有"选择礼包"时选天禄好礼（点上方卡的"选择"）；没有则跳过。

        选择失败不阻断后续月卡流程。实测选择后无弹窗，直接回到周礼页。
        """
        if not self._switch_tab("周礼", ZHOULI_TAB_POS, self._on_zhouli_page):
            log.warning("未能进入周礼页，跳过周礼选择")
            return
        hit = ocr.find_text(self.device.screenshot(), "选择礼包",
                            region=GIFT_BTN_REGION, min_similarity=1.0)
        if not hit:
            log.info("周礼页无“选择礼包”（本周已选过），跳过")
            return
        log.info("点击 [选择礼包] @ (%d, %d)", hit[0], hit[1])
        self.device.click(hit[0], hit[1])
        # 等选择面板打开，点上方天禄好礼的"选择"（下方是御灵好礼，别点错）
        deadline = time.time() + 8
        while time.time() < deadline:
            hit = ocr.find_text(self.device.screenshot(), "选择",
                                region=TIANLU_SELECT_REGION, min_similarity=1.0)
            if hit:
                break
            time.sleep(0.6)
        pos = (hit[0], hit[1]) if hit else TIANLU_SELECT_POS
        log.info("点击 天禄好礼 [选择] @ (%d, %d)", *pos)
        self.device.click(*pos)
        time.sleep(random.uniform(1.2, 1.8))
        if ocr.find_text(self.device.screenshot(), "选择礼包",
                         region=GIFT_BTN_REGION, min_similarity=1.0):
            log.warning("选择后“选择礼包”仍在，可能未选成功")
        else:
            log.info("周礼已选择：天禄好礼")

    def _claim_all(self):
        """分别领取左右两卡。返回右卡（至尊月卡）是否成功领取——只有它解锁抽奖。"""
        self._claim_card(LEFT_CLAIM_REGION, "超值月卡")
        return self._claim_card(RIGHT_CLAIM_REGION, "至尊月卡")

    def _claim_card(self, region, label):
        """点卡面上的"领取"按钮并关掉奖励弹窗；无按钮（未购卡/已领取）返回 False。

        必须精确匹配"领取"：相似匹配会误中"已领取"。
        """
        for _ in range(2):
            hit = ocr.find_text(self.device.screenshot(), "领取",
                                region=region, min_similarity=1.0)
            if not hit:
                log.info("%s 无“领取”按钮（未购卡或已领取），跳过", label)
                return False
            log.info("点击 %s [领取] @ (%d, %d)", label, hit[0], hit[1])
            self.device.click(hit[0], hit[1])
            self.close_reward_popup()
            time.sleep(random.uniform(0.8, 1.5))
            if not ocr.find_text(self.device.screenshot(), "领取",
                                 region=region, min_similarity=1.0):
                log.info("%s 领取成功", label)
                return True
            log.warning("%s 领取后按钮仍在，重试", label)
        return False

    def _lottery(self):
        """右卡领取后解锁的妖尾抽奖：入口 → 转盘中间抽奖 → 关结果弹窗 → 关面板。"""
        hit = ocr.find_text(self.device.screenshot(), "抽奖",
                            region=LOTTERY_ENTRY_REGION, min_similarity=1.0)
        pos = (hit[0], hit[1]) if hit else LOTTERY_ENTRY_POS
        log.info("点击 [抽奖入口] @ (%d, %d)", *pos)
        self.device.click(*pos)
        if not self._wait_lottery_panel():
            log.warning("抽奖面板未打开，跳过抽奖")
            return
        hit = ocr.find_text(self.device.screenshot(), "抽奖",
                            region=LOTTERY_BTN_REGION, min_similarity=1.0)
        pos = (hit[0], hit[1]) if hit else LOTTERY_BTN_POS
        log.info("点击 [抽奖] @ (%d, %d)", *pos)
        self.device.click(*pos)
        self.close_reward_popup(timeout=15)  # 转盘动画数秒后才出结果弹窗
        self._close_lottery_panel()

    def _wait_lottery_panel(self, timeout=8):
        deadline = time.time() + timeout
        while time.time() < deadline:
            screen = self.device.screenshot()
            if self._lottery_panel_open(screen):
                return True
            time.sleep(0.6)
        return False

    def _lottery_panel_open(self, screen):
        return bool(ocr.find_text(screen, "妖尾抽奖", region=LOTTERY_TITLE_REGION,
                                  min_similarity=0.75)
                    or ocr.find_text(screen, "抽奖", region=LOTTERY_BTN_REGION,
                                     min_similarity=1.0))

    def _close_lottery_panel(self):
        """点右上角 X 关闭抽奖面板（回到月卡页），失败按 ESC 兜底。"""
        for _ in range(3):
            screen = self.device.screenshot()
            if not self._lottery_panel_open(screen):
                return
            self.device.click(*LOTTERY_CLOSE_POS)
            time.sleep(random.uniform(1.0, 1.5))
            if self._on_yueka_page(self.device.screenshot()):
                return
        log.warning("X 关不掉抽奖面板，按 ESC 兜底")
        self.device.press_esc()

    def _on_zhouli_page(self, screen):
        return bool(ocr.find_text(screen, "累计活跃度", region=ZHOULI_PAGE_REGION))

    def _on_yueka_page(self, screen):
        return bool(ocr.find_text(screen, "持续30天", region=YUEKA_PAGE_REGION)
                    or ocr.find_text(screen, "超值月卡", region=YUEKA_PAGE_REGION)
                    or ocr.find_text(screen, "至尊月卡", region=YUEKA_PAGE_REGION))
