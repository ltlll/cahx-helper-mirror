# -*- coding: utf-8 -*-
"""收尾任务：接收灵珠（收集号在好友消息里领取 1~4 号送来的礼物）。

流程（只在收集号上执行）：
主界面 好友图标 → 关系面板「消息」页签 → 会话列表逐个好友（1~4号角色名）：
点名字进聊天框 → 点「点击领取」→ 礼物详情弹窗（显示已领取）→ 点「消息」页签关弹窗
（页签是开关：弹窗开着时点它只关弹窗、仍留在聊天框）→ 继续领下一条；
当前一屏没有「点击领取」就向上滑（聊天区从上往下拖）加载更早的消息，
连续两次上滑都翻不到新的可领取消息即认为该好友收完 → 点「消息」页签回会话列表
换下一位好友。全部收完回主界面。

坐标均为 405x720 客户区（2026-10-11 实测于 5 号客户端）。
"""
import logging
import random
import time

from core import ocr
from tasks.base import Task

log = logging.getLogger("task.shouli")

# ---- 关系面板 / 消息页 ----
FRIEND_ICON_REGION = (0, 605, 60, 48)       # 主界面左下角"好友"图标（OCR 常读成"好发"）
FRIEND_ICON_POS = (25, 628)                 # 好友图标兜底坐标
PANEL_TAB_REGION = (0, 140, 70, 115)        # 关系面板左侧栏（消息/好友/帮会…）
MSG_TAB_REGION = (5, 148, 60, 55)           # 左侧栏"消息"页签 @ (34,176)
MSG_TAB_POS = (34, 176)                     # 消息页签兜底坐标（也是关礼物弹窗的点击位）
MAIL_ROW_REGION = (120, 168, 120, 36)       # 会话列表"邮件"行 @ (164,186)（列表页判定）
CONV_LIST_REGION = (150, 195, 200, 445)     # 会话列表区（名字 x≈212、预览 x≈190），y 195-640
CHAT_TITLE_REGION = (95, 160, 235, 34)      # 聊天框顶部好友名 @ (~200,174)（聊天页判定）
CLAIM_BTN_REGION = (240, 140, 140, 485)     # 聊天框内"点击领取"按钮列 @ x≈305
GIFT_POPUP_REGION = (145, 415, 120, 45)     # 礼物详情弹窗内的"已领取"按钮 @ (202,441)
# 注意：弹窗区域只框住"已领取"按钮本身——消息行内领取后也会显示内联的"已领取"
# （x≈305，y 随消息行），框大了会把它当成弹窗一直在开（实测教训）。
CHAT_SCROLL_FROM = (200, 260)               # 聊天区上滑起点（从上往下拖 = 看更早消息）
CHAT_SCROLL_TO = (200, 620)                 # 上滑终点

CLAIM_TRIES = 3             # 同一条消息"点击领取"最多重试次数
IDLE_SCROLLS = 2            # 连续 N 次上滑都翻不到新礼物即判该好友收完
MAX_ROUNDS_PER_FRIEND = 40  # 单个好友最多循环轮数（防死循环）
OPEN_CHAT_TIMEOUT = 12      # 等聊天框打开的秒数


class Shouli(Task):
    """收尾任务：收集号领取好友赠送的灵珠（消息 → 会话 → 点击领取 → 上滑加载）。

    ⚠️ **暂不可选（available=False）**：本任务与 `Lingzhu`（提交灵珠）是同一个
    玩法「灵珠收集」（base.STAGE_GROUPS["lingshu"]）的**阶段 ②**——各号先把灵珠
    提交/集中给收集号，收集号再在这里接收。整体流程（逐号提交、数量不足收尾）
    尚未定稿，GUI 任务页合并成一张只读阶段卡、不可勾选，调度器与账号线程都会
    跳过本任务。流程补完后把 `available` 改回 True 即可恢复。
    """

    name = "shouli"
    title = "接收灵珠"
    category = "收尾任务"
    stage_group = "lingshu"
    stage_index = 2
    stage_desc = "收集号逐个领取各号送来的灵珠"
    available = False

    def _try_once(self):
        receiver = self._resolve_receiver()
        me = (self.account or {}).get("character") or ""
        if receiver and me and me != receiver:
            log.info("本号（%s）不是收集号（%s），无需接收，跳过", me, receiver)
            return True
        friends = self._resolve_friends(me)
        if not friends:
            log.info("没有需要接收的好友，跳过")
            return True
        log.info("从以下好友接收礼物：%s", "、".join(friends))
        if not self._goto_msg_list():
            return False
        total = 0
        ok_all = True
        for name in friends:
            self._check_stop()
            claimed, ok = self._receive_from(name)
            total += claimed
            if claimed:
                log.info("[%s] 已领取 %d 份礼物", name, claimed)
            else:
                log.info("[%s] 没有可领取的礼物（或会话不存在）", name)
            if not ok:
                ok_all = False
            # 回到会话列表，准备下一位好友
            self._goto_msg_list()
        log.info("接收礼物结束：共领取 %d 份", total)
        return ok_all

    # ---- 收集号 / 好友名单 ----

    def _resolve_receiver(self):
        """收集号角色名：config `receiver` 优先，缺省 = 账号库排序最后一个账号。"""
        receiver = str(self.config.get("receiver") or "").strip()
        if receiver:
            return receiver
        try:
            from core import db
            accounts = db.list_accounts()
        except Exception:
            accounts = []
        return ((accounts[-1] or {}).get("character") or "") if accounts else ""

    def _resolve_friends(self, me):
        """要接收的好友角色名：config `from`（字符串/列表）优先，
        缺省 = 账号库里除自己以外的所有账号（1~4 号）。"""
        raw = self.config.get("from")
        if raw:
            items = raw if isinstance(raw, (list, tuple)) else [raw]
            return [str(x).strip() for x in items if str(x).strip()]
        try:
            from core import db
            accounts = db.list_accounts()
        except Exception:
            accounts = []
        names = [(a or {}).get("character") or "" for a in accounts]
        names = [n for n in names if n and n != me]
        log.info("未配置 from，按账号库取除自己外的所有账号作为好友：%s", names)
        return names

    # ---- 打开关系面板「消息」页 ----

    def _goto_msg_list(self, attempts=3):
        """确保停在「消息」会话列表页：主界面好友图标 → 消息页签。
        已在聊天框时点一次消息页签即可回到列表。"""
        for _ in range(attempts):
            self._check_stop()
            screen = self.device.screenshot()
            if self.dismiss_popups(screen):
                continue
            if self._is_msg_list(screen):
                return True
            if self._is_chat(screen):
                log.info("关闭礼物弹窗/回到会话列表：点击 [消息页签] @ %s", MSG_TAB_POS)
                self.device.click(*MSG_TAB_POS)
                time.sleep(random.uniform(1.0, 1.5))
                continue
            if self._in_relation_panel(screen):
                log.info("点击 [消息页签] @ %s", MSG_TAB_POS)
                self.device.click(*MSG_TAB_POS)
                time.sleep(random.uniform(1.0, 1.5))
                continue
            # 不在面板：回主界面后点好友图标
            self.ensure_main_screen()
            hit = ocr.find_text(self.device.screenshot(), "好友",
                                region=FRIEND_ICON_REGION, min_similarity=0.5)
            pos = (hit[0], hit[1]) if hit else FRIEND_ICON_POS
            log.info("点击 [好友图标] @ (%d, %d)", *pos)
            self.device.click(*pos)
            time.sleep(random.uniform(2.0, 2.6))
        ok = self._is_msg_list(self.device.screenshot())
        if not ok:
            log.warning("未能进入好友消息列表")
            self.report_unknown("msg_list_fail", note="打开好友→消息列表失败")
        return ok

    def _in_relation_panel(self, screen):
        """关系面板已打开：左侧栏出现"消息"+"好友"页签。"""
        tabs = [t for t, *_ in ocr.scan(screen, region=(0, 140, 70, 115),
                                        min_score=0.5)]
        return any("消息" in t for t in tabs) or any("好友" in t for t in tabs)

    def _is_msg_list(self, screen):
        """会话列表页判定：顶部有"邮件"行 @ (164,186)。"""
        return ocr.contains_text(screen, "邮件", region=MAIL_ROW_REGION, min_score=0.5)

    def _gift_popup_open(self, screen):
        """礼物详情弹窗是否开着（认弹窗内那颗"已领取"按钮，见区域注释）。"""
        return ocr.contains_text(screen, "已领取", region=GIFT_POPUP_REGION,
                                 min_score=0.5)

    def _is_chat(self, screen):
        """聊天框打开判定：礼物弹窗开着，或 关系面板开着且顶部没有"邮件"行
        （列表页必定有"邮件"）。"""
        if self._gift_popup_open(screen):
            return True
        return self._in_relation_panel(screen) and not self._is_msg_list(screen)

    # ---- 单个好友：进会话 → 领取 → 上滑 ----

    def _receive_from(self, name):
        """给好友 name 的会话领取全部礼物。返回 (领取份数, 是否正常结束)。"""
        claimed = 0
        idle = 0
        for _ in range(MAX_ROUNDS_PER_FRIEND):
            self._check_stop()
            screen = self.device.screenshot()
            if self.dismiss_popups(screen):
                continue
            if self._is_chat(screen) and self._chat_with(screen, name):
                hit = self._find_claim(screen)
                if hit:
                    self.device.click(hit[0], hit[1])
                    time.sleep(random.uniform(1.0, 1.4))
                    if not self._close_gift_popup():
                        self.report_unknown(
                            "gift_popup_stuck",
                            note="礼物详情弹窗关不掉，停止该好友的领取（已领的算数）")
                        return claimed, True
                    claimed += 1
                    idle = 0
                    continue
                # 本屏没有可领取的消息：上滑加载更早的消息
                log.info("[%s] 本屏无可领取消息，上滑加载更早消息", name)
                self.device.drag(*CHAT_SCROLL_FROM, *CHAT_SCROLL_TO, steps=20)
                time.sleep(random.uniform(1.2, 1.8))
                idle += 1
                if idle >= IDLE_SCROLLS:
                    return claimed, True
                continue
            # 不在该好友的聊天框：回列表 → 点名字进会话
            if not self._open_chat(name):
                return claimed, False
        log.warning("[%s] 领取轮数达到上限（%d 轮），停止该好友",
                    name, MAX_ROUNDS_PER_FRIEND)
        return claimed, True

    def _chat_with(self, screen, name):
        """当前聊天框是否就是好友 name 的会话。

        用模糊匹配：OCR 对长名字会漏字（实测「早起只为干饭」被读成「起只为干饭」
        ——标题区首字被裁掉），精确包含会漏判；去尾部关系标签（兄妹/金兰/亲密无间…）
        后按相似度 ≥0.6 判定。"""
        from difflib import SequenceMatcher
        for t, _cx, _cy, _s in ocr.scan(screen, region=CHAT_TITLE_REGION, min_score=0.5):
            if name in t or t in name:
                return True
            core = t
            for suffix in ("亲密无间", "风雨同舟", "心有灵犀", "兄妹", "金兰", "情缘", "★", "赠礼"):
                core = core.replace(suffix, "")
            core = core.strip()
            if len(core) >= 3 and (core in name or name in core):
                return True
            if SequenceMatcher(None, core, name).ratio() >= 0.6:
                return True
        return False

    def _find_claim(self, screen):
        """在当前聊天框找"点击领取"按钮，返回 (cx, cy) 或 None。
        必须精确匹配"点击领取"——系统行"你领取了XX的礼物"也含"领取"二字。"""
        best = None
        for t, cx, cy, s in ocr.scan(screen, region=CLAIM_BTN_REGION, min_score=0.5):
            if "点击领取" in t:
                if best is None or cy < best[1]:
                    best = (cx, cy)
        return best

    def _close_gift_popup(self, tries=3):
        """关掉礼物详情弹窗。优先按 ESC（实测在聊天框里只关弹窗、面板与聊天框都保留）；
        ESC 无效再点「消息」页签兜底（弹窗开着时点它也只关弹窗）。
        返回是否确认已关。弹窗未开时不动手（点消息页签会退回会话列表）。"""
        for i in range(tries):
            self._check_stop()
            screen = self.device.screenshot()
            if not self._gift_popup_open(screen):
                return True
            if i == 0:
                log.info("按 ESC 关闭礼物详情弹窗")
                self.device.press_esc()
            else:
                log.info("ESC 未关掉礼物详情弹窗，点 [消息页签] 兜底 @ %s", MSG_TAB_POS)
                self.device.click(*MSG_TAB_POS)
            time.sleep(random.uniform(1.5, 2.0))   # 等弹窗淡出 + 截图帧刷新
        return not self._gift_popup_open(self.device.screenshot())

    def _open_chat(self, name):
        """在会话列表里点名字进入聊天框。返回是否成功。"""
        if not self._goto_msg_list():
            return False
        deadline = time.time() + OPEN_CHAT_TIMEOUT
        clicked = False
        while time.time() < deadline:
            self._check_stop()
            screen = self.device.screenshot()
            if self.dismiss_popups(screen):
                continue
            if self._is_chat(screen) and self._chat_with(screen, name):
                log.info("[%s] 已在聊天框", name)
                return True
            hit = None
            for t, cx, cy, s in ocr.scan(screen, region=CONV_LIST_REGION, min_score=0.5):
                if cx > 150 and name in t:
                    hit = (cx, cy, t)
                    break
            if hit:
                log.info("点击 [好友会话] %s @ (%d, %d)（%s）", name, hit[0], hit[1], hit[2])
                self.device.click(hit[0], hit[1])
                clicked = True
            elif not clicked:
                log.warning("会话列表中没有找到好友 [%s] 的会话", name)
                return False
            time.sleep(1.2)
        log.warning("[%s] 聊天框未打开", name)
        return False
