import logging
import random
import re
import time

from core import ocr
from tasks.base import Task
from tasks.zudui import (INPUT_CLICK_POS, FRIEND_AVATAR_POS, FRIEND_NAME_REGION,
                         RESULT_REGION, SEARCH_BTN_POS, SEARCH_BTN_REGION,
                         Zudui)

log = logging.getLogger("task.lingzhu")

# 以下均为 405x720 客户区坐标。
# 来源：用户手动赠送灵珠的截图（2026-10-11）经项目 OCR + 像素实测，
# 与 zudui 手动组队的搜索流程同源（搜索框/搜索按钮/结果行/头像坐标直接复用）。
GIFT_TITLE_REGION = (0, 40, 120, 50)        # 赠送面板左上角标题"赠送" @ (42,65)
INFO_GIFT_BTN_REGION = (230, 448, 100, 42)  # 好友信息卡右列"赠送" @ (279,469)（左列"分享名片" @ (137,469) 不进区域）
INFO_GIFT_BTN_POS = (279, 469)              # 信息卡"赠送"兜底坐标
ITEM_TAB_REGION = (240, 670, 90, 40)        # 赠送面板底部"道具"页签 @ (280,689)（防面板记住"礼物"页）
GIFT_BTN_REGION = (120, 528, 170, 48)       # 赠送面板中部"赠送"按钮 @ (202,552)（上方"数量 0/5" @ (222,512) 不进区域）
GIFT_BTN_POS = (202, 552)                   # 赠送按钮兜底坐标
GRID_REGION = (60, 215, 330, 95)            # 赠送面板第一行道具格（四色灵珠所在行，格子中心 y≈260）
TOOLTIP_REGION = (100, 198, 210, 45)        # 选中提示泡"选中火灵珠" @ (202,224)
QTY_REGION = (120, 496, 180, 34)            # "数量：无限制"/"0/5" @ (197,513)/(222,512)
CONFIRM_REGION = (80, 330, 250, 160)        # 赠送确认弹窗"确定/确认"（居中弹窗，样式待实测后校准）
DETAIL_TITLE_REGION = (100, 195, 210, 45)   # "获取土灵珠"详情弹窗标题 @ (202,216)（实测 2026-10-11）
DETAIL_CLOSE_POS = (40, 400)                # 详情弹窗左缘外空白，点它关闭弹窗（弹窗无关闭按钮）

GEMS = ("火灵珠", "风灵珠", "土灵珠", "水灵珠")
# 阈值 0.90：实测自身命中 未选中 1.0 / 选中态 0.967；最大交叉误匹配 火↔土 0.834、
# 风↔水 0.653 —— 0.90 能干净分开（选中态只在反馈等待阶段出现，主循环找珠时无选中框）
GEM_FIND_THRESHOLD = 0.90
MAX_BATCHES_PER_GEM = 15    # 单颗灵珠最多赠送批数（单批有上限时自动分批送完）
QTY_BADGE_CROP = (2, 10, 44, 20)    # 库存角标裁剪区：格子中心偏移 (dx,dy,w,h)，右下角
QTY_BADGE_PAD = 8                   # 角标 OCR 前四周复制的边距（det 模型需要上下文）
QTY_BADGE_SCALE = 6                 # 角标 OCR 前放大倍数（小字直接喂识别不出）


class Lingzhu(Task):
    """收尾任务：把背包里的四色灵珠经好友「赠送」集中到收集号。

    流程（每个号各自执行）：主界面 → 好友图标 → 好友页签 → 找好友 → 搜索收集号
    角色名 → 点结果行头像 → 信息卡"赠送" → 赠送面板批量赠送 火灵珠/风灵珠/
    土灵珠/水灵珠（模板匹配定位图标，不依赖格子顺序——赠送后格子会重排；
    连点珠子累加本次赠送数量直到库存量，超量点击自动封顶）。

    收集号：config 条目 `target` 指定角色名（字符串，或列表配置多个回退目标）；
    缺省 = 账号库排序最后两个账号（主收集号 + 备用：主号被顶号/未登录时赠给
    备用号）。收集号本身执行本任务时自动跳过。
    未加入 GUI 并行模式（无账号库）且未配置 target 时跳过，不算失败。
    背包里没有灵珠时快速跳过（打不开赠送面板才算失败重试）。

    ⚠️ **暂不可选（available=False）**：本任务与 `Shouli`（接收灵珠）是同一个
    玩法「灵珠收集」（base.STAGE_GROUPS["lingshu"]）的**阶段 ①**——各号把背包里
    的灵珠提交/集中给收集号，收集号再用 Shouli 接收。整体流程（先集中到一个号、
    逐个号提交直到完成或数量不足）尚未定稿，GUI 任务页合并成一张只读阶段卡、
    不可勾选，调度器与账号线程都会跳过本任务。流程补完后把 `available` 改回 True。
    """

    name = "lingzhu"
    title = "提交灵珠"
    category = "收尾任务"
    stage_group = "lingshu"
    stage_index = 1
    stage_desc = "各号把背包里的灵珠赠送集中到收集号"
    available = False

    def _try_once(self):
        targets = self._resolve_targets()
        if not targets:
            return True
        me = (self.account or {}).get("character") or ""
        targets = [t for t in targets if not (me and t == me)]
        if not targets:
            log.info("本号（%s）就是收集号，无需赠送，跳过", me)
            return True
        log.info("收集号顺序：%s（前一个不可用时依次回退）", " → ".join(targets))
        for i, target in enumerate(targets):
            self._check_stop()
            self._target = target
            log.info("尝试向收集号 [%s] 赠送灵珠（火/风/土/水）", target)
            if not self._ensure_gift_panel():
                left = len(targets) - i - 1
                log.warning("无法向 [%s] 打开赠送面板（可能未登录/被顶号）%s",
                            target, f"，尝试备用收集号（剩 {left} 个）" if left else "，且无备用收集号")
                self.back_to_home()
                continue
            total = 0
            panel_ok = True
            for gem in GEMS:
                self._check_stop()
                sent, ok = self._gift_gem(gem)
                total += sent
                if sent:
                    log.info("%s 已赠送 %d 批", gem, sent)
                if not ok:
                    panel_ok = False
                    break
            if total == 0 and panel_ok:
                log.info("背包没有可赠送的灵珠（或已全部送过），任务结束")
            else:
                log.info("灵珠赠送结束：共向 %s 赠送 %d 批", target, total)
            return panel_ok
        log.warning("所有收集号均不可用，赠送失败")
        return False

    # ---- 收集号解析 ----

    def _resolve_targets(self):
        """收集号列表：config 条目 `target`（字符串或列表）优先；缺省 = 账号库
        排序最后两个账号且**主收集号在前**——排序最后一个（5号）是主目标，
        倒数第二个（4号）是备用（主号被顶号/未登录时赠给备用号）。"""
        raw = self.config.get("target")
        if raw:
            items = raw if isinstance(raw, (list, tuple)) else [raw]
            names = [str(x).strip() for x in items if str(x).strip()]
            if names:
                return names
        try:
            from core import db
            accounts = db.list_accounts()
        except Exception:
            accounts = []
        if not accounts:
            log.warning("未配置 target 且账号库不可用，跳过灵珠赠送")
            return []
        names = [(a or {}).get("character") or ""
                 for a in reversed(accounts[-2:])]
        names = [n for n in names if n]
        log.info("未配置 target，按账号库排序取最后两个账号作为收集号"
                 "（主目标在前，备用兜底）：%s", names)
        return names

    # ---- 打开赠送面板（好友搜索 → 信息卡 → 赠送）----

    def _ensure_gift_panel(self):
        """确保赠送面板已打开且在"道具"页。复用手动组队已实机验证的
        好友搜索导航（Zudui._goto_friend_search）。"""
        if ocr.find_text(self.device.screenshot(), "赠送",
                         region=GIFT_TITLE_REGION, min_similarity=0.9):
            return True
        return self._open_gift_panel(self._target)

    def _open_gift_panel(self, target):
        for attempt in range(2):
            self._check_stop()
            if not Zudui._goto_friend_search(self):
                self.back_to_home()
                continue
            # 清空输入框（连发退格，⊗ 位置漂移点不中——zudui 实测教训）后粘贴角色名
            log.info("点击 [搜索输入框] @ (%d, %d)", *INPUT_CLICK_POS)
            self.device.click(*INPUT_CLICK_POS)
            self.device.press_backspace()
            time.sleep(random.uniform(0.3, 0.6))
            if not self.device.paste_text(target):
                continue
            btn = ocr.find_text(self.device.screenshot(), "搜索",
                                region=SEARCH_BTN_REGION, min_similarity=1.0)
            pos = (btn[0], btn[1]) if btn else SEARCH_BTN_POS
            log.info("点击 [搜索] @ (%d, %d)", *pos)
            self.device.click(*pos)
            # 等结果行出现收集号名字；搜索点击可能被吞，8 秒无果重点一次
            hit = None
            deadline = time.time() + 30
            next_click = time.time() + 8
            while time.time() < deadline:
                self._check_stop()
                screen = self.device.screenshot()
                if self.dismiss_popups(screen):
                    continue
                hit = Zudui._find_name_in(screen, RESULT_REGION, target)
                if hit:
                    break
                if time.time() >= next_click:
                    btn = ocr.find_text(screen, "搜索", region=SEARCH_BTN_REGION,
                                        min_similarity=1.0)
                    p = (btn[0], btn[1]) if btn else SEARCH_BTN_POS
                    log.info("搜索无结果，重点 [搜索] @ (%d, %d)", *p)
                    self.device.click(*p)
                    next_click = time.time() + 8
                time.sleep(0.6)
            if not hit:
                log.warning("搜索结果中未找到收集号 %s", target)
                self.save_debug_screenshot("lingzhu_search_none")
                self.back_to_home()
                continue
            # 点结果首行头像（名字已核对，列位置固定）；信息卡未弹出重点一次
            log.info("点击 [好友头像] @ (%d, %d)（结果: %s）",
                     *FRIEND_AVATAR_POS, target)
            self.device.click(*FRIEND_AVATAR_POS)
            card = None
            reclicked = False
            deadline = time.time() + 10
            while time.time() < deadline:
                self._check_stop()
                screen = self.device.screenshot()
                if self.dismiss_popups(screen):
                    continue
                card = Zudui._find_name_in(screen, FRIEND_NAME_REGION, target)
                if card:
                    break
                if not reclicked and time.time() > deadline - 4:
                    reclicked = True
                    log.info("信息卡未弹出，重点 [好友头像]")
                    self.device.click(*FRIEND_AVATAR_POS)
                time.sleep(0.6)
            if not card:
                log.warning("好友信息卡未出现（或顶部名字不是 %s）", target)
                self.save_debug_screenshot("lingzhu_card_fail")
                self.back_to_home()
                continue
            # 信息卡点"赠送"打开赠送面板
            gbtn = ocr.find_text(self.device.screenshot(), "赠送",
                                 region=INFO_GIFT_BTN_REGION, min_similarity=1.0)
            gpos = (gbtn[0], gbtn[1]) if gbtn else INFO_GIFT_BTN_POS
            log.info("点击 [赠送-信息卡] @ (%d, %d)", *gpos)
            self.device.click(*gpos)
            deadline = time.time() + 8
            while time.time() < deadline:
                self._check_stop()
                if ocr.find_text(self.device.screenshot(), "赠送",
                                 region=GIFT_TITLE_REGION, min_similarity=0.9):
                    # 防面板记住上次停留的"礼物"页，点一次"道具"页签
                    tab = ocr.find_text(self.device.screenshot(), "道具",
                                        region=ITEM_TAB_REGION, min_similarity=1.0)
                    if tab:
                        log.info("点击 [道具页签] @ (%d, %d)", tab[0], tab[1])
                        self.device.click(tab[0], tab[1])
                        time.sleep(random.uniform(0.8, 1.2))
                    log.info("已进入赠送面板")
                    return True
                time.sleep(0.6)
            log.warning("赠送面板未打开，重试 (%d/2)", attempt + 1)
            self.back_to_home()
        log.warning("多次尝试仍未能进入赠送面板")
        self.save_debug_screenshot("lingzhu_panel_fail")
        return False

    # ---- 赠送灵珠 ----

    def _gift_gem(self, gem):
        """批量赠送单颗灵珠直到图标消失。每批：未选中态读库存角标 → 点珠选中 →
        连点累加数量到库存量 → 确认无详情弹窗 → 点赠送。
        返回 (赠送批数, 面板是否可用)。

        ⚠️ 珠子**已处于选中态**（上一批赠送没生效/面板保留选中）时绝不能再点珠子：
        已选数量已满（如库存仅 1，选中即 1/1）时再点会弹「获取XX灵珠」详情弹窗——
        2026-10-11 第 2 个客户端实测：水灵珠仅 1 个，选中后被再次点击 → 弹窗 →
        客户端假死、账号线程沉默卡死。此时必须直接点「赠送」。"""
        batches = 0
        while batches < MAX_BATCHES_PER_GEM:
            self._check_stop()
            if not self._ensure_gift_panel():
                return batches, False
            screen = self.device.screenshot()
            if self.dismiss_popups(screen):
                continue
            if self._close_detail_popup():
                continue
            hit = self.matcher.find(screen, gem, region=GRID_REGION,
                                    threshold=GEM_FIND_THRESHOLD)
            if not hit:
                log.info("赠送面板已无 %s（没有库存或已送完）", gem)
                return batches, True
            sel, _stock = self._read_stock_pair(screen, hit)
            if sel:
                log.info("%s 已处于选中态（已选 %d），不再点珠子，直接赠送", gem, sel)
                self._fill_batch(gem, hit, screen, clicked=False)
            else:
                log.info("点击 [%s] @ (%d, %d) score=%.2f", gem, hit[0], hit[1], hit[2])
                self.device.click(hit[0], hit[1])
                if not self._wait_selected(gem, hit):
                    self.report_unknown(
                        f"no_select_{gem}",
                        note="点灵珠后未出现选中提示（可能格子为空/不可赠送），跳过该灵珠")
                    return batches, True
                self._fill_batch(gem, hit, screen, clicked=True)
            self._close_detail_popup()
            self._click_gift_button()
            self._wait_gift_feedback(gem)
            batches += 1
            time.sleep(random.uniform(0.8, 1.5))
        log.warning("%s 赠送 %d 批后画面上仍能找到，停止赠送（请人工确认剩余数量）",
                    gem, batches)
        self.report_unknown("gift_loop_cap",
                            note=f"{gem} 已赠 {batches} 批仍存在（剩余库存见截图）")
        return batches, True

    def _fill_batch(self, gem, hit, pre_screen, clicked=True):
        """选中后继续连点灵珠，把本次赠送数量累加到库存量。

        clicked=False：进入前珠子**已处于选中态**（本轮没点它，多为上一批赠送
        没生效）——已选数取角标"已选/库存"的第一个数，补点数可为 0。

        库存以两次读数中较小者为准：①未选中态纯数字角标（pre_screen，可靠）；
        ②选中态"已选/库存"角标（"3/3" 曾被 OCR 误读成 13——实测教训：点满数量后
        再点珠子会弹出"获取灵珠"详情弹窗吃掉后续点击，超量点击必须避免）。
        两次都读不出则只送 1 个，由外层循环分批补送。"""
        a = self._read_stock(pre_screen, hit)
        sel, b = self._read_stock_pair(self.device.screenshot(), hit)
        reads = [x for x in (a, b) if x > 0]
        total = min(reads) if reads else 1
        if not clicked and not sel:
            # 已选中但读不出已选数：当作已选满，保守不补点（再点必弹详情弹窗）
            log.info("%s 已处于选中态但角标未读出已选数，保守不补点（目标 %d）",
                     gem, total)
            extra = 0
        else:
            done = sel or 1      # 首次点击已选中并计入 1 个；角标读不出已选数按 1 算
            extra = max(total - done, 0)
        for _ in range(extra):
            self._check_stop()
            self.device.click(hit[0], hit[1])
            time.sleep(random.uniform(0.15, 0.3))
        log.info("%s 连点 %d 次累计数量（未选中读数=%s，已选=%s，库存读数=%s）",
                 gem, extra + (1 if clicked else 0), a or "未读出",
                 sel or ("未读出" if not clicked else 1), b or "未读出")

    def _close_detail_popup(self, timeout=8):
        """关闭"获取XX灵珠"详情弹窗（点满数量后再点珠子会触发；无关闭按钮，
        点弹窗外空白关闭，无效再试 ESC）。返回是否关过弹窗。"""
        closed = False
        deadline = time.time() + timeout
        esc_tried = False
        while time.time() < deadline:
            self._check_stop()
            screen = self.device.screenshot()
            if not ocr.contains_text(screen, "获取",
                                     region=DETAIL_TITLE_REGION, min_score=0.5):
                return closed
            if not closed:
                log.info("检测到灵珠详情弹窗，点击弹窗外空白关闭 @ %s", DETAIL_CLOSE_POS)
                self.device.click(*DETAIL_CLOSE_POS)
            elif not esc_tried:
                esc_tried = True
                log.info("弹窗外点击未关闭详情弹窗，按 ESC 兜底")
                self.device.press_esc()
            else:
                return closed
            closed = True
            time.sleep(random.uniform(0.8, 1.2))
        return closed

    def _read_stock_pair(self, screen, hit):
        """读格子右下角角标，返回 (已选, 库存)。

        未选中态是纯数字（如 6）→ (None, 6)；选中态是"已选/库存"（如 3/3，
        选中后连点会涨第一个数）→ (3, 3)。读不出 → (None, 0)。数字封顶 99。
        小字黄字必须 加边距+放大 6 倍 OCR 才读得出（实测 pad=8/scale=6 全对）。"""
        import cv2
        dx, dy, w, h = QTY_BADGE_CROP
        x0, y0 = hit[0] + dx, hit[1] + dy
        crop = screen[max(y0, 0):y0 + h, max(x0, 0):x0 + w]
        if crop.size == 0:
            return None, 0
        crop = cv2.copyMakeBorder(crop, QTY_BADGE_PAD, QTY_BADGE_PAD,
                                  QTY_BADGE_PAD, QTY_BADGE_PAD, cv2.BORDER_REPLICATE)
        crop = cv2.resize(crop, (crop.shape[1] * QTY_BADGE_SCALE,
                                 crop.shape[0] * QTY_BADGE_SCALE),
                          interpolation=cv2.INTER_CUBIC)
        try:
            texts = ocr.scan(crop, min_score=0.2)
        except Exception:
            return None, 0
        for t, _cx, _cy, _s in texts:
            m = re.search(r"(\d+)\s*/\s*(\d+)", t)
            if m:
                return min(int(m.group(1)), 99), min(int(m.group(2)), 99)
        for t, _cx, _cy, _s in texts:
            digits = re.sub(r"\D", "", t)
            if digits:
                return None, min(int(digits), 99)
        return None, 0

    def _read_stock(self, screen, hit):
        """读格子右下角库存角标（兼容未选中纯数字与选中"a/b"两种态）。
        失败返回 0。"""
        _sel, stock = self._read_stock_pair(screen, hit)
        return stock

    def _wait_selected(self, gem, hit, timeout=6):
        """等选中反馈：提示泡"选中<gem>"、数量行"无限制"，或角标变为"已选/库存"。

        hit 传入珠子格坐标用于读角标。重点（二次点击）前必须先确认**尚未选中**——
        已选满的珠子再点会弹"获取灵珠"详情弹窗（2026-10-11 实测会导致客户端假死）。"""
        deadline = time.time() + timeout
        reclicked = False
        while time.time() < deadline:
            self._check_stop()
            screen = self.device.screenshot()
            if (ocr.contains_text(screen, f"选中{gem}", region=TOOLTIP_REGION)
                    or ocr.contains_text(screen, "无限制", region=QTY_REGION)):
                return True
            # 角标已是"已选/库存"格式＝已选中（提示泡 OCR 偶尔不中，以角标为准）
            sel, _stock = self._read_stock_pair(screen, hit)
            if sel:
                return True
            # 点已选满数量的珠子会弹"获取灵珠"详情弹窗，挡住一切判定——先关再等
            if self._close_detail_popup():
                continue
            if not reclicked and time.time() > deadline - 3:
                reclicked = True
                hit2 = self.matcher.find(screen, gem, region=GRID_REGION,
                                         threshold=GEM_FIND_THRESHOLD)
                if hit2:
                    log.info("未出现选中提示，重点 [%s]", gem)
                    self.device.click(hit2[0], hit2[1])
            time.sleep(0.6)
        return False

    def _click_gift_button(self):
        btn = ocr.find_text(self.device.screenshot(), "赠送",
                            region=GIFT_BTN_REGION, min_similarity=1.0)
        pos = (btn[0], btn[1]) if btn else GIFT_BTN_POS
        log.info("点击 [赠送] @ (%d, %d)", *pos)
        self.device.click(*pos)

    def _wait_gift_feedback(self, gem, timeout=10):
        """等赠送动作结束：确认弹窗（若有）点"确定"，选中态复位即算完成。"""
        deadline = time.time() + timeout
        confirmed = False
        while time.time() < deadline:
            self._check_stop()
            screen = self.device.screenshot()
            if self.dismiss_popups(screen):
                continue
            # 详情弹窗若在赠送后仍开着，说明赠送点击被它吃掉了——关闭后补点赠送
            if self._close_detail_popup():
                log.info("详情弹窗吃掉了赠送点击，补点 [赠送]")
                self._click_gift_button()
                continue
            cfm = (ocr.find_text(screen, "确定", region=CONFIRM_REGION,
                                 min_similarity=1.0)
                    or ocr.find_text(screen, "确认", region=CONFIRM_REGION,
                                     min_similarity=1.0))
            if cfm and not confirmed:
                confirmed = True
                log.info("点击 [确定-赠送确认] @ (%d, %d)", cfm[0], cfm[1])
                self.device.click(cfm[0], cfm[1])
                deadline = time.time() + timeout  # 点了确认再给一轮等待
                time.sleep(1.0)
                continue
            # 选中态已复位（提示泡消失且数量行不再是"无限制"）＝本次赠送已结束
            if (not ocr.contains_text(screen, "选中", region=TOOLTIP_REGION)
                    and not ocr.contains_text(screen, "无限制", region=QTY_REGION)):
                return True
            time.sleep(0.6)
        log.warning("点击赠送后 %d 秒画面未复位（可能有未处理的弹窗/提示）", timeout)
        self.report_unknown("gift_no_feedback",
                            note=f"赠送 {gem} 后画面未复位，见截图（确认框样式/提示待人工确认）")
        return False
