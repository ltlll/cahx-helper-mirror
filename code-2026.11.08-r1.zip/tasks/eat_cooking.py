import logging
import random
import time

from tasks.base import Task

log = logging.getLogger("task.eat_cooking")

# 快捷食用面板（405x720 客户区）
CHECKBOX_REGION = (104, 230, 24, 262)   # 复选框列：检测剩余绿色 √
PANEL_CLOSE_POS = (197, 696)            # 面板外下方空白处：点击关闭快捷食用面板
BEIZHAN_CLOSE_POS = (389, 24)           # 备战页右上角 X：关闭备战回到背包页
EAT_BTN_REGION = (100, 570, 250, 60)    # 备战页"烹饪"行一键食用（避开下方"美食"行同款按钮）
MAX_EAT_CLICKS = 8


class EatCooking(Task):
    """吃烹饪：背包 → 备战 → 一键食用，把快捷食用里勾选的烹饪 buff 全部吃完。

    流程：主界面点"背包" → 背包页点"备战" → 备战页点烹饪行"一键食用" →
    快捷食用面板反复点"一键食用"，直到复选框的 √ 全部消失（最多 8 次，间隔 1~2 秒）→
    点面板外下方空白处关闭面板 → 点左下"返回"回主界面。
    """

    name = "eat_cooking"
    title = "吃烹饪"
    category = "备战任务"

    def _try_once(self):
        self.dismiss_popups()
        if not self.open_backpack():
            return False
        if not self.matcher.find_and_click(self.device, "备战", timeout=8):
            return False
        if not self.matcher.find_and_click(self.device, "一键食用", timeout=8,
                                           region=EAT_BTN_REGION):
            return False

        for i in range(1, MAX_EAT_CLICKS + 1):
            time.sleep(random.uniform(1.0, 2.0))
            screen = self.device.screenshot()
            if not self._has_checked_buff(screen):
                log.info("烹饪已全部食用（第 %d 轮确认）", i)
                break
            hit = self.matcher.find(screen, "一键食用_面板")
            if not hit:
                log.warning("快捷食用面板中未找到一键食用按钮")
                return False
            log.info("一键食用（第 %d/%d 次）", i, MAX_EAT_CLICKS)
            self.device.click(hit[0], hit[1])
        else:
            log.warning("已达最大食用次数 %d 次，强制收尾", MAX_EAT_CLICKS)
            # 留下复选框列现状，便于排查绿色 √ 像素检测为何没收敛
            self.save_debug_screenshot("eat_cooking_stuck")

        self.device.click(*PANEL_CLOSE_POS)
        time.sleep(random.uniform(0.8, 1.5))
        # 关闭快捷食用面板后停在备战页：点右上角 X 回背包页，再点返回回主界面
        self.device.click(*BEIZHAN_CLOSE_POS)
        time.sleep(random.uniform(0.8, 1.5))
        if not self.matcher.find_and_click(self.device, "背包返回", timeout=5):
            log.warning("未找到返回按钮，按 ESC 兜底返回主界面")
            self.back_to_home()
        return True

    @staticmethod
    def _has_checked_buff(screen):
        """快捷食用面板复选框列里是否还有绿色 √。"""
        x, y, w, h = CHECKBOX_REGION
        crop = screen[y:y + h, x:x + w]
        b = crop[:, :, 0].astype(int)
        g = crop[:, :, 1].astype(int)
        r = crop[:, :, 2].astype(int)
        green = (g > 120) & (g > r + 30) & (g > b + 30)
        return int(green.sum()) >= 30
