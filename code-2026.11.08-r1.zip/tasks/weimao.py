import logging
import random
import re
import time

import cv2
import numpy as np

from core import ocr
from tasks.home_base import HomeTask

log = logging.getLogger("task.weimao")

# 以下均为 405x720 客户区坐标（按用户真机截图校准，账号5 实测 2026-10-10）。
# 机制（用户口述 + 实测）：
#   - 猫（黑猫/橘猫）**会动**，不能用固定坐标判定；猫名标签（黑猫/橘猫）在猫身**下方**。
#   - 猫需要喂但当前画面看不到猫时，**屏幕左/右边缘出现金色爪印指引图标**（水滴 pin
#     内含橙色猫头），点它 = 镜头自动平移到猫。左缘或右缘都可能出现。
#   - 猫可能被角色自己挡住：可点远处地面让角色走开，再通过爪印图标找猫。
#   - 点猫 → 弹「旅行吧喵喵」面板（喂猫按钮 / 日志 / 串门）；喂猫前**偶发**先弹
#     「将探索奖励分享给一同付出的好友吧」送礼面板，必须先勾满好友点「送礼」处理掉。
#   - 喂猫 → toast「成功喂猫，喂养进度+1」+「恭喜获得」结算窗（**要点弹窗内部**，
#     点面板外会把喵喵面板一起关掉——实测教训）。
#   - 两只猫**共享喂猫操作，每天只能喂 1 次**；喂完「喂猫」按钮变灰（禁用态）。
#     喂饱进度满 5/5（=5 天）后猫出游带回礼物。
#   - 喵喵面板的**关闭按钮 = 右上角金色装饰花**（ESC 关不掉、点面板外不稳定）。

# ---- 找猫 ----
CAT_LABELS = ("黑猫", "橘猫")              # 猫名标签（OCR，标签在猫身下方）
CAT_BODY_DY = -27                          # 猫身点击点相对标签中心的纵向偏移（实测黑猫标签 (167,357)→猫 (167,331)）
CAT_LABEL_X_RANGE = (20, 385)              # 标签 x 范围（全图 OCR 后过滤）
CAT_LABEL_Y_RANGE = (100, 560)             # 标签 y 范围（避开顶部 HUD 与底部聊天栏）
# 金色爪印检测：金/橙色像素掩码 + 连通域面积过滤，只在左右边缘条带内找
PAW_STRIPS = ((0, 70, "左缘"), (335, 405, "右缘"))
PAW_AREA_MIN = 150                         # 连通域面积下限（实测爪印金色块 bbox 31x25）
PAW_AREA_MAX = 3000                        # 面积上限（防大块金色场景元素误中）
STEP_ASIDE_POS = (90, 500)                 # 点远处地面让角色走开（猫被角色挡住时用）
LOCATE_TRIES = 5                           # 找猫总轮数（OCR 标签 → 爪印平移 → 点地面走开 交替；
                                           # 实测账号4 猫被挡/需多次平移，3 轮不够）

# ---- 「旅行吧喵喵」面板 ----
# ⚠️ 面板判定必须用全图 OCR：实测（账号7）小区域裁剪对美术字标题会整行漏检
# （标题命中点明明在区域内也读不到），同 zhongcai 的"小裁剪漏检"教训，勿改回 region。
CAT_PANEL_KEYWORDS = ("旅行吧喵喵",)        # 喵喵面板标题判定
CAT_PANEL_CLOSE_POS = (330, 242)           # 右上角金色装饰花 = 关闭按钮
FEED_BTN_POS = (210, 461)                  # 「喂猫」按钮中心（橙色可用态；喂完变灰）
FEED_BTN_REGION = (150, 440, 120, 40)      # 按钮橙色像素采样区（判可用/禁用态，辅助判定）
FEED_BTN_ORANGE_MIN = 0.05                 # 橙色像素占比 ≥ 此值 = 可用（实测可用≈0.11，灰态≈0.00）
FEED_TOAST_KEYWORDS = ("成功喂猫", "喂养进度")   # 喂猫成功的 toast
REWARD_TITLE_REGION = (80, 140, 250, 90)   # 「恭喜获得」结算窗标题区（实测中心 ≈(200,178)）
# 喂猫后的「恭喜获得」结算窗：**必须点弹窗内部**，点面板外 (202,500) 会把喵喵面板一起关掉
REWARD_INNER_POS = (202, 420)

# ---- 送礼面板（点猫后偶发，必须先处理才能喂猫）----
GIFT_PANEL_KEYWORDS = ("分享给一同付出", "将探索奖励")   # 标题实测中心 (198,174)，小区域会漏检
GIFT_CB_X = 326                            # 复选框列 x（实测勾选生效）
GIFT_ROW_X_RANGE = (100, 180)              # 玩家名字列（OCR 找行 y 用）
GIFT_ROW_Y_RANGE = (235, 470)              # 好友行 y 范围（避开表头与「已选择」行）
GIFT_SEND_POS = (202, 524)                 # 「送 礼」按钮兜底坐标
GIFT_SCROLL_DRAG = ((200, 430), (200, 280))  # 列表上滑（找更多好友）
GIFT_SCROLL_MAX = 4                        # 上滑次数上限


class Weimao(HomeTask):
    """喂猫（家园）：主界面十字 → 功能面板"家园" → 回家 → 家园场景找猫
    （OCR 猫名标签 / 左右缘金色爪印指引图标）→ 点猫 → 处理偶发的送礼面板
    （勾满好友 ×/5 → 送礼 → 关确认窗 → 用掉「灵宠旅行礼物」）→「旅行吧喵喵」
    面板点「喂猫」→ 关「恭喜获得」（点弹窗内部）→ 点右上角装饰花关面板 →
    右缘「离开」回主界面。

    ⚠️ **喂猫结束后必须回主界面**（用户规则）：后续若跑种菜任务，需要重新进
    家园才能复位视角——喂完猫原地直接种菜会找不到路牌锚点。

    每天只能喂 1 次（两只猫共享），喂完按钮变灰 → 本任务已加入 DAILY_ONCE_TASKS
    （当天成功后跳过）。**家园里找不到猫属正常状态**（用户确认）：今天已喂过
    （喂后爪印消失）或喂饱 5/5 后猫出游旅行中（家园无猫无爪印）→ 直接收工，
    不判失败、不报问题。

    不确定项（首次真机跑完请对照 debug/run.log 校准）：
      - 送礼确认窗（"成功送礼…点击空白处关闭"）按"点窗内空白"关闭；
      - 喂猫按钮的可用/禁用用橙色像素占比判定，阈值 FEED_BTN_ORANGE_MIN 可能要按
        实机微调（判定失手时点灰按钮无反应，无害）。
    """

    name = "weimao"
    title = "喂猫"
    category = "日常任务"

    def _try_once(self):
        self._stage = "清理系统弹窗"
        self.dismiss_popups()
        self._stage = "进家园"
        if not self._open_garden():
            return False
        ok = self._feed_cat()
        self._stage = "关喵喵面板"
        self._close_cat_panel()
        # 用户规则：喂猫结束回主界面。后续种菜任务重新进家园才能复位视角。
        self._stage = "离开家园回主界面"
        self._leave_home()
        return ok

    # ---------- 找猫 ----------

    def _feed_cat(self):
        """家园场景 → 找猫 → 点猫 → 处理送礼面板 → 喂猫 → 关结算窗。
        找不到猫时按"今天已喂过"收工（返回 True），详见类文档。"""
        self._stage = "找猫"
        cat_pos, via = self._locate_cat()
        if cat_pos is None:
            # 用户确认（2026-10-10）：两种正常状态家园里都没猫没爪印——
            # ① 今天已喂过（喂后爪印消失）；② 喂饱 5/5 后猫出游旅行中。
            # 直接收工（DAILY_ONCE 会记今天完成，明天 5 点刷新后再试）。
            log.info("家园里没有猫也没有爪印指引（今天已喂过，或猫喂饱 5/5 "
                     "出游旅行中），无需喂猫，收工")
            return True
        log.info("找到猫 @ (%d, %d)（%s），点击", cat_pos[0], cat_pos[1], via)
        self._stage = "点猫"
        self.device.click(cat_pos[0], cat_pos[1])
        time.sleep(random.uniform(1.2, 2.0))
        # 点猫后先弹送礼面板（偶发）或直接喵喵面板；送礼面板必须先处理
        self._stage = "等喵喵面板"
        if not self._wait_cat_panel(timeout=10, cat_pos=cat_pos):
            self.report_unknown("no_cat_panel",
                                note="点猫后 10s 内未见「旅行吧喵喵」面板（送礼面板已处理过）")
            return False
        # 送礼面板可能盖在喵喵面板上/后补弹，喂猫前再清一次
        self._stage = "处理送礼面板"
        self._handle_gift_panel()
        return self._do_feed()

    def _locate_cat(self):
        """定位猫，返回 (点击坐标, 定位方式) 或 (None, None)。

        每轮：先 OCR 猫名标签（猫身 = 标签 y-27）；不在画面 → 找左右缘金色爪印
        图标，点它让镜头平移；都不行 → 点远处地面让角色走开（猫可能被角色挡住）
        再找一轮（用户教的方法）。

        ⚠️ 爪印点击后**必须看到猫标签才算有效**，否则拉黑该点：实测（账号4）
        场景里的彩虹金星、家园左列白底圆按钮的金色图标都会被误认为爪印，
        而"画面变化"不能当作平移成功的判据——点场景地面/装饰角色会走动，
        画面必然变化（误报点连点 4 轮全白耗的教训）。
        """
        dead_paws = []                       # 点击无效的疑似爪印位置（不重复点）
        for rnd in range(1, LOCATE_TRIES + 1):
            self._check_stop()
            screen = self.device.screenshot()
            pos = self._find_cat_label(screen)
            if pos:
                return pos, "OCR猫名标签"
            paw = self._find_paw_icon(screen, skip=dead_paws)
            if paw:
                log.info("第 %d 轮：猫不在画面，点击%s金色爪印指引 @ (%d, %d) 平移镜头",
                         rnd, paw[2], paw[0], paw[1])
                self.device.click(paw[0], paw[1])
                time.sleep(random.uniform(2.0, 3.0))   # 等镜头平移完成
                screen2 = self.device.screenshot()
                pos = self._find_cat_label(screen2)
                if pos:
                    return pos, "爪印平移后OCR标签"
                dead_paws.append((paw[0], paw[1]))
                if not self._on_garden_scene(screen2):
                    # 家园 HUD/路牌都消失 = 误点家园左列白底圆按钮（金色图标形似
                    # 爪印）打开了面板——按 ESC 关掉，别让面板盖住后续判定
                    log.info("点击爪印后家园场景特征消失（疑似误点家园按钮开了面板），"
                             "按 ESC 关掉并拉黑该点")
                    self.device.press_esc()
                    time.sleep(random.uniform(1.0, 1.5))
                else:
                    log.info("点击后仍未见猫标签（疑似场景金色元素误报），拉黑该点")
                continue
            if rnd < LOCATE_TRIES:
                log.info("第 %d 轮：未见猫与爪印指引，点远处地面 (%d, %d) 让角色走开再找",
                         rnd, *STEP_ASIDE_POS)
                self.device.click(*STEP_ASIDE_POS)
                time.sleep(random.uniform(1.5, 2.5))
        log.info("找猫 %d 轮未果（猫与爪印指引都未见）", LOCATE_TRIES)
        return None, None

    @staticmethod
    def _find_cat_label(screen):
        """OCR 找猫名标签（黑猫/橘猫），返回猫身点击坐标 (标签x, 标签y-27)。"""
        for t, x, y, *_ in ocr.scan(screen):
            if not (CAT_LABEL_X_RANGE[0] <= x <= CAT_LABEL_X_RANGE[1]
                    and CAT_LABEL_Y_RANGE[0] <= y <= CAT_LABEL_Y_RANGE[1]):
                continue
            for label in CAT_LABELS:
                if label in t and len(t) <= 6:   # 标签就两三个字，长文本是聊天/其它 UI
                    log.info("OCR 命中猫名标签「%s」@ (%d, %d)", t, x, y)
                    return (x, y + CAT_BODY_DY)
        return None

    @staticmethod
    def _find_paw_icon(screen, skip=()):
        """在左/右边缘条带内找金色爪印指引图标，返回 (cx, cy, 位置描述) 或 None。

        检测：金/橙色像素掩码（r>190, g 120-210, b<110, r-b>90，实测右缘爪印
        金色块 bbox (361,293,31,25)）+ 连通域面积过滤（150 < 面积 < 3000，
        下限滤噪点、上限滤大块金色场景元素）。y 限定 80-620（避开顶部 HUD
        与底部聊天栏的金色装饰）。skip 里的位置（点击无反应的误报点）跳过。
        """
        for x0, x1, side in PAW_STRIPS:
            strip = screen[80:620, x0:x1].astype(int)
            b, g, r = strip[:, :, 0], strip[:, :, 1], strip[:, :, 2]
            mask = ((r > 190) & (g > 120) & (g < 210) & (b < 110)
                    & ((r - b) > 90)).astype(np.uint8)
            if mask.sum() < PAW_AREA_MIN:
                continue
            n, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
            for i in range(1, n):
                area = int(stats[i, cv2.CC_STAT_AREA])
                if not (PAW_AREA_MIN <= area <= PAW_AREA_MAX):
                    continue
                cx = x0 + int(stats[i, cv2.CC_STAT_LEFT] + stats[i, cv2.CC_STAT_WIDTH] / 2)
                cy = 80 + int(stats[i, cv2.CC_STAT_TOP] + stats[i, cv2.CC_STAT_HEIGHT] / 2)
                if any(abs(cx - sx) <= 15 and abs(cy - sy) <= 15 for sx, sy in skip):
                    continue
                log.info("金色爪印指引命中（%s，面积 %d）@ (%d, %d)", side, area, cx, cy)
                return cx, cy, side
        return None

    # ---------- 喵喵面板 / 喂猫 ----------

    def _wait_cat_panel(self, timeout=15, cat_pos=None):
        """等「旅行吧喵喵」面板出现；中途先处理弹出的送礼面板。
        送礼处理完喵喵面板没自动出现时，最后阶段补点一次猫。
        （实测账号7：面板打开有动画 + 全图 OCR 单次 ~2-3s，10s 轮询只跑得动
        1-2 轮就误报过 no_cat_panel——面板其实已开。改 15s 超时，且每轮只做
        **一次**全图 scan 同时判两种面板。）"""
        deadline = time.time() + timeout
        reclicked = False
        while time.time() < deadline:
            self._check_stop()
            state = self._panel_state(self.device.screenshot())
            if state == "cat":
                log.info("「旅行吧喵喵」面板已打开")
                time.sleep(random.uniform(0.8, 1.4))
                return True
            if state == "gift":
                self._handle_gift_panel()
                continue
            if (cat_pos and not reclicked
                    and time.time() > deadline - timeout / 3):
                # 面板一直没来（点击被吞？），最后阶段补点一次猫
                log.info("喵喵面板未出现，补点一次猫 @ (%d, %d)", *cat_pos)
                self.device.click(*cat_pos)
                reclicked = True
            time.sleep(0.6)
        return self._panel_state(self.device.screenshot()) == "cat"

    @staticmethod
    def _panel_state(screen_or_texts):
        """从**一次**全图 OCR（截图或已扫出的文字列表）判面板状态：
        "cat"=喵喵面板 / "gift"=送礼面板 / None。每轮只 scan 一次、两判定共用
        （全图 OCR 单次 ~2-3s，分开判要跑两遍，实测拖垮轮询导致误报超时）。"""
        texts = (screen_or_texts if isinstance(screen_or_texts, list)
                 else [t[0] for t in ocr.scan(screen_or_texts)])
        if any("旅行吧喵喵" in t for t in texts):
            return "cat"
        if any(k in t for t in texts for k in GIFT_PANEL_KEYWORDS):
            return "gift"
        return None

    @classmethod
    def _cat_panel_open(cls, screen):
        """「旅行吧喵喵」面板是否已打开。"""
        return cls._panel_state(screen) == "cat"

    def _do_feed(self):
        """点「喂猫」→ 等 toast → 关「恭喜获得」结算窗（点弹窗内部）。"""
        self._stage = "点喂猫"
        screen = self.device.screenshot()
        orange = self._feed_btn_orange(screen)
        if orange < FEED_BTN_ORANGE_MIN:
            # 喂完按钮变灰（每天 1 次，两只猫共享）——灰态点击无反应，直接收工
            log.info("「喂猫」按钮呈禁用态（橙色占比 %.2f < %.2f），今天已喂过，收工",
                     orange, FEED_BTN_ORANGE_MIN)
            return True
        log.info("点击「喂猫」@ %s（橙色占比 %.2f）", FEED_BTN_POS, orange)
        self.device.click(*FEED_BTN_POS)
        time.sleep(random.uniform(1.2, 2.0))
        # 等「成功喂猫」toast / 「恭喜获得」结算窗（喂猫成功两者必出其一）
        fed = False
        deadline = time.time() + 8
        while time.time() < deadline:
            self._check_stop()
            screen = self.device.screenshot()
            texts = [t[0] for t in ocr.scan(screen)]
            if any(k in t for t in texts for k in FEED_TOAST_KEYWORDS):
                fed = True
                break
            if any("恭喜获得" in t for t in texts):
                fed = True   # 实测（账号7）：toast 可能被漏检，但「恭喜获得」结算窗必弹
                break
            time.sleep(0.6)
        if fed:
            log.info("喂猫成功（奖励结算窗「恭喜获得」已出现）")
        else:
            self.report_unknown("no_feed_toast",
                                note="点「喂猫」后未见「成功喂猫」提示（按钮是可用态）；"
                                     "若今天已喂过属正常，否则请看截图")
        # 关「恭喜获得」结算窗：**点弹窗内部**（202,420），点面板外会把喵喵面板一起关掉
        for _ in range(3):
            screen = self.device.screenshot()
            if not ocr.contains_text(screen, "恭喜获得", region=REWARD_TITLE_REGION):
                break
            log.info("关闭喂猫「恭喜获得」结算窗（点弹窗内部 %s）", (REWARD_INNER_POS,))
            self.device.click(*REWARD_INNER_POS)
            time.sleep(random.uniform(1.2, 1.8))
        return True

    @staticmethod
    def _feed_btn_orange(screen):
        """「喂猫」按钮的橙色像素占比（可用态≈0.5+，喂完变灰≈0）。"""
        x, y, w, h = FEED_BTN_REGION
        c = screen[y:y + h, x:x + w].astype(int)
        b, g, r = c[:, :, 0], c[:, :, 1], c[:, :, 2]
        return float(((r > 180) & (g > 120) & (b < 130)).mean())

    def _close_cat_panel(self):
        """关「旅行吧喵喵」面板：点右上角金色装饰花（就是关闭按钮，ESC 关不掉）。"""
        for _ in range(3):
            screen = self.device.screenshot()
            if not self._cat_panel_open(screen):
                return
            log.info("关闭喵喵面板：点右上角装饰花 @ %s", (CAT_PANEL_CLOSE_POS,))
            self.device.click(*CAT_PANEL_CLOSE_POS)
            time.sleep(random.uniform(1.2, 1.8))
        if self._cat_panel_open(self.device.screenshot()):
            self.report_unknown("cat_panel_close_failed",
                                note="点装饰花 %s 三次后「旅行吧喵喵」面板仍在"
                                     % (CAT_PANEL_CLOSE_POS,))
        else:
            log.info("喵喵面板已关闭")

    # ---------- 送礼面板 ----------

    def _handle_gift_panel(self):
        """处理「将探索奖励分享给一同付出的好友吧」送礼面板：勾满 ×/5 → 送礼。

        勾选复选框列 x≈326；勾后 OCR「已选择：x/5」验证递增，不增重点一次；
        可见行勾完不够就列表内上滑找更多。送礼后关「成功送礼」确认窗（点窗内
        空白），再用掉右缘「灵宠旅行礼物」道具卡（复用基类 dismiss_item_cards）。
        """
        if not self._gift_panel_open(self.device.screenshot()):
            return
        self._stage = "送礼面板勾选好友"
        log.info("出现送礼面板（喂猫前必经环节），开始勾选好友")
        tried = []                                     # 已勾过的行 y（近邻去重）
        scrolls = 0
        target = None
        for _ in range(30):
            self._check_stop()
            screen = self.device.screenshot()
            cur = self._gift_selected(screen)
            if cur:
                target = cur[1]
                if cur[0] >= cur[1]:
                    log.info("好友已勾满 %d/%d", cur[0], cur[1])
                    break
            ys = [y for y in self._gift_rows(screen)
                  if all(abs(y - t) > 8 for t in tried)]
            if not ys:
                scrolls += 1
                if scrolls > GIFT_SCROLL_MAX:
                    self.report_unknown("gift_rows_exhausted",
                                        note="列表上滑 %d 次仍凑不齐 %s 个好友（可能好友不足）"
                                             % (GIFT_SCROLL_MAX, target))
                    break
                log.info("可见好友行已勾完（%d/%s），上滑列表找更多", 
                         cur[0] if cur else 0, target)
                self.device.drag(*GIFT_SCROLL_DRAG[0], *GIFT_SCROLL_DRAG[1], steps=12)
                time.sleep(random.uniform(1.2, 1.8))
                continue
            y = ys[0]
            tried.append(y)
            prev = cur[0] if cur else -1
            log.info("勾选好友行 (%d, %d)", GIFT_CB_X, y)
            self.device.click(GIFT_CB_X, y)
            time.sleep(random.uniform(1.0, 1.5))
            cur2 = self._gift_selected(self.device.screenshot())
            if cur2 and cur2[0] == prev:
                log.info("勾选未生效，重点一次")
                self.device.click(GIFT_CB_X, y)
                time.sleep(random.uniform(1.0, 1.5))
        # 点「送 礼」
        hit = ocr.find_text(self.device.screenshot(), "送礼", min_similarity=0.8)
        pos = (hit[0], hit[1]) if hit else GIFT_SEND_POS
        log.info("点击「送礼」@ %s", (pos,))
        self.device.click(*pos)
        time.sleep(random.uniform(2.0, 3.0))
        # 「成功送礼」确认窗（"…点击空白处关闭"在窗内）→ 点窗内空白关掉
        for _ in range(3):
            screen = self.device.screenshot()
            hit = ocr.find_text(screen, "点击空白处关闭", min_similarity=0.8)
            if hit:
                # 点文字正上方 45px = 弹窗内部空白（点窗外会把送礼/喵喵面板一起关掉）
                log.info("关闭「成功送礼」确认窗 @ (%d, %d)", 202, hit[1] - 45)
                self.device.click(202, hit[1] - 45)
            elif ocr.contains_text(screen, "成功送礼"):
                self.device.click(202, 420)
            else:
                break
            time.sleep(random.uniform(1.2, 1.8))
        # 右缘出现「灵宠旅行礼物」+「使用」→ 用掉（得 60 家具物料），顺带关「恭喜获得」
        self.dismiss_item_cards()

    @classmethod
    def _gift_panel_open(cls, screen):
        """送礼面板是否已打开。"""
        return cls._panel_state(screen) == "gift"

    @staticmethod
    def _gift_selected(screen):
        """OCR 读「已选择：x/5」→ (x, 5)；读不到返回 None。"""
        for t, x, y, *_ in ocr.scan(screen):
            m = re.search(r"(\d+)\s*/\s*(\d+)", t)
            if m and ("已选择" in t or y > 480):
                return int(m.group(1)), int(m.group(2))
        return None

    @staticmethod
    def _gift_rows(screen):
        """好友行 y 坐标：玩家名字列（x 100-180）内的文字行（避开表头与「已选择」行）。"""
        ys = []
        for t, x, y, *_ in ocr.scan(screen):
            if (GIFT_ROW_X_RANGE[0] <= x <= GIFT_ROW_X_RANGE[1]
                    and GIFT_ROW_Y_RANGE[0] <= y <= GIFT_ROW_Y_RANGE[1]):
                ys.append(y)
        return sorted(set(ys))
