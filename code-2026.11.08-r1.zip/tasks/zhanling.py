import logging
import random
import re
import time

from core import ocr
from tasks.base import MAIN_ANCHOR_REGIONS, Task
from tasks.yueka import (ACT_NAV_POS, ACT_NAV_POS_4TAB, TAB_REGION,
                         ZHOULI_PAGE_REGION, ZHOULI_TAB_POS)

log = logging.getLogger("task.zhanling")

# 以下均为 405x720 客户区坐标（2026-10-09 实机标定）
HUODONG_REGION = MAIN_ANCHOR_REGIONS["活动"]  # 主界面左侧"活动"图标锚点（与全项目共用）
ZHANLING_TAB_REGION = (150, 680, 130, 40)    # 活动面板底部"战令"页签
ZHANLING_MARK_REGION = (0, 0, 405, 260)      # 战令页标志区（"重置时间"/"荣功令"/"殊勋令"）
ITEMS_REGION = (0, 240, 405, 430)            # 物品列表区（扫"可领取"标记）
PANEL_NAV_REGION = (0, 680, 405, 40)         # 活动面板底部导航（福赠/战令/活动/珍藏），确认面板已打开
ICON_OFFSET_Y = 26                           # "可领取"标签 → 物品图标中心的 y 偏移（点标签本身无效，实测）

# "可领取"标记是绿色美术字，OCR 可能把"领"读成"镇"等（实测"可镇取"），宽松匹配。
# 判定规则（战令/周礼通用，用户确认）：绿色√=已领取、加锁=不可领取、
# "可领取"标签=可领取——只认标签，√ 和锁天然跳过
CLAIM_LABEL_RE = re.compile(r"^可.取$")


class Zhanling(Task):
    """领战令+周礼（收尾任务）：主界面"活动"打开面板后**不切出去**，依次在
    战令页和周礼页（福赠）各领一轮"可领取"物品，最后统一回主界面。

    战令和周礼同在活动面板里（用户确认），点一次活动、切页签一起领：
    1. 战令页：判定"重置时间/荣功令/殊勋令"任一出现即在战令页，否则点底部
       "战令"页签（页签是开关，乱点会切走）；
    2. 点底部导航"福赠"图标（ACT_NAV_POS，2026-10-11 晚标定 ~213,690；偶发
       4 页签布局时左移一格用 ACT_NAV_POS_4TAB）切到福赠页，再确认/点击
       "周礼"页签（周礼页标志是"累计活跃度"文字）；
    3. 两页共用同一套领取逻辑：扫所有"可领取"标记，点标签下方约 26px 的
       物品图标本体（点标签本身无效），关"恭喜获得"弹窗后重扫直到没有。

    细节（实测）：面板记住上次停留页签，所以两页都要"先判定再决定点不点"；
    不需要翻页——进页面扫一轮，没有可领取就是没有了；右侧付费轨未解锁是
    锁图标、没有可领取标记，天然跳过。
    """

    name = "zhanling"
    title = "领战令周礼"
    category = "收尾任务"

    def _try_once(self):
        self.dismiss_popups()
        # 队伍侧栏没收起时「活动」图标不在原位、点击会被气泡吞掉
        # （2026-10-23 run c7e254 根因：0.959 低分误匹配 + 面板挡界面）
        if self._team_view_open(self.device.screenshot()):
            log.warning("队伍侧栏仍停在队伍视图，先收起再开活动面板")
            self._restore_quest_view()
        if not self._open_panel():
            return False
        claimed = 0
        # 1) 战令页
        if self._ensure_zhanling_page():
            claimed += self._claim_all()
        else:
            log.warning("未能进入战令页，跳过战令领取")
        # 2) 周礼页（同在活动面板，点导航切过去，面板不切出）
        if self._goto_fuzeng() and self._switch_zhouli():
            claimed += self._claim_all()
        else:
            log.warning("未能进入周礼页，跳过周礼领取")
        log.info("战令/周礼奖励%s", f"已领取 {claimed} 个物品" if claimed else "无待领取")
        return True

    def _open_panel(self):
        """点"活动"并**确认面板真的打开了**（底部导航 福赠/战令/珍藏 任一出现）。
        客户端卡顿/休眠后点击可能延迟生效或没点开，不确认就往下走会对空气操作。"""
        for i in range(3):
            if not self._click_activity():
                return False
            deadline = time.time() + 8
            while time.time() < deadline:
                texts = ocr.dump_texts(self.device.screenshot(), PANEL_NAV_REGION)
                if any(t in ("福赠", "战令", "珍藏", "活动") for t in texts):
                    return True
                time.sleep(0.6)
            log.warning("活动面板未确认打开，重试点击 (%d/3)", i + 1)
        log.warning("活动面板多次点击未打开")
        return False

    def _click_activity(self):
        """点主界面左列「活动」图标：模板优先，失败时两级兜底。

        2026-10-13 实测（5 号）：活动图标带红点/限定角标时模板 CCOEFF 二次
        验证被拒（0.439 < 0.45，on_main_screen 注释早有记载的同款坑），两次
        "未找到模板: 活动" → 整任务异常。兜底：
        ① OCR 左列图标下方「活动」文字标签；
        ② 固定点 (30, 175)（= MAIN_SCREEN_ANCHORS["活动"]；活动恒为左列第一个，
        新图标"坊市"插在玩法/商城之间不影响顶部）。
        只在主界面才兜底（队伍状态左列会变，盲点会点中别的图标）；点错也无害
        ——调用方会确认面板是否真的打开，没打开会重试/放弃。

        2026-10-23：模板阈值 0.88 → **0.97**。run c7e254 实测画面中部浮着
        「篝火宴令」气泡时，气泡图案在 0.959/0.960 分命中「活动」模板 → 点弹
        的是活动气泡而非活动面板，两次尝试全灭。0.97 拒掉这类低分误匹配后
        走 OCR 文字标签 / 固定点兜底，反而更稳。"""
        if self.matcher.find_and_click(self.device, "活动", timeout=8,
                                       region=HUODONG_REGION,
                                       threshold=0.97, ccoeff_floor=0.45):
            return True
        screen = self.device.screenshot()
        if not self.on_main_screen(screen):
            log.warning("活动图标模板未命中且不在主界面，不兜底盲点")
            return False
        hit = ocr.find_text(screen, "活动", region=(0, 140, 90, 80),
                            min_score=0.4, min_similarity=0.8)
        if hit:
            log.info("活动图标模板未命中（疑似红点角标遮挡），OCR 定位「活动」"
                     "@ (%d, %d) 点击", hit[0], hit[1])
            self.device.click(hit[0], hit[1])
            return True
        log.info("活动图标模板与 OCR 均未命中，按固定点 (30, 175) 点击")
        self.device.click(30, 175)
        return True

    # ---- 战令页 ----

    def _ensure_zhanling_page(self, timeout=12):
        """判定/切换到战令页：面板顶部出现"重置时间"/"荣功令"/"殊勋令"即已
        在战令页；否则点底部"战令"页签。"""
        deadline = time.time() + timeout
        while time.time() < deadline:
            screen = self.device.screenshot()
            texts = ocr.dump_texts(screen, ZHANLING_MARK_REGION)
            if any(("重置时间" in t or "荣功令" in t or "殊勋令" in t)
                   for t in texts):
                return True
            hit = ocr.find_text(screen, "战令", region=ZHANLING_TAB_REGION,
                                min_similarity=1.0)
            if hit:
                log.info("点击 [战令页签] @ (%d, %d)", hit[0], hit[1])
                self.device.click(hit[0], hit[1])
            time.sleep(random.uniform(0.8, 1.2))
        return False

    # ---- 周礼页 ----

    def _goto_fuzeng(self, timeout=10):
        """切到福赠（福利）页：等面板底部出现"周礼/月卡"页签，没有则点底部
        导航"福赠"图标（3 页签位置 → 4 页签位置交替，见 yueka.ACT_NAV_POS
        注释；底部聊天气泡会盖住导航文字，OCR 定位不可靠，用固定坐标）。
        活动面板此刻是开着的（战令页）。"""
        deadline = time.time() + timeout
        tries = 0
        while time.time() < deadline:
            texts = ocr.dump_texts(self.device.screenshot(), TAB_REGION)
            if any("周礼" in t or "月卡" in t for t in texts):
                return True
            pos = ACT_NAV_POS if tries % 2 == 0 else ACT_NAV_POS_4TAB
            log.info("点底部导航 [福赠] @ %s 切到周礼/月卡页", pos)
            self.device.click(*pos)
            tries += 1
            time.sleep(random.uniform(1.0, 1.5))
        log.warning("福赠页未出现")
        return False

    def _switch_zhouli(self, timeout=8):
        """点"周礼"页签并确认进入（周礼页有"累计活跃度"文字）。"""
        deadline = time.time() + timeout
        clicked = False
        while time.time() < deadline:
            screen = self.device.screenshot()
            if ocr.find_text(screen, "累计活跃度", region=ZHOULI_PAGE_REGION,
                             min_similarity=1.0):
                return True
            if not clicked:
                hit = ocr.find_text(screen, "周礼", region=TAB_REGION,
                                    min_similarity=1.0)
                pos = (hit[0], hit[1]) if hit else ZHOULI_TAB_POS
                log.info("点击 [周礼页签] @ (%d, %d)", *pos)
                self.device.click(*pos)
                clicked = True
            time.sleep(random.uniform(0.8, 1.2))
        log.warning("未能进入周礼页")
        return False

    # ---- 通用领取 ----

    def _claim_all(self):
        """扫当前页所有"可领取"标记逐个领取（点标签下方 26px 的物品图标，
        关"恭喜获得"弹窗后重扫），返回领取个数。"""
        claimed = 0
        hits = self._find_claimables()
        while hits:
            self._check_stop()
            x, y = hits.pop(0)
            log.info("点击可领取物品 @ (%d, %d)", x, y + ICON_OFFSET_Y)
            self.device.click(x, y + ICON_OFFSET_Y)
            self.close_reward_popup(timeout=6)
            time.sleep(random.uniform(0.8, 1.2))
            claimed += 1
            hits = self._find_claimables()  # 领取后列表刷新，重新扫
        return claimed

    def _find_claimables(self):
        """当前视野内所有"可领取"标记，返回按 y 排序的 (x, y) 列表。"""
        texts = ocr.scan(self.device.screenshot(), region=ITEMS_REGION,
                         min_score=0.6)
        hits = [(cx, cy) for t, cx, cy, _ in texts
                if CLAIM_LABEL_RE.match(t.strip())]
        return sorted(hits, key=lambda p: p[1])
