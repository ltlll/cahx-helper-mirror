import logging
import random
import time

from core import ocr
from tasks.base import BATTLE_MARK_REGION, Task

log = logging.getLogger("task.xunbao")

# 以下均为 405x720 客户区坐标
LUOPAN_NODE_POS = (110, 545)              # 玩法地图上的寻宝罗盘节点（位置固定）
GO_BTN_REGION = (140, 455, 130, 55)       # 寻宝罗盘详情卡的"前往"按钮
CARD_DONE_REGION = (140, 425, 130, 60)    # 详情卡底部"已完成"（今日挖完时无"前往"；地图左侧灯笼的"已完成"标签不在此区域）
ENTRY_SCAN_REGION = (260, 140, 145, 170)  # 任务列表"寻宝罗盘"进度条目扫描区（条目可能粘在第 2/3 行；向下扩到提示弹窗的"可领取"用于区分）
CLAIM_GO_REGION = (250, 280, 155, 70)     # 提示卡「前往」按钮（「取消」@ (298,306) 右侧同排，2026-10-23 标定待实机复核）

# 「奖励加成」挡路（2026-10-31 实测 7 号，xunbao 连续两次失败的真因）：
# 点详情卡「前往」后**不会直接启动寻宝链**，而是先弹一张提示卡
# 「寻宝罗盘有奖励加成尚未领取，先去领取加成效果吧 [前往领取]」（(204,446)）→
# 点它进「奖励加成 助力成长」面板，两行「领取」（(337,320)/(337,484)）→
# ESC 回到玩法面板，再点「前往」才真正开始。（当天 7 号 0/10 一次没挖。）
# 老逻辑不认这张卡：dismiss_popups 的通用提示卡处理只点「取消」→ 链永远启动
# 不了，60 秒后判「寻宝链未启动」，AI 兜底也只能点任务/可领取乱撞。
BONUS_GO_TEXT = "前往领取"
BONUS_PANEL_TITLE = ("奖励加成", "助力成长")
BONUS_CLAIM_REGION = (250, 240, 155, 300)


class Xunbao(Task):
    """寻宝罗盘：主界面"玩法" → 寻宝罗盘节点 → 详情卡点"前往" → 寻宝链全自动
    （自动寻路+自动挖宝，中途无需任何点击）→ 任务列表里"寻宝罗盘"进度条目
    消失即完成（无结束画面）。

    节点点不出"前往"说明今日已挖完，跳过不算失败。
    """

    name = "xunbao"
    title = "寻宝罗盘"

    CHAIN_TIMEOUT = 1500  # 寻宝链最长等待（秒）

    def _try_once(self):
        # 宝物提示卡可能在任务开始前就挂着（上一轮中断残留）：先领再干活，
        # 否则 dismiss_popups 的通用提示卡处理会点「取消」把领取机会关掉
        self._claim_luopan_card(self.device.screenshot())
        self.dismiss_popups()
        self._restore_quest_view()
        # 寻宝链已在进行中（上次中断后继续跑/手动开过）：直接等它结束
        if self._entry_visible(self.device.screenshot()):
            log.info("寻宝链已在进行中，直接等待完成")
            return self._wait_chain_done()
        if not self.open_wanfa():
            return False
        hit = None
        done = False
        for i in range(2):
            self.device.click(*LUOPAN_NODE_POS)
            hit, done = self._wait_card()
            if hit or done:
                break
            log.warning("寻宝罗盘详情卡未弹出，重试节点点击 (%d/2)", i + 1)
        if done:
            log.info("寻宝罗盘今日已挖完（详情卡显示已完成），跳过")
            return True
        if not hit:
            log.info("寻宝罗盘无“前往”（今日已挖完），跳过")
            return True
        log.info("点击 [前往] @ (%d, %d)，启动寻宝链", hit[0], hit[1])
        self.device.click(hit[0], hit[1])
        time.sleep(random.uniform(2.0, 3.0))
        return self._wait_chain_done()

    def _wait_card(self, timeout=8):
        """等详情卡弹出：有"前往"返回 (pos, False)；显示"已完成"返回 (None, True)。"""
        deadline = time.time() + timeout
        while time.time() < deadline:
            screen = self.device.screenshot()
            hit = ocr.find_text(screen, "前往", region=GO_BTN_REGION,
                                min_similarity=1.0)
            if hit:
                return hit, False
            if ocr.find_text(screen, "已完成", region=CARD_DONE_REGION,
                             min_similarity=1.0):
                return None, True
            time.sleep(0.6)
        return None, False

    def _entry_visible(self, screen):
        # 进度条目文字是"寻宝罗盘 7/10"，计数可能和标题粘成一个文本框
        # （"寻宝罗盘7/10" vs "寻宝罗盘" 相似度仅 0.73），必须用包含匹配
        return self._find_entry(screen) is not None

    # ---- 宝物提示卡（2026-10-23 根因修复） ----
    # run c7e254 实测：5 号链进行中弹出「寻宝罗盘 可领取 [取消|前往]」提示卡，
    # dismiss_popups 的通用提示卡处理点了「取消」（它的注释假设"点取消不影
    # 响任务本身"——对寻宝**不成立**：卡关了、奖励没领、进度条目也没了），
    # 13 秒后"条目消失 15s"被当成完成 → 寻宝实际没做完。寻宝流程里这张卡
    # 必须抢先点「前往」（去挖宝点领取，链会自己接上），绝不能落到通用取消。

    def _claim_luopan_card(self, screen):
        """「寻宝罗盘 可领取」提示卡在场时点「前往」领取，返回 True=已处理。"""
        texts = ocr.scan(screen, ENTRY_SCAN_REGION, min_score=0.5)
        for t, cx, cy, _ in texts:
            if "寻宝罗盘" not in t:
                continue
            if not any("可领取" in t2 and abs(x2 - cx) < 60 and 5 < y2 - cy < 45
                       for t2, x2, y2, _ in texts):
                continue
            hit = ocr.find_text(screen, "前往", region=CLAIM_GO_REGION,
                                min_similarity=0.8)
            if not hit:
                log.warning("寻宝藏宝提示卡在场但没找到「前往」按钮，不乱点")
                self.report_unknown("claim_card_no_go", screen,
                                    note="提示卡有「可领取」但 CLAIM_GO_REGION 没扫到前往")
                return False
            log.info("寻宝藏宝提示卡在场，点击 [前往] 领取 @ (%d, %d)（绝不能点取消）",
                     hit[0], hit[1])
            self.device.click(hit[0], hit[1])
            time.sleep(random.uniform(1.5, 2.2))
            return True
        return False

    @staticmethod
    def _find_entry(screen):
        """找任务列表里的寻宝进度条目，返回 (cx, cy, 归一化文本)；找不到返回 None。

        主界面"寻宝罗盘 可领取 [取消|前往]"提示弹窗的标题（约 y=248）也会落入
        条目区域，未开启寻宝时会被误判成进度条目：其正下方紧跟"可领取"，
        进度条目下方是计数或其它条目，以此排除。
        """
        texts = ocr.scan(screen, ENTRY_SCAN_REGION, min_score=0.5)
        for text, cx, cy, _ in texts:
            if "寻宝罗盘" not in text or cy >= 255:
                continue
            if any("可领取" in t and abs(x - cx) < 60 and 5 < y - cy < 45
                   for t, x, y, _ in texts):
                continue  # 提示弹窗标题，不是进度条目
            return cx, cy, text.replace(" ", "")
        return None

    def _claim_bonus(self, screen):
        """处理「奖励加成尚未领取」挡路：提示卡点「前往领取」→ 面板逐个
        「领取」→ ESC 回玩法面板。返回 True=本帧动过手（调用方 continue）。

        必须在 dismiss_popups **之前**判：通用提示卡处理会点「取消」，
        等于把"去领加成"这一步关掉，链照样启动不了。
        """
        texts = ocr.scan(screen, (60, 380, 285, 120), min_score=0.5)
        go = None
        for t, cx, cy, _ in texts:
            if BONUS_GO_TEXT in t:
                go = (cx, cy)
                break
        if go:
            log.info("寻宝前弹「奖励加成尚未领取」提示卡，点 [前往领取] @ (%d, %d)",
                     go[0], go[1])
            self.device.click(*go)
            time.sleep(random.uniform(1.5, 2.2))
            return True
        # 加成面板：标题含「奖励加成/助力成长」→ 逐个点「领取」，最多 4 个
        head = [t for t, *_ in ocr.scan(screen, (40, 60, 330, 200), min_score=0.5)]
        if not any(any(k in t for k in BONUS_PANEL_TITLE) for t in head):
            return False
        btns = [(cx, cy) for t, cx, cy, _ in
                ocr.scan(screen, BONUS_CLAIM_REGION, min_score=0.5)
                if "领取" in t and "已" not in t]
        for i, pos in enumerate(btns[:4]):
            log.info("奖励加成面板：点 [领取] @ (%d, %d)（第 %d 个）",
                     pos[0], pos[1], i + 1)
            self.device.click(*pos)
            time.sleep(random.uniform(1.2, 1.8))
        log.info("奖励加成面板领取完毕，ESC 回玩法面板")
        self.device.press_esc()
        time.sleep(random.uniform(1.2, 1.8))
        return True

    def _wait_chain_done(self):
        """寻宝链全自动：先等进度条目出现（链已启动），再等它消失（链结束）。

        跨图传送/战斗画面里任务列表本来就不可见，所以只在主界面状态下
        累计"条目消失"，且要持续消失 15 秒才算完成（防传送加载误判）。
        链可能卡死（寻路被打断等）：进度文字 10 秒没变化就点一下进度条目催动。
        链结束后也可能被"收益"结算等遮挡面板卡住（实测 10/10 后卡收益界面，
        既无条目也非主界面，纯静默等待卡死 10 分钟）：该状态持续 20 秒
        （排除战斗/过场）就按 ESC 关面板，首次留存 report_unknown 截图。"""
        deadline = time.time() + 60
        start = time.time()
        reclicked = False
        bonus_retries = 0
        while time.time() < deadline:
            self._check_stop()  # 长循环：响应 GUI 停止
            screen = self.device.screenshot()
            # 「奖励加成尚未领取」挡路要在 dismiss_popups 之前处理（后者会点取消）
            if bonus_retries < 3 and self._claim_bonus(screen):
                bonus_retries += 1
                # 领完加成后详情卡已关，重新点节点 → 前往，链才会真正启动。
                # ⚠️ 节点点击后卡片有展开动画，**一次没弹出来要再点**：实测
                # （2026-10-31 7 号）领完加成的下一拍只点一次节点，前往读不到，
                # 白白等到 60 秒判"未启动"，第 2 次尝试才成功。
                time.sleep(random.uniform(1.5, 2.0))
                again = None
                for attempt in range(3):
                    self.device.click(*LUOPAN_NODE_POS)
                    deadline_card = time.time() + 6
                    while time.time() < deadline_card:
                        again = ocr.find_text(self.device.screenshot(), "前往",
                                              region=GO_BTN_REGION,
                                              min_similarity=0.9)
                        if again:
                            break
                        time.sleep(0.6)
                    if again:
                        break
                    log.info("领完加成后详情卡未弹出，重点罗盘节点 (%d/3)", attempt + 1)
                if again:
                    log.info("领完加成，重新点击 [前往] @ (%d, %d)",
                             again[0], again[1])
                    self.device.click(*again)
                    time.sleep(random.uniform(2.0, 2.6))
                deadline += 25          # 这一圈是额外的，给足时间
                start = time.time()
                reclicked = False
                continue
            if self.dismiss_popups(screen):
                continue
            self._restore_quest_view()
            if self._entry_visible(screen):
                break
            # 「前往」可能被残留面板/弹窗吞掉（2026-10-21 4 号实测：妖灵渡口
            # 残留 + 孤品订单弹窗刚被 AI 清掉，点了前往链没启动，两次尝试
            # 各白等 70 秒）：30 秒条目未出现且详情卡还开着就再点一次「前往」；
            # 卡片已关说明链在启动中（寻路耗时），继续等。
            if not reclicked and time.time() - start > 30:
                reclicked = True
                hit = ocr.find_text(screen, "前往", region=GO_BTN_REGION,
                                    min_similarity=0.8)
                if hit:
                    log.info("30 秒进度条目未出现且详情卡仍开着，"
                             "重试点击 [前往] @ (%d, %d)", hit[0], hit[1])
                    self.device.click(hit[0], hit[1])
            time.sleep(2)
        else:
            # 「前往」点了但条目一直不出现：两种可能——今日已挖完（详情卡仍显示
            # 「前往」，点进去被弹回，条目永远不会出现），或点击被吞。
            # **不能直接判负**：先读玩法面板进度做正向证据（2026-10-31 run
            # e5ee47，7 号两次尝试各白耗 ~100 秒，AI 兜底又连点三次 give_up）。
            prog = self.read_activity_progress(["xunbao"]).get("xunbao")
            if prog == "done" or (isinstance(prog, tuple) and prog[0] >= prog[1]):
                log.info("进度条目未出现，但玩法面板进度已满（%s），按今日已挖完处理",
                         prog if isinstance(prog, str) else "%d/%d" % prog)
                return True
            log.warning("寻宝链未启动（进度条目未出现，玩法面板进度 %s）", prog)
            return False
        log.info("寻宝链进行中，等待完成...")
        deadline = time.time() + self.CHAIN_TIMEOUT
        gone_since = None
        blocked_since = None
        reported = False
        progress_reported = False
        resumed = False
        last_text, last_change = None, time.time()
        while time.time() < deadline:
            self._check_stop()  # 长循环：响应 GUI 停止
            screen = self.device.screenshot()
            # 宝物提示卡优先于通用弹窗清理（通用处理会点「取消」把领取关掉）
            if self._claim_luopan_card(screen):
                gone_since = None  # 领取导航会刷新条目状态，重算"消失"计时
                continue
            if self.dismiss_popups(screen):
                continue
            entry = self._find_entry(screen)
            if entry:
                gone_since = None
                blocked_since = None
                cx, cy, text = entry
                if text != last_text:
                    last_text, last_change = text, time.time()
                elif time.time() - last_change > 10:
                    log.info("寻宝进度 10 秒未变化（%s），点击进度条目催动", text)
                    self.device.click(cx, cy)
                    last_change = time.time()  # 重置计时，防连点
            elif self.on_main_screen(screen):
                blocked_since = None
                if gone_since is None:
                    gone_since = time.time()
                elif time.time() - gone_since > 15:
                    # 完成判定加正向证据（捉鬼那套逻辑，2026-10-23）：
                    # 玩法面板寻宝进度 10/10（或"已完成"）才算真完成。
                    # 旧判据"条目消失 15s"在提示卡被误点取消时也会成立
                    # （run c7e254，5 号寻宝假完成），必须玩法面板复核。
                    prog = self.read_activity_progress(["xunbao"]).get("xunbao")
                    if prog == "done" or (isinstance(prog, tuple)
                                          and prog[0] >= prog[1]):
                        log.info("寻宝罗盘完成（进度条目已消失，玩法面板进度：%s）",
                                 prog if isinstance(prog, str)
                                 else "%d/%d" % prog)
                        return True
                    if prog is None:
                        # 进度读不到（面板改版/OCR 失误）：退回旧判据，但存图
                        # 待值守复核——不许静默。
                        if not progress_reported:
                            self.report_unknown(
                                "progress_unverified",
                                note="条目消失判完成时玩法面板寻宝进度读不到（待校准）")
                            progress_reported = True
                        log.warning("玩法面板寻宝进度读不到，按旧判据"
                                    "（条目消失 15s）算完成——已存图待复核")
                        return True
                    log.warning("寻宝条目已消失但玩法面板进度 %d/%d 未满，"
                                "继续等待（可能在等领取/链未走完）", *prog)
                    if resumed:
                        log.warning("条目消失+进度未满已复现，链大概率已断，"
                                    "判失败交任务级重试（重新从玩法地图进入）")
                        return False
                    resumed = True
                    gone_since = None  # 不算完成，回到等待循环
            elif ocr.contains_text(screen, "战况", region=BATTLE_MARK_REGION):
                blocked_since = None  # 挖宝战斗：链在正常推进，等它打完
            else:
                # 既无条目也非主界面/战斗：传送过场（短），或被"收益"结算
                # 等遮挡面板卡住（长）：持续 20 秒按 ESC 关面板恢复
                if blocked_since is None:
                    blocked_since = time.time()
                elif time.time() - blocked_since > 20:
                    log.warning("既无进度条目也非主界面已持续 20 秒，"
                                "按 ESC 关遮挡面板")
                    if not reported:
                        self.report_unknown("blocked_screen", screen,
                                            note="寻宝链等待中既无条目也非主界面")
                        reported = True
                    self.device.press_esc()
                    blocked_since = time.time()  # 重置计时，每次尝试间隔 20 秒
            time.sleep(3)
        log.warning("等待寻宝链结束超时")
        return False
