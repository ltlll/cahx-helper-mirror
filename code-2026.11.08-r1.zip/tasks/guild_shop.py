import logging
import random
import time

from core import ocr
from tasks.base import Task

log = logging.getLogger("task.guild_shop")

# 以下均为 405x720 客户区坐标
SHOP_BUILDING_POS = (280, 380)          # 帮会地图上的商店建筑（位置固定）
SHOP_MARK_REGION = (100, 15, 210, 60)   # "珍宝商店"标题横幅（模板匹配，固定 UI 不用 OCR）
SHOP_GRID_REGION = (20, 160, 365, 500)  # 商品网格区域（全扫描贡图标，商品位置每天/每号都变）
BUY_REGION = (230, 460, 130, 55)        # 购买确认弹窗"购买"按钮
PRICE_CLICK_OFFSET = 27                 # 贡图标在价格标签左侧，点图标右侧的标签中间


class GuildShop(Task):
    """帮会商店：帮会 → 活动页 → 商店建筑 → 珍宝商店里挨个购买所有
    以帮贡（蓝色贡图标）标价的商品 → 返回主界面。

    商品位置每天、每个号都不一样，不能按固定格子点：
    用 Matcher.find_all 全网格扫描"帮贡图标"模板定位所有贡价商品。
    商品图标上盖"售罄"章后价格标签仍在，按图标位置去重防止重复点；
    点价格标签没弹购买确认 = 已售罄/不可买，跳过。
    """

    name = "guild_shop"
    title = "帮会商店"
    category = "帮会任务"

    def _try_once(self):
        r = self.enter_guild_activity()
        if r == "no_guild":
            return True
        if not r:
            return False
        if not self._open_shop():
            return False
        self._buy_all_gong()
        self.exit_panel_to_home()
        return True

    def _open_shop(self, timeout=8):
        """点商店建筑打开珍宝商店。点击可能被吞/加载慢，没开就再点，最多 3 次。"""
        for i in range(3):
            self.device.click(*SHOP_BUILDING_POS)
            deadline = time.time() + timeout
            while time.time() < deadline:
                if self.matcher.find(self.device.screenshot(), "珍宝商店",
                                     region=SHOP_MARK_REGION, threshold=0.8):
                    log.info("已进入珍宝商店")
                    return True
                time.sleep(0.6)
            log.warning("商店未打开，重试点建筑 (%d/3)", i + 1)
        return False

    def _buy_all_gong(self, max_buys=12):
        """扫描全部贡价商品，逐个点价格标签 → 购买确认弹窗点"购买"。"""
        bought = []  # 已点过的图标位置（售罄后价格标签仍在，按位置去重）
        for _ in range(max_buys):
            screen = self.device.screenshot()
            hits = self.matcher.find_all(screen, "帮贡图标",
                                         region=SHOP_GRID_REGION, threshold=0.85)
            todo = [(x, y) for x, y, _ in hits
                    if not any(abs(x - bx) < 30 and abs(y - by) < 30 for bx, by in bought)]
            if not todo:
                log.info("贡价商品已全部处理完")
                return
            x, y = todo[0]
            log.info("点击贡价商品价格标签 @ (%d, %d)", x + PRICE_CLICK_OFFSET, y)
            self.device.click(x + PRICE_CLICK_OFFSET, y)
            bought.append((x, y))
            # 等购买确认弹窗（售罄的商品点了不会弹）
            hit = None
            for _ in range(6):
                time.sleep(0.7)
                hit = ocr.find_text(self.device.screenshot(), "购买",
                                    region=BUY_REGION, min_similarity=1.0)
                if hit:
                    break
            if not hit:
                log.info("未弹出购买确认（已售罄？），跳过该商品")
                continue
            log.info("点击 [购买] @ (%d, %d)", hit[0], hit[1])
            self.device.click(hit[0], hit[1])
            time.sleep(random.uniform(1.5, 2.2))
            # 正常买完弹窗自动关；没关说明买不了（帮贡不足等），停买关窗
            if ocr.find_text(self.device.screenshot(), "购买",
                             region=BUY_REGION, min_similarity=1.0):
                log.warning("购买后弹窗未关闭（帮贡不足？），停止购买")
                self.device.press_esc()
                return
        log.warning("购买次数达到上限")
