import logging
import random
import re
import time

from core import ocr, teamup
from tasks.base import Task, TaskSkipped

log = logging.getLogger("task.zhongkui")

# 以下均为 405x720 客户区坐标（按实操记录标定）
ZHONGKUI_NODE_POS = (195, 235)            # 玩法地图上的钟馗捉鬼节点（位置固定）
GO_REGION = (140, 455, 130, 55)           # 钟馗捉鬼详情卡的"前往"按钮
REMAIN_REGION = (140, 545, 150, 45)       # NPC 面板"今日剩余：n次"
ACCEPT_REGION = (140, 565, 150, 60)       # NPC 面板"接受任务"
BATTLE_ROUND_REGION = (150, 0, 130, 40)   # 战斗画面顶部"第X回合"
BATTLE_AUTO_POS = (368, 683)              # 战斗右下角"自动"
CHAIN_REGION = (60, 80, 285, 520)         # 链中各类提示（恭喜完成5次/10次、前往继续）
PROGRESS_REGION = (260, 100, 145, 160)    # 追踪面板"钟馗捉鬼n/5"进度条目（链卡死时点它催动）
CLOSE_REGION = (140, 520, 130, 70)        # 奖励总览"关闭"按钮

# 玩法地图今日进度（用户规则 2026-10-22：**判定捉鬼是否打完，唯一可信判据是
# 玩法地图钟馗捉鬼节点下方显示的 n/10**——2026-10-22 实测 6 号只打了 5/10，
# 第 2 轮 25 秒没等到「接受任务」就按"已打完"收工记完成）。
NODE_TITLE_REGION = (140, 200, 160, 75)   # 节点标题（OCR 把"馗"读成"道"等，
                                          # 还带"荐"角标，用 钟.捉鬼 模糊匹配）
NODE_PROGRESS_DY = 57                     # 进度"n/10"在标题正下方（实测
                                          # 标题(241,242)→进度(199,299)）
WANFA_BACK_POS = (33, 683)                # 玩法地图左下返回箭头（回主界面）

CHAIN_TIMEOUT = 1500      # 10 场连打最长等待（秒）（游戏内链本身限时约 20 分钟）
MEMBER_GIVEUP = 1800      # 队员端等副本结果的最长时长
# 第 2 轮等「接受任务」出现的最长时间（秒）。2026-10-17 从 6 秒改上来：
# 点「前往继续」回 NPC 面板要重新加载，实测同一套流程一次 5s 就到、一次 12s
# 还没到（run f5e7b5 因此只打了 5/10 却按完成上报）。
ACCEPT_WAIT = 25


class Zhongkui(Task):
    """钟馗捉鬼（日常副本，5 人组队）：NPC 接任务自动 5 场连打 ×2 轮。

    前置：zudui 组队成功（team_success=True），否则全队跳过。
    队长端：玩法→**先读节点 n/10（满了直接收工，不点「前往」）**→钟馗捉鬼
    节点→详情卡"前往"→NPC 面板读"今日剩余:n次"（0 次直接收工）→"接受任务"
    →5 场连打（全自动）→"恭喜完成5次"点"前往继续"回 NPC 面板→再"接受任务"
    →5 场连打→"恭喜完成10次"奖励总览点"关闭"。
    队员端：等信号→进战斗点"自动"→等"恭喜完成10次/奖励总览"→点"关闭"。
    队员端永不判失败；赐福令卡一律点 X。
    """

    name = "zhongkui"
    title = "钟馗捉鬼"
    category = "日常副本"

    def _try_once(self):
        coord = teamup.coordinator()
        if not coord.begun:
            log.info("非 GUI 5 开并行模式（协调器未初始化），跳过钟馗捉鬼")
            raise TaskSkipped("协调器未初始化（非 5 开并行模式），钟馗捉鬼未执行")
        if coord.dungeon_result(self.name) is not None:
            # 结果已定（重试尝试短路）：如实回报——成了算成功，败了算失败
            if coord.dungeon_result(self.name) is not True:
                raise TaskSkipped("组队已判负，钟馗捉鬼未执行")
            return True
        # 上个组队副本任务队长端失败后自动改选了队长：先重建队伍
        if coord.reteam_pending():
            self.reteam_if_requested(coord, self.title)
        # 队长按协调器判定（不是账号库静态标记）：自动改选后新队长立即接管
        me_is_captain = (coord.captain_id == self.account.get("id"))
        if coord.team_success is not True:
            log.info("组队未成功，钟馗捉鬼按失败计入小结")
            if me_is_captain:
                coord.dungeon_finish(self.name, False)
            raise TaskSkipped("组队未成功")
        if me_is_captain:
            return self._captain_flow(coord)
        return self._member_flow(coord)

    # ---- 队长端 ----

    def _captain_flow(self, coord):
        entered = self._enter_npc()
        if entered == "done":
            # 正向证据（玩法地图 n/10 满 / NPC 面板「今日剩余 0 次」）：今日已打满
            log.info("今日捉鬼已打满（正向证据确认），直接收工，不发起新轮次")
            coord.dungeon_finish(self.name, True)
            return True
        if entered != "ok":
            log.warning("进钟馗捉鬼面板失败")
            self.captain_fail_finish(coord, "进钟馗捉鬼面板失败")
            return False
        coord.dungeon_start_round(self.name)
        round_ = 0
        reentries = 0            # "没等到接受任务但进度未满"的重进次数（防死循环）
        done_evidence = False    # 是否拿到过"今日已打完"的**正向证据**
        while round_ < 2:
            round_ += 1
            self._check_stop()
            remaining = self._remaining()
            if remaining == 0:
                log.info("今日剩余 0 次，不再挑战")
                done_evidence = True
                break
            hit = self._wait_accept_task(timeout=ACCEPT_WAIT)
            if not hit:
                # 2026-10-22 事故修复：**没等到按钮 ≠ 今日已打完**。去玩法
                # 地图读节点上的今日进度 n/10（用户指定的唯一判据）：
                #   满 → 真打完了，正常收工；
                #   未满 → 还有次数，重进 NPC 面板续打（不消耗轮次）；
                #   读不到 → 进度未知，不许记完成，交给重试/改选。
                prog = self._read_day_progress()
                if prog is not None and prog[0] >= prog[1]:
                    log.info("玩法地图确认今日捉鬼 %d/%d，已打完收工", *prog)
                    done_evidence = True
                    break
                if prog is None:
                    log.warning("第 %d 轮没等到「接受任务」且玩法地图进度读不到，"
                                "按未完成处理交给重试", round_)
                    self.captain_fail_finish(coord, "第 %d 轮接续失败且进度未知"
                                             % round_)
                    return False
                reentries += 1
                if reentries > 1:
                    log.warning("重进 %d 次仍未等到「接受任务」（今日 %d/%d），"
                                "交给重试/改选", reentries, *prog)
                    self.captain_fail_finish(coord, "接续失败（今日 %d/%d）"
                                             % prog)
                    return False
                log.warning("第 %d 轮没等到「接受任务」，但玩法地图显示今日只"
                            "完成 %d/%d——重进面板续打", round_, *prog)
                again = self._enter_npc()
                if again == "done":
                    log.info("重进时确认今日已打满，收工")
                    done_evidence = True
                    break
                if again != "ok":
                    self.captain_fail_finish(coord, "续打时进钟馗捉鬼面板失败")
                    return False
                round_ -= 1   # 不消耗轮次，重等「接受任务」
                continue
            log.info("点击 [接受任务]（第 %d 轮）@ (%d, %d)", round_, hit[0], hit[1])
            self.device.click(hit[0], hit[1])
            outcome = self._run_chain()
            if outcome == "done":
                done_evidence = True
                break
            if outcome == "timeout":
                # 链超时 = 没读到「完成10次/奖励总览」，不是完成证据。
                # 不能在 _run_chain 里当 "done" 返回（旧写法就这么干，等于
                # 超时也记完成），交给下面的终局守卫判定。
                log.warning("第 %d 轮捉鬼链超时结束（未读到完成证据）", round_)
                break
            # "mid"：已点前往继续回到 NPC 面板，进入下一轮
        self._close_summary()
        # 终局守卫（用户规则 2026-10-22）：记完成前必须看玩法地图的实际进度，
        # n/10 没满绝不记完成（链超时也会被 _run_chain 按 "done" 返回，只有
        # 这里能兜住）。
        # 2026-11-02 加严：**读不到进度不再默许完成**（旧注释写着"读不到不
        # 拦截"，12:45 那轮就是这么把"捉鬼其实早打满、却又被拉进新链"记成
        # 成功的）。只有正向证据（链里读到完成10次/奖励总览、NPC 面板剩余 0、
        # 玩法地图 n/10 满）才认。
        prog = self._read_day_progress()
        if prog is not None and prog[0] < prog[1]:
            log.warning("玩法地图显示今日捉鬼只完成 %d/%d，不记完成，"
                        "交给第 2 次尝试/改选", *prog)
            self.captain_fail_finish(coord, "今日进度 %d/%d 未满" % prog)
            return False
        if prog is None and not done_evidence:
            log.warning("玩法地图进度读不到、也没有任何完成证据，不记完成")
            self.captain_fail_finish(coord, "进度未知且无完成证据")
            return False
        if prog is None:
            log.info("玩法地图进度读不到，按链内正向证据记完成")
        coord.dungeon_finish(self.name, True)
        return True

    def _enter_npc(self):
        """玩法 → 钟馗捉鬼节点 → 详情卡"前往" → NPC 面板（有"接受任务"）。

        返回：
        - "ok"   NPC 面板就绪（有「接受任务」）；
        - "done" 今日已打满（正向证据：玩法地图节点 n/10 满，或 NPC 面板
                 「今日剩余 0 次」）；
        - None   进不去（清场/退场景后重试 2 轮仍失败）。

        2026-10-17：入口失败不再"点两下就判负"。实测"没找到「玩法」图标"多为
        主界面残留浮层遮挡、或人还在上一个副本场景里（该场景根本没有左列图标），
        所以失败后先清浮层 + 退特殊场景再重来一遍。

        2026-11-02：**点「前往」之前先读玩法地图节点上的 n/10**。点「前往」会
        把全队拖进一条新的捉鬼任务链（12:45 那轮捉鬼明明 10/10，先点前往 +
        dungeon_start_round 播报"第 1 轮挑战已发起"，13:37 才读到"今日剩余 0 次"
        ——全队已在新链里，5 号追踪挂「钟馗捉鬼 1/5」，随后 3 次玩法找不到 +
        4 次盲点离开才收工）。玩法地图此刻是开着的，这一读不额外花钱。
        """
        for attempt in range(2):
            if attempt:
                log.warning("钟馗捉鬼入口失败，清浮层/退特殊场景后重试（第 %d 次）",
                            attempt + 1)
                self.dismiss_popups()
                self._escape_special_scene()
            if not self.open_wanfa():
                continue
            # ① 进节点前先读今日进度（面板已开）：满了就别点「前往」
            prog = None
            deadline = time.time() + 6
            while prog is None and time.time() < deadline:
                prog = self._day_progress(self.device.screenshot())
                if prog is None:
                    time.sleep(0.8)
            if prog is not None and prog[0] >= prog[1]:
                log.info("玩法地图显示今日捉鬼已 %d/%d，不点「前往」直接收工", *prog)
                self.device.click(*WANFA_BACK_POS)
                time.sleep(random.uniform(1.0, 1.5))
                return "done"
            for i in range(2):
                self.device.click(*ZHONGKUI_NODE_POS)
                hit = self._wait_text("前往", GO_REGION, timeout=8)
                if hit:
                    log.info("点击 [前往] @ (%d, %d)", hit[0], hit[1])
                    self.device.click(hit[0], hit[1])
                    if self._wait_text("接受任务", ACCEPT_REGION, timeout=15):
                        return "ok"
                    # 今日已打完时面板没有"接受任务"：看一眼剩余次数收工
                    if self._remaining() == 0:
                        return "done"
                log.warning("钟馗捉鬼详情卡/NPC 面板未弹出，重试 (%d/2)", i + 1)
        return None

    def _wait_accept_task(self, timeout=ACCEPT_WAIT):
        """等 NPC 面板的「接受任务」出现（第 2 轮接续用）。

        2026-10-17 事故（run f5e7b5 只打了 5/10 却报"完成"）：点「前往继续」
        回 NPC 面板后，旧写法只等 6 秒，没读到按钮就判「今日已打完」收工 →
        第 2 轮 5 场没打成。**"没等到按钮"不等于"今日已打完"**：只有明确读
        到「今日剩余 0 次」才算打完；等待期间顺手点掉挡路的奖励总览 /「前往
        继续」/ 赐福令卡，把面板加载时间给足。
        """
        deadline = time.time() + timeout
        i = 0
        while time.time() < deadline:
            self._check_stop()
            screen = self.device.screenshot()
            hit = ocr.find_text(screen, "接受任务", region=ACCEPT_REGION,
                                min_similarity=1.0)
            if hit:
                return hit
            # 明确证据才收工（每 3 轮读一次，OCR 不便宜）
            if i % 3 == 0 and self._remaining() == 0:
                log.info("今日剩余 0 次（面板明确读到），收工")
                return None
            cleared = False
            for text, region in (("前往继续", CHAIN_REGION), ("关闭", CLOSE_REGION)):
                h = ocr.find_text(screen, text, region=region, min_similarity=1.0)
                if h:
                    log.info("等「接受任务」时点掉挡路浮层 [%s] @ (%d, %d)",
                             text, h[0], h[1])
                    self.device.click(h[0], h[1])
                    cleared = True
                    break
            if not cleared:
                cleared = self._close_fuka_card(screen)
            i += 1
            time.sleep(1.0 if cleared else 1.5)
        return None

    def _remaining(self):
        """NPC 面板"今日剩余：n次"解析；读不出返回 None。"""
        for text in ocr.dump_texts(self.device.screenshot(), REMAIN_REGION):
            m = re.search(r"(\d+)\s*次", text)
            if m:
                return int(m.group(1))
        return None

    @staticmethod
    def _day_progress(screen):
        """玩法地图钟馗捉鬼节点下方的今日进度，返回 (done, total)。

        OCR 把"馗"读成"道/尴"等，节点还带"荐"角标，标题用 钟.捉鬼 模糊
        匹配；进度文本在标题正下方 ~57px（实机 2026-10-22：标题 (241,242)
        → "5/10" @ (199,299)）。节点位置若整体显示"已完成"按满处理。
        读不到返回 None（调用方按未知处理，**不许当完成**）。
        """
        for t, cx, cy, _ in ocr.scan(screen, NODE_TITLE_REGION, min_score=0.5):
            if not re.search(r"钟.捉鬼", t.replace(" ", "")):
                continue
            region = (max(0, cx - 55), max(0, cy + NODE_PROGRESS_DY - 18), 110, 36)
            for pt, _, _, _ in ocr.scan(screen, region, min_score=0.6):
                pt = pt.replace(" ", "")
                m = re.search(r"(\d+)\s*/\s*(\d+)", pt)
                if m:
                    return int(m.group(1)), int(m.group(2))
                if "已完成" in pt:
                    return 10, 10   # 节点显示"已完成"即今日打满
            return None
        return None

    def _read_day_progress(self):
        """回主界面 → 打开玩法地图 → 读钟馗捉鬼节点今日进度。

        返回 (done, total) 或 None（玩法地图打不开/节点识别不到——调用方
        必须把 None 当"进度未知"处理，不得当成已完成）。读完关面板回主
        界面（后续 open_wanfa/进 NPC 都需要干净的主界面）。
        """
        self.dismiss_popups()
        if not self.on_main_screen(self.device.screenshot()):
            self._escape_special_scene()
        if not self.open_wanfa():
            return None
        prog = None
        deadline = time.time() + 8
        while time.time() < deadline and prog is None:
            prog = self._day_progress(self.device.screenshot())
            if prog is None:
                time.sleep(1.0)
        self.device.click(*WANFA_BACK_POS)   # 关玩法地图回主界面
        time.sleep(random.uniform(1.2, 1.8))
        return prog

    @staticmethod
    def _find_progress(screen):
        """找追踪面板里的"钟馗捉鬼 n/5"进度条目，返回 (cx, cy, 归一化文本)。

        OCR 会把"馗"读成各种字（提/尴/甚至丢掉），进度计数也可能和标题
        粘成一个框：用 "鬼...数字/数字" 的包含式正则判定。
        """
        for text, cx, cy, _ in ocr.scan(screen, PROGRESS_REGION, min_score=0.5):
            if re.search(r"鬼.*\d\s*/\s*\d", text):
                return cx, cy, text.replace(" ", "")
        return None

    def _nudge_if_stuck(self, screen, state):
        """链的自动状态可能被打断（实测卡 1/5 数分钟）：进度文字 10 秒没
        变化就点一下进度条目催动（同 xunbao 寻宝链的催动机制）。
        state: [last_text, last_change]，原地修改。"""
        entry = self._find_progress(screen)
        if not entry:
            return
        cx, cy, text = entry
        if text != state[0]:
            state[0], state[1] = text, time.time()
        elif time.time() - state[1] > 10:
            log.info("捉鬼进度 10 秒未变化（%s），点击进度条目催动", text)
            self.device.click(cx, cy)
            state[1] = time.time()  # 重置计时，防连点

    def _run_chain(self):
        """等一轮 5 场连打：结束返回 "done"（读到「完成10次/奖励总览」这个
        **正向证据**），中段返回 "mid"（已点前往继续），超时返回 "timeout"
        （没读到任何完成证据——调用方按"进度未知"处理，不许当完成）。"""
        auto_clicked = False
        state = [None, time.time()]
        deadline = time.time() + CHAIN_TIMEOUT
        while time.time() < deadline:
            self._check_stop()
            screen = self.device.screenshot()
            texts = ocr.dump_texts(screen, CHAIN_REGION)
            if any("完成10次" in t or "奖励总览" in t for t in texts):
                return "done"
            hit = ocr.find_text(screen, "前往继续", region=CHAIN_REGION,
                                min_similarity=1.0)
            if hit:
                log.info("恭喜完成 5 次，点击 [前往继续] @ (%d, %d)", hit[0], hit[1])
                self.device.click(hit[0], hit[1])
                time.sleep(random.uniform(2.0, 3.0))
                return "mid"
            if not auto_clicked and ocr.contains_text(screen, "回合",
                                                      region=BATTLE_ROUND_REGION):
                self.device.click(*BATTLE_AUTO_POS)
                auto_clicked = True
                log.info("已开自动，链式战斗进行中")
            self._nudge_if_stuck(screen, state)
            self._close_fuka_card(screen)
            time.sleep(3)
        log.warning("钟馗捉鬼链超时（没读到完成10次/奖励总览）")
        return "timeout"

    def _close_summary(self):
        """奖励总览（恭喜完成10次）点"关闭"；没有就跳过。"""
        for _ in range(5):
            screen = self.device.screenshot()
            hit = ocr.find_text(screen, "关闭", region=CLOSE_REGION,
                                min_similarity=1.0)
            if hit:
                log.info("点击 [关闭-奖励总览] @ (%d, %d)", hit[0], hit[1])
                self.device.click(hit[0], hit[1])
                time.sleep(random.uniform(1.2, 1.8))
                continue
            if self._close_fuka_card(screen):
                continue
            return

    # ---- 队员端 ----

    def _member_flow(self, coord):
        """队员端：**纯被动**——只等队长的副本结果，不做任何 OCR / 点击
        （用户规则 2026-10-13：钟馗捉鬼队员不需要点确认，进战斗自动连打，
        识别与操作全交给队长）。

        历史上队员端做了大量画蛇添足的事：dump CHAIN_REGION 判"奖励总览"
        （见下方警告，第 1 轮总结绝不能当结束）、点自动、_nudge_if_stuck 催动、
        关赐福令卡——全是抢鼠标/抢 OCR 开销的无用动作。两轮链式战斗由客户端
        自动推进，队员只需阻塞等队长 dungeon_result（队长"离开"后自动跟随
        回主界面）。"""
        deadline = time.time() + MEMBER_GIVEUP
        me_id = self.account.get("id")
        log.info("队员端：只等队长信号，不做识别/不抢鼠标（被动模式）")
        while time.time() < deadline:
            self._check_stop()
            # 队长改选接管（2026-10-18 run 7792f4：5 号改选 6 号后无人跑队长
            # 流程，全队干等 1800s，见 liudao._member_flow 同款注释）
            if (coord.dungeon_result(self.name) is None
                    and me_id == coord.captain_id):
                log.warning("原队长失败，本号被改选为队长，接管钟馗捉鬼队长流程")
                return self._captain_flow(coord)
            if coord.dungeon_result(self.name) is not None:
                ok = coord.dungeon_result(self.name)
                log.info("副本已结束（%s）", "完成" if ok else "失败")
                if not ok:
                    # 队长端判负 = 本号也没打成，如实计失败（不"没打也算成功"）
                    raise TaskSkipped("队长端钟馗捉鬼失败，本号未参与完成")
                if not coord.in_current_team(me_id):
                    # 全队结果 ≠ 本号参战（2026-10-18 run 188ac5：4 号不在
                    # 重建后的 4 人队里，却按全队结果记"完成"）
                    raise TaskSkipped("本号不在当前队伍（重建后未接受邀请），"
                                      "钟馗捉鬼未参与")
                return True
            time.sleep(2)
        log.warning("等钟馗捉鬼副本结果超时（%ds）", MEMBER_GIVEUP)
        # 2026-10-18 改判：超时 = 副本没完成，如实计失败（旧 `return True` 把
        # 全队没打的钟馗记成完成，见 liudao._member_flow 注释）
        raise TaskSkipped("等待钟馗捉鬼副本结果超时（%ds），本号未参与完成"
                          % MEMBER_GIVEUP)

    # ---- 公共 ----

    def _close_fuka_card(self, screen):
        """画面里有赐福令卡就点 X 关掉（用户要求一律关闭，避免遮挡 OCR）。
        有动作返回 True。"""
        if ocr.find_text(screen, "赐福令", region=(270, 380, 125, 60),
                         min_similarity=0.75):
            self.device.click(373, 405)
            return True
        return False

    def _wait_text(self, text, region, timeout, min_similarity=1.0):
        deadline = time.time() + timeout
        while time.time() < deadline:
            hit = ocr.find_text(self.device.screenshot(), text,
                                region=region, min_similarity=min_similarity)
            if hit:
                return hit
            time.sleep(0.6)
        return None
