"""一键登录（命令行版）：从 SQLite 读取账号，逐个启动客户端并走完登录状态机。

用法:
    python login.py              # 顺序登录数据库中的全部账号（自动启动客户端）
    python login.py --ids 1 3    # 只登录指定 id 的账号
    python login.py --parallel   # 并行登录：对已经打开的客户端窗口同时走登录流程
    python login.py --tile       # 只对已开的窗口重新平铺排列

账号管理请使用 gui.py（账号登录页签）。
"""
import argparse
import logging
import sys
import threading
import time
import random
from difflib import SequenceMatcher
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import win32con
import win32gui
import yaml

from core import anchors, binding, charfp, db, dialogs, gamecls, launcher, locate, ocr
from core.device import Device
from core.matcher import Matcher
from core.login_flow import LoginFlow
from core.logsetup import account_tag, clear_account, set_account, setup_logging
from core.paths import ASSETS_DIR, CONFIG_PATH, ensure_user_files
from tasks.base import BEIBAO_REGION

ensure_user_files()
# 注意：日志初始化不再放在模块导入期（避免被 gui 之类的模块 import 时产生副作用），
# 改由各入口显式调用 setup_logging()；本文件命令行入口见 main()。
log = logging.getLogger("login")


def _relaunch_client(acc, cfg, existing=None, relaunch_lock=None):
    """启动一个新的客户端实例，返回新窗口句柄（失败 None）。

    并行登录时传 relaunch_lock 串行化——否则两个线程可能抢到同一个新窗口
    （wait_new_window 靠"启动前枚举的差集"认窗口，并发启动会认错）。
    沙盒内程序可能崩溃（SBIE2224）：窗口没出现时清一次弹窗再试一次，
    与 launch_missing 的处理保持一致。
    """
    keyword = cfg.get("window_keyword") or Device.DEFAULT_KEYWORD
    if not cfg.get("game_exe"):
        log.error("config.yaml 未配置 login.game_exe，无法重启客户端")
        return None
    with (relaunch_lock or threading.Lock()):
        known = set(Device.find_all(keyword)) if existing is None else set(existing)
        launcher.launch_instance(
            cfg["game_exe"],
            mode=acc["launch_mode"],
            box=acc["sandbox_box"] or None,
            sandboxie_start=cfg.get("sandboxie_start"),
        )
        hwnd = launcher.wait_new_window(keyword, known,
                                        timeout=cfg.get("launch_timeout", 180))
    if hwnd is None:
        log.warning("账号 %s 重启客户端窗口未出现，清理沙盒弹窗后重试一次", acc["account"])
        launcher.dismiss_sandboxie_popups()
        with (relaunch_lock or threading.Lock()):
            known = set(Device.find_all(keyword)) if existing is None else set(existing)
            launcher.launch_instance(
                cfg["game_exe"],
                mode=acc["launch_mode"],
                box=acc["sandbox_box"] or None,
                sandboxie_start=cfg.get("sandboxie_start"),
            )
            hwnd = launcher.wait_new_window(keyword, known, timeout=60)
    return hwnd


def _broken_client_reason(flow):
    """客户端本身坏了的失败原因（换了新客户端就能好），否则返回 None。

    三类：启动闪屏卡死 / 运行中假死（client_hung）、登录后 UI 残废
    （ui_broken——右上角「任务/队伍」页签不出、点击无反应）。用户实测沙盒
    客户端这类故障重启 5~10 次内能碰到一个正常的，所以只有这类失败才值得
    反复重启；普通登录失败（超时/中止）换新客户端也没用，不重试。
    """
    if getattr(flow, "ui_broken", False):
        return "登录后 UI 残废（右上角「任务/队伍」页签始终不出现，点击无反应）"
    if getattr(flow, "client_hung", False):
        return "客户端卡死（启动闪屏不消失 / 窗口持续无响应）"
    return None


def _login_with_client_retry(acc, cfg, matcher, hwnd):
    """跑登录状态机；客户端本身坏了就关窗换一个新客户端重试（顺序登录用）。

    普通登录失败（超时/中止）**不**重试——换新客户端也解决不了，白付一次冷启动。
    客户端坏了（卡死/假死/登录后 UI 残废）则最多试 broken_client_attempts 次：
    用户实测沙盒客户端这种故障，重启 5~10 次内能碰到一个正常的（2026-10-28）。
    返回 (ok, hwnd, flow)：hwnd 可能因重启而变化，调用方要重新配对/回填。
    """
    broken_attempts = int(cfg.get("broken_client_attempts", 8) or 8)
    flow = None
    for attempt in range(1, broken_attempts + 1):
        flow = LoginFlow(Device(hwnd=hwnd), matcher,
                         character=acc["character"] or None,
                         account=acc["account"] or None,
                         server=acc.get("server") or None,
                         timeout=cfg.get("login_timeout", 300),
                         ui_check_grace=cfg.get("ui_check_grace"))
        ok = flow.run()
        if ok or flow.abort_reason:
            return ok, hwnd, flow
        reason = _broken_client_reason(flow)
        if not reason:
            return False, hwnd, flow
        if attempt >= broken_attempts:
            log.error("账号 %s %s，已换新客户端 %d 次仍未恢复，放弃",
                      acc["account"], reason, attempt)
            return False, hwnd, flow
        log.warning("账号 %s %s，关闭客户端换一个新的重试 (%d/%d)",
                    acc["account"], reason, attempt + 1, broken_attempts)
        launcher.force_close_window(hwnd)
        _gone_deadline = time.time() + 5
        while time.time() < _gone_deadline and win32gui.IsWindow(hwnd):
            time.sleep(0.3)
        new_hwnd = _relaunch_client(acc, cfg)
        if new_hwnd is None:
            log.error("账号 %s 重启客户端失败", acc["account"])
            return False, hwnd, flow
        hwnd = new_hwnd
        _pair(acc, hwnd)   # 句柄变了：重新绑定 + 回填内存快照
    return False, hwnd, flow


def run_login(accounts, cfg, matcher):
    """顺序登录给定账号列表，返回成功登录的窗口句柄列表。"""
    keyword = cfg.get("window_keyword") or Device.DEFAULT_KEYWORD
    existing = set(Device.find_all(keyword))  # 已开窗口不算"新窗口"
    hwnds = []
    for acc in accounts:
        set_account(account_tag(acc))
        log.info("---- 登录: %s | %s | %s | %s ----",
                 acc["account"], acc["server"], acc["character"], acc["launch_mode"])
        launcher.launch_instance(
            cfg["game_exe"],
            mode=acc["launch_mode"],
            box=acc["sandbox_box"] or None,
            sandboxie_start=cfg.get("sandboxie_start"),
        )
        hwnd = launcher.wait_new_window(keyword, existing, timeout=cfg.get("launch_timeout", 180))
        if hwnd is None:
            log.error("账号 %s 窗口未出现，跳过", acc["account"])
            continue
        existing.add(hwnd)
        binding.bind_account(acc["id"], hwnd)  # 程序拉起的客户端：配对确切，直接绑定
        acc["hwnd"] = hwnd
        ok, hwnd, flow = _login_with_client_retry(acc, cfg, matcher, hwnd)
        if ok:
            hwnds.append(hwnd)
            existing.add(hwnd)
        elif flow.abort_reason:
            log.warning("账号 %s 跳过: %s", acc["account"], flow.abort_reason)
        elif getattr(flow, "client_hung", False) or getattr(flow, "ui_broken", False):
            # 客户端本身坏了（卡死 / UI 残废）：已重试到上限仍未恢复，关掉它
            # （假死窗口的消息泵不处理消息，PostMessage 关不掉时会强杀进程），
            # 也不进返回列表——否则调用方会对着一个已经死掉的窗口平铺/执行任务。
            log.warning("账号 %s 客户端异常（%s），重试 %s 次仍未恢复，关闭窗口",
                        acc["account"], _broken_client_reason(flow),
                        cfg.get("broken_client_attempts", 8))
            launcher.force_close_window(hwnd)
        else:
            log.error("账号 %s 登录失败，需人工查看", acc["account"])
        if acc is not accounts[-1]:
            time.sleep(random.uniform(cfg.get("stagger_min", 15), cfg.get("stagger_max", 30)))
    clear_account()
    return hwnds


def launch_missing(accounts, cfg, existing_hwnds):
    """为给定账号逐个启动客户端（账号间带间隔）。

    返回 [(account_id, hwnd), ...]——带上账号身份，调用方才能把新句柄回填进
    自己的 accounts 快照（之前只返回裸 hwnd 列表，GUI 侧信息在返回处就断了，
    导致紧接着的 run_login_parallel 仍拿旧句柄解析、全判 dead 跳过登录）。
    """
    keyword = cfg.get("window_keyword") or Device.DEFAULT_KEYWORD
    existing = set(existing_hwnds)
    new_pairs = []
    for acc in accounts:
        log.info("启动客户端: %s | %s | %s", acc["account"], acc["character"], acc["launch_mode"])
        launcher.launch_instance(
            cfg["game_exe"],
            mode=acc["launch_mode"],
            box=acc["sandbox_box"] or None,
            sandboxie_start=cfg.get("sandboxie_start"),
        )
        hwnd = launcher.wait_new_window(keyword, existing, timeout=cfg.get("launch_timeout", 180))
        if hwnd is None:
            # 沙盒内程序可能崩溃（SBIE2224）：清理弹窗后重试一次
            log.warning("账号 %s 窗口未出现，清理弹窗后重试启动一次", acc["account"])
            launcher.dismiss_sandboxie_popups()
            launcher.launch_instance(
                cfg["game_exe"],
                mode=acc["launch_mode"],
                box=acc["sandbox_box"] or None,
                sandboxie_start=cfg.get("sandboxie_start"),
            )
            hwnd = launcher.wait_new_window(keyword, existing, timeout=60)
        if hwnd is None:
            log.error("账号 %s 窗口未出现", acc["account"])
            continue
        existing.add(hwnd)
        new_pairs.append((acc["id"], hwnd))
        _pair(acc, hwnd)  # 程序拉起的客户端：配对确切，写 db + 回填内存快照
        if acc is not accounts[-1]:
            # 启动间隔比登录间隔短得多，仅避免多开瞬间并发
            time.sleep(random.uniform(cfg.get("launch_stagger_min", 3),
                                      cfg.get("launch_stagger_max", 8)))
    return new_pairs


def run_login_parallel(accounts, cfg, matcher, stop_event=None):
    """并行登录：每个已打开的客户端窗口一个线程，各自跑登录状态机。

    不启动客户端，需先手动开好窗口。窗口与账号按顺序配对
    （窗口按屏幕从左到右排序 = 账号列表顺序）。
    截图/OCR/模板匹配在线程间并行；鼠标/键盘操作经 Device._input_lock
    全局串行——某个窗口加载等待时其它窗口照常推进，点击互不打架。
    登录中途窗口死亡（崩溃/被强退）时自动重启客户端重试，
    最多 login_attempts 次（默认 2）。
    stop_event（2026-10-25 worker 化）：置位时状态机逐个中断，不再重试。
    """
    keyword = cfg.get("window_keyword") or Device.DEFAULT_KEYWORD
    hwnds = Device.find_all(keyword)
    if not hwnds:
        log.error("没有检测到已打开的客户端窗口，请先打开客户端再运行 --parallel")
        return []
    # 账号↔窗口配对：有绑定句柄的优先用绑定（确切）；未绑定的按窗口从左到右
    # 顺序兜底——手动打开的客户端顺序可能错，配对不准时在 GUI 账号编辑里
    # 用鼠标指定客户端句柄
    resolved = binding.resolve_hwnds(accounts, hwnds, keyword)
    pairs = []
    for acc in accounts:
        hwnd, source = resolved[acc["id"]]
        if hwnd is None:
            log.error("账号 %s（%s）无可配对窗口（%s），跳过登录",
                      acc["account"], acc["character"], source)
            continue
        pairs.append((acc, hwnd))
    results = []
    stop_watcher = threading.Event()
    relaunch_lock = threading.Lock()  # 重启客户端串行，避免两个线程抢到同一个新窗口

    def popup_watcher():
        """登录期间后台清理 Sandboxie 弹窗（崩溃消息可能随时弹出遮挡游戏窗口）。"""
        while not stop_watcher.wait(2):
            launcher.dismiss_sandboxie_popups()

    threading.Thread(target=popup_watcher, daemon=True).start()

    def worker(acc, hwnd):
        """跑一个账号的登录状态机；窗口中途死亡（崩溃/被强退）时重启客户端重试。"""
        set_account(account_tag(acc, hwnd))  # 本线程日志自动带账号标签
        max_attempts = int(cfg.get("login_attempts", 2) or 2)
        # 客户端本身坏了（卡死/假死/登录后 UI 残废）时，重启一次 = 换一个新客户端，
        # 用户实测沙盒客户端 5~10 次内能碰到一个正常的（2026-10-28），所以这类
        # 失败单独给上限 broken_client_attempts；普通登录失败（超时/中止）换新
        # 客户端也没用，仍受 login_attempts 限制（默认 2 次）。
        broken_attempts = int(cfg.get("broken_client_attempts", 8) or 8)
        limit = max_attempts
        flow, ok = None, False
        for attempt in range(1, max(max_attempts, broken_attempts) + 1):
            if stop_event is not None and stop_event.is_set():
                log.info("账号 %s 登录被停止请求中断", acc["account"])
                break
            flow = LoginFlow(Device(hwnd=hwnd), matcher,
                             character=acc["character"] or None,
                             account=acc["account"] or None,
                             server=acc.get("server") or None,
                             timeout=cfg.get("login_timeout", 300),
                             stop_event=stop_event,
                             ui_check_grace=cfg.get("ui_check_grace"))
            ok = flow.run()
            if ok or flow.abort_reason:
                break
            broken_reason = _broken_client_reason(flow)
            limit = broken_attempts if broken_reason else max_attempts
            if broken_reason:
                # 客户端本身坏了：它永远登不进去/登进去也点不动，还占着一个客户端
                # 实例名额 → 关掉它（假死窗口的消息泵不处理消息，PostMessage 关不
                # 掉时会强杀进程），交给下面的重启逻辑换一个干净客户端重试。
                log.warning("账号 %s %s，关闭后换新客户端重试", acc["account"],
                            broken_reason)
                launcher.force_close_window(hwnd)
                _deadline = time.time() + 5
                while time.time() < _deadline and win32gui.IsWindow(hwnd):
                    time.sleep(0.3)
            if win32gui.IsWindow(hwnd):
                # 2026-10-16：窗口活着 ≠ 重启无意义（旧注释的结论是错的）。
                # 实测残留的坏窗口会卡在「踏入长安页」——点"选择区服"打不开选服
                # 面板、页面反复"未识别"，状态机只能干耗到超时；而**同一个账号
                # 换个新客户端立刻能登进去**（7 号先复用坏窗失败、后新开窗成功；
                # 紧接着 5 号复用同一个坏窗又失败）。所以关掉这个坏窗口，交给
                # 下面的重启逻辑换一个干净客户端重试；次数仍受 login_attempts
                # 限制（默认 2 次 = 最多多花一次冷启动）。
                log.warning("账号 %s 登录状态机超时（窗口仍在），关闭该窗口并换新客户端重试",
                            acc["account"])
                launcher.force_close_window(hwnd)
                _deadline = time.time() + 5
                while time.time() < _deadline and win32gui.IsWindow(hwnd):
                    time.sleep(0.3)
            if win32gui.IsWindow(hwnd):
                break  # 关不掉（强杀也没成功）：不再重启，避免反复失败
            if attempt >= limit:
                log.error("账号 %s 客户端反复退出/异常（已试 %d 次），放弃该账号",
                          acc["account"], attempt)
                break
            log.warning("账号 %s 客户端窗口已关闭（崩溃/被强退/坏客户端已关），"
                        "重启客户端重试 (%d/%d)", acc["account"], attempt + 1, limit)
            hwnd = _relaunch_client(acc, cfg, relaunch_lock=relaunch_lock)
            if hwnd is None:
                log.error("账号 %s 重启客户端失败", acc["account"])
                break
            _pair(acc, hwnd)  # 程序重启的客户端：重新绑定 + 回填内存快照
        results.append((acc, flow, ok))

    threads = []
    for acc, hwnd in pairs:
        log.info("---- 并行登录: %s | %s | %s (hwnd=%s) ----",
                 acc["account"], acc["server"], acc["character"], hwnd)
        t = threading.Thread(target=worker, args=(acc, hwnd), daemon=True)
        t.start()
        threads.append(t)
        time.sleep(random.uniform(0.5, 1.5))  # 错开首帧，避免同时抢输入锁
    for t in threads:
        t.join()
    stop_watcher.set()

    hwnds_ok = []
    for acc, flow, ok in results:
        if ok:
            hwnds_ok.append(flow.device.hwnd)
        elif flow is None:
            log.warning("账号 %s 未跑登录状态机（被停止请求中断）", acc["account"])
        elif flow.abort_reason:
            log.warning("账号 %s 跳过: %s", acc["account"], flow.abort_reason)
        else:
            log.error("账号 %s 登录失败或超时，需人工查看", acc["account"])
    return hwnds_ok


def _quit_kicked(hwnd):
    """窗口开着但账号已不在游戏里（弹窗"被迫下线"→"退出游戏"；或
    "网络已断开，请重新登录"→"重新登录"）：OCR 定位并点击唯一按钮。
    点"退出游戏"客户端可能直接退出（窗口消失，由调用方重启客户端）；
    点"重新登录"退回登录界面。处理过弹窗返回 True。

    仅在定时任务 preflight / 重登流程使用——任务进行中的顶号先走
    AccountKicked 中止（dismiss_popups 不点按钮），由账号线程的重登逻辑调到这里。
    """
    device = Device(hwnd=hwnd)
    kicked = False
    stale = 0   # 连续"点击后弹窗仍在"的次数 → 客户端输入线程卡死判据
    for _ in range(3):
        if not win32gui.IsWindow(hwnd):
            break
        try:
            texts = ocr.scan(device.screenshot(), dialogs.DIALOG_SCAN_REGION)
        except Exception as e:
            log.warning("窗口 %s 顶号检查截图失败（窗口按原样保留）: %s", hwnd, e)
            break
        if not dialogs.handle_kicked(device, None, texts):
            break
        kicked = True
        # 2026-10-15 实机事故：客户端被顶后输入线程卡死，弹窗"退出游戏"
        # 对合成点击/真实鼠标/回车**全部无响应**（实测 2 小时死循环：点了没
        # 反应→再检测→再点）。旧实现点满 3 次就返回，窗口永远卡在弹窗上，
        # 账号线程跟着空转。这里改为：连续两次点击后弹窗仍在即判定客户端
        # 卡死，强制关窗（含杀进程），交给调用方重启客户端。
        if stale >= 2:
            log.warning("窗口 %s 顶号弹窗对点击无响应（客户端输入线程卡死），"
                        "强制关闭窗口交由调用方重启", hwnd)
            try:
                launcher.force_close_window(hwnd)
            except Exception as e:
                log.warning("强制关窗失败 hwnd=%s: %s", hwnd, e)
            break
        btn = [(cx, cy) for t, cx, cy, _ in texts if "退出游戏" in t] or \
              [(cx, cy) for t, cx, cy, _ in texts if "重新登录" in t]
        if btn:
            log.warning("窗口 %s 处理断网/顶号弹窗，点击按钮 @ %s", hwnd, btn[0])
            device.click(*btn[0])
        else:
            log.warning("窗口 %s 断网/顶号弹窗未定位到按钮，强制关闭窗口", hwnd)
            try:
                launcher.force_close_window(hwnd)
            except Exception as e:
                log.warning("关闭窗口失败 hwnd=%s: %s", hwnd, e)
            break
        time.sleep(4)  # 等客户端退出/退回登录界面
        stale += 1
    return kicked


def relogin_kicked(acc, cfg, matcher, hwnd=None, max_attempts=3, stop_event=None):
    """任务进行中被顶号/断网后的单号重登（gui.py worker 在账号线程内调用）：
    点顶号/断网弹窗按钮 →（窗口消失则重启客户端）→ 跑一遍登录状态机。
    内部最多尝试 max_attempts 次（用户规则：重登 3 次仍被顶就放弃），
    任一次成功立即返回（新）hwnd；全部失败返回 None。

    hwnd 参数：外部已找到的候选窗口（如句柄失效后枚举出的最小化窗口）；
    缺省用账号库绑定的句柄。与 preflight 的批量逻辑不同：这里只处理
    这一个账号，不做其它窗口的角色配对。
    """
    keyword = cfg.get("window_keyword") or Device.DEFAULT_KEYWORD
    hwnd = hwnd or acc.get("hwnd") or 0
    try:
        for attempt in range(1, max_attempts + 1):
            if stop_event is not None and stop_event.is_set():
                log.info("账号 %s 重登被停止请求中断", acc.get("account"))
                return None
            log.info("账号 %s 第 %d/%d 次重登", acc.get("account"), attempt,
                     max_attempts)
            if hwnd and win32gui.IsWindow(hwnd):
                if win32gui.IsIconic(hwnd):  # 最小化的窗口截不到图：先还原
                    win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
                    time.sleep(1.5)
                device = Device(hwnd=hwnd)
                device.activate()
                dialogs.handle_sleep_mode(device, device.screenshot())
                _quit_kicked(hwnd)  # 点"退出游戏"/"重新登录"：可能关窗或退登录界面
            if not (hwnd and win32gui.IsWindow(hwnd)):
                if not cfg.get("game_exe"):
                    log.error("账号 %s 客户端已关闭且未配置 login.game_exe，无法重登",
                              acc["account"])
                    return None
                log.warning("账号 %s 客户端已退出，重启客户端后重登", acc["account"])
                existing = set(Device.find_all(keyword))
                launcher.launch_instance(
                    cfg["game_exe"],
                    mode=acc["launch_mode"],
                    box=acc["sandbox_box"] or None,
                    sandboxie_start=cfg.get("sandboxie_start"),
                )
                hwnd = launcher.wait_new_window(keyword, existing,
                                                timeout=cfg.get("launch_timeout", 180))
                if hwnd is None:
                    log.error("账号 %s 重启客户端后窗口未出现", acc["account"])
                    return None
                _pair(acc, hwnd)
            flow = LoginFlow(Device(hwnd=hwnd), matcher,
                             character=acc["character"] or None,
                             account=acc["account"] or None,
                             server=acc.get("server") or None,
                             timeout=cfg.get("login_timeout", 300),
                             stop_event=stop_event,
                             ui_check_grace=cfg.get("ui_check_grace"))
            if flow.run():
                _pair(acc, hwnd)
                launcher.tile_windows(Device.find_all(keyword), **cfg.get("tile", {}))
                log.info("账号 %s 重登成功（hwnd=%s，第 %d 次尝试）",
                         acc["account"], hwnd, attempt)
                return hwnd
            broken_reason = _broken_client_reason(flow)
            if broken_reason:
                # 客户端本身坏了（运行时假死 / 登录后 UI 残废——右上角「任务/队伍」
                # 页签不出、点击无反应）：点击已无效，这个窗口再也登不进去 →
                # 关掉它（消息泵不响应时 PostMessage 关不掉，会强杀进程），
                # 下一轮 attempt 就会走上面的"窗口已关闭 → 重启客户端"分支
                log.warning("账号 %s 重登时%s，关闭后重启", acc["account"], broken_reason)
                launcher.force_close_window(hwnd)
            log.warning("账号 %s 第 %d 次重登未完成登录状态机", acc["account"], attempt)
        log.error("账号 %s 连续 %d 次重登失败，放弃（按有人看管处理）",
                  acc["account"], max_attempts)
        return None
    except Exception:
        log.exception("账号 %s 重登异常", acc.get("account"))
        return None


def relaunch_dead_client(acc, cfg, matcher, attempts=None, stop_event=None):
    """运行中判定「整窗失灵」后的换 new：关掉当前窗口 → 起一个新客户端 → 登录。

    与 relogin_kicked 的区别：那边先尝试点"退出游戏"（正常客户端走得动，
    代价最小）；整窗失灵时**点击根本不生效**（2026-10-29 沙盒客户端），点了
    纯属浪费时间，所以这里直接 force_close_window 换新。登录失败且判定为
    "客户端本身坏了"（含登录期 UI 残废）时继续换，最多 attempts 次。

    成功返回新 hwnd，失败返回 None。调用方必须拿它重建 Device 并回填
    acc["hwnd"]（同一份 accounts 会被多次解析，只写 db 会读到旧句柄）。
    """
    if stop_event is not None and stop_event.is_set():
        log.info("账号 %s 换新客户端被停止请求中断", acc.get("account"))
        return None
    keyword = cfg.get("window_keyword") or Device.DEFAULT_KEYWORD
    tries = int(attempts or cfg.get("input_dead_attempts", 3) or 3)
    old = acc.get("hwnd") or 0
    try:
        if old and win32gui.IsWindow(old):
            log.warning("账号 %s 整窗失灵：关闭旧客户端 hwnd=%s",
                        acc.get("account"), old)
            launcher.force_close_window(old)
            time.sleep(1.0)
        new_hwnd = _relaunch_client(acc, cfg)
        if new_hwnd is None:
            log.error("账号 %s 新客户端窗口未出现，换新失败", acc.get("account"))
            return None
        _pair(acc, new_hwnd)
        login_cfg = dict(cfg)
        login_cfg["broken_client_attempts"] = tries   # 换新的重试上限
        ok, hwnd, _flow = _login_with_client_retry(acc, login_cfg, matcher, new_hwnd)
        if ok and hwnd:
            launcher.tile_windows(Device.find_all(keyword), **cfg.get("tile", {}))
            log.info("账号 %s 整窗失灵换新完成（新 hwnd=%s）",
                     acc.get("account"), hwnd)
            return hwnd
        log.error("账号 %s 换新客户端后仍未登录成功", acc.get("account"))
        return None
    except Exception:
        log.exception("账号 %s 整窗失灵换新异常", acc.get("account"))
        return None


# ---- 查看当前角色 / 切换登录（405x720 客户区坐标，2026-10-09 实机标定）----

INFO_BTN_POS = (230, 685)                  # 背包面板底部"信息"页签
# 信息页右上角"角色名"所在的那一行。
# 注意：旧值 (155, 8, 240, 45) 把 y 下探到 45，会把名字下方的"109（141）级！"
# 一起框进来；小区域 OCR 有时只认出等级数字、丢掉名字（实测读到 '09/141'），
# 于是窗口被误判成"错号窗口"→触发无谓的切换登录→再多开一个客户端。
# 只框名字这一行更稳（实测对不同角色名的窗口都能正确读出）。
INFO_NAME_REGION = (235, 4, 170, 30)
# 名字行没读出人名时的兜底：更宽的顶部条（含头像/名字/等级），
# 靠 _looks_like_name（≥2 汉字且不含数字）把名字挑出来。
INFO_NAME_FALLBACK_REGION = (150, 0, 255, 70)
FUNC_SETTINGS_REGION = (40, 630, 110, 70)  # 功能页底部"设置"按钮
SETTINGS_TAB_REGION = (60, 660, 120, 60)   # 设置页底部"通用"页签
SWITCH_LOGIN_REGION = (270, 570, 135, 75)  # 设置-通用页右下"切换登录"
LOGOUT_TEXT_REGION = (60, 200, 285, 340)   # "是否退出登录？"提示框文字区
LOGOUT_CONFIRM_REGION = (220, 410, 155, 70)  # 提示框"确认"按钮
LOGIN_SCREEN_REGION = (80, 390, 245, 60)   # 登录界面"进入游戏"按钮（判定已退出到登录界面）
BAG_LOAD_REGION = (260, 585, 120, 60)      # 背包页底部"整理"按钮（判定背包已打开）
# 背包页锚点：左下角"返回"箭头（52x48 图标，背包页固定元素——eat_cooking/
# eat_pet_food 关背包就用它）。模板命中 = 背包已打开，免一次 OCR（~0.9s）；
# 判不出来再走 OCR「整理」兜底。region 圈住面板返回箭头的常驻位（33,683）。
BAG_PAGE_ANCHOR = anchors.Anchor("背包返回", (0, 560, 140, 160), 0.85, 0.40)


def _wait_bag_open(device, matcher, timeout=8):
    """等背包页打开：先「背包返回」锚点（0 次 OCR），判不出来再 OCR「整理」。

    锚点阶段只给 2.5s——背包打开通常 1s 内；没命中大概率是背包没开
    （也可能是锚点素材/区域不准），余下时间交给 OCR 兜底定论。锚点素材
    缺失或一直不命中时，行为与旧的纯 OCR 版完全一致（多花的只是几次
    毫秒级模板匹配）。
    """
    box = anchors.wait_anchor(device, matcher, BAG_PAGE_ANCHOR,
                              timeout=min(2.5, timeout), interval=0.4)
    if box:
        log.info("背包页锚点命中（%.2f），免 OCR 确认加载", box[2])
        return True
    return bool(_wait_ocr(device, "整理", BAG_LOAD_REGION, timeout))


def _wait_ocr(device, text, region, timeout, min_similarity=1.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        hit = ocr.find_text(device.screenshot(), text, region=region,
                            min_similarity=min_similarity)
        if hit:
            return hit
        time.sleep(0.6)
    return None


_NAME_HAN = ("\u4e00", "\u9fff")


def _looks_like_name(texts):
    """OCR 结果是否像角色名：至少 2 个汉字且不含数字。

    信息页名字行旁边就是等级/经验这类纯数字（'109（141）级！'、'0/111610800'），
    一旦 OCR 只认出数字（如 '09/141'），绝不能当成"另一个角色名"——那会把窗口
    误判成错号窗口。这个判定把"数字垃圾"和"真·别的角色名"区分开。
    """
    for t in texts or []:
        t = (t or "").strip()
        han = sum(1 for ch in t if _NAME_HAN[0] <= ch <= _NAME_HAN[1])
        if han >= 2 and not any(c.isdigit() for c in t):
            return True
    return False


def _open_bag(device, matcher):
    """ESC 关浮层 → 点开背包并等加载完成。失败返回 False。

    失败可能是窗口不在游戏内（登录界面/闪屏），也可能是有弹窗挡着——
    交给调用方按"读不出角色"的路径处理，这里不做二次猜测。
    """
    device.press_esc()   # 关掉可能开着的浮层（否则背包/信息页都可能点不开）
    time.sleep(0.4)
    if not matcher.find_and_click(device, "背包", timeout=5,
                                  region=BEIBAO_REGION, ccoeff_floor=0.45):
        return False
    return _wait_bag_open(device, matcher, timeout=8)


def _name_texts(screen):
    """信息页截图 → 名字行 OCR 文本（窄区域优先，读不出退宽区域）。"""
    texts = ocr.dump_texts(screen, INFO_NAME_REGION)
    if not _looks_like_name(texts):
        texts = ocr.dump_texts(screen, INFO_NAME_FALLBACK_REGION)
    return texts


def _name_crop(screen):
    """信息页截图 → 名字行裁剪图（区域与 INFO_NAME_REGION 一致，指纹用）。"""
    x, y, w, h = INFO_NAME_REGION
    return screen[y:y + h, x:x + w]


def _identify_and_class(screen, characters, label=""):
    """读角色 + 顺带学习/识别门派徽标（2026-10-12 新增，用户需求）。

    角色名确认后，把名字左侧的门派圆徽交给 core.gamecls：db 里已指定门派的
    角色存样本（自学习），未指定的尝试按样本识别并写回。失败只记日志，
    **绝不影响登录/配对主流程**。
    """
    ch, texts = _identify_info_screen(screen, characters, label)
    if ch:
        try:
            badge = gamecls.badge_from_info_screen(screen)
            if badge is not None:
                gamecls.observe(ch, badge, db.list_accounts())
        except Exception:
            log.exception("门派徽标学习/识别失败（不影响登录流程）")
    return ch, texts


def read_current_character(device, matcher):
    """读当前窗口登录的角色名：ESC 关浮层 → 背包 → 底部"信息" → 名字行（OCR）。

    返回 OCR 文本列表（可能为空）；窗口不在游戏内（登录界面等）或面板
    打不开时返回 []。

    两道稳健性处理（2026-10-09 事故教训：窗口停在一个功能九宫格浮层上时，
    背包/信息页切不过去、只读到等级数字 '09/141'，被误判"错号窗口"→切换登录
    失败→多开一个客户端并卡死）：
    1. 先按 ESC 关掉可能开着的浮层，再开背包；
    2. 名字行没读出人名时，退回更宽的顶部条再识别一次。
    """
    if not _open_bag(device, matcher):
        return []
    device.click(*INFO_BTN_POS)
    time.sleep(1.5)
    texts = _name_texts(device.screenshot())
    device.press_esc()  # 关信息面板回主界面
    time.sleep(0.8)
    return texts


def _identify_info_screen(screen, characters, label=""):
    """信息页截图 → (character 或 None, texts 或 None)：先指纹后 OCR。

    指纹 = 名字行裁剪图的二值文字掩码（core/charfp.py）：同一角色每次截出
    来几乎一致，IoU 达标即判同一角色，**免 OCR**（省 ~1s/窗）。没命中照旧
    OCR，识别到已知角色就把这次的裁剪图存为指纹——OCR 只在第一次（或画面
    变化）时付一次钱。指纹命中时 texts 为 None（没做过 OCR）。

    **防"判错被固化"**（见 core/charfp.py 模块注释）：写指纹那一步（OCR +
    模糊匹配）判错的话，错指纹会稳定高分命中且永远不再经过 OCR，一次偶发
    错误就被自学习固化成永久错误（=绑错号）。所以命中路径也要定期对账：
    - 刚存下的指纹**下次使用前必须 OCR 对账**（mark_saved → mark_hit）；
    - 之后每 AUDIT_EVERY 次命中再对账一次；
    - 对账一致 → audit_ok；判成**不同**角色 → 立即 invalidate（删指纹）并以
      OCR 结果为准；OCR 读不出 → 不判决，`mark_audit_due` 下次再验。
    """
    where = f"{label} " if label else ""
    crop = _name_crop(screen)
    ch, score = charfp.best_match(crop, characters)
    if ch and not charfp.mark_hit(ch):
        log.info("%s名字行指纹命中 %s（IoU=%.2f），免 OCR", where, ch, score)
        return ch, None

    texts = _name_texts(screen)
    ocr_ch = _match_character(texts, characters) if texts else None

    if ch:
        # 命中了但轮到对账：拿 OCR 结果核对指纹
        if ocr_ch is None:
            charfp.mark_audit_due(ch)
            log.warning("%s指纹对账：%s（IoU=%.2f）命中但 OCR 读不出角色名，"
                        "本次不判决（指纹保留，下次继续对账）", where, ch, score)
            return ch, texts
        if ocr_ch == ch:
            charfp.audit_ok(ch)
            log.info("%s指纹对账一致（%s，IoU=%.2f），继续免 OCR", where, ch, score)
            return ch, texts
        charfp.invalidate(ch, f"对账不一致（指纹判 {ch}、OCR 判 {ocr_ch}）")
        log.warning("%s指纹与 OCR 不一致 → 以 OCR（%s）为准", where, ocr_ch)
        return ocr_ch, texts

    if ocr_ch and charfp.save_fp(ocr_ch, crop):
        charfp.mark_saved(ocr_ch)
        log.info("%s已保存 %s 的名字行指纹（下次使用前先对账），下次配对免 OCR",
                 where, ocr_ch)
    return ocr_ch, texts


def read_character_fp(device, matcher, characters):
    """带「名字行指纹」快通道的读角色（单窗口版，流程同 read_current_character）。

    返回 (character 或 None, texts)；指纹命中时 texts 为 None；打不开
    背包/信息页时返回 (None, [])。批量路径见 _pair_by_names。
    """
    if not _open_bag(device, matcher):
        return None, []
    device.click(*INFO_BTN_POS)
    time.sleep(1.5)
    ch, texts = _identify_and_class(device.screenshot(), characters)
    device.press_esc()  # 关信息面板回主界面
    time.sleep(0.8)
    return ch, texts


def _wait_bags_ready(devs, hwnds, matcher, timeout=6.0):
    """批量等背包页就绪：轮询各窗「背包返回」锚点，全部确认即提前继续。

    替代旧的盲等 2s：背包开得快的窗口不用陪跑，开得慢的多等一会儿；
    没确认的窗口不阻塞流程（它们的"信息"页多半点不开，识别会失败而转
    pending 慢路径——比旧版对没打开背包的窗口盲点"信息"更安全）。
    锚点素材缺失时返回 None，调用方退回盲等（行为与旧版一致）。
    """
    if not anchors.has_anchor(matcher, BAG_PAGE_ANCHOR):
        return None
    deadline = time.time() + timeout
    pending = list(hwnds)
    while pending and time.time() < deadline:
        left = []
        for h in pending:
            if not anchors.find_anchor(matcher, devs[h].screenshot(),
                                       BAG_PAGE_ANCHOR):
                left.append(h)
        pending = left
        if pending:
            time.sleep(0.4)
    ready = [h for h in hwnds if h not in pending]
    if pending:
        log.warning("窗口 %s 背包页锚点 %.0fs 未确认，转慢路径", pending, timeout)
    return ready


def _pair_by_names(hwnds, matcher, by_character):
    """批量版"读当前角色"：把每个窗口的固定等待重叠起来（多线程的安全替代）。

    为什么不用多线程：置前点击（_click_foreground）与"置顶后抓屏"
    （screenshot）都必须独占屏幕——5 个线程各把自己的窗口抬到最前，
    会互相把对方压下去，截到的就是别人的画面；而"读错角色 = 绑错号 =
    任务跑错账号"，代价远大于省下的时间。所以这里的"并行"是**按步骤
    分批**（流水线）：每个窗口的固定等待（背包加载 ~2s、信息页 ~1.5s）
    从"逐窗串行相加"变成"所有窗口重叠"——5 窗 ≈40s → ≈15s，且全程
    单线程、零竞态，与逐窗版行为一一对应。

    返回 (results, pending)：
      results: {hwnd: (character 或 None, texts 或 None)}；character 非空
               = 已确认（指纹命中或 OCR 确认，指纹已存档）；texts 非 None
               = 该窗做过 OCR（分类 switchable/reusable 用）；
      pending: 批量路径没走通的窗口（背包没开出来等）——调用方对它们走
               原逐窗慢路径（read_current_character 第一步就是 ESC 清场，
               不怕这里留下的半开面板）。
    """
    characters = list(by_character)
    devs = {h: Device(hwnd=h) for h in hwnds}
    results, bag_ok = {}, []
    # 1) 统一 ESC 清浮层（浮层开着时背包/信息页都点不开，2026-10-09 教训）
    for h in hwnds:
        devs[h].press_esc()
        time.sleep(0.15)
    # 2) 统一点开背包（点不开的窗口不进 bag_ok，留给慢路径）
    for h in hwnds:
        if matcher.find_and_click(devs[h], "背包", timeout=5,
                                  region=BEIBAO_REGION, ccoeff_floor=0.45):
            bag_ok.append(h)
    # 3) 统一等背包加载：锚点（背包返回）确认替代盲等 2s；素材缺失退回盲等
    if bag_ok:
        ready = _wait_bags_ready(devs, bag_ok, matcher)
        if ready is None:
            time.sleep(2.0)
        else:
            if len(ready) < len(bag_ok):
                log.warning("背包页锚点未确认的窗口不点信息页: %s",
                            [h for h in bag_ok if h not in ready])
            bag_ok = ready
        # 4) 统一切到信息页
        for h in bag_ok:
            devs[h].click(*INFO_BTN_POS)
            time.sleep(0.2)
        time.sleep(1.5)   # 信息页打开动画（原每窗 1.5s 在这里重叠）
        # 5) 逐窗截图：指纹命中免 OCR；未命中 OCR 并把指纹存档
        for h in bag_ok:
            screen = devs[h].screenshot()   # 自带置顶，信息页仍开着
            results[h] = _identify_and_class(screen, characters, label=f"窗口 {h}")
        # 6) 统一关信息页回主界面（必须：后续 _in_game_window 靠主界面锚点判定）
        for h in bag_ok:
            devs[h].press_esc()
            time.sleep(0.15)
    pending = [h for h in hwnds if h not in results]
    return results, pending


def _in_game_window(hwnd, matcher):
    """窗口是否已在游戏内（**不依赖角色名是否读得出来**）。

    复用登录状态机的「已进入游戏」多路特征（主界面锚点/左上角地图名/战斗画面/
    背包+头像/右上角任务·队伍页签），见 core/login_flow.LoginFlow._is_logged_in。

    用途：preflight 里要区分两类"读不出角色名"的窗口——
      · 真空闲：停在登录界面（被顶号/刚开客户端）→ 可以复用给缺窗口的账号；
      · **占用中**：人在游戏里，只是名字没读出来（战斗中/家园/剧情对话/被面板
        遮住，read_current_character 打不开背包→返回空）→ **绝不能复用**，
        否则会把另一个账号登进这个窗口、顶掉正在玩的角色
        （用户 2026-10-12：下午会手动顶号玩所有号，17:50 才交给脚本）。
    判定失败时**保守当作"在游戏内"**（宁可少复用，不可顶错号）。
    """
    try:
        device = Device(hwnd=hwnd)
        flow = LoginFlow(device, matcher)
        return bool(flow._is_logged_in(device.screenshot()))
    except Exception:
        log.exception("判断窗口 %s 是否在游戏内失败，保守按「占用中」处理", hwnd)
        return True


# preflight 里对"无响应窗口"（IsHungAppWindow=true）的观察等待：短暂挂起很
# 常见（加载/GC），先等这么久再看它是否自愈，仍无响应才关窗（必要时强杀）重启。
PREFLIGHT_HUNG_WAIT = 15


def _device_hung(device):
    """窗口是否无响应（IsHungAppWindow）；测试桩没有 is_hung 时按"正常"处理。"""
    fn = getattr(device, "is_hung", None)
    return bool(fn()) if callable(fn) else False


def is_on_client_splash(device, matcher):
    """窗口是否停在客户端启动闪屏（诗悦 logo）。

    闪屏正常只出现几秒；若一直停在这里，说明客户端启动后卡死（实测像素
    10 分钟零变化）。这类窗口既不能配对也不能当空闲窗口复用，必须识别出来。
    """
    try:
        return matcher.find(device.screenshot(), "客户端闪屏", threshold=0.9) is not None
    except FileNotFoundError:
        return False


def _match_character(texts, characters):
    """从信息页 OCR 文本里识别当前角色名：任一已知角色名完整出现，
    或与某角色名相似度 >= 0.8。识别不出返回 None（错号/未知角色）。"""
    joined = "".join(texts)
    for ch in characters:
        if ch in joined:
            return ch
    best, best_s = None, 0.0
    for t in texts:
        for ch in characters:
            s = SequenceMatcher(None, t, ch).ratio()
            if s > best_s:
                best, best_s = ch, s
    return best if best_s >= 0.8 else None


def switch_login(device, matcher):
    """游戏内切换登录：主界面十字 → 功能页"设置" → 通用页签 → "切换登录"
    → 确认"是否退出登录？" → 回到登录界面。成功返回 True。"""
    # 主界面 → 十字功能页（点击可能被吞，打不开就再点）
    for i in range(3):
        if not matcher.find_and_click(device, "功能展开", timeout=5,
                                      region=(350, 585, 55, 55),
                                      threshold=0.88, ccoeff_floor=0.45):
            return False
        if _wait_ocr(device, "设置", FUNC_SETTINGS_REGION, 8):
            break
        log.warning("功能页未打开，重试点十字 (%d/3)", i + 1)
    else:
        log.warning("十字功能页多次点击未打开")
        return False
    # 功能页 → 设置
    hit = ocr.find_text(device.screenshot(), "设置", region=FUNC_SETTINGS_REGION,
                        min_similarity=1.0)
    log.info("点击 [设置] @ (%d, %d)", hit[0], hit[1])
    device.click(hit[0], hit[1])
    # 设置页默认停在"通用"页签；找不到"切换登录"时先点一下通用页签
    hit = _wait_ocr(device, "切换登录", SWITCH_LOGIN_REGION, 8)
    if not hit:
        tab = ocr.find_text(device.screenshot(), "通用", region=SETTINGS_TAB_REGION,
                            min_similarity=1.0)
        if tab:
            log.info("点击 [通用页签] @ (%d, %d)", tab[0], tab[1])
            device.click(tab[0], tab[1])
        hit = _wait_ocr(device, "切换登录", SWITCH_LOGIN_REGION, 6)
    if not hit:
        log.warning("设置页找不到 [切换登录] 按钮")
        return False
    log.info("点击 [切换登录] @ (%d, %d)", hit[0], hit[1])
    device.click(hit[0], hit[1])
    # 确认"是否退出登录？"
    deadline = time.time() + 8
    while time.time() < deadline:
        screen = device.screenshot()
        if ocr.contains_text(screen, "是否退出登录", region=LOGOUT_TEXT_REGION):
            cfm = ocr.find_text(screen, "确认", region=LOGOUT_CONFIRM_REGION,
                                min_similarity=1.0)
            if cfm:
                log.info("点击 [确认] 退出登录 @ (%d, %d)", cfm[0], cfm[1])
                device.click(cfm[0], cfm[1])
                break
        time.sleep(0.6)
    else:
        log.warning("未出现退出登录确认框")
        return False
    # 等回到登录界面
    return bool(_wait_ocr(device, "进入游戏", LOGIN_SCREEN_REGION, 20))


def _pair(acc, hwnd):
    """账号↔窗口配对落定：写 db 绑定 + **就地回填 acc["hwnd"]**。

    回填内存快照是必需的：调用链条里同一份 accounts 会被多次解析
    （preflight_clients 内部的 run_login_parallel、以及定时任务 _tasks_worker
    随后的 resolve_hwnds）。只写 db 的话，内存里仍是 fire 时刻的旧句柄，
    后续解析会判 dead 而跳过账号；更糟的是若旧句柄恰好"全 dead"，
    resolve_hwnds 的整批兜底会按窗口顺序**错误配对**，导致任务跑错账号。
    """
    binding.bind_account(acc["id"], hwnd)
    acc["hwnd"] = hwnd


def preflight_clients(accounts, cfg, matcher, stop_event=None):
    """定时任务触发前的客户端准备：保证每个账号都有窗口且登录进正确角色。

    2026-10-09 整改（超限事故教训）：**先识别每个窗口当前登录的是谁，
    再决定怎么做，不再无脑补开客户端**——
    1. 平铺已有窗口；
    2. 逐窗口处理省电模式（滑动解锁）与顶号（点"退出游戏"，窗口消失则
       之后重启）；
    3. 逐窗口先排除两类异常窗口：
       - 停在客户端启动闪屏（诗悦 logo）= 客户端卡死 → 关闭后重新启动；
       - 其余读当前登录角色（ESC 关浮层 → 背包 → 信息 → 名字行）：
         · 角色 == 某目标账号 → 直接配对绑定（重启过的客户端句柄会变，
           按角色配对比句柄绑定/顺序配对都可靠）；
         · 读到的是像人名的别的角色 → "错号窗口"，用切换登录修正；
         · 读不到/只读到等级数字（如 '09/141'）→ "空闲窗口"，直接登录即可；
           乱码绝不能当"错号窗口"，否则会白切换登录、失败后多开客户端。
    4. 缺窗口的账号：优先复用空闲窗口（已在登录界面无需切换），再用
       错号窗口切换登录，**都不够才启动新客户端**（防客户端数量超限）；
    5. 平铺 → 全部账号并行跑登录状态机（已在主界面的秒过）。
    返回成功登录的 hwnd 列表（调用方据此剔除登录失败的账号）。

    stop_event（2026-10-25 worker 化实测修复）：preflight 曾是停止盲区——
    任务跑起来前点"停止"毫无反应。现在各阶段边界都检查，置位即提前收工
    （返回已配对的部分名单，由调用方决定是否继续）。
    """
    def _stopped():
        return stop_event is not None and stop_event.is_set()
    keyword = cfg.get("window_keyword") or Device.DEFAULT_KEYWORD
    hwnds = Device.find_all(keyword)
    if hwnds:
        launcher.tile_windows(hwnds, **cfg.get("tile", {}))
    # 1) 省电模式解锁 + 顶号处理（顶号可能直接关窗，之后重取窗口列表）
    for hwnd in hwnds:
        if _stopped():
            log.info("preflight 收到停止请求，提前收工")
            return []
        try:
            device = Device(hwnd=hwnd)
            # 挂了一夜的客户端可能在休眠（省电模式，画面变暗）：先滑动解锁，
            # 否则顶号 OCR 与角色识别都会失灵
            dialogs.handle_sleep_mode(device, device.screenshot())
            _quit_kicked(hwnd)
        except Exception:   # noqa: BLE001
            # 单个窗口异常（如最小化窗口截图失败、客户端半死）不能拖垮整段
            # 准备——旧实现让一个坏窗口直接抛到调用方，preflight 整体退出，
            # 其余账号连登录都不做（2026-10-15 实机：5 号窗口最小化导致
            # 3 轮运行 preflight 全部秒崩）。这里跳过坏窗口，交给后面的
            # 「占用中/缺窗口」逻辑兜底。
            log.exception("窗口 %s 预处理异常，跳过该窗口继续", hwnd)
    hwnds = Device.find_all(keyword)
    # 2) 按当前登录角色配对窗口
    by_character = {a["character"]: a for a in accounts if a.get("character")}
    characters = list(by_character)
    paired = {}      # acc_id -> hwnd
    switchable = []  # 错号窗口（登录了非目标角色）
    reusable = []    # 空闲窗口（读不到角色，**已确认在登录界面**）
    busy = []        # 占用中：读不出角色名但人在游戏里（战斗中/家园/对话）

    def _classify(hwnd, ch, texts):
        """窗口分类：配对 / 错号 / 占用中 / 空闲。批量与逐窗两条路径共用。"""
        if ch:
            acc = by_character[ch]
            if acc["id"] in paired:
                switchable.append(hwnd)  # 同角色重复窗口，理论上不该出现
                return
            paired[acc["id"]] = hwnd
            _pair(acc, hwnd)
            log.info("窗口 %s 当前登录 %s，配对账号 %s", hwnd, ch, acc["account"])
        elif texts and _looks_like_name(texts):
            switchable.append(hwnd)
            log.warning("窗口 %s 当前登录 %s（非目标账号），将切换登录",
                        hwnd, "".join(texts))
        elif _in_game_window(hwnd, matcher):
            # 读不出角色名但人在游戏里：**绝不参与空闲窗口复用**。
            # 旧逻辑直接当"空闲窗口"，会被分配给缺窗口的账号并由其执行登录，
            # 把正在玩的角色顶掉/乱点（用户 2026-10-12 场景：下午手动顶号玩号）。
            busy.append(hwnd)
            log.warning("窗口 %s 在游戏内但未读出角色名（可能在战斗/家园/剧情"
                        "对话中），按「占用中」处理：不参与空闲窗口复用", hwnd)
        else:
            # 读不到角色名（登录界面/信息页没读出人名）→ 当空闲窗口直接登录。
            # 关键：只读到等级数字之类的乱码（如 '09/141'）绝不能当"错号窗口"，
            # 否则会白白去切换登录、失败后再多开一个客户端（事故根因之一）。
            reusable.append(hwnd)
            if texts:
                log.info("窗口 %s 未读出角色名（OCR=%r），按空闲窗口处理",
                         hwnd, "".join(texts))

    # 2a) 客户端卡死在启动闪屏：既不能配对也不能当空闲窗口复用，关掉它释放
    #     实例名额——否则紧接着为缺失账号启动的新客户端可能与它互相挤占而
    #     同样卡死（实测：5 个正常客户端 + 1 个闪屏卡死客户端时，新启动的
    #     第 6 个也卡在闪屏，白白拖满 300 秒登录超时）
    alive = []
    for hwnd in hwnds:
        if not win32gui.IsWindow(hwnd):
            continue
        try:
            dev = Device(hwnd=hwnd)
            if _device_hung(dev):
                # 运行中假死（IsHungAppWindow）：消息泵不响应 → 读角色/登录/点击
                # 全部做不成。先给一点时间自愈（短暂挂起常见），仍无响应就关掉重启。
                log.warning("窗口 %s 无响应（IsHungAppWindow），等待 %.0f 秒自愈",
                            hwnd, PREFLIGHT_HUNG_WAIT)
                deadline = time.time() + PREFLIGHT_HUNG_WAIT
                while time.time() < deadline and _device_hung(dev):
                    time.sleep(0.5)
                if _device_hung(dev):
                    log.warning("窗口 %s 持续无响应（客户端假死），关闭后重新启动", hwnd)
                    launcher.force_close_window(hwnd)
                    continue
            if is_on_client_splash(dev, matcher):
                log.warning("窗口 %s 停在客户端启动闪屏（客户端已卡死），关闭后重新启动",
                            hwnd)
                launcher.force_close_window(hwnd)
                continue
        except Exception:   # noqa: BLE001
            log.exception("窗口 %s 健康检查异常：按「异常窗口」关闭后重启", hwnd)
            try:
                launcher.force_close_window(hwnd)
            except Exception as e:
                log.warning("关闭异常窗口失败 hwnd=%s: %s", hwnd, e)
            continue
        alive.append(hwnd)
    hwnds = alive
    # 2b) 批量读当前角色：分批流水线 + 名字行指纹快通道（login.preflight_batch
    #     可关）。单窗口时直接走逐窗路径；批量任何异常都整体回退逐窗识别。
    results = {}
    if (cfg.get("login") or {}).get("preflight_batch", True) and len(hwnds) > 1:
        try:
            results, pending = _pair_by_names(hwnds, matcher, by_character)
        except Exception:
            log.exception("批量读角色异常，本轮回退逐窗识别")
            results, pending = {}, list(hwnds)
    else:
        pending = list(hwnds)
    for hwnd, (ch, texts) in results.items():
        _classify(hwnd, ch, texts)
    # 2c) 批量没走通的窗口走原逐窗慢路径（分类逻辑完全一致）
    for hwnd in pending:
        if _stopped():
            log.info("preflight 收到停止请求，提前收工")
            return []
        texts = read_current_character(Device(hwnd=hwnd), matcher)
        ch = _match_character(texts, characters) if texts else None
        _classify(hwnd, ch, texts)
    hwnds = [h for h in hwnds if win32gui.IsWindow(h)]   # 剔除刚关掉的卡死窗口
    # 无角色名的账号（库里没配角色）按旧逻辑句柄兜底
    charless = [a for a in accounts if not a.get("character")]
    if charless:
        resolved = binding.resolve_hwnds(charless, hwnds, keyword)
        for a in charless:
            hwnd, _ = resolved[a["id"]]
            if hwnd is not None and hwnd not in paired.values():
                paired[a["id"]] = hwnd
                a["hwnd"] = hwnd   # 回填内存（兜底猜测，不写 db 绑定）
    missing = [a for a in accounts if a["id"] not in paired]
    # 3) 缺窗口账号：绑定句柄认领「占用中」窗口 > 空闲窗口 > 切换错号窗口 > 启新客户端
    #    （绑定句柄在前：占用中的窗口多半就是该账号自己的，认领它比另找一个
    #      空闲窗口准确——否则会把占用中的窗口留给别的账号去登录）
    for acc in list(missing):
        bound = acc.get("hwnd") or 0
        if bound and bound in busy:
            busy.remove(bound)
            _pair(acc, bound)
            log.warning("账号 %s（%s）角色名读不出，按绑定句柄认领「占用中」窗口 "
                        "hwnd=%s（不动它，交给登录状态机/任务流程处置）",
                        acc["account"], acc["character"], bound)
            missing.remove(acc)
        elif reusable:
            hwnd = reusable.pop()
            _pair(acc, hwnd)
            log.info("复用空闲窗口（%s）给账号 %s（%s）", hwnd, acc["account"],
                     acc["character"])
            missing.remove(acc)
        elif switchable:
            hwnd = switchable.pop()
            log.info("窗口 %s 账号不一致，切换登录到 %s（%s）",
                     hwnd, acc["account"], acc["character"])
            if switch_login(Device(hwnd=hwnd), matcher):
                _pair(acc, hwnd)
                missing.remove(acc)
            else:
                log.error("账号 %s 切换登录失败，该窗口保持原样", acc["account"])
    if busy:
        log.warning("以下窗口在游戏内但认不出角色名，已保持原样不占用（可能需要"
                    "人工确认是哪个账号）：%s", "、".join(str(h) for h in busy))
    if missing:
        if _stopped():
            log.info("preflight 收到停止请求，不再补开客户端")
            return []
        if not cfg.get("game_exe"):
            log.error("以下账号无客户端窗口且未配置 login.game_exe，无法启动: %s",
                      "、".join(a["account"] for a in missing))
        else:
            log.info("现有窗口不足，为 %d 个账号启动客户端: %s", len(missing),
                     "、".join(a["character"] or a["account"] for a in missing))
            # launch_missing 会就地回填 acc["hwnd"]，下面的 run_login_parallel
            # 用同一份 accounts 即可拿到新句柄，不会全判 dead
            launch_missing(missing, cfg, hwnds)
    all_hwnds = Device.find_all(keyword)
    if not all_hwnds:
        log.error("preflight 后仍无任何客户端窗口")
        return []
    launcher.tile_windows(all_hwnds, **cfg.get("tile", {}))
    if _stopped():
        log.info("preflight 收到停止请求，跳过并行登录")
        return []
    log.info("客户端就绪，并行登录/校验 %d 个账号...", len(accounts))
    return run_login_parallel(accounts, cfg, matcher, stop_event=stop_event)


def main():
    setup_logging("login")
    parser = argparse.ArgumentParser()
    parser.add_argument("--ids", type=int, nargs="*", help="只登录指定 id 的账号")
    parser.add_argument("--tile", action="store_true", help="只平铺已有窗口")
    parser.add_argument("--parallel", action="store_true",
                        help="并行登录已打开的客户端窗口（不自动启动客户端）")
    args = parser.parse_args()

    with open(CONFIG_PATH, encoding="utf-8") as f:
        config = yaml.safe_load(f)
    # 路径留空/写 auto 时按注册表自动定位（写死的路径仍优先，见 core/locate.py）
    cfg = locate.apply_login_paths(config)
    keyword = cfg.get("window_keyword", config.get("window_keyword") or Device.DEFAULT_KEYWORD)

    if args.tile:
        launcher.tile_windows(Device.find_all(keyword), **cfg.get("tile", {}))
        return

    accounts = db.list_accounts()
    if args.ids:
        accounts = [a for a in accounts if a["id"] in args.ids]
    if not accounts:
        log.error("数据库中没有账号，请先运行 python gui.py 添加")
        sys.exit(1)

    if not args.parallel and not cfg.get("game_exe"):
        log.error("config.yaml 未配置 login.game_exe，且未能自动找到游戏主程序"
                  "（可运行 python core/locate.py 看探测明细）")
        sys.exit(1)

    matcher = Matcher(ASSETS_DIR, threshold=config.get("threshold", 0.85))
    if args.parallel:
        hwnds = run_login_parallel(accounts, cfg, matcher)
    else:
        hwnds = run_login(accounts, cfg, matcher)
    log.info("登录流程结束，成功 %d/%d，开始平铺窗口", len(hwnds), len(accounts))
    launcher.tile_windows(Device.find_all(keyword), **cfg.get("tile", {}))


if __name__ == "__main__":
    main()
