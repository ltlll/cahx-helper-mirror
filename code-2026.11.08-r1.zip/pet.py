# -*- coding: utf-8 -*-
"""桌面宠物 + 系统托盘（pet.py，2026-10-25 三次改版：动作系统）

默认启动不再弹出大主窗口：App 常驻但隐藏（定时巡检/试用计时/热更新全挂在
App 上，隐藏后照常运行），桌面只留一个会动的芳菲蝶恋立绘小宠物 +
系统托盘图标双通道。立绘精灵 theme/icons/pet_full.png（透明底全身抠图，
源图 F:\\短视频\\长安幻想\\初回\\人物\\芳菲蝶恋-女\\正面.png）。

交互设计参考开源桌宠惯例（Shimeji / Clover Shimeji / vscode-pets）：
所有动作都用 QPainter 时间驱动变换 + 粒子 + 台词气泡实现，零多帧素材。

- 空闲 = 「瞌睡 / 走路」二选一循环（2026-11-02 用户规则）：没动作时随机打盹
  （sleep 帧 8~20s，💤 粒子）或踱步（walk 帧走完接挥手打招呼），睡醒接着走，
  走完接着睡；点她/拖她/投喂即醒（惊跳 Q 弹 + ⭐ 粒子）。
- 任务中 = 不断循环转圈（spin 帧按累计角度连播，~3.3s 一圈）+ 头顶琥珀旋转
  徽章；结束绿/红常亮 5s。
- 任务结束 = 一律欢呼（跳跳+摆动 cheer 姿态）：成功 ✨🎉 粒子 + 庆祝气泡；
  失败动作同样是欢呼、但 💧 粒子 + 道歉气泡。
- 左键单击 = 摸摸头：Q 弹挤压回弹 + 飘心心/音符粒子 + 头顶 PetBubble
  台词气泡（鼠标穿透、1.9s 自销）；2 秒内连戳 5 次 → 晕头转向特殊反应。
- 拖动：拎起来会晃（阻尼摇摆），松手 Q 弹落定。
- 右键 = 主菜单：开始一条龙 / 开始任务 / 账号配置 / 定时任务 / 投喂
  小鱼干 / 停止任务 / 显示主面板 / 隐藏宠物 / 退出；双击 = 显示主面板。
- 投喂小鱼干：🐟 粒子落下 + 心心 + 道谢气泡（打盹会先醒来）。
- 鼠标悬停：15s 冷却的一次小摇摆（引起注意）。
- 启动问候：按当前时段冒一句问候气泡。
- 位置持久化 data/pet.json；加载时把坐标夹回屏幕可用区域（防拔副屏失踪）。

新增动作的方法：在 _pick_action 的动作池里加一项（名字+权重），再在
paintEvent 的 _act_pose() 里按名字写一段「t∈[0,1] → dy/dx/rot/sx/sy/翻转」
的映射即可；粒子用 _spawn() 任意字符+颜色。

本模块**不 import gui**（gui.py 会 import 本模块，反向 import 成循环）。
对主程序的依赖全部经构造函数注入：`PetWindow(app)` 只要求 `app` 上有
`tasks_tab` / `show_main(page=None)` / `set_pet_visible(on)` /
`PAGE_ACCOUNT` / `PAGE_TASKS` 这几个成员（离屏自检用桩对象即可）。
"""
from __future__ import annotations

import json
import logging
import math
import random
import time

from PySide6.QtCore import QPoint, QPointF, QRectF, Qt, QTimer
from PySide6.QtGui import QColor, QFont, QGuiApplication, QPainter, QPen, QPixmap
from PySide6.QtWidgets import QApplication, QLabel, QMenu, QSystemTrayIcon, QWidget

from core import yitiaolong as ytl
from core.paths import DATA_DIR
from theme.theme import ICONS_DIR, icon
from theme.tokens import Color

log = logging.getLogger("gui")

POS_PATH = DATA_DIR / "pet.json"

PET_W = 156              # 宠物窗口宽（须容纳最大帧：跳跃画布 146 宽 @170px 基准）
PET_H = 240              # 宠物窗口高（跳跃画布 222 + 腾空抬高 10 + 影子余量）
SPRITE_H = 168           # 立绘显示高（宽按原图比例；与帧动画 170px 基准一致）
CLICK_SLOP = 6           # 按下到松开位移小于它判「点击」，否则算拖拽
FLOAT_MS = 50            # 待机动画刷新间隔
SPIN_MS = 40             # 运行中徽章旋转刷新间隔
RESULT_GLOW_S = 5        # 本轮结束后结果色常亮时长
FLOAT_AMP = 3.0          # 上下浮动幅度（像素）
SWAY_DEG = 2.4           # 左右轻摆幅度（度）
BREATHE_AMP = 0.015      # 呼吸形变幅度
BOUNCE_DUR_S = 0.55      # 点击 Q 弹时长


def failure_names(failures, limit=3):
    """失败清单 → 托盘提示用的"任务名"串。

    `last_failures` 由 gui.TasksTab._on_finished 生成，元素是**字符串**
    （"5:角色 · 任务标题"）；历史实现按 dict 取 `.get("task")`，每轮结束必
    AttributeError（2026-10-30 17:51、10-31 07:32 两次 crash.log 同一行 825）。
    两种形态都兼容：dict 取 task 字段，字符串原样用。
    """
    out = []
    for f in list(failures or [])[:limit]:
        out.append(str(f.get("task") or "?") if isinstance(f, dict) else str(f))
    return "、".join(out)


ACT_MIN_S = 5            # 插入离散动作（走/睡）的间隔范围
ACT_MAX_S = 12
NAP_MIN_S = 8.0          # 空闲打盹时长（2026-11-02 用户规则：空闲=瞌睡/走路）
NAP_MAX_S = 20.0
RUN_SPIN_DPS = 110.0     # 任务中循环转圈速度（度/秒，~3.3s 一圈）
SPIN_SETTLE_DPS = 540.0  # 进动作前旋转角向 0 收拢的速度（最短路径，衔接平滑）
SPIN_PROFILE_MIN = 0.22  # 立转最窄水平压缩（侧面轮廓比例，避免压成纸片线）
WALK_DIST = 34           # 踱步动作的真实平移距离（像素）
SLEEP_AFTER_S = 180      # 无交互多久自动打盹
POKE_WINDOW_S = 2.0      # 连戳计数窗口
POKE_N = 5               # 连戳几次触发晕头转向
HOVER_COOL_S = 15        # 悬停小动作冷却

FRAMES_DIR = ICONS_DIR / "pet_frames"   # 帧动画精灵表 <action>/NN.png + meta.json
FRAME_FPS = 7.0          # 帧动画默认帧率
WALK_FPS = 5.0           # 走路帧率（素材 0.25s/帧，5fps ≈ 1.25 倍速更利落）
RUN_FPS = 6.0            # 小跑帧率（比走路略快，显轻快）
JUMP_FPS = 5.0           # 跳跃帧率（放慢让下蹲/腾空/落地看得清）
WAVE_FPS = 6.0           # 挥手帧率
WALK_BOB_AMP = 2.6       # 走路帧上叠加的颠步幅度（长裙挡腿时强化步感）
JUMP_LIFT = 10.0         # 腾空帧上叠加的额外升高（强化屈腿跳高度）
WALK_FACES_LEFT = True   # 侧面走路素材原生朝左：往右走需镜像（翻转逻辑取反）
SLEEP_FRAME_FPS = 2.5    # 打盹帧循环放慢
TARGET_CHAR_H = 170.0    # 精灵表构建时的角色高基准（meta.json 里同步存）

# 空闲动作池（2026-11-02 用户规则：没动作时只用「瞌睡 / 走路」），
# 行走结束自动衔接挥手打招呼（_end_action 链式触发）
ACTION_POOL = {
    "walk":  (0.50, None),   # 踱步：走完接挥手
    "sleep": (0.50, None),   # 打盹：时长随机 NAP_MIN_S~NAP_MAX_S
}

PET_PHRASES_IDLE = (
    "在的哦~", "喵~有事叫我", "任务交给我吧♪", "戳我干嘛呀~",
    "今天也要加油鸭", "(=^･ω･^=)", "双击我可以看主面板哦",
)
PET_PHRASES_BUSY = (
    "正在跑任务哦~", "别急，马上就好", "大家都在努力中♪",
    "右键可以停止任务", "进度不错哦！",
)
PET_PHRASES_WAKE = ("哇！吓我一跳！", "呼啊…我睡着了呢", "来了来了~")
PET_PHRASES_DIZZY = ("再戳就要坏掉啦！(＞﹏＜)", "呜哇——别戳了", "头晕眼花中…")
PET_PHRASES_FED = ("谢谢款待，小鱼干好好吃♪", "唔，最爱小鱼干了！", "投喂+1，心情真好~")
PET_PHRASES_OK_DONE = ("任务全部完成！好耶♪", "全部搞定，夸我！", "收工！去休息咯~")
PET_PHRASES_FAIL = ("有失败项…主人看看吧(ó﹏ò｡)", "呜，有几个任务没成功…")


def _greeting_phrase() -> str:
    """按当前时段给一句开机问候。"""
    h = time.localtime().tm_hour
    if h < 6:
        return "夜深了，主人早点休息哦…"
    if h < 11:
        return "早上好！今天也从我开始的哦~"
    if h < 14:
        return "中午好，记得吃饭呀♪"
    if h < 18:
        return "下午好，困了可以让我打盹~"
    return "晚上好，今天的任务交给我吧♪"


_BUBBLE_QSS = f"""
QLabel {{
    background: {Color.SURFACE}; color: {Color.TEXT_PRIMARY};
    border: 1px solid {Color.PRIMARY_BORDER}; border-radius: 10px;
    padding: 5px 12px; font-size: 12px;
}}
"""


def load_pos() -> tuple[int, int] | None:
    try:
        d = json.loads(POS_PATH.read_text(encoding="utf-8"))
        return int(d["x"]), int(d["y"])
    except Exception:
        return None


def save_pos(x: int, y: int) -> None:
    try:
        POS_PATH.write_text(json.dumps({"x": int(x), "y": int(y)}),
                            encoding="utf-8")
    except Exception:
        log.exception("宠物位置写入失败")


def clamp_to_screen(x: int, y: int,
                    size: tuple[int, int] = (PET_W, PET_H)) -> tuple[int, int]:
    """把坐标夹回所在屏幕的可用区域（副屏拔掉后坐标可能落到虚空）。"""
    screen = QGuiApplication.screenAt(QPoint(x, y)) or QGuiApplication.primaryScreen()
    geo = screen.availableGeometry()
    cx = min(max(x, geo.left()), geo.right() - size[0])
    cy = min(max(y, geo.top()), geo.bottom() - size[1])
    return cx, cy


class PetBubble(QLabel):
    """点击宠物时头顶冒出的台词气泡：无边框置顶、鼠标穿透、自动销毁。"""

    def __init__(self, text: str, anchor_top_center: QPoint):
        super().__init__(text)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint
                            | Qt.Tool | Qt.WindowTransparentForInput)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WA_ShowWithoutActivating, True)
        self.setStyleSheet(_BUBBLE_QSS)
        self.adjustSize()
        x = anchor_top_center.x() - self.width() // 2
        y = anchor_top_center.y() - self.height() - 6
        screen = (QGuiApplication.screenAt(anchor_top_center)
                  or QGuiApplication.primaryScreen())
        geo = screen.availableGeometry()
        x = min(max(x, geo.left() + 4), geo.right() - self.width() - 4)
        y = max(y, geo.top() + 4)
        self.move(x, y)
        self.show()
        QTimer.singleShot(1900, self.deleteLater)


class PetWindow(QWidget):
    """会动的桌面宠物（芳菲蝶恋立绘）。无边框、置顶、不进任务栏（Qt.Tool）。"""

    def __init__(self, app):
        super().__init__()
        self._app = app
        self._tasks = app.tasks_tab
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint
                            | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setFixedSize(PET_W, PET_H)
        self.setWindowTitle("任务管家宠物")
        self.setWindowIcon(icon("app-icon.ico"))
        self.setToolTip("芳菲蝶恋\n左键：摸摸她 · 右键：菜单 · "
                        "双击：主面板 · 拖动：移动 · 没事多戳戳")

        # ---- 立绘精灵（透明底全身；缺失回退旧圆形头像）----
        self._sprite = QPixmap((ICONS_DIR / "pet_full.png").as_posix())
        if self._sprite.isNull():
            log.warning("宠物立绘缺失：%s（回退圆形头像 pet.png）",
                        ICONS_DIR / "pet_full.png")
            self._sprite = QPixmap((ICONS_DIR / "pet.png").as_posix())
        if self._sprite.isNull():
            log.warning("宠物头像缺失：%s（跑 tools/make_pet_avatar.py 生成）",
                        ICONS_DIR / "pet.png")
        aspect = self._sprite.width() / max(1, self._sprite.height())
        self._disp_h = 88.0 if aspect > 0.9 else float(SPRITE_H)  # 圆头像兜底小些
        self._disp_w = self._disp_h * aspect
        # 2x 超采样副本：旋转/形变时边缘更细腻
        self._sprite_hi = self._sprite.scaled(
            max(1, round(self._disp_w * 2)), max(1, round(self._disp_h * 2)),
            Qt.KeepAspectRatio, Qt.SmoothTransformation)

        self._press_pos = None      # 按下时的全局坐标（点击/拖拽判定）
        self._dragging = False
        self._phase = 0.0           # 待机动画相位（浮动/摆动/呼吸共用）
        self._angle = 0             # 运行中徽章旋转角
        self._running = False
        self._glow_until = 0.0      # 结束结果色常亮截止时刻
        self._glow_ok = True
        self._bounce_start: float | None = None  # 点击 Q 弹开始时刻
        self._parts: list[dict] = []             # 粒子（任意字符+颜色）

        # ---- 动作系统状态 ----
        self._act: dict | None = None            # 当前动作 {name,start,dur,dir}
        self._pending_act: dict | None = None    # 待启动动作（先转正再开始）
        self._next_act_at = time.monotonic() + random.uniform(3.0, 8.0)
        self._spin_angle = 0.0                   # 立转角（空闲恒 0；进动作前收拢用）
        self._run_spin = 0.0                     # 任务中循环转圈累计角（度）
        self._flip = False                       # 立绘水平镜像（朝左踱步）
        self._sleep_since: float | None = None   # 打盹开始时刻（None=清醒）
        self._zzz_at = 0.0                       # 下一个 💤 粒子时刻
        self._last_touch = time.monotonic()      # 最近一次交互（点击/拖动/投喂）
        self._pokes: list[float] = []            # 连戳时间戳
        self._hover_at = 0.0                     # 悬停小动作上次触发

        # ---- 帧动画精灵表（缺失时对应动作回退变换动画）----
        self._frames: dict[str, list] = {}       # action -> [QPixmap]
        self._frames_size: dict[str, tuple] = {} # action -> (disp_w, disp_h)
        self._load_frames()
        # 动作池：空闲只用「瞌睡 / 走路」（2026-11-02 用户规则）
        self._pool = dict(ACTION_POOL)

        self._float_timer = QTimer(self)
        self._float_timer.setInterval(FLOAT_MS)
        self._float_timer.timeout.connect(self._float_tick)
        self._float_timer.start()

        self._spin_timer = QTimer(self)
        self._spin_timer.setInterval(SPIN_MS)
        self._spin_timer.timeout.connect(self._spin_tick)

        # 运行状态跟随：tasks_finished 信号 + 轻量轮询 _running（起跑瞬间
        # 没有信号，轮询兜底；300ms 一次只读内存标志，开销可忽略）
        self._poll = QTimer(self)
        self._poll.setInterval(300)
        self._poll.timeout.connect(self._sync_running)
        self._poll.start()
        finished = getattr(self._tasks, "tasks_finished", None)
        if finished is not None:
            finished.connect(self._on_tasks_finished)

        pos = load_pos()
        if pos is None:
            geo = QGuiApplication.primaryScreen().availableGeometry()
            pos = (geo.right() - PET_W - 40, geo.bottom() - PET_H - 120)
        self.move(*clamp_to_screen(*pos))

        # 开机问候（1s 后冒泡，避开启动瞬间的窗口抖动）
        QTimer.singleShot(1000, self._greet)

    # ------------------------------------------------------------------
    # 动作系统

    def _load_frames(self) -> None:
        """加载帧动画精灵表（theme/icons/pet_frames/<action>/NN.png）。
        meta.json 记录 target_char_h（构建时的角色像素高基准），运行时按
        SPRITE_H 等比缩放；画布底边=地面线（联合 bbox 保证帧间位移不丢）。"""
        try:
            meta = json.loads((FRAMES_DIR / "meta.json").read_text("utf-8"))
        except Exception:
            return
        for tag, m in meta.items():
            if not isinstance(m, dict):
                continue
            pngs = sorted((FRAMES_DIR / tag).glob("*.png"))
            if len(pngs) < 2:
                continue
            frames = [QPixmap(f.as_posix()) for f in pngs]
            frames = [f for f in frames if not f.isNull()]
            if len(frames) < 2:
                continue
            k = SPRITE_H * 1.02 / float(m.get("target_char_h", TARGET_CHAR_H))
            # 2x 超采样：绘制时从 2 倍大图缩到显示尺寸，边缘/衣纹更清晰
            frames = [f.scaled(f.width() * 2, f.height() * 2,
                               Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
                      for f in frames]
            self._frames[tag] = frames
            self._frames_size[tag] = (m["canvas_w"] * k, m["canvas_h"] * k)
        if self._frames:
            log.info("宠物帧动画加载: %s",
                     {k: len(v) for k, v in self._frames.items()})

    def _pick_action(self, now: float) -> None:
        """按权重随机挑一个空闲动作（瞌睡 / 走路）。"""
        names = list(self._pool)
        weights = [self._pool[n][0] for n in names]
        name = random.choices(names, weights=weights, k=1)[0]
        if name == "sleep":                  # 打盹：随机睡 8~20s，到点自己醒
            self._pending_act = {"name": "sleep", "start": now,
                                 "dur": random.uniform(NAP_MIN_S, NAP_MAX_S),
                                 "frames": True, "loop": True}
            return
        act = {"name": name, "start": now,
               "dur": random.uniform(1.2, 2.2)}   # 踱步：时长随机，方向随机
        if name == "walk":
            act["dir"] = random.choice((-1, 1))
            if name in self._frames:         # 帧走路：一个完整循环 + 窗口渐移
                act["frames"] = True
                act["loop"] = True
                act["dur"] = len(self._frames["walk"]) / WALK_FPS
        self._pending_act = act              # 先等旋转角转正，再开始动作

    def _end_action(self, now: float) -> None:
        """动作收尾。帧走路已通过窗口渐移落位；走完自动衔接挥手打招呼。"""
        act, self._act = self._act, None
        if act and act["name"] == "sleep":
            self._sleep_since = None         # 睡到点自然醒（不播惊跳）
            self._zzz_at = 0.0
            self._next_act_at = now + random.uniform(1.5, 4.0)
            return
        if act and act["name"] == "walk":
            if act.get("frames"):
                self._flip = False         # 侧面走完转回正面（避免一直侧脸）
                if "wave" in self._frames: # 行走后接打招呼（链式动作）
                    self._act = {"name": "wave", "start": now,
                                 "dur": len(self._frames["wave"]) / WAVE_FPS,
                                 "frames": True}
                    return                 # 挥手结束时再排下一个动作
            else:
                self._flip = act.get("dir", 1) < 0
                nx, ny = self.x() + act.get("dir", 1) * WALK_DIST, self.y()
                self.move(*clamp_to_screen(nx, ny))
        self._next_act_at = now + random.uniform(ACT_MIN_S, ACT_MAX_S)

    def _act_pose(self, now: float) -> dict:
        """当前动作 → 姿态参数（dy/dx/rot/sx/sy/flip）。"""
        act = self._act
        t = min(1.0, max(0.0, (now - act["start"]) / act["dur"]))
        name = act["name"]
        pose = {"dy": 0.0, "dx": 0.0, "rot": 0.0, "sx": 1.0, "sy": 1.0}
        if name == "hop":
            pose["dy"] -= 20 * math.sin(math.pi * t)
            pose["sy"] += 0.10 * math.sin(math.pi * t)
            pose["sx"] -= 0.08 * math.sin(math.pi * t)
        elif name == "walk":
            d = act.get("dir", 1)
            ease = t * t * (3 - 2 * t)                    # smoothstep
            pose["dx"] = d * WALK_DIST * ease
            pose["flip"] = d < 0
            step = math.sin(t * math.pi * 6)
            pose["dy"] -= 2.2 * abs(step)
            pose["rot"] = 2.0 * step * d
        elif name == "stretch":
            w = math.sin(math.pi * t)
            pose["sy"] += 0.08 * w
            pose["sx"] -= 0.06 * w
        elif name == "nod":
            pose["rot"] = 5.0 * math.sin(t * math.pi * 2)
        elif name == "wiggle":
            pose["rot"] = 6.0 * math.sin(t * math.pi * 4)
        elif name == "spin":
            pose["rot"] = 360.0 * (t * t * (3 - 2 * t))   # 转一整圈
        elif name == "sleep":
            pass                 # 睡姿交给 sleep 帧（无帧时走 _sleep_pose 变换）
        elif name == "cheer":
            pose["dy"] -= 14 * abs(math.sin(t * math.pi * 2))
            pose["rot"] = 8.0 * math.sin(t * math.pi * 2)
        return pose

    def _sleep_pose(self, now: float) -> dict:
        """打盹姿态：下蹲 + 慢呼吸（轻微）。"""
        br = 0.008 * math.sin(self._phase * 0.3)
        return {"dy": 7.0, "dx": 0.0, "rot": 5.5,
                "sx": 1.05 + br, "sy": 0.90 - br}

    def _pirouette(self, deg: float) -> tuple:
        """小彩旗式立转（绕竖直轴的舞者旋转，参考舞剧「小彩旗」）。

        不是纸片绕平面打转（Z 轴旋转，90° 时压成一条线），而是模拟
        身体绕竖直轴转：正面→侧面→背身（镜像）→侧面→正面，像真人
        转圈。返回 (sx, flip, dy, rot)：
        sx    水平压缩系数（最窄留侧面轮廓宽，不会消失成竖线）
        flip  转过背身后是否镜像（背身用镜像近似）
        dy    踮脚小弹跳（每半圈一个起伏，舞剧节拍感）
        rot   转身时身体的自然倾斜（±2°）
        """
        th = math.radians(deg)
        c = math.cos(th)
        sx = max(SPIN_PROFILE_MIN, abs(c))
        flip = c < 0.0
        dy = -2.0 * abs(math.sin(th))
        rot = 2.0 * math.sin(th)
        return sx, flip, dy, rot

    def _touch(self) -> None:
        """任意交互统一入口：刷新交互时间；打盹中则惊醒。"""
        self._last_touch = time.monotonic()
        if self._sleep_since is not None:
            self._sleep_since = None
            self._act = None
            self._pending_act = None
            self._bounce_start = self._last_touch
            self._spawn("⭐", 4, vy=(-40, -24))
            self._say(random.choice(PET_PHRASES_WAKE))

    def _greet(self) -> None:
        if self.isVisible():
            self._say(_greeting_phrase())

    def _say(self, text: str) -> None:
        try:
            PetBubble(text, QPoint(self.x() + PET_W // 2, self.y() - 2))
        except Exception:
            log.exception("宠物气泡显示失败")

    # ------------------------------------------------------------------
    # 粒子

    def _spawn(self, chars: str | tuple, n: int = 6, *,
               x_center: float | None = None, y_base: float | None = None,
               spread: tuple = (-14, 14), vy: tuple = (-52, -34),
               vx: tuple = (-16, 16), size: tuple = (11, 16),
               life: tuple = (0.8, 1.3), colors: tuple = (),
               fall: bool = False) -> None:
        """在宠物身上撒一把粒子。chars/colors 可传元组随机挑。
        fall=True 时粒子从头顶上方落下（投喂用）。"""
        xc = PET_W / 2 if x_center is None else x_center
        yb = PET_H - 44 if y_base is None else y_base
        for _ in range(n):
            self._parts.append({
                "x": xc + random.uniform(*spread),
                "y": (PET_H - self._disp_h - 14 + random.uniform(-8, 8)
                      if fall else yb + random.uniform(-10, 10)),
                "vx": random.uniform(*vx),
                "vy": random.uniform(*vy),
                "age": 0.0,
                "life": random.uniform(*life),
                "ch": random.choice(tuple(chars)),
                "col": random.choice(colors) if colors else None,
                "size": random.uniform(*size),
            })

    # ------------------------------------------------------------------
    # 反馈动作

    def _playful(self):
        """左键摸摸头：Q 弹 + 心心 + 台词；连戳触发晕头转向。"""
        now = time.monotonic()
        self._touch()
        self._pokes = [t for t in self._pokes if now - t < POKE_WINDOW_S]
        self._pokes.append(now)
        if len(self._pokes) >= POKE_N:
            self._pokes.clear()
            self._say(random.choice(PET_PHRASES_DIZZY))
            self._spawn("💫", 5, vy=(-30, -14))
        else:
            phrases = PET_PHRASES_BUSY if self._running else PET_PHRASES_IDLE
            self._say(random.choice(phrases))
            self._spawn(("♥", "♥", "♪"), 6)
        # 有挥手帧（theme/icons/pet_frames/wave/）就播挥手，否则 Q 弹
        if ("wave" in self._frames and not self._running
                and not self._dragging):
            self._pending_act = {"name": "wave", "start": time.monotonic(),
                                 "dur": len(self._frames["wave"]) / WAVE_FPS,
                                 "frames": True}
            self._bounce_start = None
        self.update()

    def _feed(self):
        """投喂小鱼干：🐟 落下 + 心心 + 道谢（打盹会先醒）。"""
        self._touch()
        self._spawn("🐟", 4, vy=(46, 30), vx=(-10, 10),
                    life=(1.0, 1.4), fall=True)
        self._bounce_start = time.monotonic()
        self._spawn(("♥", "♪"), 5)
        self._say(random.choice(PET_PHRASES_FED))
        self.update()

    def _celebrate(self, ok: bool):
        """本轮任务收尾：一律欢呼（2026-11-02 用户规则「任务结束就欢呼」），
        成败只差粒子与台词：成功 ✨🎉 + 庆祝，失败 💧 + 道歉。"""
        now = time.monotonic()
        self._pending_act = {"name": "cheer", "start": now, "dur": 1.2}
        if ok:
            self._spawn(("✨", "🎉"), 8, vy=(-46, -26), life=(1.0, 1.5))
            self._say(random.choice(PET_PHRASES_OK_DONE))
        else:
            self._spawn(("💧", "✨"), 6, vy=(-30, -16), life=(0.9, 1.3))
            self._say(random.choice(PET_PHRASES_FAIL))

    # ------------------------------------------------------------------
    # 外观

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        now = time.monotonic()

        # ---- 姿态参数：位移 dy/dx、旋转 rot、形变 sx/sy、镜像 flip ----
        dy = dx = rot = 0.0
        sx = sy = 1.0
        flip = self._flip
        sprite = self._sprite_hi
        disp_w, disp_h = self._disp_w, self._disp_h
        layers = [(sprite, disp_w, disp_h, 1.0)]   # 绘制图层（立转可为多层）
        if self._running:
            # 干活 = 不断循环转圈（2026-11-02 用户规则）：spin 帧按累计角
            # 连播；无帧素材时回退 cos 压缩近似立转。徽章照常转。
            if "spin" in self._frames:
                fl = self._frames["spin"]
                idx = int(self._run_spin / 360.0 * len(fl)) % len(fl)
                layers = [(fl[idx], *self._frames_size["spin"], 1.0)]
            else:
                tsx, tflip2, tdy, trot = self._pirouette(self._run_spin)
                sx *= tsx
                flip = flip != tflip2
                dy += tdy
                rot += trot
        elif self._dragging:                        # 被拎起来：晃来晃去
            rot = 6.0 * math.sin(now * 10)
            sx, sy = 1.04, 0.94
        else:
            if self._sleep_since is not None:       # 打盹（无 sleep 帧时的变换兜底）
                sp = self._sleep_pose(now)
                dy, rot, sx, sy = sp["dy"], sp["rot"], sp["sx"], sp["sy"]
            else:                                   # 常态：轻浮动 + 呼吸
                # （空闲不再立转——没动作时由动作池随机插入瞌睡/走路，2026-11-02）
                dy = -FLOAT_AMP * math.sin(self._phase)
                br = BREATHE_AMP * math.sin(self._phase * 0.35)
                sx = 1.0 + br
                sy = 1.0 - br * 0.8
            if self._act is not None:
                ap = self._act_pose(now)
                dy += ap["dy"]; dx += ap["dx"]; rot += ap["rot"]
                sx *= ap["sx"]; sy *= ap["sy"]
                flip = ap.get("flip", flip)
        if self._bounce_start is not None:          # 点击 Q 弹（挤压回弹）
            t = (now - self._bounce_start) / BOUNCE_DUR_S
            if t >= 1.0:
                self._bounce_start = None
            else:
                wob = math.sin(t * math.pi * 3) * 0.16 * (1.0 - t)
                sy += wob
                sx -= wob

        # ---- 帧动画分支：选中当前帧，姿态交给帧本身（位移已烘进帧里）----
        # （动作经 _pending_act 转正后才启动，播放时旋转角已是 0，无需再压缩）
        act = self._act
        if (act is not None and act.get("frames") and not self._dragging
                and act["name"] in self._frames):
            fl = self._frames[act["name"]]
            n = len(fl)
            fps = {"walk": WALK_FPS, "jump": JUMP_FPS, "run": RUN_FPS,
                   "wave": WAVE_FPS, "sleep": SLEEP_FRAME_FPS}.get(
                       act["name"], FRAME_FPS)
            if act.get("loop"):
                idx = int((now - act["start"]) * fps) % n
            else:
                idx = min(n - 1, int((now - act["start"]) * fps))
            sprite = fl[idx]
            disp_w, disp_h = self._frames_size[act["name"]]
            layers = [(sprite, disp_w, disp_h, 1.0)]
            dy = dx = rot = 0.0
            sx = sy = 1.0
            # 侧面走路素材原生朝左：往右走才镜像；其余动作素材朝前不翻
            flip = (WALK_FACES_LEFT and act.get("dir", 1) > 0
                    if act["name"] == "walk" else False)
            # ---- 帧上叠加的步态/腾空夸张（长裙挡腿时动作仍可读）----
            if act["name"] == "walk":
                # 颠步：随帧号 2 帧一个周期上下颠，与脚步同步（循环处连续）
                dy = -WALK_BOB_AMP * abs(math.sin(math.pi * idx))
                rot += 1.2 * math.sin(math.pi * idx * 0.5)
            elif act["name"] == "run":
                dy = -2.0 * abs(math.sin(math.pi * idx))   # 小跑轻颠
            elif act["name"] == "jump":
                # 腾空帧再抬高一点 + 落地帧轻微压扁，强化「跳」的弹感
                dy = -{"3": 5.0, "4": JUMP_LIFT, "5": 5.0}.get(str(idx), 0.0)
                if idx == n - 1:
                    sy = 0.96
        elif (self._sleep_since is not None and "sleep" in self._frames
                and not self._dragging and not self._running):
            fl = self._frames["sleep"]
            idx = int((now - self._sleep_since) * SLEEP_FRAME_FPS) % len(fl)
            sprite = fl[idx]
            disp_w, disp_h = self._frames_size["sleep"]
            layers = [(sprite, disp_w, disp_h, 1.0)]
            dy = rot = 0.0
            sx = sy = 1.0

        # 地面软影子（跳得越高影子越小越淡；宽度取最宽图层）
        air = max(0.0, -dy) / 20.0
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(0, 0, 0, max(14, int(34 * (1.0 - air)))))
        p.drawEllipse(QPointF(PET_W / 2, PET_H - 8),
                      max(lw for _, lw, _, _ in layers) * 0.30
                      * (1.0 - 0.25 * air), 4.2)

        # 立绘/帧/视角：以脚底中心为锚点做镜像/旋转/形变（多层=交叉淡化）
        p.save()
        p.translate(PET_W / 2 + dx, PET_H - 6 + dy)
        p.rotate(rot)
        p.scale(-1.0 if flip else 1.0, 1.0)
        p.scale(sx, sy)
        for lpm, lw, lh, lop in layers:
            if lop < 1.0:
                p.setOpacity(max(0.0, min(1.0, lop)))
            p.drawPixmap(QRectF(-lw / 2, -lh, lw, lh),
                         lpm, QRectF(lpm.rect()))
            if lop < 1.0:
                p.setOpacity(1.0)
        p.restore()

        # 粒子（任意字符，上飘或下落渐隐）
        if self._parts:
            f = QFont(self.font())
            for pt in self._parts:
                k = max(0.0, 1.0 - pt["age"] / pt["life"])
                col = QColor(pt["col"]) if pt["col"] else QColor(
                    "#E8638C" if pt["ch"] == "♥" else Color.PRIMARY)
                col.setAlpha(int(235 * k))
                f.setPixelSize(int(pt["size"]))
                p.setFont(f)
                p.setPen(QPen(col))
                p.drawText(QPointF(pt["x"], pt["y"]), pt["ch"])

        # 状态徽章（头顶右侧小圆点；空闲时不画，保持干净）
        if self._running:
            color, spin = QColor(Color.WARNING), True
        elif now < self._glow_until:
            color = QColor(Color.SUCCESS if self._glow_ok else Color.DANGER)
            spin = False
        else:
            color, spin = None, False
        if color is not None:
            r = 6.0
            rect = QRectF(PET_W - 15 - r, 15 - r, r * 2, r * 2)
            pen = QPen(color, 3)
            pen.setCapStyle(Qt.RoundCap)
            p.setPen(pen)
            p.setBrush(Qt.NoBrush)
            if spin:
                p.drawArc(rect, -self._angle * 16, 300 * 16)
            else:
                p.setBrush(color)
                p.drawEllipse(rect)
        p.end()

    # ------------------------------------------------------------------
    # 动画与状态

    def _float_tick(self):
        now = time.monotonic()
        dt = FLOAT_MS / 1000.0
        if not self._running and not self._dragging:
            self._phase = (self._phase + 0.06) % (2 * math.pi)
            # 空闲不再立转（2026-11-02：没动作时=瞌睡/走路动作池），旋转角
            # 只在「进动作前」收拢到 0（衔接对齐正面首帧）；空闲恒 0。
            if (self._sleep_since is not None or self._act is not None
                    or self._pending_act is not None):
                da = ((-self._spin_angle) + 180.0) % 360.0 - 180.0
                step = math.copysign(min(abs(da), SPIN_SETTLE_DPS * dt), da)
                self._spin_angle = (self._spin_angle + step) % 360.0
                # 待启动动作：旋转角转正到正面后才真正开始（衔接无跳变）
                if (self._pending_act is not None and abs(da) < 6.0
                        and self._act is None and self._sleep_since is None):
                    self._act, self._pending_act = self._pending_act, None
                    if self._act["name"] == "sleep":   # 真开始睡了：进打盹态
                        self._sleep_since = now
                        self._zzz_at = now + 0.8
                        self._say("Zzz…")
            else:
                self._spin_angle = 0.0
            if self._sleep_since is not None:       # 打盹：定时冒 💤
                if now >= self._zzz_at:
                    self._zzz_at = now + 2.6
                    self._spawn("💤", 1, x_center=PET_W / 2 + 16, y_base=24,
                                spread=(-4, 4), vy=(-16, -8), vx=(-4, 4),
                                size=(12, 15), life=(1.6, 2.2))
                # sleep 动作睡满自然醒（打盹态与 sleep 动作并存，
                # 结束检查必须放在这个分支里，否则永远醒不来）
                act = self._act
                if act is not None and act["name"] == "sleep" \
                        and now - act["start"] >= act["dur"]:
                    self._end_action(now)
            elif self._act is not None:
                # 帧走路：窗口随帧渐移（真实在桌面上走，收尾不用瞬移）
                act = self._act
                if act["name"] == "walk" and act.get("frames"):
                    step = act.get("dir", 1) * WALK_DIST * (dt / act["dur"])
                    self.move(*clamp_to_screen(int(self.x() + step), self.y()))
                if now - act["start"] >= act["dur"]:
                    self._end_action(now)
            elif (self._bounce_start is None and self._pending_act is None
                  and now >= self._next_act_at
                  and now - self._last_touch >= 1.0):
                self._pick_action(now)
            # 长时间无交互 → 强制安排一次打盹（走动作池，睡 8~20s 自然醒，
            # 不会像旧版那样睡死到被戳）
            if (self._sleep_since is None and self._act is None
                    and self._pending_act is None
                    and self._bounce_start is None
                    and now - self._last_touch >= SLEEP_AFTER_S):
                self._pending_act = {"name": "sleep", "start": now,
                                     "dur": random.uniform(NAP_MAX_S,
                                                           NAP_MAX_S * 1.5),
                                     "frames": True, "loop": True}
                self._next_act_at = now + SLEEP_AFTER_S
        else:
            self._act = None                        # 拖动不打动作
            self._pending_act = None
            if self._running:
                # 任务中循环转圈：累计角推进，spin 帧按角度取帧（paintEvent）
                self._run_spin = (self._run_spin + RUN_SPIN_DPS * dt) % 360.0
        if self._parts:
            for pt in self._parts:
                pt["age"] += dt
                pt["x"] += pt["vx"] * dt
                pt["y"] += pt["vy"] * dt
                if pt["vy"] < 0:
                    pt["vy"] += 22 * dt             # 上飘微减速
                else:
                    pt["vy"] += 10 * dt             # 下落微加速
            self._parts = [pt for pt in self._parts if pt["age"] < pt["life"]]
        self.update()

    def _spin_tick(self):
        self._angle = (self._angle + 8) % 360
        self.update()

    def _sync_running(self):
        running = bool(getattr(self._tasks, "_running", False))
        if running == self._running:
            return
        self._running = running
        if running:
            self._act = None
            self._sleep_since = None
            self._last_touch = time.monotonic()
            self._spin_timer.start()
        else:
            self._spin_timer.stop()
        self._refresh_tooltip()
        self.update()

    def _refresh_tooltip(self):
        if not self._running:
            self.setToolTip("芳菲蝶恋\n左键：摸摸她 · 右键：菜单 · "
                            "双击：主面板 · 拖动：移动 · 没事多戳戳")
            return
        rows = getattr(self._tasks, "_rows_state", {}) or {}
        total = len(rows)
        done = sum(1 for r in rows.values()
                   if r.get("done", 0) >= r.get("total", 1))
        current = next((f"{r['acc']}：{r['current']}" for r in rows.values()
                        if r.get("current")), "")
        self.setToolTip(f"任务运行中：{done}/{total} 个账号完成\n{current}"
                        "\n右键：菜单（可停止）")

    def _on_tasks_finished(self):
        failures = getattr(self._tasks, "last_failures", None) or []
        self._glow_ok = not failures
        self._glow_until = time.monotonic() + RESULT_GLOW_S
        self._sleep_since = None                 # 收工叫醒看结果
        self._last_touch = time.monotonic()
        self._sync_running()
        self._celebrate(not failures)
        tray = getattr(self._app, "tray", None)
        if tray is not None:
            rows = getattr(self._tasks, "_rows_state", {}) or {}
            total = len(rows)
            if failures:
                # last_failures 是**字符串**列表（gui.py `_on_finished` 存的是
                # "5:角色 · 任务标题"），老代码按 dict 取 .get("task") → 每轮
                # 结束必抛 AttributeError（2026-10-30 17:51 / 10-31 07:32 两次
                # crash.log 同一处），托盘提示永远发不出去还把主线程带崩。
                names = failure_names(failures)
                tray.showMessage("任务管家", f"本轮结束，{len(failures)} 项失败：{names}",
                                 QSystemTrayIcon.Warning, 5000)
            elif total:
                tray.showMessage("任务管家", f"本轮任务全部完成（{total} 个账号）",
                                 QSystemTrayIcon.Information, 4000)

    # ------------------------------------------------------------------
    # 交互

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._touch()
            self._press_pos = e.globalPosition().toPoint()
            self._dragging = False
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        if self._press_pos is not None:
            gp = e.globalPosition().toPoint()
            if not self._dragging and (gp - self._press_pos).manhattanLength() > CLICK_SLOP:
                self._dragging = True
                self._last_touch = time.monotonic()
            if self._dragging:
                self.move(self.pos() + gp - self._press_pos)
                self._press_pos = gp
                return
        super().mouseMoveEvent(e)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self._press_pos is not None:
            if self._dragging:
                save_pos(self.x(), self.y())
                self._bounce_start = time.monotonic()   # 落地 Q 弹
                self._spawn("✨", 3, vy=(-28, -14), life=(0.5, 0.8))
            else:
                self._playful()             # 左键单击 = 摸摸头反馈
            self._press_pos = None
            self._dragging = False
            return
        super().mouseReleaseEvent(e)

    def mouseDoubleClickEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._touch()
            self._press_pos = None
            self._dragging = False
            self._app.show_main()
            return
        super().mouseDoubleClickEvent(e)

    def enterEvent(self, e):
        """鼠标悬停：冷却内一次小摇摆（引起注意）。"""
        now = time.monotonic()
        if (now - self._hover_at >= HOVER_COOL_S and not self._running
                and not self._dragging and self._sleep_since is None
                and self._act is None and self._pending_act is None):
            self._hover_at = now
            self._pending_act = {"name": "wiggle", "start": now, "dur": 0.8}
        super().enterEvent(e)

    def contextMenuEvent(self, e):
        self.popup_menu(e.globalPos())

    # ------------------------------------------------------------------
    # 菜单（宠物右键与托盘共用同一构建函数）

    def popup_menu(self, global_pos):
        m = QMenu(self)
        build_main_menu(self._app, self, into=m)
        self._exec_menu(m, global_pos)

    def _exec_menu(self, menu, global_pos):
        """独立成方法 = 离屏自检的打桩缝（C++ 槽 QMenu.exec monkeypatch 不生效，
        offscreen 下模态 exec 会永久阻塞）。"""
        menu.exec(global_pos)

    def _quit(self):
        if getattr(self._tasks, "_running", False):
            from gui import _confirm_destructive   # 延迟 import 防循环
            if not _confirm_destructive(
                    self, "退出任务管家",
                    "任务正在运行，退出会中止全部账号的剩余任务。确定退出？",
                    ok_text="退出"):
                return
        save_pos(self.x(), self.y())
        self._tasks.shutdown_worker()   # 收尾 worker 子进程（防孤儿进程）
        QApplication.quit()


def _fill_ytl_menu(sub: QMenu, app, tasks):
    """「开始一条龙」子菜单：读已存方案，逐个列出一键开跑。"""
    running = bool(getattr(tasks, "_running", False))
    try:
        plans = ytl.plans()
    except Exception:
        log.exception("读取一条龙方案失败")
        plans = []
    if not plans:
        act = sub.addAction("（尚无方案——打开主面板配置）")
        act.setEnabled(False)
        return
    for plan in plans:
        act = sub.addAction(plan.get("name", "未命名方案"))
        act.setEnabled(not running)
        pid = plan.get("id")
        act.triggered.connect(
            lambda _=False, p=pid: tasks.start_yitiaolong(p, preflight=True))


def build_main_menu(app, pet, into: QMenu) -> None:
    """宠物右键菜单 / 托盘菜单共用：把动作填进 `into`（每次弹出前现填，
    方案清单、运行态、宠物显隐都是活的，且动作所有权直接落在目标菜单上）。"""
    tasks = app.tasks_tab
    running = bool(getattr(tasks, "_running", False))
    m = into

    sub = m.addMenu("开始一条龙")
    _fill_ytl_menu(sub, app, tasks)

    act = m.addAction("开始任务…")
    act.setEnabled(not running)
    act.setToolTip("打开三步向导，临时跑一次自选任务")
    act.triggered.connect(lambda: tasks.open_start_wizard())

    m.addSeparator()
    act = m.addAction("账号配置")
    act.triggered.connect(lambda: app.show_main(app.PAGE_ACCOUNT))
    act = m.addAction("定时任务")
    act.triggered.connect(lambda: app.show_main(app.PAGE_TASKS))
    act = m.addAction("显示主面板")
    act.triggered.connect(lambda: app.show_main())
    if pet is not None:
        act = m.addAction("投喂小鱼干")
        act.setToolTip("给芳菲蝶恋投喂小鱼干（打盹会先醒来）")
        act.triggered.connect(pet._feed)

    m.addSeparator()
    act = m.addAction("停止任务")
    act.setEnabled(running)
    act.triggered.connect(lambda: tasks.stop_tasks())

    if pet is not None:
        act = m.addAction("隐藏宠物")
        act.setToolTip("关闭桌面宠物（托盘图标仍在，可随时打开）")
        act.triggered.connect(lambda: app.set_pet_visible(False))
    else:
        act = m.addAction("显示宠物")
        act.setCheckable(True)
        act.setChecked(False)
        act.triggered.connect(lambda: app.set_pet_visible(True))
    act = m.addAction("退出")
    act.triggered.connect(pet._quit if pet is not None
                          else lambda: _quit_from_tray(app))


def _quit_from_tray(app):
    """托盘菜单的退出（宠物已隐藏时托盘是唯一入口，确认框 parent 给 None）。"""
    tasks = app.tasks_tab
    if getattr(tasks, "_running", False):
        from gui import _confirm_destructive
        if not _confirm_destructive(
                None, "退出任务管家",
                "任务正在运行，退出会中止全部账号的剩余任务。确定退出？",
                ok_text="退出"):
            return
    tasks.shutdown_worker()   # 收尾 worker 子进程（防孤儿进程）
    QApplication.quit()


def build_tray(app, pet) -> QSystemTrayIcon | None:
    """系统托盘图标。系统托盘不可用时返回 None（调用方兜底显示主面板）。"""
    if not QSystemTrayIcon.isSystemTrayAvailable():
        log.warning("系统托盘不可用")
        return None
    tray = QSystemTrayIcon(icon("app-icon.ico"), app)
    tray.setToolTip("任务管家")

    menu = QMenu()
    # 每次弹出前重建：方案清单/运行态/宠物显隐都是活的
    menu.aboutToShow.connect(lambda: _rebuild_tray_menu(menu, app, pet))
    tray.setContextMenu(menu)

    def on_activated(reason):
        if reason == QSystemTrayIcon.Trigger:      # 左键单击 = 显示主面板
            app.show_main()

    tray.activated.connect(on_activated)
    return tray


def _rebuild_tray_menu(menu: QMenu, app, pet):
    menu.clear()
    pet_ref = pet if pet is not None and pet.isVisible() else None
    build_main_menu(app, pet_ref, into=menu)


def show_hide_hint(tray):
    """主窗首次被隐藏到后台时给用户一个提示气泡（只提示一次）。"""
    if tray is not None:
        tray.showMessage("任务管家",
                         "已隐藏到后台：点桌面宠物或托盘图标随时再打开。",
                         QSystemTrayIcon.Information, 4000)
