# -*- coding: utf-8 -*-
"""单实例锁（**只用标准库**，可被 boot.py / gui.py / 工具脚本复用）。

为什么必须单实例：一个 GUI 实例 = 一份执行调度器（App 内 QTimer 每 30 秒巡检
定时计划）。跑起两个实例就会出现"同一分钟双触发"——两套任务线程同时点同一批
客户端窗口，抢置前、抢 OCR、互相当成"被别人顶号"，组队/副本直接乱掉
（2026-10-13 11:53 实测：主 GUI 之外又冒出两个完整 app=gui 进程各跑一段）。

实现：Windows 命名互斥体（`Local\\` 命名空间，同一登录会话内唯一）。
- 第二个实例拿到 `ERROR_ALREADY_EXISTS` → 激活已有窗口后退出，不进入业务；
- boot.py 的 `--sandbox-cli` 提权子进程**不能**被挡（它不启 GUI，是短命助手），
  调用方自己跳过；
- 提权重启（ensure_elevation → runas 拉起新进程）是**合法的实例交接**：
  老进程必须先在 spawn 之前 `release()`，否则新进程会被自己的锁挡在门外。

进程内用 `sys._cahx_singleton_held` 标记"本进程已持锁"：boot.py 与 gui.py 在
同一进程里先后调用，靠它避免对同一个命名互斥体重复 CreateMutex 被误判成重复实例
（同进程重复 create 也会置 ERROR_ALREADY_EXISTS）。
"""
import sys

MUTEX_NAME = r"Local\ChanganHelper_TaskButler_GUI"
HOLD_FLAG = "_cahx_singleton_held"
ERROR_ALREADY_EXISTS = 183

_handle = None   # 持有句柄直到进程退出（关掉即释放锁）
WINDOW_TITLE = "任务管家"


def _activate_existing_window():
    """把已有实例的主窗口拉回前台（找不到就算了，不报错）。"""
    try:
        import ctypes
        from ctypes import wintypes
        u32 = ctypes.windll.user32
        found = []

        @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        def _cb(hwnd, _lparam):
            if not u32.IsWindowVisible(hwnd):
                return True
            n = u32.GetWindowTextLengthW(hwnd)
            if n <= 0:
                return True
            buf = ctypes.create_unicode_buffer(n + 1)
            u32.GetWindowTextW(hwnd, buf, n + 1)
            if buf.value.strip() == WINDOW_TITLE:
                found.append(hwnd)
                return False
            return True

        u32.EnumWindows(_cb, 0)
        if not found:
            return False
        hwnd = found[0]
        u32.ShowWindow(hwnd, 9)          # SW_RESTORE
        u32.SetForegroundWindow(hwnd)
        return True
    except Exception:
        return False


def acquire(activate=True):
    """尝试成为唯一实例。True=本进程可以继续；False=已有实例在跑（已尝试激活）。"""
    global _handle
    if getattr(sys, HOLD_FLAG, False):
        return True                       # 同进程重复调用（boot → gui）
    try:
        import ctypes
        from ctypes import wintypes
        k32 = ctypes.windll.kernel32
        k32.CreateMutexW.restype = wintypes.HANDLE
        k32.CreateMutexW.argtypes = [wintypes.LPVOID, wintypes.BOOL,
                                     wintypes.LPCWSTR]
        h = k32.CreateMutexW(None, False, MUTEX_NAME)
        if not h:
            return True                   # 异常环境（权限/API 缺失）不拦启动
        if k32.GetLastError() == ERROR_ALREADY_EXISTS:
            k32.CloseHandle(h)
            if activate:
                _activate_existing_window()
            return False
        _handle = h                       # 保留引用，进程存活期间不释放
        setattr(sys, HOLD_FLAG, True)
        return True
    except Exception:
        return True


def release():
    """释放本进程持有的锁（提权重启前调用：把位置让给即将拉起的新进程）。"""
    global _handle
    try:
        if _handle:
            import ctypes
            ctypes.windll.kernel32.CloseHandle(_handle)
    except Exception:
        pass
    _handle = None
    try:
        if getattr(sys, HOLD_FLAG, False):
            delattr(sys, HOLD_FLAG)
    except Exception:
        pass
