# -*- coding: utf-8 -*-
"""
设计令牌 —— 多账号管理工具（浅色主题 / 蓝青主色）
====================================================

本模块是 Python 侧的**唯一配色来源**；`app.qss` 是样式侧的**唯一视觉来源**。
两者一一对应，改色时请同步（推荐只改本文件，再用 `theme.build_qss()` 注入）。

约定：
  * QSS 不支持 CSS 变量，所以颜色在 app.qss 中是字面量。
      - 若你想支持运行时换肤：把 app.qss 里的十六进制值替换成 $token 占位，
        再用 string.Template 渲染（见 theme.py 文末注释）。
  * 本模块主要给「QSS 覆盖不到的地方」用：
      - QGraphicsDropShadowEffect（阴影）
      - QFont（等宽数字 / 行高）
      - QTextCharFormat（日志逐行着色）
      - QPalette（占位符文字颜色）
      - QSS 里用不到但代码里要用的间距、尺寸常量
"""

from __future__ import annotations

# ============================================================================
# 一、颜色 Color
# ============================================================================


class Color:
    """浅色主题配色。命名与 design-tokens.css 完全一致。"""

    # ---------- 背景与面 ----------
    CANVAS = "#F4F5F7"          # 应用画布底色（最外层）
    SURFACE = "#FFFFFF"         # 卡片 / 按钮 / 表格容器
    SUBTLE = "#F7F8FA"          # 表头、卡片头
    SUBTLE_2 = "#F8F9FB"        # 面板头、内嵌条、弹窗头尾
    INPUT = "#F5F6F8"           # 输入框、下拉框
    CHIP_IDLE = "#F4F5F7"       # 未选中芯片底
    TAG = "#F1F2F5"             # 数量标签胶囊
    TRACK = "#E7E9EE"           # 进度条轨道
    DIVIDER = "#EEF0F3"         # 行分割线（比边框更浅）

    # ---------- 边框 ----------
    BORDER = "#E5E7EB"          # 卡片、表格主边框
    BORDER_SOFT = "#E3E5EA"     # 次级容器、按钮边框
    BORDER_INPUT = "#E5E7EB"    # 输入框边框
    BORDER_CHECKBOX = "#C4C8D0"  # 未选中勾选框描边
    BORDER_MODAL = "#DDDEE3"    # 弹窗描边
    ICON_MUTED = "#6B7280"      # 图标描边（搜索、设置）

    # ---------- 文字 ----------
    TEXT_PRIMARY = "#16181D"    # 标题、主文字
    TEXT_STRONG = "#2B313A"     # 状态行名称、次级标题
    TEXT_MONO = "#3C424C"       # 账号 / 手机号等数字列
    TEXT_SECONDARY = "#5F6672"  # 正文、次要按钮文字
    TEXT_TERTIARY = "#6E7683"   # 表头、日志文本
    TEXT_MUTED = "#9AA1AC"      # 占位符、弱化文字
    TEXT_FAINT = "#A8AEBA"      # 空值 "—"、禁用文字

    # ---------- 主色 · 蓝青 ----------
    PRIMARY = "#0E7C9E"          # 主按钮底、勾选态、开关、进度条、Logo
    PRIMARY_HOVER = "#0C6E8C"    # 主按钮 hover（派生值）
    PRIMARY_PRESSED = "#0A6079"  # 主按钮 pressed（派生值）
    PRIMARY_STRONG = "#0B6480"   # 主色系深色文字（激活页签、选中芯片文字）
    PRIMARY_SOFT = "#DEF1F7"     # 激活页签底
    PRIMARY_SOFTER = "#E8F6FA"   # 选中芯片底
    PRIMARY_SOFTEST = "#D3ECF4"  # 激活页签 hover
    PRIMARY_BORDER = "#AEDBE7"   # 选中芯片描边 / 主按钮禁用底
    ON_PRIMARY = "#FFFFFF"       # 主色底上的文字

    # ---------- 语义色 ----------
    SUCCESS = "#0E9384"          # 在线 / 成功 / 已完成
    SUCCESS_SOFT = "#E4F5F2"     # 成功徽章底
    SUCCESS_BORDER = "#A9DFD8"   # 成功徽章描边
    WARNING = "#D9822B"          # 排队 / 警示
    WARNING_SOFT = "#FDF3E7"     # 警示徽章底
    WARNING_BORDER = "#F0CFA3"   # 警示徽章描边
    DANGER = "#E5484D"           # 失败 / 错误日志 / 删除
    DANGER_SOFT = "#FDECEC"      # 失败徽章底
    DANGER_BORDER = "#F3C9CA"    # 失败边框


class Radius:
    """圆角。规则：卡片 10 → 内部子容器减去 1px 边框 = 9。"""

    CHECKBOX = 4      # 勾选框
    CHIP = 6          # 按钮、输入框、芯片
    LOGO = 7          # Logo 方块
    SEGMENT = 8       # 分段页签容器
    TOGGLE = 8        # 开关（28x16）
    CARD_INNER = 9    # 卡片内子容器顶部（= 10 - 1px 描边）
    CARD = 10         # 卡片、面板
    MODAL_INNER = 11  # 弹窗内子容器（= 12 - 1px 描边）
    MODAL = 12        # 弹窗
    PILL = 13         # 状态徽章胶囊
    DOT = 3           # 状态点（6x6）


class Space:
    """间距刻度。所有间距只能取这里的值。"""

    XS = 4
    S = 6
    M = 8
    L = 10
    XL = 12
    XXL = 14
    GUTTER = 16    # 左右两栏之间
    PAD = 20       # 卡片内边距基准
    WIDE = 24


class Size:
    """关键尺寸。"""

    WINDOW_W = 1440
    WINDOW_H = 900

    TOPBAR_H = 56
    TOPBAR_PAD_L = 20
    TOPBAR_PAD_R = 20

    LOGO = 26

    SEG_H = 28
    SEG_PAD = 14
    SEG_CONTAINER_PAD = 3

    PILL_H = 26
    ICON_BTN = 28

    TOOLBAR_H = 60          # 卡片头（含工具栏）
    TOOLBAR_PAD_L = 20
    TOOLBAR_PAD_R = 16
    CARD_HEADER_H = 42      # 右侧面板卡片头
    TOOLS_PANEL_H = 160     # 01 账号页「小工具」面板最小高度（带边框大框，随剩余空间拉伸）

    CONTROL_H = 32          # 次按钮 / 输入框 / 搜索框
    FIELD_H = 34            # 弹窗输入框 / 下拉框
    MODAL_BTN_H = 32

    SEARCH_W = 170
    API_FILTER_W = 0

    TABLE_HEADER_H = 34     # 2026-10-12 信息架构重组：由 36 收紧（表头更安静）
    ROW_H_ACCOUNT = 40      # 01 账号页行高（2026-10-12 由 44 收紧）
    ROW_H_SCHEDULE = 52     # 02 任务页「定时计划」区行高（一行是"计划"不是"记录"）
    CELL_PAD_X = 20
    CELL_GAP = 12

    # ---- 2026-10-12 信息架构重组新增（设计书 §6.10）----
    ACTION_PANE_W = 200     # 01 账号页：表格右侧的操作区宽度（固定，不随窗口拉伸）
    ACTION_BTN_W = 140      # 操作区内按钮宽度
    ACTION_PRIMARY_H = 36   # 操作区主按钮高（比常规 CONTROL_H=32 高一档）
    SECTION_BAR_H = 44      # 页内区段标题行（立即执行 / 定时计划）
    GROUP_HEADER_H = 56     # 设置页分组卡卡头（手风琴）
    FIELD_LABEL_W = 160     # 设置页分组内的字段标签宽度

    RIGHT_PANEL_W = 360
    RIGHT_PANEL_RAIL_W = 34   # 右侧面板收起后只剩的竖条（放展开按钮）
    STATUS_ROW_H = 38         # 空闲行：一行（状态点 + 角色名 + 计数）
    STATUS_ROW_H_ACTIVE = 54  # 运行中/失败行：多一行放整条进度条 / 失败任务名
    PROGRESS_W = 70
    PROGRESS_H = 8           # 原 4px 太细几乎看不见

    DOT = 6
    CHECKBOX = 16
    CHECKBOX_SM = 14
    TOGGLE_W = 28
    TOGGLE_H = 16

    CHIP_H = 28
    CHIP_SM_H = 26

    MODAL_W = 520
    MODAL_HEADER_H = 52
    MODAL_FOOTER_H = 60
    MODAL_MARGIN = 24       # 弹窗卡片四周留白（给阴影用）


class FontSize:
    """字号。层级靠字重 + 颜色区分，不靠放大。"""

    PANEL_TITLE = 15   # 「账号管理」「任务配置」
    APP_NAME = 14      # 顶栏应用名 / 弹窗标题
    SECTION = 13       # 区块标题、「执行状态」
    BODY = 12          # 正文、表格内容、按钮
    CAPTION = 11       # 表头、辅助说明、日志、徽章


class FontFamily:
    UI = '"Microsoft YaHei UI", "Microsoft YaHei", "Segoe UI", "Noto Sans SC", "PingFang SC"'
    MONO = '"Cascadia Mono", Consolas, "JetBrains Mono", "Sarasa Mono SC", monospace'


# ============================================================================
# 二、字体辅助
# ============================================================================

UI_FONT_STACK = ["Microsoft YaHei UI", "Microsoft YaHei", "Segoe UI", "Noto Sans SC", "PingFang SC"]
MONO_FONT_STACK = ["Cascadia Mono", "Consolas", "JetBrains Mono", "Sarasa Mono SC", "Consolas"]


def ui_font(size: int = FontSize.BODY, weight: int = 400):
    """取一个界面字体。weight 传 CSS 数值（400/500/600/700）。"""
    from PySide6.QtGui import QFont

    f = QFont()
    f.setFamilies(UI_FONT_STACK)          # Qt6：多字体回退，等价于 CSS font-family 列表
    f.setPixelSize(size)
    f.setWeight(_qt_weight(weight))
    return f


def mono_font(size: int = FontSize.BODY, weight: int = 400):
    """等宽字体。账号、PID、时间戳、日志一律用它 —— 这是本设计的辨识度来源。"""
    from PySide6.QtGui import QFont

    f = QFont()
    f.setFamilies(MONO_FONT_STACK)
    f.setPixelSize(size)
    f.setWeight(_qt_weight(weight))
    f.setStyleHint(QFont.StyleHint.Monospace)   # 字体缺失时退回系统等宽，而不是变比例字体
    return f


def _qt_weight(weight: int):
    from PySide6.QtGui import QFont

    table = {
        100: QFont.Weight.Thin,
        300: QFont.Weight.Light,
        400: QFont.Weight.Normal,
        500: QFont.Weight.Medium,
        600: QFont.Weight.DemiBold,
        700: QFont.Weight.Bold,
        900: QFont.Weight.Black,
    }
    return table.get(weight, QFont.Weight.Normal)


# ============================================================================
# 三、语义色映射（给状态类控件用，避免代码里散落魔法字符串）
# ============================================================================

# 状态点 / 状态文字：ok=进行中·已完成  fail=失败  queue=排队  idle=空闲·离线
STATE_COLORS = {
    "ok": Color.SUCCESS,
    "fail": Color.DANGER,
    "queue": Color.WARNING,
    "idle": Color.TEXT_FAINT,
}

# 日志级别 → 颜色
LOG_COLORS = {
    "normal": Color.TEXT_TERTIARY,
    "success": Color.SUCCESS,
    "fail": Color.DANGER,
    "queue": Color.WARNING,
}


__all__ = [
    "Color",
    "Radius",
    "Space",
    "Size",
    "FontSize",
    "FontFamily",
    "UI_FONT_STACK",
    "MONO_FONT_STACK",
    "ui_font",
    "mono_font",
    "STATE_COLORS",
    "LOG_COLORS",
]
