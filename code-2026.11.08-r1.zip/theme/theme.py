# -*- coding: utf-8 -*-
"""
主题加载与应用 —— 把 app.qss + tokens.py 接进 PySide6 应用
============================================================

用法（放在 main.py 最前面，创建任何窗口之前）：

    from PySide6.QtWidgets import QApplication
    from theme.theme import apply_theme

    app = QApplication(sys.argv)
    apply_theme(app)              # ← 一行搞定：Fusion 风格 + 字体 + 高DPI + QSS
    win = MainWindow()
    win.show()
    app.exec()

之后在窗口里这样用：

    from theme.theme import set_state, card_shadow, append_log
    from theme.tokens import Color

    set_state(name_label, "online")          # 加动态属性并刷新样式
    card_shadow(modal_card)                  # 卡片阴影（QSS 做不到）
    append_log(log_view, "19:31:02", "登录成功 (direct)", "success")
"""

from __future__ import annotations

from pathlib import Path

# 高 DPI 四舍五入策略必须在 QApplication 创建【之前】设置——apply_theme 是在
# app 创建之后才被调用的，放那里只会打印 "must be called before creating the
# QApplication instance" 警告且不生效。Qt6 默认值本来就是 PassThrough，这里
# 提前显式声明：行为不变、警告消失。本模块被 import 的时机早于任何 app 创建。
try:
    from PySide6.QtCore import Qt
    from PySide6.QtGui import QGuiApplication

    QGuiApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )
except Exception:
    pass

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont, QIcon, QPalette, QTextCharFormat, QTextCursor
from PySide6.QtWidgets import QApplication, QGraphicsDropShadowEffect, QWidget

from .tokens import (
    LOG_COLORS,
    MONO_FONT_STACK,
    UI_FONT_STACK,
    Color,
    FontSize,
    Radius,
    Space,
)

THEME_DIR = Path(__file__).resolve().parent
QSS_PATH = THEME_DIR / "app.qss"
ICONS_DIR = THEME_DIR / "icons"


# ============================================================================
# QSS 加载
# ============================================================================


def build_qss() -> str:
    """读取 app.qss，把 __ICONS__ 占位替换成图标目录绝对路径。

    QSS 的 url() 是按进程工作目录解析相对路径的，打包成 exe 后工作目录会变，
    所以必须在加载时替换成绝对路径。
    """
    qss = QSS_PATH.read_text(encoding="utf-8")
    return qss.replace("__ICONS__", ICONS_DIR.as_posix())


def icon(name: str) -> QIcon:
    """按文件名取图标，例如 icon("settings.svg")。"""
    return QIcon((ICONS_DIR / name).as_posix())


# ============================================================================
# 主题应用
# ============================================================================


def apply_theme(app: QApplication) -> None:
    """一次性完成：Fusion 风格 → 高 DPI → 字体 → 调色板 → QSS。"""

    # 1) Fusion 风格。必须！Windows 默认的 windowsvista 风格会覆盖掉大量 QSS 规则，
    #    表现就是"边框不生效""圆角没了""hover 态是系统蓝"。
    app.setStyle("Fusion")

    # 2) 全局字体走 QFont，而不是只依赖 QSS font-family。
    #    原因：QSS 的 font-family 不做逐字回退，中文缺字时容易出现方块。
    base = QFont()
    base.setFamilies(UI_FONT_STACK)
    base.setPixelSize(FontSize.BODY)
    app.setFont(base)

    # 4) 调色板只管 QSS 覆盖不到的地方：占位符文字、工具提示底色等。
    pal = app.palette()
    pal.setColor(QPalette.ColorRole.PlaceholderText, QColor(Color.TEXT_FAINT))
    pal.setColor(QPalette.ColorRole.Window, QColor(Color.CANVAS))
    pal.setColor(QPalette.ColorRole.Base, QColor(Color.SURFACE))
    pal.setColor(QPalette.ColorRole.Text, QColor(Color.TEXT_PRIMARY))
    pal.setColor(QPalette.ColorRole.Highlight, QColor(Color.PRIMARY_SOFT))
    pal.setColor(QPalette.ColorRole.HighlightedText, QColor(Color.PRIMARY_STRONG))
    app.setPalette(pal)

    # 5) 应用样式表。
    app.setStyleSheet(build_qss())


def repolish(widget: QWidget) -> None:
    """动态属性变化后强制重算样式。

    QSS 的 [state="..."] / [variant="..."] 选择器只在控件被 polish 时求值一次，
    改了属性不调用本函数，样式不会刷新 —— 这是 QSS 最常见的坑。
    """
    style = widget.style()
    style.unpolish(widget)
    style.polish(widget)
    widget.update()


def set_prop(widget: QWidget, **props) -> None:
    """批量设置动态属性并刷新样式。

    set_prop(dot, state="fail")
    set_prop(btn, variant="primary")
    """
    for key, value in props.items():
        widget.setProperty(key, value)
    repolish(widget)


def set_state(widget: QWidget, state: str) -> None:
    """设置 state 动态属性（ok / fail / queue / idle / online / offline ...）。"""
    set_prop(widget, state=state)


# ============================================================================
# 阴影（QSS 无 box-shadow，必须用 QGraphicsDropShadowEffect）
# ============================================================================


def card_shadow(
    widget: QWidget,
    blur: int = 40,
    dy: int = 12,
    alpha: float = 0.14,
    dx: int = 0,
) -> QGraphicsDropShadowEffect:
    """给弹窗卡片加投影。

    注意：效果绘制区域 = 控件矩形上下左右各 ±blur、底部再 +dy，必须完全
    落在窗口内，否则 Windows 会拒绝 UpdateLayeredWindow（控制台
    dirty>size 报错）并留下旧帧残影。约束：blur + dy ≤ 父布局预留边距
    （弹窗 MODAL_MARGIN=24 → blur=18/dy=4 是上限组合，blur40/dy12 已实测出问题）。

    如果你想要"卡片带阴影而不是靠描边"，也可以给 #Card 用本函数，
    但要给它所在的 layout 留出 8–12px 外边距，否则卡片会贴着窗口边裁切阴影。
    """
    effect = QGraphicsDropShadowEffect(widget)
    effect.setBlurRadius(blur)
    effect.setOffset(dx, dy)
    effect.setColor(QColor(15, 23, 42, int(255 * alpha)))
    widget.setGraphicsEffect(effect)
    return effect


# ============================================================================
# 运行日志：QSS 无法逐行着色，必须用 QTextCharFormat
# ============================================================================


def append_log(
    view,
    timestamp: str,
    message: str,
    level: str = "normal",
    auto_scroll: bool = True,
) -> None:
    """向日志视图追加一行彩色日志。

    行格式（设计规范）：[HH:MM:SS] 消息
    level: normal | success | fail | queue
    """
    fmt = QTextCharFormat()
    fmt.setForeground(QColor(LOG_COLORS.get(level, Color.TEXT_TERTIARY)))

    cursor = view.textCursor()
    cursor.movePosition(QTextCursor.MoveOperation.End)
    cursor.insertText(f"[{timestamp}] {message}\n", fmt)

    if auto_scroll:
        view.verticalScrollBar().setValue(view.verticalScrollBar().maximum())


# ============================================================================
# 便捷构造器（可选，用来保证尺寸与设计稿一致）
# ============================================================================


def fixed(widget: QWidget, w: int | None = None, h: int | None = None) -> QWidget:
    """固定尺寸。QSS 的 min/max 写法容易在布局里被拉伸，代码里设更稳。"""
    if w is not None:
        widget.setFixedWidth(w)
    if h is not None:
        widget.setFixedHeight(h)
    return widget


def styled(role_widget: QWidget, role: str | None = None, variant: str | None = None):
    """设置 role / variant 动态属性（构造时调用，晚于 setStyleSheet 也没问题，因为会 repolish）。"""
    if role is not None:
        role_widget.setProperty("role", role)
    if variant is not None:
        role_widget.setProperty("variant", variant)
    repolish(role_widget)
    return role_widget


# ============================================================================
# 附：如果后续要支持运行时换肤（亮 / 暗切换）
# ----------------------------------------------------------------------------
# 1) 把 app.qss 里所有十六进制色值改成 $token 占位，例如：
#       background-color: $surface;
# 2) 用 string.Template 渲染：
#
#       from string import Template
#       themes = {
#           "light": {"surface": "#FFFFFF", "canvas": "#F4F5F7", ...},
#           "dark":  {"surface": "#101113", "canvas": "#08090A", ...},
#       }
#       qss = Template(QSS_PATH.read_text(encoding="utf-8")).substitute(themes["light"])
#
# 3) 切换时 app.setStyleSheet(qss)。
#    string.Template 用 $name 语法，不会和 QSS 的 {} 冲突（这也是不用 str.format 的原因）。
# 4) 图标 SVG 里的颜色是写死的，换肤时需要重新生成 SVG（toggle-on/off、search 等）。
# ============================================================================
