# -*- coding: utf-8 -*-
"""主题包 —— 多账号管理工具（浅色主题 / 蓝青主色）

对外只需两个入口：

    from theme import apply_theme, set_state, set_prop, card_shadow, append_log
    from theme import Color, Size, Space, Radius, FontSize

    app = QApplication(sys.argv)
    apply_theme(app)          # 必须在创建任何窗口之前调用
"""

from .theme import (  # noqa: F401
    ICONS_DIR,
    QSS_PATH,
    THEME_DIR,
    append_log,
    apply_theme,
    build_qss,
    card_shadow,
    fixed,
    icon,
    repolish,
    set_prop,
    set_state,
    styled,
)
from .tokens import (  # noqa: F401
    LOG_COLORS,
    MONO_FONT_STACK,
    STATE_COLORS,
    UI_FONT_STACK,
    Color,
    FontSize,
    FontFamily,
    Radius,
    Size,
    Space,
    mono_font,
    ui_font,
)

__all__ = [
    "apply_theme",
    "build_qss",
    "repolish",
    "set_prop",
    "set_state",
    "card_shadow",
    "append_log",
    "fixed",
    "styled",
    "icon",
    "Color",
    "Size",
    "Space",
    "Radius",
    "FontSize",
    "FontFamily",
    "STATE_COLORS",
    "LOG_COLORS",
    "ui_font",
    "mono_font",
    "UI_FONT_STACK",
    "MONO_FONT_STACK",
    "THEME_DIR",
    "QSS_PATH",
    "ICONS_DIR",
]
