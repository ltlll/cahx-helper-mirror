# -*- coding: utf-8 -*-
"""任务执行 worker 子进程（worker.py，2026-10-25）

由 GUI 进程（core/workerclient.py）拉起的常驻子进程：任务执行引擎
（core/runner.py）跑在这里，GUI 只负责界面。崩溃隔离 + 停止可秒杀
（GUI terminate 本进程即停，命名互斥量随进程死亡自动释放，GUI 侧补一发
device.force_mouse_up 防鼠标按键卡死）。

协议（stdin/stdout，一行一条 JSON）：
- stdout 事件行带前缀 `CAHX1:`（库/异常往 stdout 的杂散输出没有前缀，
  GUI 侧忽略）；启动后第一件事是 sys.stdout 重定向到 stderr，协议写
  复制前的原始 fd，保证管道里只有协议行。
- 命令（GUI→worker，stdin）：
    {"cmd":"run","params":{...}}   run_session 参数（见 core/runner.py）
    {"cmd":"rerun","params":{acc,name,titles}}
    {"cmd":"stop"}                 协作式停止（置位 stop_event）
    {"cmd":"ping"} / {"cmd":"quit"}
- 事件（worker→GUI，stdout）：
    hello{version,pid} / pong / run_accepted / run_rejected{reason}
    row{acc_id,state}（state 增量：total/done/current/failed_add/failed_remove/
    done_add；done=None 表示"置为 total"）
    log{level,line}（logging 记录，gui_formatter 格式 HH:MM:SS|账号|正文）
    finished / rerun_done{acc_id}

入口：打包 = `cahx-helper.exe --worker`（boot.py 派发，热更 sys.path 已就绪）；
开发 = `python boot.py --worker`。⚠️ 绝不能走 gui.main()（会 acquire
单实例锁并起 QApplication）。
"""
from __future__ import annotations

import json
import logging
import os
import sys
import threading

PREFIX = "CAHX1:"


class _Protocol:
    """协议行写器：dup 出来的原始 stdout fd，线程安全。"""

    def __init__(self):
        self._out = os.fdopen(os.dup(1), "w", encoding="utf-8",
                              buffering=1, errors="replace")
        self._lock = threading.Lock()
        # 协议通道独占 stdout；之后的一切 print/库输出统统去 stderr
        sys.stdout = sys.stderr

    def send(self, **event):
        line = PREFIX + json.dumps(event, ensure_ascii=False, default=str)
        with self._lock:
            try:
                self._out.write(line + "\n")
                self._out.flush()
            except (OSError, ValueError):
                # 管道断 = GUI 已死：worker 没有存在意义，直接退出
                os._exit(2)


class _EventLogHandler(logging.Handler):
    """把 logging 记录作为 log 事件转发给 GUI（面板显示用）。

    run.log / accounts 分文件由 logsetup 的 FileHandler 照常落盘，
    这里只管"转发给 GUI 显示"这一条路。
    """

    def __init__(self, proto):
        super().__init__()
        self._proto = proto
        from core.logsetup import gui_formatter
        self.setFormatter(gui_formatter())

    def emit(self, record):
        try:
            self._proto.send(ev="log", level=record.levelname,
                             line=self.format(record))
        except Exception:
            pass


def main() -> int:
    # 协议编码（2026-10-26 事故）：GUI 侧 subprocess 以 UTF-8 写 stdin
    # （workerclient.Popen encoding="utf-8"），冻结应用的 sys.stdin 默认按
    # 系统 ANSI（GBK）解码——中文角色名全部变乱码：模板名（角色卡_X）永远
    # 不存在、OCR 相似度比对目标本身乱码恒 0 分、按角色名配对全失败。
    # stdout 协议行已走 os.fdopen(dup(1), encoding="utf-8")，stdin 这里补齐。
    try:
        sys.stdin.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    proto = _Protocol()

    from core.logsetup import setup_logging
    setup_logging("worker")           # run.log + accounts 分文件（追加模式）
    # 崩溃/未捕获异常落盘：2026-10-29 那场"零任务完成"就是账号线程里的
    # NameError 走 threading.excepthook、被窗口版 exe 的 None stderr 吞掉。
    try:
        from core import crashlog
        crashlog.install()
    except Exception:
        pass
    handler = _EventLogHandler(proto)
    handler.setLevel(logging.INFO)
    logging.getLogger().addHandler(handler)

    try:
        from core.logexport import app_version
        version = app_version()
    except Exception:
        version = "?"
    proto.send(ev="hello", version=version, pid=os.getpid())

    # 抵消本次 worker 启动给 boot 崩溃计数加的那一分（详见 core/updater.py
    # mark_worker_ok：不清零的话，跑满 2 轮定时任务后 GUI 一重启就被误判
    # "该版本起不来"而回滚到上一版 —— 2026-10-28 现场踩过）。放这里而不是
    # 更早：走到这儿说明载荷 import 链是完好的。
    try:
        from core import updater
        updater.mark_worker_ok()
    except Exception:
        pass

    from core import runner
    log = logging.getLogger("gui")

    state = {"busy": False, "stop": None, "thread": None}

    def emit(kind, **kw):
        proto.send(ev=kind, **kw)

    def do_run(params):
        stop = threading.Event()
        state["stop"] = stop
        state["busy"] = True
        proto.send(ev="run_accepted")

        def work():
            try:
                runner.run_session(params, emit, stop)
            except Exception:
                log.exception("run_session 未捕获异常")
            finally:
                state["busy"] = False
                state["stop"] = None
                proto.send(ev="finished")

        state["thread"] = threading.Thread(target=work, daemon=True)
        state["thread"].start()

    def do_rerun(params):
        stop = threading.Event()
        state["stop"] = stop

        def work():
            try:
                runner.rerun_task(params, emit, stop)
            except Exception:
                log.exception("rerun_task 未捕获异常")
            finally:
                state["stop"] = None

        threading.Thread(target=work, daemon=True).start()

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            cmd = json.loads(line)
        except ValueError:
            log.warning("worker 收到无法解析的命令行: %r", line[:120])
            continue
        op = cmd.get("cmd")
        if op == "ping":
            proto.send(ev="pong")
        elif op == "run":
            if state["busy"]:
                proto.send(ev="run_rejected", reason="busy")
            else:
                do_run(cmd.get("params") or {})
        elif op == "rerun":
            if state["busy"]:
                log.warning("任务正在执行中，不能重跑")
            else:
                do_rerun(cmd.get("params") or {})
        elif op == "stop":
            if state["stop"] is not None:
                state["stop"].set()
                log.info("收到停止请求：各账号将在当前步骤结束后停下")
        elif op == "quit":
            if state["stop"] is not None:
                state["stop"].set()
            return 0
    return 0


if __name__ == "__main__":
    sys.exit(main())
