"""图形界面入口（PySide6）：任务管家 —— 账号登录管理 + 日常任务 + 定时计划。

页签结构（顶栏分段页签切换 · 2026-10-12 信息架构重组为三页）：
    账号     账号增删改查（SQLite）+ 勾选账号并行登录 + 拖拽/按钮调整顺序 + 平铺窗口
             （主按钮「开始登录」在表格右侧的操作区里，运行日志默认收起）
    任务     两区一页：上半「立即执行」（一条龙 / 临时跑一次 / 默认清单只读摘要），
             下半「定时计划」（原独立页并入，条目增删改 + 到点自动触发）
    设置     低频配置与程序信息：AI 兜底 / OCR 性能 / 程序信息 / 高级（手风琴分组卡）

顶栏右侧**只保留 1 个常驻动作按钮**（「导出日志」）；配置类入口一律进设置页。

UI 遵循 doc/UI设计/UI-DESIGN-SPEC.md（浅色主题）：样式唯一来源 theme/app.qss，
配色唯一来源 theme/tokens.py；功能逻辑与旧版一致。
"""
import json
import logging
import os
import random
import sys
import threading
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import yaml
import win32api
import win32con
import win32gui
import win32process

import pet as petwin
from PySide6.QtCore import (QEvent, QObject, QRectF, QSize, Qt, QTime, QTimer,
                            QUrl, Signal)
from PySide6.QtGui import (QColor, QDesktopServices, QFont, QIcon, QKeySequence,
                           QLinearGradient, QPainter, QPixmap, QShortcut)
from PySide6.QtWidgets import (
    QAbstractItemView, QApplication, QButtonGroup, QCheckBox, QComboBox, QDialog,
    QDoubleSpinBox, QFrame, QHBoxLayout, QHeaderView, QInputDialog, QLabel,
    QLineEdit, QListWidget, QListWidgetItem, QMainWindow, QMenu, QMessageBox,
    QPlainTextEdit, QProgressBar, QPushButton, QScrollArea, QSizePolicy,
    QSpinBox, QStackedWidget, QTableWidget, QTableWidgetItem, QVBoxLayout,
    QWidget,
)

from core import (aihelper, binding, db, gamecls, launcher, locate, ocr,
                  sandbox_tools, schedules, task_params, updater,
                  wintweaks, yitiaolong as ytl)
from core import autostart
from core import license as lic
from core import feedback, macro
from core.device import Device
from core.logsetup import gui_formatter, setup_logging
from core.matcher import Matcher
from core.session_keepalive import keep_alive
from core.workerclient import WorkerClient
from core.paths import (ASSETS_DIR, CONFIG_PATH, DATA_DIR, DEBUG_DIR,
                        ensure_user_files)
from login import run_login_parallel, launch_missing
from tasks.cook import MODE_LABEL as COOK_MODE_LABEL
from tasks.haishi import LAYERS as HAISHI_LAYERS
from tasks.zhongcai import DISH_AUTO as ZHONGCAI_DISH_AUTO
from tasks.zhongcai import DISH_RECIPES as ZHONGCAI_DISH_RECIPES
from theme.theme import (apply_theme, append_log, card_shadow, icon, repolish,
                         set_prop, set_state, styled)
from theme.tokens import Color, FontSize, Size, mono_font, ui_font

try:                       # 单实例锁（仓库根 _singleton.py，随载荷一起分发）
    import _singleton as single_instance
except Exception:          # 旧载荷没有这个文件：降级为不拦（boot.py 仍会拦）
    single_instance = None

SANDBOX_BOXES = ["DefaultBox", "kuafu", "cahx2"]

# 职业分类（任务按分类做差异化操作）：封印 / 奶妈 / 输出。
# 2026-10-12 起账号的「职业」升级为实际门派（core.gamecls.CLASSES，10 门派），
# 分类由门派自动映射；ROLES 保留给兼容读取（不再作为下拉选项）。
ROLES = ["输出", "封印", "奶妈"]

# 定时任务到点却被"正在执行的任务"占用时，最多延后多久再补跑（秒）。
# 用户规则 2026-10-12：限时玩法（打地鼠 12:00/18:00 整点刷新）错过就没了，
# 不能因为那一刻正好有任务在跑就"今日跳过"。15 分钟足够上一轮收尾，
# 又不会让地鼠等到 18:00 刷新之后太久。
SCHED_DEFER_MAX = 900

log = logging.getLogger("gui")

# 统一日志初始化（幂等）：run.log + 按账号分文件 + [账号标签] 逐行格式。
# 放在模块级是为了让工具脚本（如 tools/trigger_schedule.py，import gui 后直接
# 构造 App）也能正常写 run.log，而不是依赖 login 的导入副作用。
ensure_user_files()
setup_logging("gui")

# 崩溃/未捕获异常落盘（core/crashlog.py）：窗口版 stderr 是 None，线程里的
# 未捕获异常、C 层 abort 全都不留痕迹。2026-10-30 两次"进程凭空消失"就是因此
# 查不到任何线索。装不上也不影响启动（内部全 try/except）。
from core import crashlog
crashlog.install()


def ensure_elevation(keyword, parent=None):
    """游戏窗口是管理员权限而本工具不是时，自动以管理员身份重启本工具。

    Windows UIPI 禁止低权限程序移动/置顶高权限程序的窗口（平铺报"拒绝访问"），
    两边权限必须一致。已触发重启返回 True（调用方应中止当前操作）。
    """
    if launcher.is_admin():
        return False
    hwnds = Device.find_all(keyword)
    if not hwnds or not any(launcher.hwnd_elevated(h) for h in hwnds):
        return False
    log.warning("检测到游戏客户端以管理员权限运行，本工具将提权重启")
    QMessageBox.information(parent, "需要提权",
                            "检测到游戏以管理员权限运行，本工具将重启为管理员模式。\n"
                            "请在弹出的 UAC 确认框中点“是”。")
    # 单实例锁交接（2026-10-13）：提权重启 = 合法的实例交接，必须**先**放锁再
    # runas 拉起新进程，否则新实例会被自己这把锁挡在门外（老进程随后才退出）
    if single_instance is not None:
        single_instance.release()
    if launcher.relaunch_as_admin():
        QApplication.quit()
        return True
    QMessageBox.warning(parent, "提权已取消", "未提权继续运行：窗口平铺可能失败，窗口遮挡会导致识别失败。")
    return False


class LogBridge(QObject):
    line = Signal(str, str)  # 文本 + 着色级别（normal/success/fail/queue）


class GuiLogHandler(logging.Handler):
    """把日志经 Qt 信号转发到界面（emit 跨线程安全），并按内容分级着色。"""

    def __init__(self, bridge):
        super().__init__()
        self.bridge = bridge

    def emit(self, record):
        text = self.format(record)
        if record.levelno >= logging.ERROR:
            level = "fail"
        elif record.levelno >= logging.WARNING:
            level = "queue"
        elif "完成" in text or "成功" in text:
            level = "success"
        else:
            level = "normal"
        self.bridge.line.emit(text, level)


# ============================================================================
# 通用小组件
# ============================================================================


class FlowLayout(QVBoxLayout):
    """简化版流式布局：横向排列，超宽换行（任务芯片用）。

    Qt 没有内置流式布局；官方 example 的 FlowLayout 太重，这里基于
    固定行高 + 宽度估算实现（芯片文字短，估算足够）。
    """

    def __init__(self, parent=None, h_spacing=8, v_spacing=8, pad=42):
        super().__init__(parent)
        self._h = h_spacing
        self._v = v_spacing
        self._pad = pad        # 计算可用宽度时要扣掉的横向占用（卡片 padding 等）
        self._items = []  # [(widget, est_width)]
        self._last_w = None   # 上次重排用的宽度（没变就不重排，防抖动）
        self._filter_on = None

    def add_chip(self, widget, est_width):
        self._items.append((widget, est_width))
        # 挂 Resize 监听：弹窗打开前 parent 宽度是默认值，首排会按错宽度换行，
        # 打开瞬间再重排一次就是"弹窗打开时跳一下"（2026-10-12 用户反馈的
        # 抖动来源之一）。宽度真正变化时才重排。
        pw = self.parentWidget()
        if pw is not None and self._filter_on is not pw:
            pw.installEventFilter(self)
            self._filter_on = pw
        self._relayout(force=True)

    def eventFilter(self, obj, ev):
        if obj is self._filter_on and ev.type() == QEvent.Resize:
            if obj.width() != self._last_w:
                self._relayout()
        return False

    def clear(self):
        for w, _ in self._items:
            w.setParent(None)
        self._items = []
        self._relayout(force=True)

    def _relayout(self, force=False):
        # 清掉旧行（QLayout.takeAt 只摘布局不删子控件，芯片由 reload 重建）
        while self.count():
            item = self.takeAt(0)
            sub = item.layout() if item else None
            if sub is not None:
                while sub.count():
                    sub.takeAt(0)
        if not self._items:
            return
        width = self.parentWidget().width() if self.parentWidget() else 800
        width = max(width - self._pad, 200)  # 卡片左右 padding 20 + 1px 描边
        if not force and width == self._last_w and self.count():
            return                       # 宽度没变：不重排（防抖动）
        self._last_w = width
        row = None
        used = 0
        for w, est in self._items:
            if row is not None and used + self._h + est > width:
                row.addStretch(1)
                row = None
                used = 0
            if row is None:
                row = QHBoxLayout()
                row.setSpacing(self._h)
                row.setContentsMargins(0, 0, 0, 0)
                self.addLayout(row)
            row.addWidget(w)
            used += est + self._h
        if row is not None:
            row.addStretch(1)


def _card_header(title, small=True, hint=""):
    """卡片头：标题 + 右侧提示，返回 (header, hbox)。"""
    header = QFrame()
    header.setObjectName("CardHeader")
    header.setFixedHeight(Size.CARD_HEADER_H if small else Size.TOOLBAR_H)
    h = QHBoxLayout(header)
    h.setContentsMargins(Size.TOOLBAR_PAD_L if not small else 16, 0, 16, 0)
    t = QLabel(title)
    t.setObjectName("CardTitleSmall" if small else "CardTitle")
    h.addWidget(t)
    if hint:
        hh = QLabel(hint)
        hh.setObjectName("CardHint")
        h.addStretch(1)
        h.addWidget(hh)
    else:
        h.addStretch(1)
    return header, h


def _pill(text):
    p = QLabel(text)
    p.setObjectName("CountPill")
    return p


def _btn(text, variant=None, slot=None):
    b = QPushButton(text)
    if variant:
        styled(b, variant=variant)
    if slot:
        b.clicked.connect(slot)
    return b


class _RailButton(QFrame):
    """右侧面板折叠把手：一根撑满高度、可点击的竖条。

    不用 QPushButton 是因为 QSS 会给按钮锁定 min/max 高度（实测锁成内容框高），
    导致它无论怎么设 stretch/sizePolicy 都只是一个小方块，撑不满整列。
    """

    clicked = Signal()

    def __init__(self, text="◀"):
        super().__init__()
        self.setObjectName("RightRail")
        self.setCursor(Qt.PointingHandCursor)
        self._label = QLabel(text, self)
        self._label.setProperty("role", "railArrow")
        self._label.setAlignment(Qt.AlignCenter)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self._label, 1)
        repolish(self)

    def setText(self, text):
        self._label.setText(text)

    def setToolTip(self, tip):
        super().setToolTip(tip)
        self._label.setToolTip(tip)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self.rect().contains(e.position().toPoint()):
            self.clicked.emit()
            e.accept()
            return
        super().mouseReleaseEvent(e)


class _EmptyHint(QLabel):
    """表格空状态：浮在表格中间，只在没有数据时显示。

    新建用户打开软件看到的是纯空白表格，一句提示都没有，不知道该干什么。
    """

    def __init__(self, view, text):
        super().__init__(text, view.viewport())
        self._view = view
        self.setProperty("role", "emptyState")
        self.setAlignment(Qt.AlignCenter)
        self.setWordWrap(True)
        # 别挡住表格自身的交互（点击、滚动）
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        repolish(self)
        view.viewport().installEventFilter(self)
        self.resize(view.viewport().size())
        self.hide()

    def eventFilter(self, obj, ev):
        if obj is self._view.viewport() and ev.type() == QEvent.Resize:
            self.resize(obj.size())
        return super().eventFilter(obj, ev)

    def sync(self, count):
        """按当前可见行数决定显示与否。"""
        self.resize(self._view.viewport().size())
        self.setVisible(count == 0)


def _short(text, limit=13):
    """状态行第二行的文字截断（过长会把进度条挤没，完整内容挂 tooltip）。"""
    return text if len(text) <= limit else text[:limit - 1] + "…"


def _config_task_order(registry=None):
    """config.yaml `tasks:` 段的执行顺序（一条龙方案、任务页执行都以此为准）。

    注册表里有但 config 没写的任务追加在最后（否则会凭空消失）。
    """
    from core.scheduler import Scheduler
    registry = registry or Scheduler._load_tasks()
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            cfg = yaml.safe_load(f).get("tasks", []) or []
    except Exception:
        cfg = []
    order = [t["name"] for t in cfg if isinstance(t, dict) and t.get("name") in registry]
    order += [n for n in registry if n not in order]
    return order


def _confirm_destructive(parent, title, text, ok_text="删除"):
    """破坏性操作确认框：默认按钮是「取消」，回车不会误删，删除键用红色样式。

    直接 `QMessageBox.question()` 的默认按钮是「是」，随手回车就把数据删了，
    所以账号/定时任务这类不可恢复的删除统一走这里。
    """
    box = QMessageBox(parent)
    box.setIcon(QMessageBox.Warning)
    box.setWindowTitle(title)
    box.setText(text)
    yes = box.addButton(ok_text, QMessageBox.DestructiveRole)
    no = box.addButton("取消", QMessageBox.RejectRole)
    box.setDefaultButton(no)
    box.exec()
    return box.clickedButton() is yes


def _scroll_host(widget):
    """"卡片内滚动区"：透明无边框、纵向滚动、横向不滚。

    卡片高度不够时出现滚动条，而不是把内容顶出窗口——任务页卡片列、
    弹窗正文都用它，避免在小屏 / 高缩放机器上被裁切。

    纵向滚动条**常驻**（ScrollBarAlwaysOn）：QSS 里轨道全透明，内容放得下时
    视觉上不存在；但视口宽度因此恒定——滚动条出现/消失会让换行内容的高度
    跟着变（视口窄了→提示多折一行→内容更高→又需要滚动条……），高度测量在
    临界点来回横跳，弹窗就"抖"。2026-10-12 用户反馈实机弹窗抖动后锁定为此因。
    """
    sc = QScrollArea()
    sc.setObjectName("CardScroll")
    sc.setWidgetResizable(True)
    sc.setFrameShape(QFrame.NoFrame)
    sc.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
    sc.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
    sc.setWidget(widget)
    return sc


# ============================================================================
# 小工具：摘要文件（data/last_*.json）+ config.yaml 单值写回
# ============================================================================
#
# 2026-10-12 信息架构重组新增。两件事都不改既有数据格式：
#   ① last_login.json / last_run.json 是**纯新增**的可选摘要文件，缺失/损坏
#      时界面只是不显示那一行，不影响任何执行逻辑。
#   ② _write_config_scalar 沿用 _save_task_option 的做法：按行文本替换，
#      保留 config.yaml 里的全部注释（这个文件是给人看的文档）。

LAST_LOGIN_PATH = DATA_DIR / "last_login.json"
LAST_RUN_PATH = DATA_DIR / "last_run.json"


def _load_json(path):
    """读一个可选摘要 json；不存在 / 损坏都返回 {}（调用方只管"有没有"）。"""
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_json(path, data):
    try:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        log.warning("写摘要文件失败：%s", path, exc_info=True)


def _gui_cfg():
    """config.yaml 的 `gui:` 段（桌面宠物等 GUI 行为开关），没有/读不出返回 {}。"""
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            return (yaml.safe_load(f) or {}).get("gui", {}) or {}
    except Exception:
        return {}


def _write_config_scalar(key, value, section=None):
    """把 config.yaml 里某个标量键改成 value（按行替换，保留其余注释）。

    section=None  → 顶层键（如 `threshold:`）
    section="delay" → 二级键（`delay:` 段里的 `click_min:`）
    返回 True 表示已写入；找不到该键时返回 False（**不新建**，
    免得把配置写成一个这里自己发明的结构）。
    """
    lines = CONFIG_PATH.read_text(encoding="utf-8").splitlines()
    in_section = section is None
    out, hit = [], False
    for line in lines:
        stripped = line.strip()
        if section is not None:
            if not in_section:
                if stripped.startswith(f"{section}:"):
                    in_section = True
                out.append(line)
                continue
            # 已进入目标段：遇到下一个顶层键就退出
            if stripped and not line[0].isspace() and not stripped.startswith("#"):
                in_section = False
                out.append(line)
                continue
        if stripped.startswith(f"{key}:"):
            indent = line[: len(line) - len(line.lstrip())]
            out.append(f"{indent}{key}: {value}")
            hit = True
            if section is None:
                in_section = False
            continue
        out.append(line)
    if not hit:
        log.warning("config.yaml 里没找到 %s%s，未写入",
                    f"{section}." if section else "", key)
        return False
    CONFIG_PATH.write_text("\n".join(out) + "\n", encoding="utf-8")
    return True


def _section_bar(title, note="", buttons=(), extra=()):
    """页内区段标题行（§6.10①）：高 44，底 SUBTLE，上下 1px DIVIDER。

    用来把"立即执行"和"定时计划"两区分开——比再开一个页签轻得多。
    右端的 0–2 枚按钮是**页级动作**（对整段生效），主按钮不放这里。
    `extra` 是紧跟标题之后的小控件（如定时计划的计划数），可随后续刷新改文案。
    """
    bar = QFrame()
    bar.setProperty("role", "sectionBar")
    bar.setFixedHeight(Size.SECTION_BAR_H)
    h = QHBoxLayout(bar)
    h.setContentsMargins(Size.TOOLBAR_PAD_L, 0, Size.TOOLBAR_PAD_R, 0)
    h.setSpacing(10)
    t = QLabel(title)
    set_prop(t, role="sectionTitle")
    h.addWidget(t)
    for w in extra:
        h.addWidget(w)
    if note:
        n = QLabel(note)
        set_prop(n, role="sectionCount")
        n.setWordWrap(True)
        h.addWidget(n, 1)
    h.addStretch(1)
    for b in buttons:
        h.addWidget(b)
    repolish(bar)
    return bar


def _hint(text):
    """表单辅助说明（11 TEXT_FAINT，自动换行）。"""
    lab = QLabel(text)
    set_prop(lab, role="hint")
    lab.setWordWrap(True)
    return lab


def _link(text, slot=None):
    """link 变体的小按钮（「自动」「恢复默认」这类就地动作）。"""
    b = QPushButton(text)
    b.setCursor(Qt.PointingHandCursor)
    styled(b, variant="link")
    if slot is not None:
        b.clicked.connect(slot)
    return b


def _saved_suboption(entry, spec):
    """config.yaml 里已存的次级选项单值（转发 `core/task_params.saved_suboption`）。

    2026-10-14 实现搬进 core（重构批次②）；保留本名以免动其他调用点。
    """
    return task_params.saved_suboption(entry, spec)


def _save_task_option(task_name, key, value):
    """把任务的参数（次级选项）单值写回 config.yaml（转发 core 实现）。

    2026-10-12 从 `TasksTab` 的方法提升为模块级函数；2026-10-14 实现再搬进
    `core/task_params.py`（重构批次②），这里保留本名以免动其他调用点。
    **必须显式传 `CONFIG_PATH`**：core 模块在 import 时绑定了自己的那个名字，
    只在 gui 侧改 `CONFIG_PATH`（自检脚本就是这么隔离的）不会影响它。
    """
    return task_params.save_task_option(task_name, key, value, CONFIG_PATH)


# ============================================================================
# 弹窗外壳（无边框 + 半透明底 + ModalCard 阴影）
# ============================================================================


class _ChoiceCard(QFrame):
    """弹窗里的"大号单选项"：整块可点的自绘卡片。

    不用可勾选的 QPushButton 是因为 QSS 会给按钮锁死 min/max 高度（撑不高），
    而"组队方式"这种要带标题 + 说明的卡片必须能被布局撑高。
    选中态 = selected="true"（浅青实底 + 主色描边）。
    """

    clicked = Signal()

    def __init__(self, title, desc="", tag=""):
        super().__init__()
        self.setProperty("role", "choiceCard")
        self.setCursor(Qt.PointingHandCursor)
        v = QVBoxLayout(self)
        v.setContentsMargins(16, 14, 16, 14)
        v.setSpacing(6)
        head = QHBoxLayout()
        head.setContentsMargins(0, 0, 0, 0)
        head.setSpacing(8)
        self._title = QLabel(title)
        self._title.setProperty("role", "choiceTitle")
        head.addWidget(self._title)
        self._tag = QLabel(tag)
        self._tag.setProperty("role", "choiceTag")
        self._tag.setVisible(bool(tag))
        head.addWidget(self._tag)
        head.addStretch(1)
        v.addLayout(head)
        self._desc = QLabel(desc)
        self._desc.setProperty("role", "choiceDesc")
        self._desc.setWordWrap(True)
        v.addWidget(self._desc)
        repolish(self)
        self.setSelected(False)

    def setSelected(self, on):
        set_prop(self, selected="true" if on else "false")

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self.rect().contains(e.position().toPoint()):
            self.clicked.emit()
            e.accept()
            return
        super().mouseReleaseEvent(e)


class _DragArea(QFrame):
    """无边框窗口的拖动把手：按住本控件即可拖动所在的顶层窗口。

    弹窗是 FramelessWindowHint（没有系统标题栏），不自己实现拖动的话，
    弹窗一旦盖住后面的内容用户就没法把它挪开。
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._offset = None

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            win = self.window()
            self._offset = (e.globalPosition().toPoint()
                            - win.frameGeometry().topLeft())
            e.accept()
            return
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        if self._offset is not None and (e.buttons() & Qt.LeftButton):
            self.window().move(e.globalPosition().toPoint() - self._offset)
            e.accept()
            return
        super().mouseMoveEvent(e)

    def mouseReleaseEvent(self, e):
        self._offset = None
        super().mouseReleaseEvent(e)


class BaseModal(QDialog):
    """设计稿 §04 弹窗外壳：#ModalHost + #ModalCard + 标题栏 + 底部栏。

    子类把内容放进 self.content_layout，确定/取消在底部栏。

    窗口是无边框的（FramelessWindowHint），所以必须自己实现"按住标题栏拖动"——
    否则弹窗盖住后面的内容时用户没任何办法挪开它。
    内容区套 QScrollArea 并限高（= 屏幕可用高度 - 边距），否则像"添加定时任务"
    这种 800+ 高的弹窗在小屏 / 高缩放的机器上会把底部"确定/取消"顶出屏幕。
    """

    def __init__(self, parent, title, width=Size.MODAL_W):
        super().__init__(parent)
        self.setObjectName("ModalHost")
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setModal(True)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(Size.MODAL_MARGIN, Size.MODAL_MARGIN,
                                 Size.MODAL_MARGIN, Size.MODAL_MARGIN)
        card = self._build_card(width)
        outer.addWidget(card)

        lay = QVBoxLayout(card)
        lay.setContentsMargins(1, 1, 1, 1)
        lay.setSpacing(0)
        lay.addWidget(self._build_header(title))
        lay.addWidget(self._build_body(), 1)
        lay.addWidget(self._build_footer())
    # ---- __init__ 拆解（批次① 上帝方法抽取）----

    def _build_card(self, width):
        """弹窗外壳卡片：固定宽、限高到屏幕可用高度，阴影走 paintEvent 静态缓存。

        阴影不再用 QGraphicsDropShadowEffect（2026-10-12 用户反馈弹窗"频繁抖动"
        后更换）：效果挂在卡片上时，卡片里**任何**子控件重绘（hover、胶囊刷新）
        都会连着阴影整窗重渲染——半透明无边框窗口每次都是全量合成，实机上就是
        可见的抖动/闪烁。改为在 paintEvent 里画**缓存的静态阴影**（尺寸变了才
        重画），子控件重绘不再触碰阴影。
        绘制区域必须完全落在窗口内（外层留白 MODAL_MARGIN=24）：
        越界会被 Windows 拒绝 UpdateLayeredWindow → 留旧帧残影。
        """
        card = QFrame()
        card.setObjectName("ModalCard")
        card.setMinimumWidth(width)
        card.setMaximumWidth(width)
        # 整张卡不超过屏幕可用高度，超出部分由内容区滚动承担
        avail_h = self._available_height() - 2 * Size.MODAL_MARGIN
        card.setMaximumHeight(avail_h)
        self._card = card
        return card

    def _build_header(self, title):
        """无边框窗口的标题栏（兼作拖动区域）+ 关闭按钮。"""
        header = _DragArea()
        header.setObjectName("ModalHeader")
        header.setFixedHeight(Size.MODAL_HEADER_H)
        header.setCursor(Qt.SizeAllCursor)
        header.setToolTip("按住标题栏可拖动窗口")
        hh = QHBoxLayout(header)
        hh.setContentsMargins(20, 0, 16, 0)
        t = QLabel(title)
        t.setObjectName("ModalTitle")
        hh.addWidget(t)
        hh.addStretch(1)
        close = QPushButton()
        close.setIcon(icon("close.svg"))
        styled(close, variant="icon")
        close.clicked.connect(self.reject)
        hh.addWidget(close)
        return header

    def _build_body(self):
        """内容区：self.content_layout 供子类填内容，外套滚动容器防底部按钮被顶出屏幕。"""
        body = QFrame()
        body.setProperty("role", "fieldGroup")
        self.content_layout = QVBoxLayout(body)
        self.content_layout.setContentsMargins(20, 16, 20, 16)
        self.content_layout.setSpacing(14)
        # 内容区滚动容器（卡片高度不足时出现滚动条，而不是把底部按钮顶出屏幕）
        self.body_scroll = _scroll_host(body)
        return self.body_scroll

    def _build_footer(self):
        """底部栏：取消 / 确定。子类改底部栏请覆写 `_customize_footer()`。

        **不要**在子类覆写本方法：默认实现挂在 `__init__` 早期，那时子类字段还没建好。
        子类要在自己的 `__init__` 末尾显式调用一次 `self._customize_footer()`。
        """
        footer = QFrame()
        footer.setObjectName("ModalFooter")
        footer.setFixedHeight(Size.MODAL_FOOTER_H)
        fh = QHBoxLayout(footer)
        fh.setContentsMargins(20, 0, 20, 0)
        fh.setSpacing(8)
        fh.addStretch(1)
        cancel = _btn("取消", slot=self.reject)
        ok = _btn("确定", variant="primary", slot=self._on_ok)
        fh.addWidget(cancel)
        fh.addWidget(ok)
        # 子类改底部栏用（如一条龙向导要把「确定」换成「上一步/下一步/保存方案」）
        self.footer_layout = fh
        self.cancel_btn = cancel
        self.ok_btn = ok
        return footer

    def _customize_footer(self):
        """底部栏定制钩子（默认啥也不做）。子类覆写后在自己的 __init__ 末尾调用。"""

    def _available_height(self):
        """弹窗可用的屏幕高度（优先用父窗口所在屏幕，多屏时不会跑到另一块屏）。"""
        scr = None
        parent = self.parent()
        if parent is not None and hasattr(parent, "screen"):
            scr = parent.screen()
        scr = scr or QApplication.primaryScreen()
        return scr.availableGeometry().height() if scr else 900

    def showEvent(self, e):
        super().showEvent(e)
        self._fit_body()

    # ---- 静态缓存阴影（替代 QGraphicsDropShadowEffect，见 __init__ 注释）----

    SHADOW_BLUR = 18
    SHADOW_DY = 4
    SHADOW_ALPHA = 0.14

    def _card_rect(self):
        """卡片在窗口坐标系里的矩形（外层布局 margin 内的唯一子项）。"""
        m = Size.MODAL_MARGIN
        return self.rect().adjusted(m, m, -m, -m)

    def _shadow_pixmap(self):
        """缓存卡片投影。卡片尺寸没变就返回旧图（绝大多数重绘走这条快路）。

        画布 = 卡片矩形外扩 blur（下边再 +dy），层叠圆角矩形近似高斯衰减；
        平时重绘只 drawPixmap，不再重算阴影本身。
        """
        rect = self._card_rect()
        blur, dy = self.SHADOW_BLUR, self.SHADOW_DY
        key = (rect.width(), rect.height())
        pm = getattr(self, "_shadow_pm", None)
        if pm is not None and getattr(self, "_shadow_key", None) == key:
            return pm
        pm = QPixmap(rect.width() + 2 * blur, rect.height() + 2 * blur + dy)
        pm.fill(Qt.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing)
        # 卡片在画布里的位置：上/左/右外扩 blur，下边 blur+dy
        base = rect.translated(blur, blur)
        layers = 6
        p.setPen(Qt.NoPen)
        for i in range(layers, 0, -1):
            t = i / layers                      # 1=最外层
            grow = int(blur * t)
            a = int(255 * self.SHADOW_ALPHA * (1.0 - t) ** 1.6) + 2
            c = QColor(15, 23, 42, a)
            p.setBrush(c)
            r = base.adjusted(-grow, -grow + dy, grow, grow + dy)
            p.drawRoundedRect(r, 12 + grow // 2, 12 + grow // 2)
        p.end()
        self._shadow_pm = pm
        self._shadow_key = key
        return pm

    def paintEvent(self, e):
        super().paintEvent(e)
        p = QPainter(self)
        rect = self._card_rect()
        blur, dy = self.SHADOW_BLUR, self.SHADOW_DY
        p.drawPixmap(rect.x() - blur, rect.y() - blur, self._shadow_pixmap())

    def _fit_body(self):
        """正文高度按内容自适应，但不超过屏幕可用高度。

        QScrollArea 的 sizeHint 不会把子控件高度透传给弹窗，直接包一层会让
        弹窗在大屏上也缩成一小块并常驻滚动条。这里显式把滚动区高度设成
        "内容实际高度"，只有内容真的超过屏幕时才截断并滚动。

        2026-10-12 抗抖动三件套：
        1. 纵向滚动条常驻（见 _scroll_host）→ 视口宽度恒定，测量不振荡；
        2. **整段测量+调整延迟到事件循环末尾**（去重合批）——页面刚 `_goto`
           显隐时 QVBoxLayout 的缓存里还留着刚隐藏页的高度（实测把刚藏起的
           596px 组队页算进来 → 量出 638 → 弹窗顶到整屏高、顶部留大白）；
        3. 调整弹窗尺寸前清掉 explicit minimumSize（见 _apply_dialog_height）。
        """
        if getattr(self, "_fit_scheduled", False):
            return
        self._fit_scheduled = True
        QTimer.singleShot(0, self._do_fit_body)

    def _invalidate_layout_chain(self):
        """立即失效 内容宿主 → 滚动区 → 卡片 → 弹窗 的尺寸提示缓存。

        Qt6 把 sizeHint/minimumSizeHint 缓存在 QWidgetPrivate 里；
        setFixedHeight 只会向父控件**投递** LayoutRequest（延迟处理），
        所以父层缓存不会立刻失效——minimumSizeHint 量出的还是旧值，
        resize 就被旧最小值钳住。这里用 updateGeometry() 立即失效。
        """
        body = self.body_scroll.widget() if self.body_scroll else None
        chain = [body]
        if body is not None:
            chain += [self.body_scroll, self.body_scroll.parentWidget()]
        chain.append(self)
        for w in chain:
            if w is not None:
                w.updateGeometry()

    def _do_fit_body(self):
        self._fit_scheduled = False
        body = self.body_scroll.widget()
        if body is None:
            return
        # 清掉整条布局链的 sizeHint 缓存（页面宿主 → 卡片 → 弹窗）：
        # 刚 _goto 显隐后，每层都还缓存着隐藏页/旧内容的高度，不清的话
        # minimumSizeHint/sizeHint 都量出陈旧值（实测 596px 的组队页被算进
        # 去导致弹窗顶到整屏高、顶部留大白）。
        lay = body.layout()
        if lay is not None:
            lay.invalidate()          # 清 sizeHint 缓存，隐藏页不再计入
        content_h = body.sizeHint().height()
        chrome = Size.MODAL_HEADER_H + Size.MODAL_FOOTER_H + 2 * Size.MODAL_MARGIN + 2
        limit = max(160, self._available_height() - chrome)
        h = min(content_h, limit)
        if h != self.body_scroll.height():
            self.body_scroll.setFixedHeight(h)
        # setFixedHeight 之后**再清一次**卡片层/外层的缓存：前面的清缓存发生在
        # 滚动区还挂着旧高度时，外层 min 里钉着的仍是旧值（实测 773 缩不回去）。
        self._invalidate_layout_chain()
        self._apply_dialog_height(h + chrome)

    def _apply_dialog_height(self, target):
        """按目标高度调整弹窗（保持左上角不动）。

        ⚠️ 先清掉 explicit minimumSize：QLayout::activate() 在顶窗上会把布局
        最小值**钉进窗口的 minimumSize**，之后 resize 永远被旧钉值钳住——
        从高内容步切回矮内容步弹窗缩不回去（实测踩到）。
        ⚠️ 不要用 minimumSizeHint() 当 resize 下限：三页向导往返时它会返回
        **陈旧值**（比真实布局最小值大几百 px，实测 773 vs 实际 450），一用
        就把缩回的路堵死。target 已含 chrome（标题+底栏+边距），直接 resize。
        """
        if not self.isVisible():
            return
        self.setMinimumSize(QSize(0, 0))
        if self.height() != target:
            self.resize(self.width(), target)

    def _on_ok(self):
        """子类覆盖做校验；默认直接 accept。"""
        self.accept()

    def field_label(self, text):
        l = QLabel(text)
        l.setProperty("role", "fieldLabel")
        repolish(l)
        return l

    def hint_label(self, text):
        l = QLabel(text)
        l.setProperty("role", "hint")
        repolish(l)
        return l


# ============================================================================
# 账号编辑弹窗
# ============================================================================


class AccountDialog(BaseModal):
    """添加/编辑账号对话框。确认后结果在 self.result。"""

    def __init__(self, parent, title, initial=None):
        super().__init__(parent, title)
        self.result = None
        initial = initial or {}

        self.account = QLineEdit(initial.get("account", ""))
        self.server = QLineEdit(initial.get("server", ""))
        self.character = QLineEdit(initial.get("character", ""))
        self.pwd2 = QLineEdit(initial.get("pwd2", ""))
        self.pwd2.setPlaceholderText("6位数字，出售触发安全锁时自动输入")
        # 职业 = 游戏实际的 10 个门派（2026-10-12 从 3 分类升级）。
        # 任务侧差异化仍按**分类**走，分类由门派自动映射（core.gamecls）；
        # db.role 存分类（兼容老数据/任务逻辑），db.cls 存门派（空 = 未指定）。
        self._initial_role = initial.get("role", "输出")
        self.cls = QComboBox()
        self.cls.addItems(["未指定"] + list(gamecls.CLASSES))
        init_cls = initial.get("cls") or ""
        if not init_cls and self._initial_role:
            # 老数据只有分类：预选该分类下的第一个门派作为建议值
            init_cls = next((c for c, r in gamecls.CLASSES.items()
                             if r == self._initial_role), "")
        self.cls.setCurrentText(init_cls or "未指定")
        self.role_hint = QLabel("")
        self.role_hint.setProperty("role", "hint")
        self.hwnd = initial.get("hwnd", 0) or 0
        self.hwnd_label = QLabel(self._hwnd_text())
        self.pick_btn = QPushButton("鼠标指定")
        self.pick_btn.clicked.connect(self._pick_client)
        self.clear_hwnd_btn = QPushButton("清除")
        self.clear_hwnd_btn.clicked.connect(self._clear_hwnd)
        hwnd_row = QWidget()
        hwnd_layout = QHBoxLayout(hwnd_row)
        hwnd_layout.setContentsMargins(0, 0, 0, 0)
        hwnd_layout.addWidget(self.hwnd_label, 1)
        hwnd_layout.addWidget(self.pick_btn)
        hwnd_layout.addWidget(self.clear_hwnd_btn)
        self.launch_mode = QComboBox()
        self.launch_mode.addItems(["direct", "sandbox"])
        self.launch_mode.setCurrentText(initial.get("launch_mode", "direct"))
        self.sandbox_box = QComboBox()
        self.sandbox_box.addItems(SANDBOX_BOXES)
        self.sandbox_box.setCurrentText(initial.get("sandbox_box", "DefaultBox"))

        cl = self.content_layout
        for label, w in (("账号 *", self.account), ("区服 *", self.server),
                         ("角色名 *", self.character), ("二级密码", self.pwd2),
                         ("职业（门派）", self.cls),
                         ("客户端句柄", hwnd_row), ("启动方式", self.launch_mode),
                         ("沙盒名", self.sandbox_box)):
            cl.addWidget(self.field_label(label))
            cl.addWidget(w)
            if w is self.cls:
                cl.addWidget(self.role_hint)
        cl.setSpacing(6)

        self.cls.currentTextChanged.connect(self._sync_role_hint)
        self._sync_role_hint(self.cls.currentText())

        self.launch_mode.currentTextChanged.connect(
            lambda text: self.sandbox_box.setEnabled(text == "sandbox"))
        self.sandbox_box.setEnabled(self.launch_mode.currentText() == "sandbox")

        self._pick_timer = QTimer(self)
        self._pick_timer.setInterval(100)
        self._pick_timer.timeout.connect(self._poll_pick)
        self._pick_deadline = 0

    # ---- 客户端句柄指定 ----

    def _hwnd_text(self):
        return str(self.hwnd) if self.hwnd else "未绑定"

    def _clear_hwnd(self):
        self.hwnd = 0
        self.hwnd_label.setText(self._hwnd_text())

    def _pick_client(self):
        """鼠标点选客户端：按钮松开后，下一次左键按下的窗口即目标。"""
        self.hwnd_label.setText("请点击目标游戏窗口（任意位置均可，15 秒内）…")
        self._pick_deadline = time.time() + 15
        self._pick_timer.start()

    def _poll_pick(self):
        if time.time() > self._pick_deadline:
            self._pick_timer.stop()
            self.hwnd_label.setText(self._hwnd_text())
            return
        if not win32api.GetAsyncKeyState(win32con.VK_LBUTTON) & 0x8000:
            return
        pos = win32api.GetCursorPos()
        # 用 GA_ROOTOWNER 而不是 GA_ROOT：游戏客户端 = UnityWndClass 框架窗口 +
        # 铺满客户区的 Qt 覆盖层（标题 "cahx-win"，真正接收点击、登录界面在这一层），
        # 两层是 owner 关系 → GA_ROOT 会归到覆盖层，点客户端内部（不是标题栏）会被
        # 误判成"不是游戏窗口"。GA_ROOTOWNER 统一归到框架窗口。
        hwnd = win32gui.GetAncestor(win32gui.WindowFromPoint(pos), win32con.GA_ROOTOWNER)
        _, pid = win32process.GetWindowThreadProcessId(hwnd)
        if pid == os.getpid():
            return  # 点到本工具自己的窗口，忽略继续等
        title = win32gui.GetWindowText(hwnd)
        if Device.DEFAULT_KEYWORD in title:
            self.hwnd = hwnd
            self._pick_timer.stop()
            self.hwnd_label.setText(f"{hwnd} ✓")
            log.info("账号指定客户端句柄: %s（%s）", hwnd, title)
        else:
            self.hwnd_label.setText("不是游戏窗口，请重新点击…")

    # ---- 职业（门派）→ 分类联动 ----

    def _sync_role_hint(self, text):
        cls = "" if text == "未指定" else text
        if cls:
            self.role_hint.setText(
                f"分类：{gamecls.role_of(cls)}（任务按分类差异化；"
                "登录时可通过角色徽标自动识别门派）")
        else:
            self.role_hint.setText(
                "未指定门派：任务按原分类执行；登录时会尝试按角色徽标自动识别")

    def _on_ok(self):
        cls = self.cls.currentText()
        data = {
            "account": self.account.text().strip(),
            "server": self.server.text().strip(),
            "character": self.character.text().strip(),
            "role": gamecls.role_of(cls) or self._initial_role or "输出",
            "cls": "" if cls == "未指定" else cls,
            "pwd2": self.pwd2.text().strip(),
            "hwnd": self.hwnd,
            "launch_mode": self.launch_mode.currentText(),
            "sandbox_box": self.sandbox_box.currentText(),
        }
        for field, label in (("account", "账号"), ("server", "区服"), ("character", "角色名")):
            if not data[field]:
                QMessageBox.warning(self, "缺少信息", f"请填写{label}")
                return
        if data["launch_mode"] == "direct":
            data["sandbox_box"] = ""
        self.result = data
        self.accept()


# ============================================================================
# 一条龙配置向导 / 开始任务向导（共用宽度常量）
# ============================================================================


YT_L_WIDTH = 1180       # 向导宽度：成员任务列并排要够宽
YT_L_CHIP_W = 96        # 成员列里的芯片估算宽度（2 枚一行）


class YitiaolongDialog(BaseModal):
    """一条龙配置向导（三步）。

    三步（顶部步骤条，底部「上一步 / 下一步 / 保存方案」）：
      ① 选人与队长  恰好 5 人（账号库下拉 ×5）+ 指定队长；可载入/删除已存方案
      ② 组队方式    一键组队 / 手动组队；是否自动启动缺失客户端（preflight）
      ③ 每人任务    5 列并排；**组队任务（日常副本）只有队长能勾**，其余 4 列是
                    跟随队长的镜像只读芯片；单人任务每位成员各自勾选

    向导**只负责配置**：`self.result` = 落盘后的方案 dict（含 id）；启动要走任务页
    横幅的「开始一条龙」（不要在这里直接开跑）。
    """

    STEPS = ("选人与队长", "组队方式", "每人任务")

    def __init__(self, parent, plan=None):
        super().__init__(parent, "一条龙配置", width=YT_L_WIDTH)
        self.result = None
        self._step = 0
        self._accounts = db.list_accounts()
        self._acc_by_id = {a["id"]: a for a in self._accounts}
        # {**空方案, **已存方案}：保留 id/updated_at，缺的键用默认值补齐
        self._plan = {**ytl.empty_plan(), **(plan or {})}
        from core.scheduler import Scheduler
        self._registry = Scheduler._load_tasks()
        self._team_names = ytl.team_task_names(self._registry)
        self._single_names = ytl.single_task_names(self._registry)
        self._order = _config_task_order(self._registry)
        self._team_mode = ytl.DEFAULT_TEAM_MODE
        self._sel_team = set()
        self._sel_self = {}
        self._page3_dirty = True
        self._team_chips = {}      # 任务名 -> 队长列芯片
        self._team_mirrors = []    # [(任务名, 镜像芯片)]（非队长列）
        self._self_chips = {}      # (账号id, 任务名) -> 芯片
        self._loading_plan = False

        cl = self.content_layout
        cl.setSpacing(16)
        cl.addWidget(self._build_step_bar())

        host = QFrame()
        host.setProperty("role", "fieldGroup")
        self._pages_host = QVBoxLayout(host)
        self._pages_host.setContentsMargins(0, 0, 0, 0)
        self._pages_host.setSpacing(0)
        self._pages = [self._build_page_members(), self._build_page_team(),
                       self._build_page_tasks()]
        for p in self._pages:
            self._pages_host.addWidget(p)
        cl.addWidget(host)

        self._customize_footer()      # 定制底栏（须在自己字段都建好之后）
        self._load_plan_into_form(self._plan)
        self._goto(0)

    # ---- 步骤条 ----

    def _build_step_bar(self):
        bar = QFrame()
        bar.setProperty("role", "fieldGroup")
        h = QHBoxLayout(bar)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(8)
        self._step_dots, self._step_texts, self._step_lines = [], [], []
        for i, name in enumerate(self.STEPS):
            if i:
                line = QFrame()
                line.setProperty("role", "stepLine")
                line.setFixedWidth(40)
                h.addWidget(line)
                self._step_lines.append(line)
            dot = QLabel(str(i + 1))
            set_prop(dot, role="stepDot")
            dot.setAlignment(Qt.AlignCenter)
            txt = QLabel(name)
            set_prop(txt, role="stepText")
            h.addWidget(dot)
            h.addWidget(txt)
            self._step_dots.append(dot)
            self._step_texts.append(txt)
        h.addStretch(1)
        return bar

    def _customize_footer(self):
        """底部栏：最左「上一步」，右侧「取消 / 下一步·保存方案」。

        末步只保存**不启动**——启动一律由任务页横幅的「开始一条龙」发起
        （用户 2026-10-11 反馈：向导点完不该自己跑起来）。
        （覆写 BaseModal 的同名钩子；不要在子类覆写 `_build_footer`。）
        """
        fh = self.footer_layout
        self.back_btn = _btn("上一步", slot=lambda: self._goto(self._step - 1))
        fh.insertWidget(0, self.back_btn)

    def _goto(self, step):
        step = max(0, min(step, len(self.STEPS) - 1))
        if step == 2 and self._page3_dirty:
            self._rebuild_task_page()
        self._step = step
        for i, p in enumerate(self._pages):
            p.setVisible(i == self._step)
        for i, (dot, txt) in enumerate(zip(self._step_dots, self._step_texts)):
            state = "done" if i < self._step else ("current" if i == self._step else "next")
            dot.setText("✓" if i < self._step else str(i + 1))
            set_state(dot, state)
            set_state(txt, state)
        for i, line in enumerate(self._step_lines):
            set_state(line, "done" if i < self._step else "next")
        self.back_btn.setVisible(self._step > 0)
        last = self._step == len(self.STEPS) - 1
        self.ok_btn.setText("保存方案" if last else "下一步")
        self.ok_btn.setToolTip("只保存方案，不启动；保存后在任务页点「开始一条龙」启动"
                               if last else "进入下一步")
        self._fit_body()

    # ---- 第 1 步：选人与队长 ----

    def _build_page_members(self):
        page = QFrame()
        page.setProperty("role", "fieldGroup")
        v = QVBoxLayout(page)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(12)

        row = QHBoxLayout()
        row.setSpacing(8)
        row.addWidget(self.field_label("方案名称"))
        self.name_edit = QLineEdit()
        self.name_edit.setProperty("role", "field")
        self.name_edit.setPlaceholderText("例如：早班一条龙")
        repolish(self.name_edit)
        self.name_edit.setMinimumWidth(240)
        row.addWidget(self.name_edit, 1)
        row.addWidget(self.field_label("已存方案"))
        self.load_combo = QComboBox()
        self.load_combo.setMinimumWidth(220)
        self.load_combo.currentIndexChanged.connect(self._on_load_combo)
        row.addWidget(self.load_combo)
        self.del_btn = _btn("删除方案", variant="danger", slot=self._delete_plan)
        row.addWidget(self.del_btn)
        v.addLayout(row)

        v.addWidget(self.hint_label(
            "一条龙固定 5 人（上限 5、最少 5）。点「设为队长」决定谁带队——"
            "队长的组队任务决定全队跑哪些副本；队员端自动跟随。"))

        state_row = QHBoxLayout()
        state_row.setSpacing(8)
        self.picked_pill = QLabel("已选 0/5")
        set_prop(self.picked_pill, role="ytlStep")
        self.captain_state = self.hint_label("队长：未指定")
        state_row.addWidget(self.picked_pill)
        state_row.addWidget(self.captain_state)
        state_row.addStretch(1)
        state_row.addWidget(_btn("自动填充前 5 个账号", slot=self._autofill_slots))
        state_row.addWidget(_btn("清空", slot=self._clear_slots))
        v.addLayout(state_row)

        slots = QHBoxLayout()
        slots.setSpacing(10)
        self._slot_widgets = []
        for i in range(ytl.TEAM_SIZE):
            sw = self._build_slot(i)
            slots.addWidget(sw["frame"], 1)
            self._slot_widgets.append(sw)
        v.addLayout(slots)
        return page

    def _build_slot(self, index):
        """一个成员槽：序号 + 队长徽章 + 账号下拉 + 「设为队长」。"""
        slot = QFrame()
        slot.setProperty("role", "memberSlot")
        v = QVBoxLayout(slot)
        v.setContentsMargins(12, 10, 12, 12)
        v.setSpacing(8)

        head = QHBoxLayout()
        head.setSpacing(6)
        idx = QLabel(f"位置 {index + 1}")
        set_prop(idx, role="slotIndex")
        badge = QLabel("队长")
        set_prop(badge, role="captainBadge")
        set_state(badge, "idle")
        head.addWidget(idx)
        head.addStretch(1)
        head.addWidget(badge)
        v.addLayout(head)

        combo = QComboBox()
        combo.addItem("（未选择）", None)
        for a in self._accounts:
            combo.addItem(a["character"], a["id"])
            combo.setItemData(combo.count() - 1,
                              f"{a['account']} / {a.get('server', '')} / {a.get('role', '')}",
                              Qt.ToolTipRole)
        combo.currentIndexChanged.connect(self._on_slot_changed)
        v.addWidget(combo)

        cap = QPushButton("设为队长")
        styled(cap, role="subchip")
        cap.setCheckable(True)
        cap.setFixedHeight(24)
        cap.clicked.connect(lambda _=False, i=index: self._on_captain_clicked(i))
        v.addWidget(cap)
        repolish(slot)
        return {"frame": slot, "combo": combo, "cap": cap, "badge": badge,
                "index": index}

    def _combo_index(self, acc_id):
        if acc_id is None:
            return 0
        i = self._slot_widgets[0]["combo"].findData(acc_id)
        return 0 if i < 0 else i

    def _slot_members(self):
        return [sw["combo"].currentData() for sw in self._slot_widgets]

    def _cap_index(self):
        for i, sw in enumerate(self._slot_widgets):
            if sw["cap"].isChecked():
                return i
        return None

    def _on_captain_clicked(self, index):
        """队长单选：点未选中的槽 = 设为队长；再点自己 = 取消（回到未指定）。

        QPushButton 的 checkable 会在 clicked 之前自动翻转，所以这里读到的
        `isChecked()` 已经是点击后的新状态。
        """
        now_on = self._slot_widgets[index]["cap"].isChecked()
        for i, sw in enumerate(self._slot_widgets):
            want = now_on and (i == index)
            if sw["cap"].isChecked() != want:
                sw["cap"].blockSignals(True)
                sw["cap"].setChecked(want)
                sw["cap"].blockSignals(False)
            sw["cap"].setText("队长 ✓" if want else "设为队长")
        self._refresh_member_state()

    def _on_slot_changed(self, *_):
        if self._loading_plan:
            return
        self._refresh_member_state()

    def _refresh_member_state(self):
        """刷新成员槽外观 + 顶部状态（已选 n/5、队长、重复提示）+ 第 2 步队伍预览。"""
        members = self._slot_members()
        picked = [m for m in members if m is not None]
        cap_i = self._cap_index()
        for i, sw in enumerate(self._slot_widgets):
            mid = members[i]
            is_cap = mid is not None and i == cap_i
            set_prop(sw["frame"], filled="true" if mid is not None else "false",
                     captain="true" if is_cap else "false")
            sw["badge"].setVisible(is_cap)
            if is_cap:
                # 构造时挂过 state="idle"（灰），当上队长要回到默认主色样式
                sw["badge"].setProperty("state", "")
                repolish(sw["badge"])
            sw["cap"].setEnabled(True)
        self.picked_pill.setText(f"已选 {len(picked)}/5")
        dup = len(picked) != len(set(picked))
        if dup:
            self.captain_state.setText("有重复账号，请调整")
            set_state(self.captain_state, "fail")
        else:
            cap_acc = self._acc_by_id.get(members[cap_i]) if cap_i is not None else None
            self.captain_state.setText(
                f"队长：{cap_acc['character']}" if cap_acc else "队长：未指定")
            set_state(self.captain_state, "next")
        # 第 2 步队伍预览（队长排最前）
        if cap_i is not None:
            ordered = [members[cap_i]] + [m for i, m in enumerate(members) if i != cap_i]
            head = "（队长）"
        else:
            ordered = members
            head = ""
        names = [self._acc_by_id[m]["character"] for m in ordered if m is not None]
        self.team_preview.setText(
            ("队伍：" + head + " · ".join(names)) if names else "队伍：—")
        self._page3_dirty = True

    def _autofill_slots(self):
        """按账号库顺序把空槽填满（已选的保留）。"""
        used = {m for m in self._slot_members() if m is not None}
        queue = [a["id"] for a in self._accounts if a["id"] not in used]
        self._loading_plan = True
        try:
            for sw in self._slot_widgets:
                if sw["combo"].currentData() is None and queue:
                    sw["combo"].setCurrentIndex(self._combo_index(queue.pop(0)))
        finally:
            self._loading_plan = False
        self._refresh_member_state()

    def _clear_slots(self):
        self._loading_plan = True
        try:
            for i, sw in enumerate(self._slot_widgets):
                sw["combo"].setCurrentIndex(0)
                sw["cap"].setChecked(False)
                sw["cap"].setText("设为队长")
        finally:
            self._loading_plan = False
        self._refresh_member_state()

    # ---- 第 2 步：组队方式 ----

    def _build_page_team(self):
        page = QFrame()
        page.setProperty("role", "fieldGroup")
        v = QVBoxLayout(page)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(12)
        v.addWidget(self.hint_label(
            "组队方式决定 5 人怎么凑成一队（写入「5开组队」任务）。"
            "组队副本、单人任务都在下一步逐人勾选。"))
        cards = QHBoxLayout()
        cards.setSpacing(12)
        self._mode_cards = {}
        for key, (title, desc) in ytl.TEAM_MODES.items():
            c = _ChoiceCard(title, desc,
                            tag="推荐" if key == ytl.DEFAULT_TEAM_MODE else "")
            c.clicked.connect(lambda k=key: self._set_team_mode(k))
            cards.addWidget(c, 1)
            self._mode_cards[key] = c
        v.addLayout(cards)
        self.team_preview = self.hint_label("队伍：—")
        v.addWidget(self.team_preview)
        self.preflight_cb = QCheckBox("客户端未开时自动启动并登录（推荐）")
        self.preflight_cb.setChecked(bool(self._plan.get("preflight", True)))
        v.addWidget(self.preflight_cb)
        v.addWidget(self.hint_label(
            "任务执行顺序仍按 config.yaml 的排列（组队副本在前、收尾在后），"
            "方案只决定「每个人跑哪些」。" ))
        return page

    def _set_team_mode(self, key):
        if key not in ytl.TEAM_MODES:
            return
        self._team_mode = key
        for k, c in self._mode_cards.items():
            c.setSelected(k == key)

    # ---- 第 3 步：每人任务 ----

    def _build_page_tasks(self):
        page = QFrame()
        page.setProperty("role", "fieldGroup")
        v = QVBoxLayout(page)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(10)
        self._p3_hint = self.hint_label("")
        v.addWidget(self._p3_hint)
        self._p3_cols = QHBoxLayout()
        self._p3_cols.setSpacing(10)
        v.addLayout(self._p3_cols)
        return page

    def _rebuild_task_page(self):
        while self._p3_cols.count():
            item = self._p3_cols.takeAt(0)
            if item.widget():
                item.widget().setParent(None)
        self._team_chips, self._team_mirrors, self._self_chips = {}, [], {}
        members = self._slot_members()
        cap_i = self._cap_index()
        for pos, acc_id in enumerate(members):
            self._p3_cols.addWidget(
                self._build_member_col(pos, acc_id,
                                       acc_id is not None and cap_i == pos), 1)
        self._sync_team_mirrors()
        self._refresh_task_hint()
        self._page3_dirty = False

    def _build_member_col(self, pos, acc_id, is_cap):
        """第 3 步的一列（一名成员的任务卡）。"""
        acc = self._acc_by_id.get(acc_id) if acc_id is not None else None
        col = QFrame()
        col.setProperty("role", "memberCol")
        col.setProperty("captain", "true" if is_cap else "false")
        v = QVBoxLayout(col)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)

        head = QFrame()
        head.setProperty("role", "memberColHead")
        hv = QVBoxLayout(head)
        hv.setContentsMargins(10, 8, 10, 8)
        hv.setSpacing(2)
        h1 = QHBoxLayout()
        h1.setSpacing(6)
        name = QLabel((acc["character"] if acc else "（未选成员）"))
        set_prop(name, role="memberName")
        h1.addWidget(name)
        h1.addStretch(1)
        if is_cap:
            badge = QLabel("队长")
            set_prop(badge, role="captainBadge")
            h1.addWidget(badge)
        hv.addLayout(h1)
        meta = QLabel(self._member_meta(acc) if acc else "该位置未选择账号")
        set_prop(meta, role="memberMeta")
        hv.addWidget(meta)
        v.addWidget(head)

        body = QFrame()
        body.setProperty("role", "fieldGroup")
        bv = QVBoxLayout(body)
        bv.setContentsMargins(10, 10, 10, 10)
        bv.setSpacing(6)

        # 组队任务
        gt = QLabel("组队任务")
        set_prop(gt, role="colGroupTitle", muted="false" if is_cap else "true")
        bv.addLayout(self._group_head(
            gt, on_all=(lambda: self._set_all_team(True)) if is_cap else None,
            on_none=(lambda: self._set_all_team(False)) if is_cap else None))
        if not is_cap:
            follow = QLabel("跟随队长 · 只读")
            set_prop(follow, role="followHint")
            bv.addWidget(follow)
        bv.addLayout(self._chips_pairs(self._team_names, acc_id,
                                       team=True, mirror=not is_cap))

        # 单人任务
        st = QLabel("单人任务")
        set_prop(st, role="colGroupTitle")
        bv.addLayout(self._group_head(
            st,
            on_all=(lambda a=acc_id: self._set_all_self(a, True)) if acc_id else None,
            on_none=(lambda a=acc_id: self._set_all_self(a, False)) if acc_id else None))
        bv.addLayout(self._chips_pairs(self._single_names, acc_id,
                                       team=False, mirror=False))
        bv.addStretch(1)
        v.addWidget(body, 1)
        repolish(col)
        return col

    @staticmethod
    def _member_meta(acc):
        parts = [acc.get("role") or ""]
        parts.append(f"id{acc['id']}")
        return " · ".join(p for p in parts if p)

    @staticmethod
    def _group_head(title_label, on_all=None, on_none=None):
        """分组标题行：标题 + 右侧「全选/清空」链接（无回调时只显示标题）。"""
        h = QHBoxLayout()
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(4)
        h.addWidget(title_label)
        h.addStretch(1)
        if on_all is not None:
            b = QPushButton("全选")
            styled(b, variant="link")
            b.setFixedHeight(20)
            b.clicked.connect(lambda _=False: on_all())
            h.addWidget(b)
        if on_none is not None:
            b = QPushButton("清空")
            styled(b, variant="link")
            b.setFixedHeight(20)
            b.clicked.connect(lambda _=False: on_none())
            h.addWidget(b)
        return h

    def _chips_pairs(self, names, acc_id, team, mirror):
        """把任务芯片排成"每行 2 枚"的竖排（5 列并排时省高度、宽度可预期）。"""
        box = QVBoxLayout()
        box.setSpacing(6)
        row = None
        for i, name in enumerate(names):
            chip = QPushButton()
            styled(chip, role="chipSmall")
            chip.setCheckable(True)
            chip.setFixedHeight(Size.CHIP_SM_H)
            chip.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            chip.setProperty("_title", self._registry[name].title)
            if mirror:
                chip.setProperty("mirror", "true")
                chip.setEnabled(False)
                chip.setChecked(name in self._sel_team)
                self._team_mirrors.append((name, chip))
            elif team:
                chip.setChecked(name in self._sel_team)
                chip.toggled.connect(lambda on, n=name: self._on_team_toggle(n, on))
                self._team_chips[name] = chip
            else:
                chip.setChecked(name in self._sel_self.get(acc_id, set()))
                chip.toggled.connect(
                    lambda on, n=name, a=acc_id: self._on_self_toggle(a, n, on))
                self._self_chips[(acc_id, name)] = chip
            self._set_chip_text(chip)
            repolish(chip)
            if i % 2 == 0:
                row = QHBoxLayout()
                row.setSpacing(6)
                box.addLayout(row)
            row.addWidget(chip)
        return box

    @staticmethod
    def _set_chip_text(chip):
        title = chip.property("_title") or ""
        chip.setText(("✓ " if chip.isChecked() else "") + title)

    def _on_team_toggle(self, name, on):
        if on:
            self._sel_team.add(name)
            if "zudui" not in self._sel_team and name != "zudui":
                self._set_team_checked("zudui", True)   # 自动带上「5开组队」拉队
        elif name == "zudui":
            # 取消「5开组队」= 不做任何组队副本（没它组不成队），一并取消其它
            for n in list(self._sel_team - {"zudui"}):
                self._set_team_checked(n, False)
            self._sel_team.discard("zudui")
        else:
            self._sel_team.discard(name)
        self._sync_team_mirrors()
        self._refresh_task_hint()

    def _set_team_checked(self, name, on):
        chip = self._team_chips.get(name)
        if chip is not None:
            chip.blockSignals(True)
            chip.setChecked(on)
            self._set_chip_text(chip)
            chip.blockSignals(False)
        if on:
            self._sel_team.add(name)
        else:
            self._sel_team.discard(name)

    def _set_all_team(self, on):
        for n in self._team_names:
            self._set_team_checked(n, on)
        if on and "zudui" in self._team_names:
            self._set_team_checked("zudui", True)
        self._sync_team_mirrors()
        self._refresh_task_hint()

    def _sync_team_mirrors(self):
        """把队长列的组队任务勾选状态同步到其余 4 列的镜像芯片（只读）。"""
        for name, chip in self._team_mirrors:
            chip.setChecked(name in self._sel_team)
            self._set_chip_text(chip)

    def _on_self_toggle(self, acc_id, name, on):
        sel = self._sel_self.setdefault(acc_id, set())
        if on:
            sel.add(name)
        else:
            sel.discard(name)
        chip = self._self_chips.get((acc_id, name))
        if chip is not None:
            self._set_chip_text(chip)
        self._refresh_task_hint()

    def _set_all_self(self, acc_id, on):
        for name in self._single_names:
            chip = self._self_chips.get((acc_id, name))
            if chip is None:
                continue
            chip.blockSignals(True)
            chip.setChecked(on)
            self._set_chip_text(chip)
            chip.blockSignals(False)
        self._sel_self[acc_id] = set(self._single_names) if on else set()
        self._refresh_task_hint()

    def _refresh_task_hint(self):
        n_self = sum(len(v) for v in self._sel_self.values())
        self._p3_hint.setText(
            f"组队任务（日常副本）共 {len(self._team_names)} 项，只有队长能勾，勾上后 5 人全队一起跑"
            f"（系统会自动带上「5开组队」）；单人任务每位成员各自勾选。"
            f"当前：组队 {len(self._sel_team)} 项 / 单人合计 {n_self} 项。")

    # ---- 方案载入 / 删除 ----

    def _reload_plan_combo(self, select_id=None):
        self._loading_plan = True
        try:
            self.load_combo.clear()
            self.load_combo.addItem("（新建方案）", None)
            for p in ytl.plans():
                self.load_combo.addItem(p.get("name") or f"方案 {p.get('id')}",
                                        p.get("id"))
            if select_id:
                i = self.load_combo.findData(select_id)
                if i >= 0:
                    self.load_combo.setCurrentIndex(i)
        finally:
            self._loading_plan = False

    def _on_load_combo(self, *_):
        if self._loading_plan:
            return
        pid = self.load_combo.currentData()
        if pid is None:
            self._plan = ytl.empty_plan()
            self._sel_team, self._sel_self = set(), {}
            self._load_plan_into_form(self._plan)
            return
        plan = ytl.get(pid)
        if plan:
            self._plan = plan
            self._load_plan_into_form(plan)

    def _delete_plan(self):
        pid = self.load_combo.currentData()
        if not pid:
            QMessageBox.information(self, "提示", "当前是新建方案，没有可删除的已存方案")
            return
        plan = ytl.get(pid)
        if not _confirm_destructive(
                self, "确认删除",
                f"删除一条龙方案「{plan.get('name') if plan else pid}」？\n\n此操作不可撤销。"):
            return
        ytl.remove(pid)
        self._plan = ytl.empty_plan()
        self._sel_team, self._sel_self = set(), {}
        self._load_plan_into_form(self._plan)
        log.info("已删除一条龙方案 id=%s", pid)

    def _load_plan_into_form(self, plan):
        self._loading_plan = True
        try:
            self.name_edit.setText(plan.get("name") or "")
            members = ytl.member_ids(plan)
            for i, sw in enumerate(self._slot_widgets):
                mid = members[i] if i < len(members) else None
                sw["combo"].setCurrentIndex(self._combo_index(mid))
                want = mid is not None and mid == ytl.captain_id(plan)
                sw["cap"].setChecked(want)
                sw["cap"].setText("队长 ✓" if want else "设为队长")
            self._sel_team = {n for n in (plan.get("team_tasks") or [])
                              if n in self._registry}
            self._sel_self = {}
            for k, v in (plan.get("self_tasks") or {}).items():
                try:
                    self._sel_self[int(k)] = {n for n in (v or []) if n in self._registry}
                except (TypeError, ValueError):
                    continue
            self._set_team_mode(plan.get("team_mode") or ytl.DEFAULT_TEAM_MODE)
            self.preflight_cb.setChecked(bool(plan.get("preflight", True)))
        finally:
            self._loading_plan = False
        self._reload_plan_combo(select_id=plan.get("id") or None)
        self._refresh_member_state()

    # ---- 校验 / 收集 ----

    def _check_step(self, step, quiet=False):
        """校验某一步，返回是否通过（quiet=True 时不弹窗，只用于第 3 步渲染前对齐）。"""
        err = None
        if step == 0:
            members = self._slot_members()
            if not self.name_edit.text().strip():
                err = "请填写方案名称（例如「早班一条龙」）"
            elif any(m is None for m in members):
                err = f"请选满 {ytl.TEAM_SIZE} 名成员（5 个位置都要选）"
            elif len(set(members)) != len(members):
                err = "同一个账号被选了多次，请重新分配 5 个成员"
            elif self._cap_index() is None:
                err = "请点「设为队长」指定一名队长"
        elif step == 2:
            if not self._sel_team and not any(self._sel_self.values()):
                err = "请至少勾选一个任务（组队任务只有队长能勾）"
        if err and not quiet:
            QMessageBox.warning(self, "还差一点", err)
            self._fit_body()
        return err is None

    def _collect(self):
        members = self._slot_members()
        cap_i = self._cap_index()
        order = self._order
        self_tasks = {}
        for m in members:
            if m is None:
                continue
            picked = [n for n in order if n in self._sel_self.get(m, set())]
            if picked:
                self_tasks[str(m)] = picked
        return {
            "id": self._plan.get("id") or 0,
            "name": self.name_edit.text().strip(),
            "members": members,
            "captain": members[cap_i] if cap_i is not None else None,
            "team_mode": self._team_mode,
            "self_tasks": self_tasks,
            "team_tasks": [n for n in self._team_names if n in self._sel_team],
            "preflight": self.preflight_cb.isChecked(),
        }

    def _save(self):
        """保存方案并关闭。**只保存，不启动**（启动由任务页横幅负责）。"""
        for step in (0, 2):
            if not self._check_step(step):
                self._goto(step)
                return
        plan = self._collect()
        err = ytl.validate(plan, {a["id"] for a in self._accounts})
        if err:
            QMessageBox.warning(self, "还差一点", err)
            return
        self.result = ytl.upsert(plan)
        log.info("一条龙方案已保存：%s（id=%s，%d 人，组队 %d 项，单人 %d 项）",
                 self.result.get("name"), self.result.get("id"),
                 len(self.result.get("members") or []),
                 len(self.result.get("team_tasks") or []),
                 sum(len(v) for v in (self.result.get("self_tasks") or {}).values()))
        self.accept()

    def _on_ok(self):
        if self._step < len(self.STEPS) - 1:
            if self._check_step(self._step):
                self._goto(self._step + 1)
            return
        self._save()


# ============================================================================
# 开始任务向导（选人 → 选任务 → 需要组队时选队员）
# ============================================================================


class StartTasksDialog(BaseModal):
    """「开始任务」三步向导：先选人、再选任务、存在组队任务时再选队员。

    ① 选人    本次要跑的账号（**默认全不勾**——用户规则，不再沿用账号登录页
              的勾选；要跑谁在这里明确选）。
    ② 选任务  组队任务（日常副本）是**全队共享**的一组（勾上后队员全队一起跑，
              自动带上「5开组队」，取消它=清空全部组队任务）；单人任务每账号
              一列各自勾选。**预填来源 = 默认清单**（`config.yaml` 的
              `tasks[].enabled`，即任务页 ③ 卡展示的那份），本次可临时增删。
              **本步是任务清单的唯一编辑处**（2026-10-12 起任务页不再摊开芯片墙）：
              · 「任务参数」行：带参数的任务（海市蜃楼层数 / 做烹饪类型）就地选；
              · 「保存为默认清单」勾选框：勾上才把本次勾选写回 `config.yaml`。
                由任务页 ③ 卡的「在向导里编辑」进入时默认勾上且置灰（`edit_default`）。
    ③ 组队    仅当勾了组队任务：组队方式（一键/手动）+ 队长 + 队员勾选 +
              手输队外队员名（队友不是自己多开时逐个搜索邀请）。
              人数下限（用户规则）：组队任务至少 3 人、含打地鼠 2 人；
              手动组队名单不足下限直接拦下，一键组队允许靠游戏自动补齐（软提示）。

    确认后 self.result = {
        "accounts":  [account dict] 本轮执行的账号（队长的 is_captain 为内存态）
        "names":     [任务名] 本轮任务并集（全局顺序）
        "names_map": {账号id: [任务名]} 每账号任务清单
        "team":      None | {"captain": id, "members": [id...],
                             "extra_names": [角色名...], "mode": auto|manual}
        "overrides": {任务名: {键: 值}}  本次要覆盖的任务参数（海市蜃楼层数等）
        "preflight": bool  客户端没开时自动启动并登录
    }

    注意：一次运行只支持一个队长/一支队（用户 2026-10-11 确认）；多队长=
    多支队并行需要把副本协同按队伍隔离，暂未实现。
    """

    STEPS = ("选人", "选任务", "组队")

    def __init__(self, tasks_tab, edit_default=False):
        """`edit_default=True` = 从任务页 ③ 卡的「在向导里编辑」进入：
        「保存为默认清单」默认勾上且置灰，末步按钮文案变「保存并开始」。"""
        super().__init__(tasks_tab, "开始任务", width=YT_L_WIDTH)
        self.result = None
        self._tab = tasks_tab
        self._edit_default = bool(edit_default)
        self._step = 0
        self._accounts = db.list_accounts()
        self._acc_by_id = {a["id"]: a for a in self._accounts}
        from core.scheduler import Scheduler
        self._registry = Scheduler._load_tasks()
        self._team_names = ytl.team_task_names(self._registry)
        self._single_names = ytl.single_task_names(self._registry)
        self._order = _config_task_order(self._registry)
        # 预填来源 = 默认清单（config.yaml 的 tasks[].enabled）：
        # 组队任务直接取交集；每账号的单人任务在 _rebuild_task_page 里按它预填。
        self._default = set(tasks_tab.checked_task_names())
        self._sel_team = {n for n in self._team_names if n in self._default}
        self._sel_self = {}          # acc_id -> set(单人任务名)
        self._picked = []            # 第 1 步勾选的账号 id（按勾选顺序）
        # 任务参数（海市蜃楼层数 / 做烹饪类型）：**全局单值**，与 config.yaml
        # 的存法一致（`_start_run(overrides=...)` 也是全局的，没有按账号的参数）。
        self._params = dict(tasks_tab.saved_params())
        self._param_host = None
        self._param_panels = {}
        self._param_labels = {}
        self._param_shown = []
        with open(CONFIG_PATH, encoding="utf-8") as f:
            cfg = yaml.safe_load(f) or {}
        zentry = next((t for t in cfg.get("tasks", []) if t.get("name") == "zudui"), {})
        self._team_mode = str(zentry.get("mode") or ytl.DEFAULT_TEAM_MODE)
        self._captain_id = None
        self._members = []           # 参与组队的账号 id（不含队长）
        self._extra_names = []       # 手输的队外队员角色名
        self._page2_dirty = True
        self._page3_dirty = True
        self._team_chips = {}
        self._self_chips = {}        # (acc_id, 任务名) -> 芯片

        cl = self.content_layout
        cl.setSpacing(16)
        cl.addWidget(self._build_step_bar())
        host = QFrame()
        host.setProperty("role", "fieldGroup")
        self._pages_host = QVBoxLayout(host)
        self._pages_host.setContentsMargins(0, 0, 0, 0)
        self._pages_host.setSpacing(0)
        self._pages = [self._build_page_pick(), self._build_page_tasks(),
                       self._build_page_team()]
        for p in self._pages:
            self._pages_host.addWidget(p)
        cl.addWidget(host)
        self._customize_footer()      # 定制底栏（须在自己字段都建好之后）
        self._do_refresh_pick_captain()   # 首次同步初始化（后续走去抖版本）
        self._goto(0)

    # ---- 外壳（步骤条 / 底部栏） ----

    def _build_step_bar(self):
        bar = QFrame()
        bar.setProperty("role", "fieldGroup")
        h = QHBoxLayout(bar)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(8)
        self._step_dots, self._step_texts, self._step_lines = [], [], []
        for i, name in enumerate(self.STEPS):
            if i:
                line = QFrame()
                line.setProperty("role", "stepLine")
                line.setFixedWidth(40)
                h.addWidget(line)
                self._step_lines.append(line)
            dot = QLabel(str(i + 1))
            set_prop(dot, role="stepDot")
            dot.setAlignment(Qt.AlignCenter)
            txt = QLabel(name)
            set_prop(txt, role="stepText")
            h.addWidget(dot)
            h.addWidget(txt)
            self._step_dots.append(dot)
            self._step_texts.append(txt)
        h.addStretch(1)
        return bar

    def _customize_footer(self):
        """把默认底栏改造成向导版：插入「保存为默认清单」勾选 + 「上一步」按钮。

        （覆写 BaseModal 的同名钩子；不要在子类覆写 `_build_footer`——默认实现挂在
        `__init__` 早期，那时子类字段尚未建好。）
        """
        fh = self.footer_layout
        self.back_btn = _btn("上一步", slot=lambda: self._goto(self._step - 1))
        # 「保存为默认清单」：勾上才把本次勾选写回 config.yaml（见类文档）。
        # 只在「选任务」这一步显示 —— 第 1 步任务还没选，摆着只会让人困惑。
        self.save_default_cb = QCheckBox("保存为默认清单")
        self.save_default_cb.setToolTip(
            "勾上后，本次的任务勾选与参数会写回 config.yaml，成为「默认清单」，"
            "下次进向导自动预填。\n不勾则本次临时生效，跑完即弃。")
        self.save_default_cb.setChecked(self._edit_default)
        if self._edit_default:
            self.save_default_cb.setEnabled(False)   # 强制写回，不可取消
            self.save_default_cb.setToolTip("从「在向导里编辑」进入：本次一定写回默认清单")
        fh.insertWidget(0, self.save_default_cb)
        self.save_default_cb.setVisible(False)
        fh.insertWidget(1, self.back_btn)

    def _has_team(self):
        """本轮是否包含组队任务（决定第 3 步是否存在、启动前要不要队长）。"""
        return bool(self._sel_team)

    def _min_members(self):
        """组队人数下限（用户规则）：组队任务至少 3 人；含打地鼠 2 人即可。"""
        return 2 if "dishu" in self._sel_team else 3

    def _sync_step3_visible(self):
        """组队任务勾选变化后实时刷新步骤条：无组队任务时第 3 步不存在
        （勾掉最后一个组队任务就退回第 2 步），末步按钮文案（下一步/开始任务）
        也要跟着重新下发。直接复用 _goto 的钳位逻辑即可。"""
        self._goto(self._step)

    def _goto(self, step):
        last = 2 if self._has_team() else 1
        step = max(0, min(step, last))
        if step == 1 and self._page2_dirty:
            self._rebuild_task_page()
        if step == 2 and self._page3_dirty:
            self._rebuild_team_page()
        self._step = step
        # 无组队任务时隐藏第 3 步指示（保持步骤条与实际步骤一致）
        self._step_dots[2].setVisible(last >= 2)
        self._step_texts[2].setVisible(last >= 2)
        self._step_lines[1].setVisible(last >= 2)
        for i, p in enumerate(self._pages):
            p.setVisible(i == self._step)
        for i, (dot, txt) in enumerate(zip(self._step_dots, self._step_texts)):
            state = "done" if i < self._step else ("current" if i == self._step else "next")
            dot.setText("✓" if i < self._step else str(i + 1))
            set_state(dot, state)
            set_state(txt, state)
        for i, line in enumerate(self._step_lines):
            set_state(line, "done" if i < self._step else "next")
        self.back_btn.setVisible(self._step > 0)
        # 「开始任务」只在第 3 步（组队）出现——第 2 步一律「下一步」。
        # 用户 2026-10-11：勾着组队任务时第 2 步冒出"开始任务"很突兀，1 个
        # 账号也能一路点出去跑组队（20:46 实测）。没有组队任务时第 3 步不
        # 存在，第 2 步的「下一步」点击即开始（_on_ok 里有轻确认兜底）。
        # 「保存为默认清单」只在第 2 步（选任务）显示：任务都还没选，摆着没意义
        if hasattr(self, "save_default_cb"):
            self.save_default_cb.setVisible(self._step == 1)
        on_last = self._step == 2
        self.ok_btn.setText(("保存并开始" if self._edit_default else "开始任务")
                            if on_last else "下一步")
        self.ok_btn.setToolTip("按上面配置启动本轮任务" if on_last
                               else ("进入下一步：选择组队方式与队员"
                                     if self._has_team()
                                     else "没有组队任务，点击直接开始本轮任务"))
        self._fit_body()

    # ---- 第 1 步：选人 ----

    def _build_page_pick(self):
        page = QFrame()
        page.setProperty("role", "fieldGroup")
        v = QVBoxLayout(page)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(12)
        v.addWidget(self.hint_label(
            "勾选本次要执行的账号（默认全不勾）。下一步给每个账号分配任务；"
            "勾了组队任务时，下面的「队长」决定谁带队（第 3 步也能改）。"))
        state_row = QHBoxLayout()
        state_row.setSpacing(8)
        self.pick_pill = QLabel("已选 0 个账号")
        set_prop(self.pick_pill, role="ytlStep")
        state_row.addWidget(self.pick_pill)
        # 「全选/清空」紧贴「已选 N 个账号」胶囊（2026-10-12 二次反馈：排在
        # 账号流末尾会跟着账号数换行跑位，固定放在胶囊旁边一眼能找到）。
        for text, on in (("全选", True), ("清空", False)):
            b = QPushButton(text)
            styled(b, variant="link")
            b.setFixedHeight(24)
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False, o=on: self._set_all_picked(o))
            state_row.addWidget(b)
        state_row.addWidget(self.hint_label("组队任务至少 3 人（打地鼠 2 人）；"
                                            "不足 5 人时第 3 步可手输队外队员名字"))
        state_row.addStretch(1)
        v.addLayout(state_row)

        chips_host = QFrame()
        flow = FlowLayout(chips_host, h_spacing=8, v_spacing=8)
        flow.setContentsMargins(0, 0, 0, 0)
        self._pick_checks = []
        for a in self._accounts:
            cb = QCheckBox(f"{a['character']}（{a['account']}）")
            cb.setProperty("role", "accountItem")
            repolish(cb)
            cb.setToolTip(f"{a.get('server', '')} / {a.get('role', '')} / id{a['id']}")
            cb.toggled.connect(lambda on, i=a["id"]: self._on_pick(i, on))
            self._pick_checks.append((a["id"], cb))
            flow.add_chip(cb, 46 + (len(a["character"]) + len(a["account"])) * 13)
        v.addWidget(chips_host)

        # 队长（用户 2026-10-11：账号库的队长标记已删除，队长一律在这里选；
        # 放在第 1 步而不是第 3 步，是为了"没勾组队任务时也能看到队长在哪选"）
        v.addWidget(self.field_label("队长（从上面选中的账号里指定 1 名）"))
        self._pick_cap_host = QFrame()
        self._pick_cap_flow = FlowLayout(self._pick_cap_host, h_spacing=6, v_spacing=6)
        self._pick_cap_flow.setContentsMargins(0, 0, 0, 0)
        v.addWidget(self._pick_cap_host)
        self._pick_cap_hint = self.hint_label("")
        v.addWidget(self._pick_cap_hint)

        self.preflight_cb = QCheckBox("客户端没开时自动启动游戏并登录（preflight）")
        self.preflight_cb.setChecked(True)
        v.addWidget(self.preflight_cb)
        v.addStretch(1)
        return page

    def _make_captain_chip(self, acc_id):
        """队长单选芯片（第 1 步与第 3 步共用同一外观与回调）。"""
        acc = self._acc_by_id.get(acc_id)
        chip = QPushButton(acc["character"] if acc else f"id{acc_id}")
        styled(chip, role="chipSmall")
        chip.setCheckable(True)
        chip.setFixedHeight(Size.CHIP_SM_H)
        chip.setProperty("_title", chip.text())
        chip.setProperty("_acc", acc_id)
        chip.setChecked(acc_id == self._captain_id)
        chip.clicked.connect(lambda _=False, i=acc_id: self._on_captain(i))
        self._set_chip_text(chip)
        repolish(chip)
        return chip

    def _refresh_pick_captain(self):
        """第 1 步的队长芯片跟随「已勾选账号」重建；未勾账号时给出引导。

        2026-10-12 抗抖动：点「全选」时每个勾选都会触发一次本方法，整行芯片
        会被推倒重建 N 次 → 弹窗内容反复跳动。改为合并到本轮事件循环末尾
        只重建一次（QTimer.singleShot(0) 天然去抖）。
        """
        if getattr(self, "_cap_refresh_scheduled", False):
            return
        self._cap_refresh_scheduled = True
        QTimer.singleShot(0, self._do_refresh_pick_captain)

    def _do_refresh_pick_captain(self):
        self._cap_refresh_scheduled = False
        self._sync_captain_state()
        self._pick_cap_flow.clear()
        for acc_id in self._picked:
            chip = self._make_captain_chip(acc_id)
            self._pick_cap_flow.add_chip(chip, 34 + len(chip.property("_title")) * 13)
        if not self._picked:
            self._pick_cap_hint.setText("先在上面勾选账号，再指定队长")
        elif self._captain_id is None:
            self._pick_cap_hint.setText(
                "未指定队长：没勾组队任务就不用指定；勾了组队任务则必须选 1 名队长")
        else:
            self._pick_cap_hint.setText(
                f"队长：{self._acc_by_id.get(self._captain_id, {}).get('character', '')}"
                "（默认取第一个勾选的账号，点上面的芯片可更换；组队任务由他带队邀请）")

    def _sync_captain_state(self):
        """队长只可能出自本次选中的账号——账号勾选变化后统一校正。"""
        if self._captain_id not in self._picked:
            self._captain_id = None

    def _on_pick(self, acc_id, on):
        if on:
            if acc_id not in self._picked:
                self._picked.append(acc_id)
                if self._captain_id is None:
                    # 第一个被勾选的账号默认当队长（用户可随时点芯片更换）：
                    # 免得走到第 3 步才被告知"必须指定队长"
                    self._captain_id = acc_id
        else:
            self._picked = [i for i in self._picked if i != acc_id]
        self.pick_pill.setText(f"已选 {len(self._picked)} 个账号")
        self._refresh_pick_captain()
        self._page2_dirty = True
        self._page3_dirty = True

    def _set_all_picked(self, on):
        for _, cb in self._pick_checks:
            if cb.isChecked() != on:
                cb.setChecked(on)
        self._refresh_pick_captain()   # 兜底：勾选态没变化时 toggled 不会触发

    # ---- 第 2 步：选任务 ----

    def _build_page_tasks(self):
        page = QFrame()
        page.setProperty("role", "fieldGroup")
        v = QVBoxLayout(page)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(10)
        self._p2_hint = self.hint_label("")
        v.addWidget(self._p2_hint)
        # 共享的组队任务区（全队一起跑，与单账号无关）
        team_card = QFrame()
        team_card.setProperty("role", "memberCol")
        tv = QVBoxLayout(team_card)
        tv.setContentsMargins(0, 0, 0, 0)
        tv.setSpacing(0)
        head = QFrame()
        head.setProperty("role", "memberColHead")
        hv = QHBoxLayout(head)
        hv.setContentsMargins(10, 8, 10, 8)
        gt = QLabel("组队任务（全队一起跑）")
        set_prop(gt, role="colGroupTitle")
        hv.addWidget(gt)
        hv.addStretch(1)
        for text, on in (("全选", True), ("清空", False)):
            b = QPushButton(text)
            styled(b, variant="link")
            b.setFixedHeight(20)
            b.clicked.connect(lambda _=False, o=on: self._set_all_team(o))
            hv.addWidget(b)
        tv.addWidget(head)
        body = QFrame()
        body.setProperty("role", "fieldGroup")
        bv = QVBoxLayout(body)
        bv.setContentsMargins(10, 10, 10, 10)
        bv.setSpacing(8)
        bv.addWidget(self.hint_label(
            "勾任意组队副本会自动带上「5开组队」（负责把全队拉进同一支队伍）；"
            "取消「5开组队」会一并清空其它组队任务"))
        self._team_chips_host = QFrame()
        self._team_flow = FlowLayout(self._team_chips_host, h_spacing=6, v_spacing=6)
        self._team_flow.setContentsMargins(0, 0, 0, 0)
        bv.addWidget(self._team_chips_host)
        # 「任务参数」挂载点：带参数的任务（海市蜃楼层数 / 做烹饪类型）就地选。
        # 参数是**全局单值**（与 config.yaml、_start_run(overrides=) 一致），
        # 所以只在这里出现一次，不跟着每个账号列重复。
        self._param_host = QFrame()
        self._param_host.setProperty("role", "fieldGroup")
        pv = QVBoxLayout(self._param_host)
        pv.setContentsMargins(0, 0, 0, 0)
        pv.setSpacing(8)
        bv.addWidget(self._param_host)
        tv.addWidget(body)
        v.addWidget(team_card)
        # 每账号一列的单人任务
        self._p2_cols = QHBoxLayout()
        self._p2_cols.setSpacing(10)
        v.addLayout(self._p2_cols)
        return page

    # ---- 第 2 步：任务参数（§5 02 / §06 ②）----

    def _rebuild_param_row(self):
        """重建「任务参数」行：只列出**本次已勾选**的带参数任务。

        参数面板与芯片区一样只 `setVisible` 开合，不销毁重建；
        任务集合没变时只刷新文案（避免勾一个任务就把展开状态重置掉）。
        """
        if self._param_host is None:
            return
        selected = set(self._sel_team)
        for v in self._sel_self.values():
            selected |= v
        shown = [n for n in TasksTab.PARAM_TASKS if n in selected]
        if shown == self._param_shown:
            self._refresh_param_labels()
            return
        self._param_shown = shown
        self._param_panels, self._param_labels = {}, {}
        lay = self._param_host.layout()
        while lay.count():
            item = lay.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)
        if not shown:
            return

        head = QLabel("任务参数")
        set_prop(head, role="colGroupTitle")
        lay.addWidget(head)
        for name in shown:
            self._build_param_row(lay, name)
        self._refresh_param_labels()

    def _build_param_row(self, lay, name):
        """为一个带参数任务建「标题行 + 可展开选项面板」，登记到 _param_labels/_param_panels。"""
        spec = TasksTab.PARAM_SPECS[name]
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(6)
        title = QLabel(spec["title"])
        set_prop(title, role="fieldLabel")
        row.addWidget(title)
        val = QLabel("")
        set_prop(val, role="subMeta")
        row.addWidget(val)
        row.addStretch(1)
        btn = QPushButton("▾")
        btn.setCursor(Qt.PointingHandCursor)
        styled(btn, role="chipParam")
        btn.setFixedSize(18, Size.CHIP_SM_H)
        btn.setToolTip("展开 / 收起参数选项")
        row.addWidget(btn)
        lay.addLayout(row)
        self._param_labels[name] = val

        panel = QFrame()
        panel.setProperty("role", "subpanel")
        pv = QVBoxLayout(panel)
        pv.setContentsMargins(14, 12, 14, 12)
        pv.setSpacing(10)
        chips_host = QFrame()
        flow = FlowLayout(chips_host, h_spacing=6, v_spacing=6)
        flow.setContentsMargins(0, 0, 0, 0)
        pv.addWidget(chips_host)
        group = QButtonGroup(panel)
        group.setExclusive(True)   # 单选互斥：始终有且仅有一个选中
        cur = self._params.get(name, spec["default"])
        for value, label in spec["options"]:
            sc = QPushButton(label)
            styled(sc, role="subchip")
            sc.setCheckable(True)
            group.addButton(sc)
            sc.setChecked(value == cur)
            sc.toggled.connect(
                lambda on, n=name, v=value: self._on_param_pick(n, v, on))
            flow.add_chip(sc, 16 + len(label) * 11)
        panel.setVisible(False)
        lay.addWidget(panel)
        btn.clicked.connect(lambda _=False, n=name: self._toggle_param_panel(n))
        self._param_panels[name] = {"panel": panel, "btn": btn}

    def _on_param_pick(self, name, value, on):
        if not on:
            return          # 互斥组切换瞬间的中间态，忽略
        self._params[name] = value
        self._refresh_param_labels()

    def _toggle_param_panel(self, name):
        rec = self._param_panels.get(name)
        if not rec:
            return
        # 展开态以 expanded 属性为准，**不用 isVisible()**：本步的页面在
        # `_goto()` 里整页 setVisible(False)，祖先隐藏时 isVisible() 恒为 False，
        # 会把「点第二次收起」误判成「再展开」（离屏自检实测踩到）。
        on = rec["btn"].property("expanded") != "true"
        rec["panel"].setVisible(on)
        rec["btn"].setProperty("expanded", "true" if on else "false")
        repolish(rec["btn"])

    def _refresh_param_labels(self):
        """把当前参数值写到行尾（缺省值显示「默认 · X」，方便一眼看出改没改）。"""
        for name, lab in self._param_labels.items():
            spec = TasksTab.PARAM_SPECS[name]
            value = self._params.get(name, spec["default"])
            is_default = value == spec["default"]
            lab.setText(("默认 · " if is_default else "") + spec["short"](value))

    def _rebuild_task_page(self):
        while self._p2_cols.count():
            item = self._p2_cols.takeAt(0)
            if item.widget():
                item.widget().setParent(None)
        self._team_flow.clear()
        self._team_chips, self._self_chips = {}, {}
        # 组队任务芯片（共享一组）
        for name in self._team_names:
            chip = QPushButton()
            styled(chip, role="chipSmall")
            chip.setCheckable(True)
            chip.setFixedHeight(Size.CHIP_SM_H)
            chip.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            chip.setProperty("_title", self._registry[name].title)
            chip.setChecked(name in self._sel_team)
            chip.toggled.connect(lambda on, n=name: self._on_team_toggle(n, on))
            self._set_chip_text(chip)
            repolish(chip)
            self._team_flow.add_chip(chip, 30 + len(chip.property("_title")) * 13)
            self._team_chips[name] = chip
        # 每账号一列（只有单人任务；组队任务全队共享，见上）。
        # 预填来源 = 默认清单里的单人任务；用户在某列手动改过之后不再覆盖
        # （setdefault：只在首次进入这一列时铺默认值）。
        default_singles = {n for n in self._single_names if n in self._default}
        for acc_id in self._picked:
            self._sel_self.setdefault(acc_id, set(default_singles))
            self._p2_cols.addWidget(self._build_self_col(acc_id), 1)
        self._rebuild_param_row()
        self._refresh_p2_hint()
        self._page2_dirty = False

    def _build_self_col(self, acc_id):
        """第 2 步的一列：账号头 + 该账号的单人任务芯片。"""
        acc = self._acc_by_id.get(acc_id)
        col = QFrame()
        col.setProperty("role", "memberCol")
        v = QVBoxLayout(col)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)
        head = QFrame()
        head.setProperty("role", "memberColHead")
        hv = QVBoxLayout(head)
        hv.setContentsMargins(10, 8, 10, 8)
        hv.setSpacing(2)
        name = QLabel(acc["character"] if acc else f"id{acc_id}")
        set_prop(name, role="memberName")
        hv.addWidget(name)
        meta = QLabel(self._member_meta(acc) if acc else "")
        set_prop(meta, role="memberMeta")
        hv.addWidget(meta)
        v.addWidget(head)
        body = QFrame()
        body.setProperty("role", "fieldGroup")
        bv = QVBoxLayout(body)
        bv.setContentsMargins(10, 10, 10, 10)
        bv.setSpacing(6)
        st = QLabel("单人任务")
        set_prop(st, role="colGroupTitle")
        bv.addLayout(self._group_head(
            st,
            on_all=(lambda a=acc_id: self._set_all_self(a, True)) if acc_id else None,
            on_none=(lambda a=acc_id: self._set_all_self(a, False)) if acc_id else None))
        sel = self._sel_self.setdefault(acc_id, set())
        box = QVBoxLayout()
        box.setSpacing(6)
        row = None
        for i, tname in enumerate(self._single_names):
            chip = QPushButton()
            styled(chip, role="chipSmall")
            chip.setCheckable(True)
            chip.setFixedHeight(Size.CHIP_SM_H)
            chip.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            chip.setProperty("_title", self._registry[tname].title)
            chip.setChecked(tname in sel)
            chip.toggled.connect(
                lambda on, n=tname, a=acc_id: self._on_self_toggle(a, n, on))
            self._self_chips[(acc_id, tname)] = chip
            self._set_chip_text(chip)
            repolish(chip)
            if i % 2 == 0:
                row = QHBoxLayout()
                row.setSpacing(6)
                box.addLayout(row)
            row.addWidget(chip)
        bv.addLayout(box)
        bv.addStretch(1)
        v.addWidget(body, 1)
        repolish(col)
        return col

    def _on_team_toggle(self, name, on):
        if on:
            self._sel_team.add(name)
            if "zudui" not in self._sel_team and name != "zudui":
                self._set_team_checked("zudui", True)   # 自动带上「5开组队」拉队
        elif name == "zudui":
            for n in list(self._sel_team - {"zudui"}):
                self._set_team_checked(n, False)
            self._sel_team.discard("zudui")
        else:
            self._sel_team.discard(name)
        self._rebuild_param_row()
        self._refresh_p2_hint()
        self._page3_dirty = True
        self._sync_step3_visible()

    def _set_team_checked(self, name, on):
        chip = self._team_chips.get(name)
        if chip is not None:
            chip.blockSignals(True)
            chip.setChecked(on)
            self._set_chip_text(chip)
            chip.blockSignals(False)
        if on:
            self._sel_team.add(name)
        else:
            self._sel_team.discard(name)

    def _set_all_team(self, on):
        for n in self._team_names:
            self._set_team_checked(n, on)
        if on and "zudui" in self._team_names:
            self._set_team_checked("zudui", True)
        self._refresh_p2_hint()
        self._page3_dirty = True
        self._sync_step3_visible()

    def _on_self_toggle(self, acc_id, name, on):
        sel = self._sel_self.setdefault(acc_id, set())
        if on:
            sel.add(name)
        else:
            sel.discard(name)
        chip = self._self_chips.get((acc_id, name))
        if chip is not None:
            self._set_chip_text(chip)
        self._rebuild_param_row()
        self._refresh_p2_hint()

    def _set_all_self(self, acc_id, on):
        for name in self._single_names:
            chip = self._self_chips.get((acc_id, name))
            if chip is None:
                continue
            chip.blockSignals(True)
            chip.setChecked(on)
            self._set_chip_text(chip)
            chip.blockSignals(False)
        self._sel_self[acc_id] = set(self._single_names) if on else set()
        self._rebuild_param_row()
        self._refresh_p2_hint()

    def _refresh_p2_hint(self):
        n_self = sum(len(v) for v in self._sel_self.values())
        tail = ("本次一定写回默认清单（从「在向导里编辑」进入）"
                if self._edit_default
                else "勾上左下角「保存为默认清单」会写回配置，不勾则只对本次生效")
        self._p2_hint.setText(
            f"已选 {len(self._picked)} 个账号：组队任务 {len(self._sel_team)} 项"
            f"（全队一起跑）/ 单人任务按账号各自勾选（当前合计 {n_self} 项）。"
            + tail)

    @staticmethod
    def _set_chip_text(chip):
        title = chip.property("_title") or ""
        chip.setText(("✓ " if chip.isChecked() else "") + title)

    @staticmethod
    def _member_meta(acc):
        parts = [acc.get("role") or ""]
        parts.append(f"id{acc['id']}")
        return " · ".join(p for p in parts if p)

    @staticmethod
    def _group_head(title_label, on_all=None, on_none=None):
        h = QHBoxLayout()
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(4)
        h.addWidget(title_label)
        h.addStretch(1)
        if on_all is not None:
            b = QPushButton("全选")
            styled(b, variant="link")
            b.setFixedHeight(20)
            b.clicked.connect(lambda _=False: on_all())
            h.addWidget(b)
        if on_none is not None:
            b = QPushButton("清空")
            styled(b, variant="link")
            b.setFixedHeight(20)
            b.clicked.connect(lambda _=False: on_none())
            h.addWidget(b)
        return h

    # ---- 第 3 步：组队（方式 / 队长 / 队员 / 手输名字） ----

    def _build_page_team(self):
        page = QFrame()
        page.setProperty("role", "fieldGroup")
        v = QVBoxLayout(page)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(12)
        self._p3_top_hint = self.hint_label("")
        v.addWidget(self._p3_top_hint)

        v.addWidget(self.field_label("组队方式"))
        modes = QHBoxLayout()
        modes.setSpacing(10)
        self._mode_cards = {}
        for key in ("auto", "manual"):
            title, desc = ytl.TEAM_MODES[key]
            card = _ChoiceCard(title, desc,
                               tag="推荐" if key == "auto" else "可邀队外好友")
            card.setSelected(key == self._team_mode)
            card.clicked.connect(lambda k=key: self._set_team_mode(k))
            modes.addWidget(card, 1)
            self._mode_cards[key] = card
        v.addLayout(modes)

        self._cap_label = self.field_label("队长（从本次选中的账号里指定 1 名）")
        v.addWidget(self._cap_label)
        self._cap_host = QFrame()
        self._cap_flow = FlowLayout(self._cap_host, h_spacing=6, v_spacing=6)
        self._cap_flow.setContentsMargins(0, 0, 0, 0)
        v.addWidget(self._cap_host)

        self._mem_label = self.field_label(
            "队员（勾选参与组队的账号，收到邀请会自动接受；不勾的只跑单人任务）")
        v.addWidget(self._mem_label)
        self._mem_host = QFrame()
        self._mem_flow = FlowLayout(self._mem_host, h_spacing=8, v_spacing=6)
        self._mem_flow.setContentsMargins(0, 0, 0, 0)
        v.addWidget(self._mem_host)

        # 手输队外队员名（队友不是自己多开时，手动组队按名字逐个搜索邀请）
        self._extra_label = self.field_label(
            "队外队员（手动组队时按名字逐个搜索邀请；一键组队用不上）")
        v.addWidget(self._extra_label)
        erow = QHBoxLayout()
        erow.setSpacing(8)
        self.extra_edit = QLineEdit()
        self.extra_edit.setProperty("role", "field")
        self.extra_edit.setPlaceholderText(
            "输入队友角色名，回车或点「添加」；最多 4 个（队伍上限 5 人）")
        repolish(self.extra_edit)
        self.extra_edit.returnPressed.connect(self._add_extra_name)
        erow.addWidget(self.extra_edit, 1)
        erow.addWidget(_btn("添加", slot=self._add_extra_name))
        v.addLayout(erow)
        self._extra_chips_host = QFrame()
        self._extra_flow = FlowLayout(self._extra_chips_host, h_spacing=6, v_spacing=6)
        self._extra_flow.setContentsMargins(0, 0, 0, 0)
        v.addWidget(self._extra_chips_host)

        self._roster_hint = self.hint_label("")
        v.addWidget(self._roster_hint)
        v.addStretch(1)
        return page

    def _rebuild_team_page(self):
        """第 3 步随第 1/2 步的选择重建（队长候选 / 队员勾选 / 手输名字）。"""
        team_titles = "、".join(self._registry[n].title for n in self._order
                                if n in self._sel_team)
        self._p3_top_hint.setText(
            f"已勾选 {len(self._sel_team)} 项组队任务（{team_titles}）。"
            f"本次运行只支持 1 名队长 / 1 支队伍；组队任务至少 {self._min_members()} 人"
            "（工具按队伍面板实际人数判定，人数不够会自动补邀，仍不足则本次跳过"
            "组队任务、单人任务照常跑完）。")
        # 队长候选芯片（与第 1 步同一份 _captain_id，两边都能选）
        self._cap_flow.clear()
        self._sync_captain_state()
        for acc_id in self._picked:
            cap = self._make_captain_chip(acc_id)
            self._cap_flow.add_chip(cap, 34 + len(cap.property("_title")) * 13)
        # 队员勾选（默认 = 除队长外的全部选中账号）
        if self._captain_id is None:
            self._members = []
        else:
            keep = [m for m in self._members
                    if m in self._picked and m != self._captain_id]
            self._members = keep or [i for i in self._picked if i != self._captain_id]
        self._mem_flow.clear()
        for acc_id in self._picked:
            if acc_id == self._captain_id:
                continue
            acc = self._acc_by_id.get(acc_id)
            cb = QCheckBox(acc["character"] if acc else f"id{acc_id}")
            cb.setProperty("role", "accountItem")
            repolish(cb)
            cb.setChecked(acc_id in self._members)
            cb.toggled.connect(lambda on, i=acc_id: self._on_member(i, on))
            self._mem_flow.add_chip(cb, 46 + len(cb.text()) * 13)
        self._refresh_extra_chips()
        self._refresh_roster_hint()
        self._page3_dirty = False

    def _set_team_mode(self, key):
        self._team_mode = key
        for k, card in self._mode_cards.items():
            card.setSelected(k == key)
        self._refresh_roster_hint()

    def _on_captain(self, acc_id):
        """队长单选（第 1 步与第 3 步共用）；换队长后重建队员区
        （默认 = 其余全部选中账号）并同步第 1 步的芯片勾选态。"""
        self._captain_id = acc_id
        self._refresh_pick_captain()
        self._rebuild_team_page()

    def _on_member(self, acc_id, on):
        if on:
            if acc_id not in self._members:
                self._members.append(acc_id)
        else:
            self._members = [i for i in self._members if i != acc_id]
        self._refresh_roster_hint()

    def _add_extra_name(self):
        name = self.extra_edit.text().strip()
        self.extra_edit.clear()
        if len(name) < 2:
            QMessageBox.information(self, "提示", "角色名至少 2 个字")
            return
        if name in self._extra_names:
            QMessageBox.information(self, "提示", f"「{name}」已经在名单里")
            return
        if any((self._acc_by_id.get(i) or {}).get("character") == name
               for i in self._picked):
            QMessageBox.information(self, "提示",
                                    f"「{name}」是本次选中的账号，不需要手输")
            return
        if len(self._extra_names) >= 4:
            QMessageBox.information(self, "提示", "队外队员最多 4 个（队伍上限 5 人）")
            return
        self._extra_names.append(name)
        self._refresh_extra_chips()
        self._refresh_roster_hint()

    def _refresh_extra_chips(self):
        self._extra_flow.clear()
        for name in self._extra_names:
            chip = QPushButton(f"{name} ✕")
            styled(chip, role="chipSmall")
            chip.setFixedHeight(Size.CHIP_SM_H)
            chip.setToolTip("点击移除该队员")
            chip.clicked.connect(lambda _=False, n=name: self._remove_extra(n))
            repolish(chip)
            self._extra_flow.add_chip(chip, 46 + len(name) * 13)

    def _remove_extra(self, name):
        self._extra_names = [n for n in self._extra_names if n != name]
        self._refresh_extra_chips()
        self._refresh_roster_hint()

    def _roster(self):
        """组队名单（人数校验/手动组队邀请用）：队长 + 勾选队员 + 手输名字。"""
        ids = []
        if self._captain_id is not None:
            ids.append(self._captain_id)
        ids.extend(i for i in self._members if i not in ids)
        names = [self._acc_by_id[i]["character"] for i in ids if i in self._acc_by_id]
        names += [n for n in self._extra_names if n not in names]
        return ids, names

    def _refresh_roster_hint(self):
        if not hasattr(self, "_roster_hint"):
            return
        _, names = self._roster()
        need = self._min_members()
        mode_txt = ytl.TEAM_MODES.get(self._team_mode, ("", ""))[0]
        joined = "、".join(names) or "空"
        if self._team_mode == "manual" and len(names) < need:
            self._roster_hint.setText(
                f"⚠ 名单只有 {len(names)} 人（{joined}），手动组队至少要 {need} 人，"
                "否则凑不齐——请勾选队员或手输队外队员名")
            set_state(self._roster_hint, "fail")
        elif len(names) < need:
            self._roster_hint.setText(
                f"⚠ 名单只有 {len(names)} 人（{joined}），不足组队任务最低 {need} 人，"
                "还不能开始——请勾选队员或手输队外队员名"
                "（开始后游戏会自动补邀帮会成员凑满 5 人）")
            set_state(self._roster_hint, "fail")
        else:
            self._roster_hint.setText(
                f"名单 {len(names)} 人（{joined}），满足组队任务最低 {need} 人；"
                f"组队方式：{mode_txt}。超过 2 分钟未同意的队友先放弃，"
                "人数不够时每 60 秒补邀一轮（最多 5 轮）")
            set_state(self._roster_hint, "next")

    # ---- 校验 / 收集 ----

    def _check_step(self, step, quiet=False):
        err = None
        if step == 0:
            if not self._picked:
                err = "请至少勾选一个要执行的账号"
        elif step == 1:
            if not self._sel_team and not any(self._sel_self.values()):
                err = "请至少勾选一个任务"
        elif step == 2:
            if not self._captain_id:
                err = "请指定一名队长（组队任务由队长发起）"
            else:
                _, names = self._roster()
                if len(names) < self._min_members():
                    # 不分一键/手动：人太少的组队没有意义（用户 2026-10-11：
                    # 1 个账号也曾一路点到开始并跑起来）。一键组队可以靠游戏
                    # 自动补邀帮会成员，但自己的名单至少要有下限这么多。
                    err = (f"组队名单只有 {len(names)} 人，凑不齐组队任务最低 "
                           f"{self._min_members()} 人——请勾选队员或手输队外队员名"
                           "（开始后游戏还会自动补邀帮会成员凑满 5 人）")
        if err and not quiet:
            QMessageBox.warning(self, "还差一点", err)
            self._fit_body()
        return err is None

    def _collect(self):
        member_ids, _names = self._roster()
        member_set = set(member_ids)
        team_set = set(self._sel_team)
        order = self._order
        names_map = {}
        for acc_id in self._picked:
            own = [n for n in order if n in self._sel_self.get(acc_id, set())]
            if acc_id in member_set:
                # 组队任务全队一致：队员 = 自己的单人任务 ∪ 组队任务
                own = [n for n in order if n in set(own) or n in team_set]
            names_map[acc_id] = own
        used = set(team_set)
        for v in self._sel_self.values():
            used |= v
        names = [n for n in order if n in used]
        accounts = []
        for acc_id in self._picked:
            if acc_id not in self._acc_by_id:
                continue
            a = dict(self._acc_by_id[acc_id])
            a["is_captain"] = 1 if acc_id == self._captain_id else 0
            accounts.append(a)
        team = None
        if self._has_team():
            team = {"captain": self._captain_id,
                    "members": [i for i in member_ids if i != self._captain_id],
                    "extra_names": list(self._extra_names),
                    "mode": self._team_mode}
        # 本次要覆盖的任务参数：只带**本次实际会跑到**的、且不是缺省值的项
        overrides = {}
        for n, value in self._params.items():
            spec = TasksTab.PARAM_SPECS.get(n)
            if spec is not None and n in used and value != spec["default"]:
                overrides[n] = {spec["key"]: value}
        return {"accounts": accounts, "names": names, "names_map": names_map,
                "team": team, "overrides": overrides,
                "preflight": self.preflight_cb.isChecked()}

    def _on_ok(self):
        last = 2 if self._has_team() else 1
        if self._step < last:
            if self._check_step(self._step):
                self._goto(self._step + 1)
            return
        for step in range(last + 1):
            if not self._check_step(step):
                self._goto(step)
                return
        # 没有组队任务时第 2 步就是末步、按钮是「下一步」：点它=开始。
        # 先给一次轻确认，避免"下一步"点了却直接跑起来（按钮文案不再在
        # 「开始任务/下一步」之间闪变——用户 2026-10-11 反馈突兀）。
        if not self._has_team():
            ret = QMessageBox.question(
                self, "开始任务",
                "没有勾选组队任务——按当前清单直接开始本轮任务？",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if ret != QMessageBox.Yes:
                return
        # 组队人数不足 5（队伍上限）给一次明确确认：一键组队会自动补邀，
        # 但要让用户知道这轮人不够（用户 2026-10-11：3 个人也能直接点开始）。
        # 纯打地鼠轮除外（2 人是它的正常配置）。确认全部通过才收集结果。
        if self._has_team():
            _ids, roster = self._roster()
            pure_dishu = set(self._sel_team) - {"zudui"} == {"dishu"}
            if len(roster) < ytl.TEAM_SIZE and not pure_dishu:
                ret = QMessageBox.question(
                    self, "人数不足 5 人",
                    f"本次组队名单只有 {len(roster)} 人（不足 5 人）。\n"
                    "开始后会自动邀请帮会成员补齐；凑不齐则跳过组队任务、"
                    "单人任务照常跑完。\n仍要开始吗？",
                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
                if ret != QMessageBox.Yes:
                    return
        self.result = self._collect()
        team = self.result["team"]
        cap = self._acc_by_id.get(self._captain_id, {})
        log.info("开始任务向导确认：%d 个账号，任务并集 %d 项%s",
                 len(self.result["accounts"]), len(self.result["names"]),
                 (f"，队长 {cap.get('character')}（{team['mode']}），队员 "
                  f"{len(team['members'])} 个 + 队外 {len(team['extra_names'])} 个"
                  if team else "（无组队任务）"))
        # 「保存为默认清单」：把本次勾选（**并集** —— 即本轮实际会跑的集合）
        # 与参数写回 config.yaml。不勾则本次临时生效，跑完即弃。
        if self.save_default_cb.isChecked():
            names = sorted(self.result["names"], key=self._order.index)
            params = {n: {TasksTab.PARAM_SPECS[n]["key"]: v}
                      for n, v in self._params.items()
                      if n in set(self.result["names"])
                      and n in TasksTab.PARAM_SPECS}
            self._tab.save_default_list(names, params)
        self.accept()


# ============================================================================
# 定时任务编辑弹窗
# ============================================================================


class ScheduleDialog(BaseModal):
    """定时任务条目编辑对话框。确认后结果在 self.result。

    三种条目：
    - 一条龙：勾选参与账号即可，执行时各账号按"按账号编辑任务"里的定制
      清单跑单人任务 + 全队组队/日常副本；
    - 定时小任务：按账号添加——账号下拉框切换，逐个账号勾选它要跑的
      单人任务（日常/帮会），每个账号可以不同；
    - 打地鼠（限时组队副本，12:00/18:00 整点刷新）：勾参与账号即可，
      执行 5开组队→打地鼠；触发时间固定只能选 11:50 / 17:50（提前 10 分钟
      组队回帮等刷新，填其它时间到点白跑）。
    """

    # 打地鼠触发时间：限时副本只有 12:00 / 18:00 两个刷新点，必须提前 10 分钟
    # 进场组队，故触发时间锁死为这两档（用户规则）
    DISHU_TIMES = ("11:50", "17:50")

    def __init__(self, parent, title, initial=None):
        super().__init__(parent, title)
        self.result = None
        initial = initial or {}
        init_type = initial.get("type")
        is_ytl = init_type == "yitiaolong" or initial.get("tasks") == ["*"]

        accounts = db.list_accounts()
        self._build_basic_fields(initial)
        self._build_mode_combo(init_type, is_ytl)
        self._build_ytl_combo(initial)
        self.acc_checks, acc_w = self._build_account_checks(accounts, initial)
        chips_host = self._build_task_chips(accounts, initial)
        self._assemble_content(acc_w, chips_host)
        self.mode.currentIndexChanged.connect(self._toggle_mode)
        self._on_ytl_changed()   # 初始化方案成员提示 + 模式显隐
        self._load_acc_tasks()

    # ---- __init__ 拆解（批次① 上帝方法抽取）----

    def _build_basic_fields(self, initial):
        """名称 / 触发时间（手填）/ 打地鼠固定档位下拉。"""
        self.name = QLineEdit(initial.get("name", ""))
        self.name.setPlaceholderText("例如：早上日常一条龙")
        self.name.setProperty("role", "field")
        repolish(self.name)
        self.time = QLineEdit(initial.get("time", "08:00"))
        self.time.setPlaceholderText("08:00")
        self.time.setProperty("role", "field")
        self.time.setProperty("mono", "true")
        repolish(self.time)
        # 打地鼠专用：触发时间只能从 DISHU_TIMES 里选（下拉，不给手填）
        self.dishu_time = QComboBox()
        self.dishu_time.addItems(self.DISHU_TIMES)
        cur_time = (initial.get("time") or "").strip()
        self.dishu_time.setCurrentText(
            cur_time if cur_time in self.DISHU_TIMES else self.DISHU_TIMES[0])

    def _build_mode_combo(self, init_type, is_ytl):
        """模式下拉；索引 0=一条龙 / 1=定时小任务 / 2=打地鼠。"""
        self.mode = QComboBox()
        self.mode.addItems(["一条龙（各账号定制任务＋组队/副本＋收尾）",
                            "定时小任务（按账号添加）",
                            "打地鼠（限时组队，触发时间固定 11:50 / 17:50）"])
        self.mode.setCurrentIndex(
            2 if init_type == "dishu" else (0 if is_ytl else 1))

    def _build_ytl_combo(self, initial):
        """一条龙方案下拉。必须选任务页里配好的方案模板（"按账号定制清单"功能
        已删除，没有可回退的执行方式）。"""
        self.ytl_combo = QComboBox()
        self.ytl_combo.setMinimumWidth(360)
        plans = ytl.plans()
        if plans:
            for p in plans:
                self.ytl_combo.addItem(p.get("name") or f"方案 {p.get('id')}", p.get("id"))
        else:
            self.ytl_combo.addItem("（尚无方案——先到任务页「一条龙」横幅新建）", None)
        if initial.get("plan_id") is not None:
            i = self.ytl_combo.findData(initial.get("plan_id"))
            if i >= 0:
                self.ytl_combo.setCurrentIndex(i)
        self.ytl_combo.currentIndexChanged.connect(lambda *_: self._on_ytl_changed())

    def _build_account_checks(self, accounts, initial):
        """参与账号勾选列（一条龙/打地鼠模式用）。返回 (acc_checks, acc_w)。"""
        chosen_acc = set(initial.get("accounts") or [a["id"] for a in accounts])
        self._chosen_acc = chosen_acc
        acc_checks = []
        acc_box = QVBoxLayout()
        acc_box.setSpacing(8)
        acc_w = QFrame()
        for a in accounts:
            cb = QCheckBox(f"{a['character']}（{a['account']}）")
            cb.setProperty("role", "accountItem")
            repolish(cb)
            cb.setChecked(a["id"] in chosen_acc)
            acc_checks.append((a["id"], cb))
            acc_box.addWidget(cb)
        acc_w.setLayout(acc_box)
        return acc_checks, acc_w

    def _build_task_chips(self, accounts, initial):
        """定时小任务：账号下拉 + 各账号任务 chip 勾选。返回 chips_host。

        只列单人任务（日常/帮会）；组队/副本走一条龙。
        """
        raw_tasks = initial.get("tasks")
        if isinstance(raw_tasks, dict):
            self._task_map = {int(k): list(v) for k, v in raw_tasks.items()}
        elif isinstance(raw_tasks, list) and raw_tasks and raw_tasks != ["*"]:
            self._task_map = {i: list(raw_tasks) for i in self._chosen_acc}
        else:
            self._task_map = {}
        self.task_acc_combo = QComboBox()
        for a in accounts:
            self.task_acc_combo.addItem(f"{a['character']}（{a['account']}）", a["id"])
        from core.scheduler import Scheduler
        chips_host = QFrame()
        self._chips_layout = FlowLayout(chips_host, h_spacing=6, v_spacing=6)
        self._chips_layout.setContentsMargins(0, 0, 0, 0)
        self.task_checks = []
        for cls in Scheduler._load_tasks().values():
            if getattr(cls, "category", "日常任务") == "日常副本":
                continue  # 小任务只列单人任务；组队/副本走一条龙
            cb = QPushButton(cls.title)
            styled(cb, role="chipSmall")
            cb.setCheckable(True)
            cb.setFixedHeight(Size.CHIP_SM_H)
            self.task_checks.append((cls.name, cb))
            self._chips_layout.add_chip(cb, 26 + len(cls.title) * 13)
        self.task_acc_combo.currentIndexChanged.connect(lambda *_: self._save_then_load())
        return chips_host

    def _assemble_content(self, acc_w, chips_host):
        """把已建好的控件按顺序放进 content_layout，并记下显隐分组。"""
        self._custom_widgets = [acc_w]  # 小任务模式下参与账号区不显示（账号由任务映射决定）
        cl = self.content_layout
        cl.addWidget(self.field_label("名称"))
        cl.addWidget(self.name)
        cl.addWidget(self.field_label("触发时间"))
        cl.addWidget(self.time)
        cl.addWidget(self.dishu_time)
        self._time_hint = self.hint_label("每天到点触发（GUI 需保持打开）；执行中到点则当天跳过")
        cl.addWidget(self._time_hint)
        self._dishu_time_hint = self.hint_label(
            "打地鼠：12:00 / 18:00 整点刷新，触发时间固定为 11:50 或 17:50"
            "（提前 10 分钟组队回帮等刷新）")
        cl.addWidget(self._dishu_time_hint)
        cl.addWidget(self.field_label("模式"))
        cl.addWidget(self.mode)
        self._ytl_label = self.field_label("一条龙方案")
        self._ytl_hint = self.hint_label(
            "一条龙直接选用任务页里配好的方案模板（5 人 + 队长 + 组队方式 + 每人任务）；"
            "到任务页「一条龙」横幅可新建/编辑方案")
        self._ytl_members = self.hint_label("")
        cl.addWidget(self._ytl_label)
        cl.addWidget(self._ytl_hint)
        cl.addWidget(self.ytl_combo)
        cl.addWidget(self._ytl_members)
        self._acc_label = self.field_label("参与账号")
        cl.addWidget(self._acc_label)
        cl.addWidget(acc_w)
        self._tasks_label = self.field_label("任务清单")
        self._tasks_hint = self.hint_label("小任务：切换账号可逐个勾选它执行的单人任务（组队/副本通用一条龙）")
        cl.addWidget(self._tasks_label)
        cl.addWidget(self._tasks_hint)
        cl.addWidget(self.task_acc_combo)
        cl.addWidget(chips_host)
        self._acc_w = acc_w
        self._custom = [self._tasks_label, self._tasks_hint,
                        self.task_acc_combo, chips_host]

    def _toggle_mode(self, idx):
        """0=一条龙（必选方案，成员以方案为准）/ 2=打地鼠：勾参与账号；
        1=定时小任务：按账号添加任务清单。"""
        is_ytl = idx == 0
        is_dishu = idx == 2
        # 打地鼠的时间是固定档位（下拉），其余模式自由手填，两者互斥显示
        self.time.setVisible(not is_dishu)
        self.dishu_time.setVisible(is_dishu)
        self._dishu_time_hint.setVisible(is_dishu)
        for w in (self._ytl_label, self._ytl_hint, self.ytl_combo):
            w.setVisible(is_ytl)
        self._ytl_members.setVisible(is_ytl)
        self._acc_label.setVisible(not is_ytl)
        self._acc_w.setVisible(not is_ytl)
        for w in self._custom:
            w.setVisible(idx == 1)
        self.adjustSize()

    def _on_ytl_changed(self):
        """方案下拉变化：显示方案成员（只读）。"""
        plan = ytl.get(self.ytl_combo.currentData())
        if plan:
            by_id = {a["id"]: a for a in db.list_accounts()}
            cap = ytl.captain_id(plan)
            names = []
            for m in ytl.member_ids(plan):
                a = by_id.get(m)
                names.append(f"{a['character']}（队长）" if a and m == cap
                             else (a["character"] if a else f"id{m} 已缺失"))
            self._ytl_members.setText(
                f"方案成员：{' · '.join(names)}　｜　{ytl.summarize(plan)}")
        else:
            self._ytl_members.setText("⚠ 尚未选择方案（无方案时该条目到点不会执行）")
        self._toggle_mode(self.mode.currentIndex())

    def _save_then_load(self):
        self._save_acc_tasks()
        self._load_acc_tasks()

    def _load_acc_tasks(self):
        acc_id = self.task_acc_combo.currentData()
        keep = set(self._task_map.get(acc_id, []))
        for name, cb in self.task_checks:
            cb.blockSignals(True)
            cb.setChecked(name in keep)
            cb.setText(("✓ " if name in keep else "") + cb.text().lstrip("✓ "))
            cb.blockSignals(False)

    def _save_acc_tasks(self):
        acc_id = self.task_acc_combo.currentData()
        if acc_id is None:
            return
        names = [n for n, cb in self.task_checks if cb.isChecked()]
        if names:
            self._task_map[acc_id] = names
        else:
            self._task_map.pop(acc_id, None)

    def _on_ok(self):
        if not self.name.text().strip():
            QMessageBox.warning(self, "缺少信息", "请填写名称")
            return
        idx = self.mode.currentIndex()
        if idx in (0, 2):  # 一条龙（必选方案）/ 打地鼠：勾参与账号
            plan_id = None
            if idx == 0:
                plan_id = self.ytl_combo.currentData()
                if not plan_id:
                    QMessageBox.warning(
                        self, "缺少信息",
                        "一条龙必须选择方案——先到任务页「一条龙」横幅新建/配置一个方案")
                    return
                plan = ytl.get(plan_id)
                accounts = ytl.member_ids(plan) if plan else []
            else:
                accounts = [i for i, cb in self.acc_checks if cb.isChecked()]
            if not accounts:
                QMessageBox.warning(self, "缺少信息", "请至少勾选一个参与账号")
                return
            if idx == 2 and len(accounts) < 2:
                QMessageBox.warning(self, "缺少信息",
                                    "打地鼠是组队副本，请至少勾选 2 个参与账号")
                return
            # 打地鼠只跑 11:50 / 17:50 两档（下拉选定），一条龙时间自由填
            time_text = (self.dishu_time.currentText() if idx == 2
                         else (self.time.text().strip() or "08:00"))
            self.result = {
                "name": self.name.text().strip(),
                "time": time_text,
                "type": "yitiaolong" if idx == 0 else "dishu",
                "accounts": accounts,
            }
            if plan_id:
                self.result["plan_id"] = plan_id
        else:
            self._save_acc_tasks()
            if not self._task_map:
                QMessageBox.warning(self, "缺少信息",
                                    "请至少给一个账号勾选任务（或选一条龙模式）")
                return
            self.result = {
                "name": self.name.text().strip(),
                "time": self.time.text().strip() or "08:00",
                "type": "custom",
                "tasks": dict(self._task_map),
            }
        self.accept()


# ============================================================================
# OCR 性能设置弹窗
# ============================================================================


class OcrPerfDialog(BaseModal):
    """OCR 性能设置：引擎池并发（多开时决定 OCR 吞吐）。

    不同电脑 CPU 核数不同，默认"自动"按本机核数估算，通常无需手动调整。
    点"确定"后写回 config.yaml 的 ocr_threads 段并**立即生效**（无需重启进程）。
    """

    def __init__(self, parent):
        super().__init__(parent, "OCR 性能设置")
        info = ocr.pool_config()
        saved = ocr.saved_config()
        auto = saved["engines"] is None and saved["intra_op"] is None

        cl = self.content_layout
        cl.addWidget(self.hint_label(
            f"本机 CPU 逻辑核数：{info['cpu_count']}。多开时多个引擎并行可提升 OCR 吞吐；"
            "默认“自动”会按核数估算，通常不必手动调整。"))

        self.auto_cb = QCheckBox("自动（推荐）：按本机 CPU 核数估算")
        self.auto_cb.setChecked(auto)
        cl.addWidget(self.auto_cb)

        self.engines_cb = QComboBox()
        self.engines_cb.addItems([str(n) for n in range(1, 7)])
        self.engines_cb.setCurrentText(str(saved["engines"] or info["engines"]))
        self.threads_cb = QComboBox()
        self.threads_cb.addItems([str(n) for n in range(1, 17)])
        self.threads_cb.setCurrentText(str(saved["intra_op"] or info["intra_op"]))

        row = QHBoxLayout()
        row.setSpacing(10)
        row.addWidget(self.field_label("并行引擎数"))
        row.addWidget(self.engines_cb)
        row.addSpacing(16)
        row.addWidget(self.field_label("每引擎线程数"))
        row.addWidget(self.threads_cb)
        row.addStretch(1)
        cl.addLayout(row)

        self.preview = QLabel()
        self.preview.setProperty("role", "hint")
        cl.addWidget(self.preview)

        cl.addWidget(self.hint_label(
            "说明：单引擎线程数不是越大越好——线程过多会让多个引擎互相抢核，反而更慢"
            "（实测线程不限时比限线程慢一倍）。自动配置约为「引擎数 × 线程数 ≈ 0.9 × 核数」。"))

        self.auto_cb.toggled.connect(self._sync_enabled)
        self.engines_cb.currentTextChanged.connect(self._refresh_preview)
        self.threads_cb.currentTextChanged.connect(self._refresh_preview)
        self._sync_enabled()

    def _sync_enabled(self, *_):
        on = not self.auto_cb.isChecked()
        self.engines_cb.setEnabled(on)
        self.threads_cb.setEnabled(on)
        self._refresh_preview()

    def _refresh_preview(self, *_):
        cpu = ocr.pool_config()["cpu_count"]
        if self.auto_cb.isChecked():
            e, t = ocr._auto_pool(cpu)
            src = "自动"
        else:
            e, t = int(self.engines_cb.currentText()), int(self.threads_cb.currentText())
            src = "手动"
        total = e * t
        over = "，超过核数、可能变慢" if total > cpu else ""
        self.preview.setText(f"{src}配置：{e} 引擎 × {t} 线程 = {total} 线程 / "
                             f"{cpu} 逻辑核{over}")

    def _on_ok(self):
        if self.auto_cb.isChecked():
            ocr.save_config(None, None)
        else:
            ocr.save_config(int(self.engines_cb.currentText()),
                            int(self.threads_cb.currentText()))
        self.accept()


# ============================================================================
# AI 兜底设置弹窗
# ============================================================================


class AiSettingsDialog(BaseModal):
    """AI 兜底设置：选服务商、贴自己的 API Key、挑模型（面向非技术用户）。

    为什么要做成界面：AI 兜底要用户**自己的**大模型 API Key（没有公共 Key 可用），
    让人去改 config.yaml 填 key 不现实。这里几步搞定——选服务商（自动填接口地址
    与候选模型）→ 贴 Key → 测试连接 → 保存。改完立即生效，无需重启。
    Key 存到 data/ai_key.txt（不在 git 里），不会跟着代码发给别人。
    """

    # 模型下拉里跟在模型名后面的短标注（真实模型名存在 itemData 里，不受影响）
    MODEL_NOTE_SEP = "   ← "

    def __init__(self, parent):
        super().__init__(parent, "AI 兜底设置", width=560)
        cfg = aihelper.config()
        self._probe = None
        self._test_cool = 0.0          # 测试失败后的冷却截止时刻（防连点加重限流）

        cl = self.content_layout
        cl.addWidget(self.hint_label(
            "开启后，脚本遇到没写过的画面会先交给大模型看一眼：能在允许的动作范围内"
            "处理就直接处理掉（只留一张存档截图，不打扰你），处理不了才像以前一样"
            "存图提醒。需要填你自己的 API Key，Key 只保存在本机。"))

        self._build_toggle(cl, cfg)
        self._build_provider(cl)
        self._build_base_url(cl)
        self._build_model(cl)
        self._build_api_key(cl)
        self._build_test_row(cl)
        self._init_provider(cur_url=str(cfg.get("base_url") or "").strip(),
                            model=str(cfg.get("model") or ""))
        self._install_timers()

    # ---- __init__ 拆解（批次① 上帝方法抽取）----

    def _build_toggle(self, cl, cfg):
        """总开关（项目统一的 Toggle 滑动开关样式）。"""
        en_row = QHBoxLayout()
        en_row.setSpacing(10)
        self.enabled_cb = QCheckBox()
        self.enabled_cb.setObjectName("Toggle")
        self.enabled_cb.setFixedSize(Size.TOGGLE_W, Size.TOGGLE_H)
        self.enabled_cb.setCursor(Qt.PointingHandCursor)
        self.enabled_cb.setChecked(bool(cfg.get("enabled")))
        en_label = QLabel("启用 AI 兜底")
        en_label.setCursor(Qt.PointingHandCursor)
        en_label.mouseReleaseEvent = lambda _e: self.enabled_cb.toggle()
        en_row.addWidget(self.enabled_cb)
        en_row.addWidget(en_label)
        en_row.addStretch(1)
        cl.addLayout(en_row)

    def _build_provider(self, cl):
        """服务商下拉 + 说明。"""
        self.provider_cb = QComboBox()
        self.provider_cb.addItems([p["name"] for p in aihelper.PROVIDERS])
        cl.addWidget(self.field_label("服务商"))
        cl.addWidget(self.provider_cb)
        self.provider_hint = self.hint_label("")
        self.provider_hint.setWordWrap(True)
        cl.addWidget(self.provider_hint)

    def _build_base_url(self, cl):
        """OpenAI 兼容接口地址。"""
        cl.addWidget(self.field_label("接口地址"))
        self.base_url_edit = QLineEdit()
        self.base_url_edit.setPlaceholderText("OpenAI 兼容的 chat/completions 地址")
        self.base_url_edit.setProperty("mono", "true")
        cl.addWidget(self.base_url_edit)

    def _build_model(self, cl):
        """模型下拉（可编辑，剥掉「← 说明」后取真名）。"""
        cl.addWidget(self.field_label("模型"))
        self.model_cb = QComboBox()
        self.model_cb.setEditable(True)
        self.model_cb.setInsertPolicy(QComboBox.NoInsert)
        cl.addWidget(self.model_cb)

    def _build_api_key(self, cl):
        """API Key 输入行（可切换明文）+ 去哪里拿 Key 的提示。"""
        cl.addWidget(self.field_label("API Key"))
        key_row = QHBoxLayout()
        key_row.setSpacing(8)
        self.key_edit = QLineEdit()
        self.key_edit.setEchoMode(QLineEdit.Password)
        self.show_key_cb = QCheckBox("显示")
        self.show_key_cb.toggled.connect(
            lambda on: self.key_edit.setEchoMode(
                QLineEdit.Normal if on else QLineEdit.Password))
        key_row.addWidget(self.key_edit, 1)
        key_row.addWidget(self.show_key_cb)
        cl.addLayout(key_row)

        if aihelper.api_key():
            self.key_edit.setPlaceholderText(
                "已配置（%s）· 留空表示不修改" % aihelper.key_source())
        else:
            self.key_edit.setPlaceholderText("在这里粘贴你的 API Key")
        self.key_hint = self.hint_label("")
        self.key_hint.setWordWrap(True)
        cl.addWidget(self.key_hint)

    def _build_test_row(self, cl):
        """测试连接按钮 + 结果标签。"""
        test_row = QHBoxLayout()
        test_row.setSpacing(10)
        self.test_btn = QPushButton("测试连接")
        self.test_btn.setCursor(Qt.PointingHandCursor)
        styled(self.test_btn, variant="tool")
        self.test_btn.clicked.connect(self._start_test)
        self.test_label = self.hint_label("保存前建议先测一下：能通再保存。")
        self.test_label.setWordWrap(True)
        test_row.addWidget(self.test_btn)
        test_row.addWidget(self.test_label, 1)
        cl.addLayout(test_row)

    def _init_provider(self, cur_url, model):
        """初始服务商：按当前 base_url 匹配预设；匹配不上选"自定义"；没配过则用第一家。"""
        idx = next((i for i, p in enumerate(aihelper.PROVIDERS)
                    if p["base_url"] and p["base_url"] == cur_url), None)
        if idx is None:
            idx = len(aihelper.PROVIDERS) - 1 if cur_url else 0
        self.provider_cb.blockSignals(True)
        self.provider_cb.setCurrentIndex(idx)
        self.provider_cb.blockSignals(False)
        self.provider_cb.currentIndexChanged.connect(self._on_provider_changed)
        self._apply_provider(idx, keep_model=model)

    def _install_timers(self):
        """测试在后台线程跑，结果用定时器取回（别让网络请求卡住界面）；
        另有失败冷却倒计时（免费模型被限流时，连点只会越试越堵）。"""
        self._probe_timer = QTimer(self)
        self._probe_timer.setInterval(200)
        self._probe_timer.timeout.connect(self._poll_test)

        self._cool_timer = QTimer(self)
        self._cool_timer.setInterval(500)
        self._cool_timer.timeout.connect(self._tick_cool)

    # ---- 服务商联动 ----

    def _apply_provider(self, idx, keep_model=""):
        p = aihelper.PROVIDERS[idx]
        if p["base_url"]:
            self.base_url_edit.setText(p["base_url"])
        notes = p.get("notes") or {}
        self.model_cb.clear()
        for m in p["models"]:
            note = notes.get(m)
            self.model_cb.addItem(
                ("%s%s%s" % (m, self.MODEL_NOTE_SEP, note)) if note else m, m)
        want = keep_model or (p["models"][0] if p["models"] else "")
        hit = self.model_cb.findData(want)
        if hit >= 0:
            self.model_cb.setCurrentIndex(hit)
        else:
            self.model_cb.setEditText(want)
        self.provider_hint.setText(p["key_hint"] or "")
        self.key_hint.setText(
            ("去哪里拿 Key：%s" % p["key_page"]) if p["key_page"] else "")

    def _current_model(self):
        """取下拉里真正要用的模型名（剥掉「← 说明」那段标注，手打的名字原样用）。"""
        txt = self.model_cb.currentText().strip()
        i = self.model_cb.currentIndex()
        if 0 <= i < self.model_cb.count() and txt == self.model_cb.itemText(i):
            return str(self.model_cb.itemData(i) or txt).strip()
        return txt.split(self.MODEL_NOTE_SEP.strip())[0].strip() \
            if self.MODEL_NOTE_SEP.strip() in txt else txt

    def _on_provider_changed(self, idx):
        self._apply_provider(idx)

    # ---- 测试连接 ----

    TEST_COOL_SEC = 8      # 测试失败后的冷却秒数

    def _start_test(self):
        if self._probe_timer.isActive():            # 上一次还在跑
            return
        left = self._test_cool - time.time()
        if left > 0:
            self.test_label.setText(
                "刚测过，等 %d 秒再试一次——连续点击会让限流更严重。"
                % int(left + 1))
            return
        url = self.base_url_edit.text().strip()
        model = self._current_model()
        if not url or not model:
            self.test_label.setText("请先把接口地址和模型名填上。")
            return
        self.test_btn.setEnabled(False)
        self.test_label.setText("正在测试…（最多约 30 秒）")
        self._probe = None
        threading.Thread(
            target=self._test_worker,
            args=(url, model, self.key_edit.text().strip() or None),
            daemon=True).start()
        self._probe_timer.start()

    def _test_worker(self, url, model, key):
        try:
            ok, msg = aihelper.test_connection(base_url=url, model=model,
                                               api_key_=key)
        except Exception as e:                       # 绝不让线程异常吞掉结果
            ok, msg = False, "测试出错：%s" % e
        self._probe = (ok, msg)

    def _poll_test(self):
        if self._probe is None:
            return
        self._probe_timer.stop()
        ok, msg = self._probe
        self._probe = None
        self.test_label.setText(("✓ " if ok else "✗ ") + msg)
        if ok:
            self.test_btn.setEnabled(True)
            return
        # 失败后冷却一小会儿：限流时连点只会越试越堵，也让用户有机会读完原因
        self._test_cool = time.time() + self.TEST_COOL_SEC
        self.test_btn.setEnabled(False)
        self._cool_timer.start()
        self._tick_cool()

    def _tick_cool(self):
        left = self._test_cool - time.time()
        if left <= 0:
            self._cool_timer.stop()
            self.test_btn.setText("测试连接")
            self.test_btn.setEnabled(True)
            return
        self.test_btn.setText("测试连接（%d）" % int(left + 1))

    # ---- 保存 ----

    def _on_ok(self):
        url = self.base_url_edit.text().strip()
        model = self._current_model()
        key = self.key_edit.text().strip()
        if not url:
            QMessageBox.warning(self, "还差一点", "接口地址不能为空。")
            return
        if not model:
            QMessageBox.warning(self, "还差一点", "模型名不能为空。")
            return
        if self.enabled_cb.isChecked() and not key and not aihelper.api_key():
            QMessageBox.warning(
                self, "还没填 API Key",
                "要启用 AI 兜底就得填一个 API Key。\n\n"
                "上面选了服务商，窗口里会提示去哪里申请；填好后点「测试连接」"
                "验证一下再保存。\n"
                "如果暂时不想开，把「启用 AI 兜底」的勾去掉再保存也行。")
            return

        # 换了服务商 → 清掉旧的备用模型（不同家的模型名不通用，留着只会一直报错）
        old_url = str(aihelper.config().get("base_url") or "").strip()
        fallback = [] if url != old_url else None
        aihelper.save_settings(enabled=self.enabled_cb.isChecked(),
                               base_url=url, model=model,
                               fallback_models=fallback,
                               api_key=key or None)
        self.accept()


# ============================================================================
# 右侧执行状态面板
# ============================================================================


class StatusPanel(QFrame):
    """右侧执行状态卡：每账号一行（状态点 + 角色名 + 进度/状态文字 + 重跑）。

    卡头右侧「一键反馈」链接：本轮有失败项且反馈通道已配置时才显示
    （App._sync_feedback_link 控制），点击弹 FeedbackDialog。
    """

    rerun_requested = Signal(int)  # 行号
    feedback_requested = Signal()  # 「一键反馈」链接

    def __init__(self):
        super().__init__()
        self.setObjectName("Card")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(1, 1, 1, 1)
        lay.setSpacing(0)
        header, hh = _card_header("执行状态", small=True, hint="失败可点击重跑")
        self.feedback_link = _link("一键反馈", self._on_feedback)
        self.feedback_link.setToolTip("把本轮失败的日志包一键发给维护者")
        self.feedback_link.setVisible(False)
        hh.addWidget(self.feedback_link)
        lay.addWidget(header)
        self._rows_host = QFrame()
        self._rows_host.setProperty("role", "fieldGroup")
        self._rows = QVBoxLayout(self._rows_host)
        self._rows.setContentsMargins(0, 0, 0, 0)
        self._rows.setSpacing(0)
        # 账号多时（运行中每行 54px）可滚动，别把窗口最小高度又顶上去
        lay.addWidget(_scroll_host(self._rows_host), 1)
        # row -> dict(row, dot, name, count, info, bar, rerun, line2)
        self._rows_widgets = {}

    def _on_feedback(self):
        self.feedback_requested.emit()

    def set_feedback_visible(self, on):
        """「一键反馈」链接显隐（App 在任务结束后按失败清单+通道配置控制）。"""
        self.feedback_link.setVisible(bool(on))

    def rebuild(self, accounts):
        for w in self._rows_widgets.values():
            w["row"].setParent(None)
        while self._rows.count():
            item = self._rows.takeAt(0)
            if item.widget():
                item.widget().setParent(None)
        self._rows_widgets = {}
        for row, acc in enumerate(accounts):
            rw = QFrame()
            rw.setProperty("role", "statusRow")
            rw.setFixedHeight(Size.STATUS_ROW_H)

            wrap = QVBoxLayout(rw)
            wrap.setContentsMargins(16, 7, 16, 7)
            wrap.setSpacing(4)

            # 第一行：状态点 + 角色名 + 计数 + 重跑
            line1 = QHBoxLayout()
            line1.setSpacing(10)
            dot = QFrame()
            dot.setProperty("role", "dot")
            dot.setFixedSize(Size.DOT, Size.DOT)
            set_state(dot, "idle")
            name = QLabel(acc["character"])
            name.setProperty("role", "statusName")
            count = QLabel("")
            count.setProperty("role", "statusMeta")
            set_state(count, "idle")
            count.setFont(mono_font(FontSize.CAPTION))
            rerun = QPushButton("重跑")
            styled(rerun, variant="link")
            rerun.setVisible(False)
            rerun.clicked.connect(lambda _=False, r=row: self.rerun_requested.emit(r))
            line1.addWidget(dot)
            line1.addWidget(name, 1)
            line1.addWidget(count)
            line1.addWidget(rerun)
            wrap.addLayout(line1)

            # 第二行（运行中/失败时才显示）：当前任务名 / 失败清单 + 整条进度条
            line2 = QWidget()
            l2 = QHBoxLayout(line2)
            l2.setContentsMargins(0, 0, 0, 0)
            l2.setSpacing(8)
            info = QLabel("")
            info.setProperty("role", "statusInfo")
            set_state(info, "idle")
            info.setMaximumWidth(130)
            bar = QProgressBar()
            bar.setFixedHeight(Size.PROGRESS_H)
            bar.setTextVisible(False)
            bar.setVisible(False)
            l2.addWidget(info)
            l2.addWidget(bar, 1)
            line2.setVisible(False)
            wrap.addWidget(line2)

            repolish(rw)
            repolish(name)
            repolish(count)
            repolish(info)
            self._rows.addWidget(rw)
            self._rows_widgets[row] = {"row": rw, "dot": dot, "name": name,
                                       "count": count, "info": info, "bar": bar,
                                       "rerun": rerun, "line2": line2}
        # 最后一行去掉底部分隔线
        if self._rows_widgets:
            self._rows_widgets[max(self._rows_widgets)]["row"].setProperty("last", "true")
            repolish(self._rows_widgets[max(self._rows_widgets)]["row"])
        self._rows.addStretch(1)

    def update_row(self, row, state):
        """state: {total, done, current, failed}。

        空闲行只显示"状态点 + 角色名"，不再显示 `0/19`——原来看起来跟禁用态一样。
        运行中/失败时才展开第二行：左边是当前任务名（失败时是失败清单），
        右边是整条 8px 进度条，一眼能看出跑到哪了、哪台机器出问题。
        """
        w = self._rows_widgets.get(row)
        if not w:
            return
        failed = list(state["failed"])
        running = bool(state["current"])
        total, done = state["total"], state["done"]
        if failed:
            dot_state = row_state = "fail"
        elif running or done > 0:
            dot_state = row_state = "ok"
        else:
            dot_state = row_state = "idle"

        set_state(w["dot"], dot_state)
        set_state(w["count"], dot_state)
        set_state(w["row"], row_state)
        set_state(w["bar"], "fail" if failed else "ok")
        set_state(w["info"], "fail" if failed else ("ok" if running else "idle"))
        w["name"].setProperty("role",
                              "statusNameMuted" if row_state == "idle" else "statusName")
        repolish(w["name"])

        w["count"].setText(f"{done}/{total}" if total and (running or done) else "")

        if failed:
            full = "失败：" + "、".join(failed)
            show = True
        elif running:
            full = state["current"]
            show = True
        else:
            full, show = "", False
        w["info"].setText(_short(full))
        w["info"].setToolTip(full)
        w["line2"].setVisible(show)
        w["bar"].setVisible(show and total > 0)
        if total > 0:
            w["bar"].setMaximum(total)
            w["bar"].setValue(done)
        w["row"].setFixedHeight(Size.STATUS_ROW_H_ACTIVE if show else Size.STATUS_ROW_H)
        w["rerun"].setVisible(bool(failed))


# ============================================================================
# 账号登录页
# ============================================================================


class LoginTab(QFrame):
    """账号登录页：账号管理 + 勾选并行登录 + 顺序调整（卡片区）。"""

    COLUMNS = ("sel", "account", "server", "character", "role",
               "status", "hwnd", "launch_mode", "sandbox_box")
    HEADINGS = ("选", "账号", "区服", "角色名", "职业", "状态",
                "客户端 PID", "启动方式", "沙盒")
    # 诊断信息列：默认隐藏（10 列里它们占了近一半宽度，日常根本不需要看）。
    # 需要排障时从「…」菜单勾「显示诊断列」临时打开。
    DIAG_COLS = ("status", "hwnd", "launch_mode", "sandbox_box")
    EMPTY_TEXT = "还没有账号\n点右上角「添加账号」开始（手机号 + 角色名 + 职业）"

    # 登录结束带回 (成功数, 总数)，供操作区写"上次登录摘要"
    login_finished = Signal(int, int)
    # 沙盘捐赠提醒开关跑完： (想要的新状态, 是否成功, 结果说明)
    sandbox_done = Signal(bool, bool, str)
    # 右键菜单开关跑完： (想要的新状态, 是否成功, 结果说明)
    wintweak_done = Signal(bool, bool, str)

    def __init__(self):
        super().__init__()
        self.setObjectName("Card")
        self._building = False
        self._diag_cols = False
        self._logging_in = False

        lay = QVBoxLayout(self)
        lay.setContentsMargins(1, 1, 1, 1)
        lay.setSpacing(0)

        lay.addWidget(self._build_header())
        lay.addWidget(self._build_table(), 1)
        self._apply_columns()

        # ---- 分割线 + 小工具面板（分割线以下都是小工具）----
        # 2026-10-13 用户红框草图定稿：列表下方先一道分割线，接着「小工具」标题，
        # 标题下面是一整块带边框的大面板，工具按钮排在面板里（悬停看功能解释）。
        self.tools_divider = self._build_tools_divider()
        self.tools_title = self._build_tools_title()
        self.tools_box = self._build_tools_bar()
        lay.addWidget(self.tools_divider)
        lay.addWidget(self.tools_title)
        lay.addWidget(self.tools_box, 1)

        self.login_finished.connect(self._on_login_finished)
        self.sandbox_done.connect(self._on_sandbox_done)
        self.wintweak_done.connect(self._on_wintweak_done)
        self.refresh()

    # ---- __init__ 拆解（批次① 上帝方法抽取）----

    def _build_header(self):
        """卡片头工具栏，返回 header widget。

        2026-10-12 三次迭代后的定稿（用户第三次反馈）：
          卡头 = 账号管理 + 两个日常动作 → 标题 · 计数 | 搜索 | 平铺窗口 |
          开始登录(primary) | 添加账号 | ⋯ ——「开始登录 / 平铺窗口」紧挨着
          「添加账号」，都在表格上方；账号**列表下方**则是分割线 + 小工具框
          （系统级开关类工具，见 _build_tools_bar）。
        勾选数/预计耗时进「开始登录」的 tooltip，登录进度写在计数胶囊上。
        """
        header, h = _card_header("账号", small=False)
        self.count_pill = _pill("0 个账号")
        h.addWidget(self.count_pill)
        h.addStretch(1)
        self.search = QLineEdit()
        self.search.setPlaceholderText("搜索账号 / 角色")
        self.search.setFixedSize(Size.SEARCH_W, Size.CONTROL_H)
        self.search.addAction(icon("search.svg"), QLineEdit.LeadingPosition)
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self._apply_filter)
        h.addWidget(self.search)
        self.tile_btn = QPushButton("平铺窗口")
        self.tile_btn.setCursor(Qt.PointingHandCursor)
        self.tile_btn.setToolTip("把所有游戏窗口按网格排好（避免互相遮挡导致识别失败）")
        self.tile_btn.clicked.connect(self.tile_windows)
        h.addWidget(self.tile_btn)
        self.login_btn = QPushButton("开始登录")
        self.login_btn.setCursor(Qt.PointingHandCursor)
        styled(self.login_btn, variant="primary")
        self.login_btn.setToolTip("勾选要登录的账号后点这里，并行启动客户端")
        self.login_btn.clicked.connect(self.start_login)
        h.addWidget(self.login_btn)
        h.addWidget(_btn("添加账号", slot=self.add_account))
        more = QPushButton()
        more.setIcon(icon("more.svg"))
        styled(more, variant="icon")
        menu = QMenu(more)
        for text, slot in (("编辑", self.edit_account),
                           ("删除", self.delete_account),
                           ("全选", self.select_all),
                           ("全不选", self.select_none),
                           ("上移", lambda: self.move_row(-1)),
                           ("下移", lambda: self.move_row(1))):
            menu.addAction(text, slot)
        menu.addSeparator()
        diag = menu.addAction("显示诊断列（状态 / PID / 启动方式 / 沙盒）")
        diag.setCheckable(True)
        diag.setChecked(self._diag_cols)
        diag.toggled.connect(self._set_diag_cols)
        more.setMenu(menu)
        h.addWidget(more)
        return header

    def _build_table(self):
        """账号表格（2026-10-12 晚：右侧操作区已取消，表格占满卡宽）。"""
        self.tree = QTableWidget(0, len(self.COLUMNS))
        self.tree.setObjectName("DataTable")
        self.tree.setHorizontalHeaderLabels(self.HEADINGS)
        self.tree.setShowGrid(False)
        self.tree.setAlternatingRowColors(False)
        self.tree.verticalHeader().setVisible(False)
        self.tree.verticalHeader().setDefaultSectionSize(Size.ROW_H_ACCOUNT)
        self.tree.horizontalHeader().setHighlightSections(False)
        self.tree.horizontalHeader().setFixedHeight(Size.TABLE_HEADER_H)
        self.tree.setMouseTracking(True)
        self.tree.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tree.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tree.setSelectionMode(QAbstractItemView.SingleSelection)
        self.tree.setFocusPolicy(Qt.NoFocus)
        self.tree.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.tree.setDragEnabled(True)
        self.tree.setAcceptDrops(True)
        self.tree.setDropIndicatorShown(True)
        self.tree.setDragDropMode(QAbstractItemView.InternalMove)
        self.tree.model().rowsMoved.connect(self._on_rows_moved)
        self._empty = _EmptyHint(self.tree, self.EMPTY_TEXT)
        return self.tree

    # ---- 分割线 + 小工具框 ----

    def _build_tools_divider(self):
        """账号列表与小工具框之间的一道分割线（1px 通栏）。

        2026-10-13 用户要求：用一道线把「账号列表」和「下面这一片小工具」划开。
        """
        line = QFrame()
        line.setObjectName("HDivider")
        line.setFixedHeight(1)
        return line

    def _build_tools_title(self):
        """「小工具」标题行——在面板外面、分割线正下方（用户草图定稿的位置）。"""
        title = QLabel("小工具")
        title.setObjectName("ToolsTitle")
        return title

    def _build_tools_bar(self):
        """分割线以下的「小工具」面板：一整块带边框的大框，工具按钮排在里面。

        2026-10-13 用户红框草图定稿（第四次调整这块）：
          * 分割线 → 「小工具」标题（框外，见 _build_tools_title）→ 一整块
            **带边框的面板**（本方法），面板有最小高度并随卡片剩余空间拉伸；
          * 工具用流式布局排在面板里，以后加工具就是加一枚按钮，多了自动换行；
          * 「开始登录 / 平铺窗口」这类**对账号列表的动作**在卡头，不进面板。

        状态型工具做成**可切换按钮**（`setCheckable`）：按下（checked）＝该工具
        已生效、按钮变主色；tooltip 第一行写明"当前状态"，后文写"点击会怎样"。
        """
        box = QFrame()
        box.setObjectName("ToolsPanel")
        box.setMinimumHeight(Size.TOOLS_PANEL_H)
        lay = QVBoxLayout(box)
        lay.setContentsMargins(14, 14, 14, 12)
        lay.setSpacing(8)

        host = QWidget()
        self.tools_flow = FlowLayout(host, h_spacing=8, v_spacing=8, pad=4)
        # QVBoxLayout 多余空间默认垂直居中：面板被拉高时按钮会悬在半空，
        # 用户草图是按钮贴面板顶部，所以显式顶对齐。
        self.tools_flow.setAlignment(Qt.AlignTop)
        lay.addWidget(host, 1)

        for build in (self._build_sandbox_tool, self._build_win_menu_tool,
                      self._build_machine_code_tool, self._build_nolock_tool,
                      self._build_autostart_tool, self._build_macro_tool):
            try:
                build()
            except Exception:                    # 单件工具出问题不影响别的
                log.exception("小工具构建失败：%s", getattr(build, "__name__", build))
        return box

    def _tool_button(self, text):
        """一枚小工具按钮（可切换：checked = 该工具已生效）。"""
        btn = QPushButton(text)
        btn.setCheckable(True)
        btn.setCursor(Qt.PointingHandCursor)
        styled(btn, variant="tool")
        return btn

    def _add_tool(self, btn):
        """把工具按钮放进流式框（估算宽度只用于换行判断）。"""
        self.tools_flow.add_chip(btn, btn.sizeHint().width() + 6)

    def _build_machine_code_tool(self):
        """「查看机器码」——授权密钥按机器码签发（core/license.py），永远显示。

        动作型工具（点开弹窗），不是状态开关，所以不做成 checkable。
        """
        btn = QPushButton("查看机器码")
        btn.setCursor(Qt.PointingHandCursor)
        styled(btn, variant="tool")
        btn.setToolTip(
            "显示本机机器码并可一键复制。\n"
            "授权密钥按机器码签发——想激活/续期时把它发给维护者即可，\n"
            "本身不包含账号等隐私信息。")
        btn.clicked.connect(lambda: MachineCodeDialog(self).exec())
        self.mc_btn = btn
        self._add_tool(btn)

    def _build_nolock_tool(self):
        """「禁止锁屏」——阻止息屏/睡眠/屏保锁定（core/session_keepalive.py）。

        状态型工具（可切换按钮）：按下 = 本机不自动锁屏。只在本程序运行
        期间生效（SetThreadExecutionState 是进程级声明，程序退出即恢复），
        不模拟输入、不影响 Win+L 手动锁屏。
        """
        self.nolock_toggle = self._tool_button("禁止锁屏")
        self._add_tool(self.nolock_toggle)
        self._nl_busy = False
        self.nolock_toggle.toggled.connect(self._on_nolock_toggle)
        self._refresh_nolock_state()

    def _on_nolock_toggle(self, on):
        if self._nl_busy:
            return
        if on:
            keep_alive.start(reason="小工具：禁止锁屏")
        else:
            keep_alive.stop()
        self._refresh_nolock_state()

    def _refresh_nolock_state(self):
        on = keep_alive.active
        self._nl_busy = True
        self.nolock_toggle.setChecked(on)
        self._nl_busy = False
        self.nolock_toggle.setToolTip(
            f"当前状态：{'已开启——本机不会自动息屏/锁屏' if on else '已关闭（跟随系统电源计划）'}\n"
            "点击切换。只在本程序运行期间生效，退出程序即恢复系统默认；\n"
            "不模拟输入，Win+L 手动锁屏不受影响。")

    def _build_autostart_tool(self):
        """「开机自启」——HKCU Run 注册表（core/autostart.py），免 UAC。

        自启后是宠物形态（只显示悬浮球+托盘，不弹主窗口）。打包版才有
        意义（exe 路径），开发模式置灰说明。
        """
        self.autostart_toggle = self._tool_button("开机自启")
        self._add_tool(self.autostart_toggle)
        if not autostart.is_frozen():
            self.autostart_toggle.setEnabled(False)
            self.autostart_toggle.setChecked(False)
            self.autostart_toggle.setToolTip(
                "开机自动启动任务管家（只显示桌面宠物和托盘图标）。\n"
                "开发模式不提供——打包版（安装包/exe）里可用。")
            return
        self._as_busy = False
        self.autostart_toggle.toggled.connect(self._on_autostart_toggle)
        self._refresh_autostart_state()

    def _on_autostart_toggle(self, on):
        if self._as_busy:
            return
        ok = autostart.enable() if on else autostart.disable()
        if not ok:
            QMessageBox.warning(self, "开机自启", "设置失败，详见运行日志。")
        self._refresh_autostart_state()

    def _refresh_autostart_state(self):
        on = autostart.enabled()
        self._as_busy = True
        self.autostart_toggle.setChecked(on)
        self._as_busy = False
        self.autostart_toggle.setToolTip(
            f"当前状态：{'已开启——登录 Windows 后自动启动' if on else '已关闭'}\n"
            "点击切换。自启后只显示桌面宠物和托盘图标，不弹主窗口。")

    def _build_macro_tool(self):
        """「动作录制」——录制固定动作序列，对勾选的账号同步广播回放。

        核心在 core/macro.py；动作型工具（点开编辑器弹窗），永远显示。
        """
        btn = QPushButton("动作录制")
        btn.setCursor(Qt.PointingHandCursor)
        styled(btn, variant="tool")
        btn.setToolTip(
            "录制点击/拖拽等固定动作，保存为「宏」，\n"
            "然后对所有勾选的账号窗口同步广播回放（齐步走）。\n"
            "适合领奖励、点准备等所有号都要做同样操作的场景。")
        btn.clicked.connect(lambda: MacroDialog(
            self, accounts_provider=self.checked_accounts).exec())
        self.macro_btn = btn
        self._add_tool(btn)

    def _build_sandbox_tool(self):
        """「关闭沙盘捐赠提醒」——只在宿主机装了 Sandboxie 时出现。

        原理与安全性见 core/sandbox_tools.py 模块注释。经典版（5.x 非 Plus）
        没有这个弹窗，所以按钮置灰并把原因写进 tooltip。
        """
        try:
            info = sandbox_tools.detect()
        except Exception:                        # 探测失败绝不影响开界面
            log.exception("沙盘探测失败")
            return
        if not info.found:
            return                               # 没装沙盘：这枚按钮根本不出现
        self._sb_info = info
        self._sb_busy = False

        self.sb_toggle = self._tool_button("关闭沙盘捐赠提醒")
        self._add_tool(self.sb_toggle)

        if not info.supported:
            self.sb_toggle.setEnabled(False)
            self.sb_toggle.setToolTip(sandbox_tools.status_text(info))
            return

        self.sb_toggle.toggled.connect(self._on_sandbox_toggle)
        self._refresh_sandbox_state()

    def _refresh_sandbox_state(self):
        """按真实探测结果同步按钮（程序化 setChecked 不触发槽：用 _sb_busy 挡住）。"""
        info = self._sb_info
        self._sb_busy = True
        self.sb_toggle.setChecked(info.disabled)
        self._sb_busy = False
        self.sb_toggle.setToolTip(self._sandbox_tip(info))

    def _sandbox_tip(self, info):
        """沙盘工具的悬停说明（第一行永远是当前状态）。"""
        state = ("当前状态：已关闭（按钮处于按下态）" if info.disabled
                 else "当前状态：未关闭，捐赠提醒仍可能弹出来")
        tip = (state + "\n\n"
               "关掉 Sandboxie-Plus 的两条界面自启（开机自启 + 沙盒启动时打开界面），"
               "让捐赠提醒弹窗没有机会出现。\n"
               "本项目用 Start.exe 直启沙盒，不需要沙盘界面常驻；"
               "代价只是没有托盘图标，需要时手动打开 SandMan 即可。\n"
               "改动前会自动备份 Sandboxie.ini 与注册表原值，再点一下按钮即可还原。")
        if not info.ini_writable:
            tip += ("\n⚠ Sandboxie.ini 只有管理员能写，切换时本工具会弹一次 UAC "
                    "请求提权（点“否”则什么都不改）。")
        return tip

    def _on_sandbox_toggle(self, on):
        if getattr(self, "_sb_busy", False):
            return
        # 写 Sandboxie.ini 需要管理员权限：提前说明，免得用户以为弹的是别的东西
        uac_note = ("" if sandbox_tools.is_elevated() else
                    "\n· 改 Sandboxie.ini 需要管理员权限，点“关闭提醒”后会弹一次 "
                    "UAC 确认框，请选“是”（选“否”则什么都不改）。")
        if on and not _confirm_destructive(
                self, "关闭沙盘捐赠提醒",
                "将关掉 Sandboxie-Plus 的两条界面自启，并结束当前运行的沙盘界面进程。\n\n"
                "· 沙盒本身与沙盒里的游戏不受影响（走 Start.exe 直启）；\n"
                "· 代价：没有托盘图标 / 沙盒主界面，要用时手动打开 SandMan 即可；\n"
                "· 改动前会自动备份配置，随时可以再点一下这枚按钮还原。"
                + uac_note,
                ok_text="关闭提醒"):
            self._sb_busy = True
            self.sb_toggle.setChecked(False)     # 用户反悔：按钮弹回原位
            self._sb_busy = False
            return
        self.sb_toggle.setEnabled(False)
        self.sb_toggle.setToolTip("正在处理…（写 Sandboxie.ini 时可能请你确认一次 UAC）")
        threading.Thread(target=self._sandbox_worker, args=(on,), daemon=True).start()

    def _sandbox_worker(self, on):
        try:
            ok, msg = sandbox_tools.disable() if on else sandbox_tools.restore()
        except Exception as exc:
            log.exception("沙盘提醒开关失败")
            ok, msg = False, f"操作失败：{exc}"
        self.sandbox_done.emit(on, ok, msg)

    def _on_sandbox_done(self, on, ok, msg):
        self.sb_toggle.setEnabled(True)
        try:
            self._sb_info = sandbox_tools.detect()   # 以真实状态为准，不猜
        except Exception:
            log.exception("沙盘复检失败")
        self._refresh_sandbox_state()
        log.info("沙盘捐赠提醒：%s（%s）", "已关闭" if on else "已恢复", msg)
        if not ok:
            QMessageBox.warning(self, "沙盘捐赠提醒", msg)

    def _build_win_menu_tool(self):
        """「右键菜单 Win10 样式」——把 Win11 的新式右键菜单还原成经典样式。

        原理与安全性见 core/wintweaks.py 模块注释（写的是 **HKCU** 的类注册表，
        普通权限即可，不弹 UAC；代价是改完要重启一次资源管理器）。

        2026-10-12 用户选择：**非 Win11 也把这枚按钮显示出来**（置灰 + 说明原因），
        而不是像沙盘那样整件隐藏——功能看得见，换到 Win11 机器上自动变成可用。
        """
        if not wintweaks.is_windows():
            return
        try:
            info = wintweaks.detect()
        except Exception:                        # 探测失败绝不影响开界面
            log.exception("右键菜单探测失败")
            return
        self._wm_info = info
        self._wm_busy = False

        self.wm_toggle = self._tool_button("右键菜单 Win10 样式")
        self._add_tool(self.wm_toggle)

        if not info.is_win11:
            # 本机（Win10 及更早）本来就是经典菜单：置灰 + 原因写进 tooltip
            self.wm_toggle.setEnabled(False)
            ver = ("Win10" if info.windows_build >= 10240
                   else "旧版 Windows" if info.windows_build else "本机系统")
            self.wm_toggle.setToolTip(
                f"{ver} 无需还原。\n\n{wintweaks.status_text(info)}")
            return

        self.wm_toggle.toggled.connect(self._on_wintweak_toggle)
        self._refresh_wintweak_state()

    def _refresh_wintweak_state(self):
        """按真实探测结果同步按钮（程序化 setChecked 不触发槽：用 _wm_busy 挡住）。"""
        info = self._wm_info
        self._wm_busy = True
        self.wm_toggle.setChecked(info.legacy_enabled)
        self._wm_busy = False

        state = ("当前状态：已还原成 Win10 经典样式（按钮处于按下态）"
                 if info.legacy_enabled else
                 "当前状态：Win11 原生菜单（带「显示更多选项」那一层）")
        tip = (state + "\n\n"
               "点一下会把它还原成 Windows 10 的经典菜单"
               "（复制/粘贴/发送到/属性等直接展开）。\n\n"
               "· 只改当前用户的注册表（HKCU 的类注册表），不需要管理员、不弹 UAC；\n"
               "· 生效需要重启一次资源管理器——会关掉已打开的文件资源管理器窗口\n"
               "  （浏览器和其他程序不受影响）；\n"
               "· 再点一下即可恢复 Win11 原生菜单。")
        self.wm_toggle.setToolTip(tip)

    def _on_wintweak_toggle(self, on):
        if getattr(self, "_wm_busy", False):
            return
        if not _confirm_destructive(
                self, "右键菜单样式",
                ("把右键菜单还原成 Windows 10 经典样式（复制/粘贴/发送到等直接展开）"
                 if on else
                 "把右键菜单恢复成 Windows 11 原生样式（折叠进「显示更多选项」）")
                + "。\n\n"
                "· 只改当前用户的注册表（HKCU），不需要管理员权限；\n"
                "· 生效需要重启一次资源管理器：会关掉已打开的文件资源管理器窗口，"
                "浏览器和其他程序不受影响（任务栏会闪一下，属正常）；\n"
                "· 随时可以再点一下这枚按钮还原。",
                ok_text="还原成 Win10" if on else "恢复 Win11"):
            self._wm_busy = True
            self.wm_toggle.setChecked(not on)    # 用户反悔：按钮弹回原位
            self._wm_busy = False
            return
        self.wm_toggle.setEnabled(False)
        self.wm_toggle.setToolTip("正在处理…（很快会重启一次资源管理器）")
        threading.Thread(target=self._wintweak_worker, args=(on,), daemon=True).start()

    def _wintweak_worker(self, on):
        try:
            ok, msg = wintweaks.apply(on)
        except Exception as exc:
            log.exception("右键菜单开关失败")
            ok, msg = False, f"操作失败：{exc}"
        self.wintweak_done.emit(on, ok, msg)

    def _on_wintweak_done(self, on, ok, msg):
        self.wm_toggle.setEnabled(True)
        try:
            self._wm_info = wintweaks.detect()   # 以真实状态为准，不猜
        except Exception:
            log.exception("右键菜单复检失败")
        self._refresh_wintweak_state()
        log.info("右键菜单样式：%s（%s）", "Win10 经典" if on else "Win11 原生", msg)
        if not ok:
            QMessageBox.warning(self, "右键菜单样式", msg)

    # ---- 卡内右侧操作区（§6.10③）----

    def _build_action_pane(self):
        """（已废弃）右侧操作区 2026-10-12 晚按用户反馈取消，按钮回到卡头。

        保留方法壳是为了兼容外部可能的引用；不再被 __init__ 调用。
        """
        return None

    def _refresh_action_pane(self):
        """刷新卡头的登录提示（勾选数/预计耗时 → 按钮 tooltip，上次登录 → 胶囊 tooltip）。"""
        n = len(self.checked_accounts())
        logging_in = getattr(self, "_logging_in", False)
        tip = ""
        data = _load_json(LAST_LOGIN_PATH)
        if data.get("at"):
            ok, total = data.get("ok", 0), data.get("total", 0)
            tail = "全部成功" if ok >= total and total else f"成功 {ok}/{total}"
            tip = f"上次登录 {data['at'][5:]} {tail}"
        self.count_pill.setToolTip(tip)
        if not logging_in:
            self.login_btn.setToolTip(
                (f"并行启动勾选的 {n} 个客户端，预计约 2 分钟"
                 if n else "先在表格里勾选要登录的账号")
                + (f"\n{tip}" if tip else ""))

    def _set_login_progress(self, text):
        """登录中：进度写在计数胶囊上（按钮文案已是「登录中…」）。"""
        self.count_pill.setText(text)

    def _on_login_finished(self, ok=0, total=0):
        self._logging_in = False
        self.login_btn.setEnabled(True)
        self.login_btn.setText("开始登录")
        self.refresh()          # 恢复计数胶囊文案 + 带 tooltip 刷新
        self._refresh_action_pane()

    # ---- 列显示 ----

    # 默认视图的固定列宽（§5 01 表）：选 30 / 账号 150 / 区服 90 / 角色名 160 / 职业 80
    WIDTHS = (30, 150, 90, 160, 80, 64, 100, 90, 100)

    def _apply_columns(self):
        """按 _diag_cols 决定诊断列是否显示；剩余宽度给最后一列可见列。

        列宽是**固定值 + 最后一列 Stretch**（2026-10-12 由 ResizeToContents 改）：
        原来的自适应宽度会让"账号"和"职业"之间随数据长短飘忽，也让右侧操作区
        与表格之间的余量无法预期。固定 510px 后，余量全部由最后一列可见列吸收，
        既不会出现"卡内右边一大片空"，也不会把角色名撑出巨大空档。
        """
        header = self.tree.horizontalHeader()
        for i, key in enumerate(self.COLUMNS):
            header.setSectionResizeMode(i, QHeaderView.Fixed)
            self.tree.setColumnWidth(i, self.WIDTHS[i])
            self.tree.setColumnHidden(
                i, key in self.DIAG_COLS and not self._diag_cols)
        visible = [i for i in range(len(self.COLUMNS))
                   if not self.tree.isColumnHidden(i)]
        if visible:
            header.setSectionResizeMode(visible[-1], QHeaderView.Stretch)

    def _set_diag_cols(self, on):
        self._diag_cols = bool(on)
        self._apply_columns()

    # ---- 列表读写 ----

    def refresh(self):
        self._building = True
        self.tree.setRowCount(0)
        keyword = self._login_keyword()
        for acc in db.list_accounts():
            row = self.tree.rowCount()
            self.tree.insertRow(row)
            sel = QTableWidgetItem()
            sel.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            sel.setCheckState(Qt.Checked)
            sel.setData(Qt.UserRole, acc["id"])
            self.tree.setItem(row, 0, sel)
            for col, key in enumerate(self.COLUMNS[1:], 1):
                if key == "status":
                    h = acc.get("hwnd") or 0
                    online = bool(h) and binding.hwnd_valid(h, keyword)
                    text = "● 在线" if online else "● 离线"
                elif key == "hwnd":
                    h = acc.get("hwnd") or 0
                    if not h:
                        text = "—"
                    elif binding.hwnd_valid(h, keyword):
                        text = str(h)
                    else:
                        text = f"{h}（失效）"
                else:
                    if key == "role":
                        # 2026-10-12：优先显示实际门派（db.cls），没有则退回分类
                        text = str(acc.get("cls") or acc[key] or "—")
                    else:
                        text = str(acc[key]) if acc[key] not in ("", None) else "—"
                item = QTableWidgetItem(text)
                item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                if key in ("account", "hwnd"):
                    item.setFont(mono_font(FontSize.BODY))
                if key == "status":
                    item.setForeground(QColor(Color.SUCCESS if acc.get("hwnd") and
                                              binding.hwnd_valid(acc.get("hwnd"), keyword)
                                              else Color.TEXT_TERTIARY))
                if text == "—":
                    item.setForeground(QColor(Color.TEXT_FAINT))
                self.tree.setItem(row, col, item)
        if not getattr(self, "_logging_in", False):
            # 登录中胶囊被 _set_login_progress 用来显示进度，别覆盖
            self.count_pill.setText(f"{self.tree.rowCount()} 个账号")
        self._apply_filter()
        self._building = False

    def _apply_filter(self):
        text = self.search.text().strip()
        visible = 0
        for row in range(self.tree.rowCount()):
            if not text:
                self.tree.setRowHidden(row, False)
                visible += 1
                continue
            blob = (self.tree.item(row, 1).text() + self.tree.item(row, 3).text())
            hit = text in blob
            self.tree.setRowHidden(row, not hit)
            visible += hit
        if not text:
            self._empty.setText(self.EMPTY_TEXT)
            self._empty.sync(self.tree.rowCount())
        else:
            self._empty.setText("没有匹配的账号\n换个关键词试试，或点搜索框右侧的 × 清除")
            self._empty.sync(visible)
        self._refresh_action_pane()

    def _current_ids(self):
        ids = []
        for row in range(self.tree.rowCount()):
            item = self.tree.item(row, 0)
            ids.append(item.data(Qt.UserRole) if item else None)
        return ids

    def checked_accounts(self):
        checked = set()
        for row in range(self.tree.rowCount()):
            item = self.tree.item(row, 0)
            if item and item.checkState() == Qt.Checked:
                checked.add(item.data(Qt.UserRole))
        return [a for a in db.list_accounts() if a["id"] in checked]

    def _selected_row(self):
        row = self.tree.currentRow()
        if row < 0:
            QMessageBox.information(self, "提示", "请先在列表中选中一行")
            return None
        return row

    # ---- 顺序调整（拖拽 + 按钮） ----

    def _on_rows_moved(self, *_):
        if self._building:
            return
        ids = self._current_ids()
        if any(i is None for i in ids):
            # 拖拽偶发行数据异常：不持久化，直接从数据库重载
            QTimer.singleShot(0, self.refresh)
            return
        db.set_account_order(ids)
        QTimer.singleShot(0, self.refresh)

    def move_row(self, delta):
        row = self._selected_row()
        if row is None:
            return
        target = row + delta
        if not (0 <= target < self.tree.rowCount()):
            return
        ids = self._current_ids()
        ids[row], ids[target] = ids[target], ids[row]
        db.set_account_order(ids)
        self.refresh()
        self.tree.selectRow(target)

    # ---- 账号增删改 ----

    def add_account(self):
        dialog = AccountDialog(self, "添加账号")
        if dialog.exec() and dialog.result:
            db.add_account(**dialog.result)
            self.refresh()
            log.info("已添加账号: %s / %s / %s", dialog.result["account"],
                     dialog.result["server"], dialog.result["character"])

    def edit_account(self):
        row = self._selected_row()
        if row is None:
            return
        acc_id = self.tree.item(row, 0).data(Qt.UserRole)
        dialog = AccountDialog(self, "编辑账号", initial=db.get_account(acc_id))
        if dialog.exec() and dialog.result:
            db.update_account(acc_id, **dialog.result)
            self.refresh()

    def delete_account(self):
        row = self._selected_row()
        if row is None:
            return
        acc_id = self.tree.item(row, 0).data(Qt.UserRole)
        acc = db.get_account(acc_id)
        if _confirm_destructive(
                self, "确认删除",
                f"删除账号 {acc['account']}（{acc['character']}）？\n\n此操作不可撤销。"):
            db.delete_account(acc_id)
            self.refresh()

    def select_all(self):
        self._set_all_checks(Qt.Checked)

    def select_none(self):
        self._set_all_checks(Qt.Unchecked)

    def _set_all_checks(self, state):
        self._building = True
        for row in range(self.tree.rowCount()):
            self.tree.item(row, 0).setCheckState(state)
        self._building = False

    # ---- 登录与窗口 ----

    @staticmethod
    def _login_keyword():
        with open(CONFIG_PATH, encoding="utf-8") as f:
            cfg = yaml.safe_load(f).get("login", {})
        return cfg.get("window_keyword") or Device.DEFAULT_KEYWORD

    def tile_windows(self):
        with open(CONFIG_PATH, encoding="utf-8") as f:
            cfg = yaml.safe_load(f).get("login", {})
        if ensure_elevation(cfg.get("window_keyword") or Device.DEFAULT_KEYWORD, self):
            return
        hwnds = Device.find_all(cfg.get("window_keyword") or Device.DEFAULT_KEYWORD)
        if not hwnds:
            QMessageBox.information(self, "提示", "未发现游戏窗口")
            return
        launcher.tile_windows(hwnds, **cfg.get("tile", {}))
        log.info("已平铺 %d 个窗口", len(hwnds))

    def start_login(self):
        accounts = self.checked_accounts()
        if not accounts:
            QMessageBox.information(self, "提示", "请先勾选要登录的账号")
            return
        if ensure_elevation(self._login_keyword(), self):
            return
        self._logging_in = True
        self.login_btn.setEnabled(False)
        self.login_btn.setText("登录中…")
        self._set_login_progress(f"正在启动 {len(accounts)} 个客户端…")
        threading.Thread(target=self._login_worker, args=(accounts,), daemon=True).start()

    def _login_worker(self, accounts):
        ok = 0
        try:
            with open(CONFIG_PATH, encoding="utf-8") as f:
                config = yaml.safe_load(f)
            # 路径留空/写 auto 时按注册表自动定位（写死的路径仍优先）
            cfg = locate.apply_login_paths(config)
            matcher = Matcher(ASSETS_DIR,
                              threshold=config.get("threshold", 0.85))
            keyword = cfg.get("window_keyword") or Device.DEFAULT_KEYWORD
            open_hwnds = Device.find_all(keyword)
            if len(open_hwnds) < len(accounts):
                # 窗口不够：按列表中靠后账号的启动配置补齐客户端
                if not cfg.get("game_exe"):
                    raise RuntimeError("窗口不足，且未配置 login.game_exe / 未能自动找到游戏主程序"
                                       "（可运行 python core/locate.py 看探测明细）")
                log.info("已开窗口 %d 个，自动启动客户端补齐到 %d 个...",
                         len(open_hwnds), len(accounts))
                # launch_missing 就地回填 accounts[*]["hwnd"] 并返回 (账号id, hwnd) 对；
                # 必须让这批新句柄进到 accounts 里再解析，否则下面的
                # run_login_parallel 拿的是启动前的旧句柄，会全判 dead 跳过登录
                # （实测：客户端全关后重启一整批，5/5 全部"绑定的句柄已失效"）
                new_pairs = launch_missing(accounts[len(open_hwnds):], cfg, open_hwnds)
                open_hwnds += [hwnd for _, hwnd in new_pairs]
            # 先平铺避免窗口互相遮挡（截图读屏幕像素），再并行登录
            log.info("共 %d 个窗口，平铺后并行登录", len(open_hwnds))
            launcher.tile_windows(open_hwnds, **cfg.get("tile", {}))
            hwnds = run_login_parallel(accounts, cfg, matcher)
            ok = len(hwnds)
            log.info("登录结束，成功 %d/%d，开始平铺窗口", ok, len(accounts))
            launcher.tile_windows(Device.find_all(keyword), **cfg.get("tile", {}))
        except Exception:
            log.exception("登录流程异常")
        finally:
            # 上次登录摘要（data/last_login.json）：纯展示用，写失败不影响流程
            _save_json(LAST_LOGIN_PATH, {
                "at": time.strftime("%Y-%m-%d %H:%M"),
                "ok": ok, "total": len(accounts)})
            self.login_finished.emit(ok, len(accounts))


# ============================================================================
# 任务页
# ============================================================================


class TasksTab(QFrame):
    """任务页（2026-10-12 起为「两区一页」）：上半「立即执行」，下半「定时计划」。

    **职责一刀切**（设计书 §5 02）：编辑任务清单**只在「开始任务」向导里发生**；
    本页 = 启动 + 看状态 + 看默认清单（只读摘要）。
    改版原因：清单在向导上线后已经是"向导第 2 步的预填来源"，再在页面上摊开成
    一墙可编辑芯片 = 同一件事有两个入口，而首屏被 6 层卡片 + 一墙芯片占满。

    「定时计划」是原独立「定时任务」页整节并入（`ScheduleTab` 由 `App` 创建、
    经 `set_schedule_widget()` 注入到本页区段二；到点巡检仍挂在 `App` 上）。
    """

    tasks_finished = Signal()
    progress_update = Signal(int)   # 行号：该账号进度有变化，主线程重绘
    worker_event = Signal(object)   # worker 子进程事件（读线程 → UI 线程的桥）

    CATEGORY_ORDER = ("备战任务", "日常任务", "帮会任务", "周常任务", "日常副本", "收尾任务")

    # 分类短标签（默认清单卡里每行只有 56px）
    CATEGORY_LABEL = {"备战任务": "备战", "日常任务": "日常", "帮会任务": "帮会",
                      "周常任务": "周常", "日常副本": "副本", "收尾任务": "收尾"}

    # 带参数的（次级选项）任务：向导第 2 步的「任务参数」行用它渲染 ▾ 面板。
    # 键名与 config.yaml 一致；旧版列表键（layers / modes）仍兼容读取。
    # zudui.mode（组队方式）不放这里 —— 它是第 3 步的组队属性。
    PARAM_SPECS = {
        "haishi": {"title": "海市蜃楼 · 挑战层数", "key": "layer", "default": 11,
                   "options": [(n, f"{n}层 {boss}") for n, boss in HAISHI_LAYERS],
                   "legacy_keys": ("layers",),
                   "short": lambda v: f"{v} 层"},
        "cook": {"title": "做烹饪 · 制作类型", "key": "mode", "default": "cooking",
                 "options": list(COOK_MODE_LABEL.items()),
                 "legacy_keys": ("modes",),
                 "short": lambda v: dict(COOK_MODE_LABEL).get(v, str(v))},
        # 种菜 · 美食配方（2026-11-03）：选了配方 = 播种按配方原料 OCR 定位作物格、
        # 制作台先「放回」清锅再把配方食材点进锅；自动 = 按游戏默认（旧行为：
        # 播种点前 3 格、制作台直接点制作做当前选中配方）。
        "zhongcai": {"title": "种菜 · 美食配方", "key": "dish",
                     "default": ZHONGCAI_DISH_AUTO,
                     "options": [(ZHONGCAI_DISH_AUTO, "自动（按游戏默认）")]
                     + [(did, f"{name}（{'+'.join(ings)}）")
                        for did, (name, ings) in ZHONGCAI_DISH_RECIPES.items()],
                     "short": lambda v: next(
                         (name for did, (name, _i) in ZHONGCAI_DISH_RECIPES.items()
                          if did == v), "自动")},
    }
    PARAM_TASKS = ("haishi", "cook", "zhongcai")

    PILL_MAX = 6      # 默认清单卡每分类最多显示几枚胶囊，超出显示 +N

    def __init__(self):
        super().__init__()
        self.setObjectName("Card")
        self._loading = False
        self._account_provider = None
        self._titles = {}
        self._stage_cards = {}    # 多阶段任务组 id -> 只读阶段卡（灵珠收集等，暂不可选）
        self._schedule_tab = None  # 定时计划表由 App 注入
        self.status_panel = None  # 状态面板由 App 注入
        self._stop_event = None   # 已废弃：停止通道在 worker 进程内（2026-10-25 迁移），字段仅留兼容
        self._stopping = False    # 已发优雅停止（停止按钮第二阶段=强制结束）
        self._running = False
        self.worker = WorkerClient()      # 任务执行子进程（core/workerclient.py）
        self.worker.on_event = self.worker_event.emit
        self.worker_event.connect(self._on_worker_event)
        self._acc_row = {}        # acc_id -> 状态面板行号（worker 事件按 acc_id 报）
        self._rows_state = {}     # 行号 -> {total, done, current, failed, acc}
        self.last_failures = []   # 本轮失败清单（「一键反馈」用，_on_finished 汇总）
        self._task_overrides = {} # 本次执行的任务参数覆盖（向导写 haishi.layer 等）
        self._run_accounts = None # 本轮执行的实际账号名单（None=未在跑）
        self._run_started_at = 0  # 本轮开始时刻（写 data/last_run.json 用）
        self._run_task_count = 0

        lay = QVBoxLayout(self)
        lay.setContentsMargins(1, 1, 1, 1)
        lay.setSpacing(0)

        # 页头：只有「停止任务」（启动类动作全部下沉到下面的卡片，见 §5 02）
        header, h = _card_header("任务", small=False)
        self.count_pill = _pill("0 项默认")
        h.addWidget(self.count_pill)
        h.addStretch(1)
        self.stop_btn = _btn("停止任务", slot=self.stop_tasks)
        self.stop_btn.setEnabled(False)
        h.addWidget(self.stop_btn)
        lay.addWidget(header)

        body = QFrame()
        body.setProperty("role", "fieldGroup")
        col = QVBoxLayout(body)
        col.setContentsMargins(0, 0, 0, 0)
        col.setSpacing(0)

        # ---- 区段一：立即执行 ----
        col.addWidget(_section_bar("立即执行", "一条龙 · 临时跑一次 · 默认清单"))
        run_wrap = QVBoxLayout()
        run_wrap.setContentsMargins(20, 16, 20, 16)
        run_wrap.setSpacing(12)
        self._ytl_banner = self._build_ytl_banner()
        run_wrap.addWidget(self._ytl_banner)
        run_wrap.addWidget(self._build_quick_card())
        run_wrap.addWidget(self._build_default_card())
        self._stage_host = QVBoxLayout()
        self._stage_host.setContentsMargins(0, 0, 0, 0)
        self._stage_host.setSpacing(12)
        run_wrap.addLayout(self._stage_host)
        col.addLayout(run_wrap)

        # ---- 区段二：定时计划（原独立页并入）----
        self.sched_count = QLabel("0 个计划")
        set_prop(self.sched_count, role="sectionCount")
        self.sched_add_btn = _btn("添加", slot=lambda: self._sched_call("add_entry"))
        self.sched_edit_btn = _btn("编辑", slot=lambda: self._sched_call("edit_entry"))
        self.sched_del_btn = _btn("删除", slot=lambda: self._sched_call("delete_entry"))
        self.sched_add_btn.setToolTip("新建一条定时计划（每天到点自动跑）")
        self.sched_edit_btn.setEnabled(False)
        self.sched_del_btn.setEnabled(False)
        col.addWidget(_section_bar(
            "定时计划",
            "每天到点触发（GUI 需保持打开）· 执行中到点则当天跳过"
            "· 打地鼠条目固定 11:50 / 17:50",
            (self.sched_add_btn, self.sched_edit_btn, self.sched_del_btn),
            extra=[self.sched_count]))
        self._sched_host = QVBoxLayout()
        self._sched_host.setContentsMargins(20, 16, 20, 20)
        self._sched_host.setSpacing(0)
        col.addLayout(self._sched_host)
        col.addStretch(1)

        # 内容整体可滚动：小屏 / 150% 缩放下两区都能滚到底，不靠"窗口足够大"
        lay.addWidget(_scroll_host(body), 1)

        self.progress_update.connect(self._render_row)
        self.tasks_finished.connect(self._on_finished)
        self.reload_default_list()
        self._refresh_quick_meta()

    def _refresh_quick_meta(self):
        """② 卡上的「上次：N 个账号 / M 项 · 用时 K 分」；无记录时整行不显示。"""
        data = _load_json(LAST_RUN_PATH)
        if not data.get("at"):
            self.quick_meta.setVisible(False)
            return
        mins = int((data.get("elapsed") or 0) // 60)
        self.quick_meta.setText(
            f"上次：{data.get('accounts', 0)} 个账号 / {data.get('tasks', 0)} 项"
            + (f" · 用时 {mins} 分" if mins else ""))
        self.quick_meta.setVisible(True)

    # ---- 注入（与 set_status_widget 同一套做法）----

    def set_account_provider(self, provider):
        """注入"获取当前勾选账号列表"的回调（由 App 把账号登录页接进来）。"""
        self._account_provider = provider

    def set_status_widget(self, panel):
        """注入执行状态面板（App 右侧常态显示区创建）。"""
        self.status_panel = panel

    def set_schedule_widget(self, tab):
        """把定时计划表（`ScheduleTab`）挂进区段二。

        标题与「添加/编辑/删除」由本页的区段标题行承载（`ScheduleTab.header`
        不再使用），这里只把表本身放进容器并接上它的两个信号。
        """
        self._schedule_tab = tab
        self._sched_host.addWidget(tab)
        tab.count_changed.connect(self._on_sched_count)
        tab.selection_changed.connect(self._on_sched_selection)
        self._on_sched_count(len(tab.entries()))

    def _sched_call(self, name):
        if self._schedule_tab is not None:
            getattr(self._schedule_tab, name)()

    def _on_sched_count(self, n):
        self.sched_count.setText(f"{n} 个计划")

    def _on_sched_selection(self, has):
        self.sched_edit_btn.setEnabled(has)
        self.sched_del_btn.setEnabled(has)

    # ---- ② 临时跑一次（次入口）----

    def _build_quick_card(self):
        card = QFrame()
        card.setObjectName("Card")
        h = QHBoxLayout(card)
        h.setContentsMargins(16, 14, 16, 14)
        h.setSpacing(12)
        left = QVBoxLayout()
        left.setSpacing(4)
        title = QLabel("临时跑一次")
        title.setObjectName("SectionTitle")
        left.addWidget(title)
        desc = QLabel("自选账号与任务，不写回默认清单")
        set_prop(desc, role="cardDesc")
        left.addWidget(desc)
        self.quick_meta = QLabel("")
        set_prop(self.quick_meta, role="cardMeta")
        self.quick_meta.setVisible(False)
        left.addWidget(self.quick_meta)
        h.addLayout(left, 1)
        # 次按钮（不用主色实底）：本屏唯一的主色实底留给 ① 的「开始一条龙」
        self.run_btn = _btn("开始任务", slot=self.start_tasks)
        h.addWidget(self.run_btn)
        return card

    # ---- ③ 默认清单（只读摘要）----

    def _build_default_card(self):
        card = QFrame()
        card.setObjectName("Card")
        v = QVBoxLayout(card)
        v.setContentsMargins(1, 1, 1, 1)
        v.setSpacing(0)
        header, h = _card_header("默认清单", small=True)
        self.default_pill = _pill("0 项已选")
        h.addWidget(self.default_pill)
        h.addStretch(1)
        edit = QPushButton("在向导里编辑")
        edit.setCursor(Qt.PointingHandCursor)
        edit.setToolTip("打开「开始任务」向导的第 2 步，改完直接写回默认清单")
        styled(edit, variant="link")
        edit.clicked.connect(lambda: self.open_start_wizard(edit_default=True))
        h.addWidget(edit)
        v.addWidget(header)

        self._default_body = QFrame()
        self._default_body.setProperty("role", "fieldGroup")
        self._default_rows = QVBoxLayout(self._default_body)
        self._default_rows.setContentsMargins(16, 12, 16, 14)
        self._default_rows.setSpacing(8)
        v.addWidget(self._default_body)
        return card

    def default_list(self):
        """默认清单 = `config.yaml` 里 `tasks[].enabled` 为 true 的任务名（按文件顺序）。

        这是**唯一**的默认清单来源：向导第 2 步的预填、本页 ③ 卡展示都读它。
        2026-10-14 实现搬进 `core/task_params.py`（重构批次②），这里只转调。
        **必须显式传 `CONFIG_PATH`**（core 绑定的是自己的名字，见 _save_task_option）。
        """
        return task_params.default_list(CONFIG_PATH)

    def _clear_layout(self, layout):
        while layout.count():
            item = layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)
            sub = item.layout()
            if sub is not None:
                self._clear_layout(sub)

    def reload_default_list(self):
        """重建 ③ 默认清单卡（只读）：每分类一行「分类名 + 只读胶囊」，最多 6 枚。

        与 ④ 多阶段任务卡共用一次注册表读取。
        """
        from core.scheduler import Scheduler
        registry = Scheduler._load_tasks()
        self._titles = {n: getattr(c, "title", n) for n, c in registry.items()}
        params = self.saved_params()
        names = [n for n in self.default_list() if n in registry]

        self._clear_layout(self._default_rows)
        if not names:
            empty = QLabel("还没有默认清单 —— 点「开始任务」勾一次，"
                           "在向导第 2 步勾上「保存为默认清单」")
            set_prop(empty, role="cardMeta")
            empty.setWordWrap(True)
            self._default_rows.addWidget(empty)
        else:
            cats = {}
            for n in names:
                cat = getattr(registry[n], "category", "日常任务")
                cats.setdefault(cat, []).append(n)
            ordered = [c for c in self.CATEGORY_ORDER if c in cats]
            ordered += [c for c in cats if c not in self.CATEGORY_ORDER]
            for cat in ordered:
                self._default_rows.addLayout(self._pill_row(cat, cats[cat], params))

        # ④ 多阶段任务卡（灵珠收集）：跟默认清单卡一起刷新
        self._clear_layout(self._stage_host)
        for card in self._stage_cards.values():
            card.setParent(None)
        self._stage_cards = {}
        self._render_stage_cards(registry)

        self.default_pill.setText(f"{len(names)} 项已选")
        self.count_pill.setText(f"{len(names)} 项默认")
        if hasattr(self, "ytl_combo"):
            self.reload_ytl_plans()   # 方案可能被向导改过

    def _pill_row(self, cat, names, params):
        """一行：分类短标签（56px）+ 只读任务胶囊（最多 6 枚，超出 +N）。"""
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(8)
        label = QLabel(self.CATEGORY_LABEL.get(cat, cat))
        set_prop(label, role="groupLabel")
        label.setFixedWidth(56)
        label.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        row.addWidget(label)
        host = QFrame()
        flow = FlowLayout(host, h_spacing=6, v_spacing=6)
        flow.setContentsMargins(0, 0, 0, 0)
        row.addWidget(host, 1)
        for name in names[:self.PILL_MAX]:
            flow.add_chip(self._make_pill(name, params.get(name)), 90)
        if len(names) > self.PILL_MAX:
            more = QLabel(f"+{len(names) - self.PILL_MAX}")
            set_prop(more, role="taskPillMore")
            more.setToolTip("、".join(self._titles.get(n, n)
                                     for n in names[self.PILL_MAX:]))
            flow.add_chip(more, 30)
        return row

    def _make_pill(self, name, param=None):
        """只读任务胶囊（`QLabel` 不是按钮：鼠标不变手型、点了没有反应）。

        带**非缺省**参数的任务用 `taskPillParam`（淡青底 + 描边 + 文案带参数），
        让人一眼看出"这项和平时不一样"。
        """
        title = self._titles.get(name, name)
        spec = self.PARAM_SPECS.get(name)
        if param is not None and spec is not None:
            pill = QLabel(f"{title} · {spec['short'](param)}")
            set_prop(pill, role="taskPillParam")
            pill.setToolTip(spec["title"])
            return pill
        pill = QLabel(title)
        set_prop(pill, role="taskPill")
        return pill

    def saved_params(self):
        """config.yaml 里已存的参数（仅**非缺省**值）：{任务名: 值}。

        用于 ③ 卡渲染带参数胶囊、以及向导第 2 步「任务参数」的初值。
        2026-10-14 实现搬进 `core/task_params.py`（重构批次②），这里只转调。
        """
        return task_params.saved_params(self.PARAM_TASKS, self.PARAM_SPECS,
                                        CONFIG_PATH)

    # ---- 默认清单写回（向导的「保存为默认清单」调它）----

    def save_default_list(self, names, params=None):
        """把本次勾选写回 `config.yaml`（`enabled` + 参数），并刷新 ③ 卡。

        - `names`：要标记为 enabled 的任务名集合（**只认名字，其余一律 false**）
        - `params`：{任务名: {键: 值}}，值 `None` = 删掉该行回到缺省
        沿用按行文本替换的写法，**保留文件里的全部注释**。
        2026-10-14 YAML 读写搬进 `core/task_params.py`（重构批次②），这里只管
        记日志 + 刷新界面。
        """
        names = list(names)
        missing = task_params.save_default_list(names, CONFIG_PATH)
        if missing:
            log.warning("config.yaml 的 tasks 段缺少 %s，默认清单未完整写入", missing)
        task_params.save_params(params, CONFIG_PATH)

        log.info("默认清单已更新：%d 项%s", len(names),
                 ("，参数 " + "、".join(f"{k}={v}" for k, v in
                                      ((t, list(d.values())[0]) for t, d in
                                       (params or {}).items()))) if params else "")
        self.reload_default_list()
        self.rebuild_status()

    # ---- 运行状态联动 ----

    def _sync_run_state(self):
        """运行中：① ② 的启动按钮与「配置…」全部禁用（tooltip 提示先停止）。"""
        busy = self._running
        for b in (getattr(self, "run_btn", None),
                  getattr(self, "ytl_start_btn", None),
                  getattr(self, "ytl_edit_btn", None)):
            if b is not None:
                b.setEnabled(not busy)
                if busy:
                    b.setToolTip("任务执行中，请先停止")
        self.stop_btn.setEnabled(busy)
        if not busy:
            self._sync_ytl_buttons()

    # ---- 启动入口 ----

    def start_tasks(self):
        """②「临时跑一次」：打开向导，本次勾选**不**写回默认清单。"""
        self.open_start_wizard(edit_default=False)

    def open_start_wizard(self, edit_default=False):
        """打开「开始任务」三步向导。

        `edit_default=True`（③ 卡的「在向导里编辑」）：第 2 步的
        「保存为默认清单」默认勾上且置灰，末步按钮文案变「保存并开始」。
        """
        if self._running:
            QMessageBox.information(self, "提示", "任务正在执行中，请先停止")
            return
        dlg = StartTasksDialog(self, edit_default=edit_default)
        if not (dlg.exec() and dlg.result):
            return
        r = dlg.result
        team = r["team"]
        cap_acc = next((a for a in r["accounts"] if a.get("is_captain")), None)
        log.info("开始任务（向导）：%d 个账号，任务并集 %d 项%s",
                 len(r["accounts"]), len(r["names"]),
                 (f"，队长 {cap_acc['character']}（{team['mode']}，队员 "
                  f"{len(team['members'])} + 队外 {len(team['extra_names'])}）" if team
                  else "（无组队任务）"))
        # overrides：向导里设的任务参数（haishi.layer / cook.mode）+ 组队方式。
        # 与一条龙同一口径 —— `_start_run` 会把它盖在 config.yaml 的值之上。
        overrides = dict(r.get("overrides") or {})
        if team:
            overrides.setdefault("zudui", {})["mode"] = team["mode"]
        self._start_run(
            r["names"], accounts=r["accounts"], names_map=r["names_map"],
            preflight=r["preflight"],
            overrides=overrides or None,
            team=team)

    # ---- 一条龙（5 人成队 → 组队方式 → 每人任务） ----

    def _build_ytl_banner(self):
        """任务页顶部的「一条龙」入口：方案下拉 + 配置 + 开始。

        放在任务列表最上方而不是藏在菜单里——这是整页最省事的用法（配一次，
        以后每天点一下「开始一条龙」）。
        """
        card = QFrame()
        card.setProperty("role", "ytlBanner")
        h = QHBoxLayout(card)
        h.setContentsMargins(20, 14, 20, 14)
        h.setSpacing(12)

        left = QVBoxLayout()
        left.setSpacing(6)
        top = QHBoxLayout()
        top.setSpacing(8)
        title = QLabel("一条龙")
        set_prop(title, role="ytlTitle")
        top.addWidget(title)
        for t in ("① 选 5 人", "② 组队方式", "③ 每人任务"):
            tag = QLabel(t)
            set_prop(tag, role="ytlStep")
            top.addWidget(tag)
        top.addStretch(1)
        left.addLayout(top)
        desc = QLabel("配好方案后，5 人一起把组队副本 + 各自的日常一次跑完（组队任务只有队长能选）")
        set_prop(desc, role="ytlDesc")
        left.addWidget(desc)
        # 保存/启动后的一行反馈（默认隐藏；见 _set_ytl_note）
        self.ytl_note = QLabel("")
        set_prop(self.ytl_note, role="ytlNote")
        self.ytl_note.setVisible(False)
        left.addWidget(self.ytl_note)
        h.addLayout(left, 1)

        self.ytl_combo = QComboBox()
        self.ytl_combo.setMinimumWidth(220)
        self.ytl_combo.currentIndexChanged.connect(lambda *_: self._on_ytl_combo())
        h.addWidget(self.ytl_combo)
        self.ytl_edit_btn = _btn("配置…", slot=lambda: self.open_ytl_dialog())
        h.addWidget(self.ytl_edit_btn)
        self.ytl_start_btn = _btn("开始一条龙", variant="primary",
                                  slot=self.on_ytl_primary)
        h.addWidget(self.ytl_start_btn)
        self.reload_ytl_plans()
        return card

    def _set_ytl_note(self, text):
        """横幅上的一行反馈（保存成功等）；text 为空则隐藏。"""
        self.ytl_note.setText(text or "")
        self.ytl_note.setVisible(bool(text))

    def _on_ytl_combo(self):
        self._set_ytl_note("")   # 换方案就不再提示上一个方案的保存结果
        self._sync_ytl_buttons()

    def reload_ytl_plans(self, select_id=None):
        """刷新方案下拉（保存/删除方案后调用）。select_id 指定要选中的方案。"""
        cur = select_id if select_id is not None else self.ytl_combo.currentData()
        self.ytl_combo.blockSignals(True)
        self.ytl_combo.clear()
        items = ytl.plans()
        for p in items:
            label = p.get("name") or f"方案 {p.get('id')}"
            self.ytl_combo.addItem(label, p.get("id"))
            self.ytl_combo.setItemData(self.ytl_combo.count() - 1,
                                       ytl.summarize(p), Qt.ToolTipRole)
        if not items:
            self.ytl_combo.addItem("（尚无方案）", None)
        if cur is not None:
            i = self.ytl_combo.findData(cur)
            if i >= 0:
                self.ytl_combo.setCurrentIndex(i)
        self.ytl_combo.blockSignals(False)
        self._sync_ytl_buttons()

    def _sync_ytl_buttons(self):
        has = bool(ytl.plans())
        self.ytl_combo.setEnabled(has)
        self.ytl_start_btn.setText("开始一条龙" if has else "配置一条龙")
        self.ytl_start_btn.setToolTip(
            "按当前方案立即执行（5 人并行）" if has else "还没有方案，点这里新建并配置")

    def on_ytl_primary(self):
        pid = self.ytl_combo.currentData()
        if pid is None:
            self.open_ytl_dialog()
        else:
            self.start_yitiaolong(pid)

    def open_ytl_dialog(self, plan_id=None):
        """打开一条龙向导（plan_id=None 时用下拉里选中的方案做初值）。

        向导只保存方案，**不启动**；保存后横幅上给一行提示引导用户点
        「开始一条龙」。
        """
        if self._running:
            QMessageBox.information(self, "提示", "任务正在执行，请先停止再配置一条龙")
            return
        pid = plan_id if plan_id is not None else self.ytl_combo.currentData()
        dlg = YitiaolongDialog(self, ytl.get(pid))
        accepted = dlg.exec()
        if not accepted or not dlg.result:
            self.reload_ytl_plans()
            return
        plan = dlg.result
        self.reload_ytl_plans(select_id=plan["id"])
        self._set_ytl_note(f"✓ 已保存「{plan.get('name')}」——点右侧「开始一条龙」启动")

    def start_yitiaolong(self, plan_id=None, preflight=None):
        """按一条龙方案启动一轮并行执行。

        - 队伍成员 = 方案里的 5 人（顺序即方案顺序），队长取方案的 captain
          （内存态写进 account 记录，不动 db 的队长标记）；
        - 每人的任务清单 = 自己的单人任务 ∪ 队长勾的组队任务（组队任务必须
          全队一致，否则队员会等一支组不起来的队）；
        - 组队方式写进 zudui 任务的 mode（覆盖 config.yaml 里的值）。
        """
        if self._running:
            QMessageBox.information(self, "提示", "任务正在执行中，请先停止")
            return
        plan = ytl.get(plan_id if plan_id is not None else self.ytl_combo.currentData())
        if not plan:
            self.open_ytl_dialog()
            return
        by_id = {a["id"]: a for a in db.list_accounts()}
        members = ytl.member_ids(plan)
        missing = [m for m in members if m not in by_id]
        if missing:
            QMessageBox.warning(
                self, "成员缺失",
                f"方案「{plan.get('name')}」里有 {len(missing)} 个成员已不在账号库"
                f"（id={missing}），请重新配置。")
            self.open_ytl_dialog(plan.get("id"))
            return
        from core.scheduler import Scheduler
        registry = Scheduler._load_tasks()
        names, names_map = ytl.build_run(plan, registry, _config_task_order(registry))
        if not names:
            QMessageBox.information(
                self, "提示", "该方案没有勾选任何任务，请先配置（第 3 步）")
            self.open_ytl_dialog(plan.get("id"))
            return
        cap = ytl.captain_id(plan)
        accounts = []
        for m in members:
            a = dict(by_id[m])
            a["is_captain"] = 1 if m == cap else 0
            accounts.append(a)
        pf = plan.get("preflight", True) if preflight is None else preflight
        log.info("一条龙启动：方案 [%s]（id=%s），%d 人，队长 %s，组队方式 %s，"
                 "任务并集 %d 项", plan.get("name"), plan.get("id"), len(accounts),
                 by_id[cap]["character"] if cap in by_id else cap,
                 plan.get("team_mode"), len(names))
        self._set_ytl_note("")
        mode = plan.get("team_mode") or "auto"
        self._start_run(names, accounts=accounts, names_map=names_map,
                        preflight=bool(pf),
                        overrides={"zudui": {"mode": mode}},
                        team={"captain": cap, "members": list(members),
                              "extra_names": [], "mode": mode})

    # ---- 多阶段任务卡（同组任务合并展示，暂不可选）----

    def _render_stage_cards(self, registry):
        """（2026-10-12 用户反馈）暂不可用的任务（`available=False` 的多阶段组，
        如「灵珠收集」）**不再展示**——只读阶段卡摆着只会让人疑惑"为什么点不动"。

        空实现保留方法与 `_stage_cards` 字典：调度层对这类任务的 available 拦截
        兜底不变；等玩法流程定稿（available 改回 True）后这里再决定展示方式。
        """
        self._stage_cards = {}
        return

    def _build_stage_card(self, gid, items):
        """一张多阶段任务卡：标题 + 徽章 + 步骤条（① 提交灵珠 → ② 接收灵珠）+ 说明。

        整卡不是按钮、卡内也没有可勾选控件，所以天然点不动（鼠标不是手型、
        无 hover/focus 反馈）——「不可选」由视觉与交互同时表达。
        """
        from tasks.base import STAGE_GROUPS
        meta = STAGE_GROUPS.get(gid, {})
        items = sorted(items, key=lambda it: getattr(it[1], "stage_index", 0))
        card = QFrame()
        card.setProperty("role", "stageCard")
        v = QVBoxLayout(card)
        v.setContentsMargins(16, 12, 16, 12)
        v.setSpacing(8)

        top = QHBoxLayout()
        top.setContentsMargins(0, 0, 0, 0)
        top.setSpacing(8)
        title = QLabel(meta.get("title") or gid)
        set_prop(title, role="stageTitle")
        top.addWidget(title)
        badge = QLabel(meta.get("badge") or "待完善")
        set_prop(badge, role="stageBadge")
        top.addWidget(badge)
        top.addStretch(1)
        note = QLabel(meta.get("note") or "暂不可选")
        set_prop(note, role="stageHint")
        top.addWidget(note)
        v.addLayout(top)

        steps = QHBoxLayout()
        steps.setContentsMargins(0, 0, 0, 0)
        steps.setSpacing(6)
        circled = "①②③④⑤⑥⑦⑧⑨"
        for i, (name, cls) in enumerate(items):
            if i:
                arrow = QLabel("→")
                set_prop(arrow, role="stageArrow")
                steps.addWidget(arrow)
            idx = circled[i] if i < len(circled) else f"{i + 1}."
            step = QLabel(f"{idx} {getattr(cls, 'title', name)}")
            set_prop(step, role="stageStep")
            desc = getattr(cls, "stage_desc", "")
            if desc:
                step.setToolTip(desc)
            steps.addWidget(step)
        steps.addStretch(1)
        v.addLayout(steps)

        desc = meta.get("desc")
        if desc:
            lab = QLabel(desc)
            set_prop(lab, role="stageDesc")
            lab.setWordWrap(True)
            v.addWidget(lab)
        return card

    def enabled_task_configs(self):
        """所有任务的勾选状态（= 默认清单），按 config.yaml 的文件顺序。

        2026-10-12 起本页不再有可勾选芯片，所以这里**只读 config.yaml**。
        2026-10-14 实现搬进 `core/task_params.py`（重构批次②），这里只转调。
        """
        return task_params.enabled_task_configs(CONFIG_PATH)

    def checked_task_names(self):
        """默认清单里的任务名（向导第 2 步预填 + ③ 卡渲染的共同数据源）。"""
        return task_params.checked_task_names(CONFIG_PATH)

    # ---- 状态面板 ----

    def rebuild_status(self, accounts=None):
        """重建状态面板行。accounts=None 时优先用本轮执行名单（运行中勾选变化
        重建也不能把行换成别的账号），否则用账号登录页的勾选账号。
        """
        if self.status_panel is None:
            return
        if accounts is None:
            accounts = self._run_accounts
        if accounts is None:
            accounts = self._account_provider() if self._account_provider else []
        names = self.checked_task_names()
        # 保留已有行的执行状态（勾选变化触发的重建不清空进度）
        old = self._rows_state
        self._rows_state = {}
        self.status_panel.rebuild(accounts)
        for row, acc in enumerate(accounts):
            state = old.get(row) or {"total": len(names), "done": 0,
                                     "current": "", "failed": [], "acc": acc}
            state["acc"] = acc
            self._rows_state[row] = state
            self._render_row(row)

    def _render_row(self, row):
        state = self._rows_state.get(row)
        if state is None or self.status_panel is None:
            return
        self.status_panel.update_row(row, state)

    def show_failures(self, row):
        """失败任务弹窗：列出失败任务，每个可单独重新执行。"""
        state = self._rows_state.get(row)
        if not state or not state["failed"]:
            return
        dlg = BaseModal(self, f"失败任务 — {state['acc']['character']}", width=420)
        dlg.content_layout.addWidget(
            dlg.hint_label("点击任务名后的按钮重新执行（只跑该账号该任务）："))
        for name in list(state["failed"]):
            row_w = QWidget()
            h = QHBoxLayout(row_w)
            h.setContentsMargins(0, 0, 0, 0)
            h.addWidget(QLabel(self._titles.get(name, name)), 1)
            btn = QPushButton("重新执行")
            btn.setEnabled(not self._running)
            btn.clicked.connect(lambda _=False, r=row, n=name, d=dlg: self._rerun_task(r, n, d))
            h.addWidget(btn)
            dlg.content_layout.addWidget(row_w)
        dlg.exec()

    def _rerun_task(self, row, name, dlg):
        """单独重跑某账号的某个失败任务（发给 worker 子进程执行）。"""
        dlg.accept()
        if self._running:
            log.warning("任务正在执行中，不能重跑")
            return
        state = self._rows_state.get(row)
        if not state:
            return
        self.worker.send({"cmd": "rerun", "params": {
            "acc": state["acc"], "name": name, "titles": self._titles}})

    # ---- worker 子进程事件（core/workerclient.py 读线程 → worker_event 信号 → 这里）----

    @staticmethod
    def _merge_row_state(state, delta):
        """worker 行状态增量合并：done=None=置满；done_add/failed_add/failed_remove
        是增量操作；其余字段直接覆盖。"""
        for k, v in delta.items():
            if k == "done" and v is None:
                state["done"] = state.get("total", 0)
            elif k == "done_add":
                state["done"] = state.get("done", 0) + v
            elif k == "failed_add":
                state.setdefault("failed", []).append(v)
            elif k == "failed_remove":
                if v in state.get("failed", []):
                    state["failed"].remove(v)
            else:
                state[k] = v

    def _on_worker_event(self, ev):
        kind = ev.get("ev")
        if kind == "row":
            acc_id = ev.get("acc_id")
            row = self._acc_row.get(acc_id)
            if row is None:
                # 重跑/兜底：按 _rows_state 里的账号 id 找行
                row = next((r for r, s in self._rows_state.items()
                            if (s.get("acc") or {}).get("id") == acc_id), None)
            if row is None or row not in self._rows_state:
                return
            self._merge_row_state(self._rows_state[row], ev.get("state") or {})
            self.progress_update.emit(row)
        elif kind == "log":
            pass  # 日志显示由 App 侧订阅 worker_event 处理（_on_worker_log）
        elif kind == "finished":
            self.tasks_finished.emit()
        elif kind == "run_rejected":
            log.warning("执行进程正忙，本轮未启动")
            self._running = False
            self._stopping = False
            self._sync_run_state()
        elif kind == "crashed":
            log.error("任务执行进程异常退出（%s）", ev.get("detail", ""))
            if self._running:
                for st in self._rows_state.values():
                    if st.get("done", 0) < st.get("total", 0):
                        st["current"] = "执行进程异常退出"
                self.tasks_finished.emit()
            # 进程已死，下次 send 时 WorkerClient 自动重生

    # ---- 执行 ----

    def _start_run(self, names, accounts=None, names_map=None, preflight=False,
                   overrides=None, team=None):
        """启动一轮并行执行。accounts 为空时取账号登录页的勾选账号
        （定时任务传入自己的名单）；names_map 为 {账号id: [任务名]}
        时各账号按映射执行（开始任务向导 / 一条龙方案 / 定时小任务）。
        preflight=True：先启动缺失的客户端并登录再跑任务。
        overrides：{任务名: {键: 值}}，覆盖 config.yaml 里该任务的参数
        （一条龙/向导把组队方式写进 zudui.mode）。
        team：组队编制 {"captain": id, "members": [id...], "extra_names": [...],
        "mode": auto|manual}（None=本轮没有组队任务，全员只跑单人任务）。"""
        if accounts is None:
            accounts = self._account_provider() if self._account_provider else []
        if not accounts:
            QMessageBox.information(self, "提示", "请先在账号登录页勾选要执行的账号")
            return
        self._task_overrides = dict(overrides or {})
        # 状态面板按本轮实际参与的账号重建（向导/一条龙/定时任务的名单可能和
        # 账号登录页的勾选不一致，沿用旧行会张冠李戴）
        self._run_accounts = list(accounts)
        self.rebuild_status(accounts)
        for row, acc in enumerate(accounts):
            state = self._rows_state.get(row)
            if state is None:
                continue
            total = len(names_map.get(acc["id"], [])) if names_map else len(names)
            state.update({"total": total, "done": 0, "current": "", "failed": []})
            self._render_row(row)
        self._stopping = False
        self._running = True
        self._run_started_at = time.time()
        self._run_task_count = len(names) if names else 0
        self._acc_row = {acc["id"]: row for row, acc in enumerate(accounts)}
        self._sync_run_state()
        # 执行全部在 worker 子进程（core/runner.py）：GUI 只收发事件，
        # 停止 = stop 命令（优雅）/ terminate（强制，见 stop_tasks）
        params = {"accounts": accounts, "names": names,
                  "names_map": ({str(k): v for k, v in names_map.items()}
                                if names_map else None),
                  "preflight": preflight, "overrides": self._task_overrides,
                  "titles": self._titles, "team": team}
        self.worker.send({"cmd": "run", "params": params})

    def stop_tasks(self):
        """停止两阶段（2026-10-25 worker 化）：第一击 = 通知 worker 协作式停止
        （各账号在当前任务/尝试边界停下）；第二击（按钮变「强制结束」）=
        直接 terminate worker 进程，立即生效（命名互斥量随进程死亡自动释放，
        鼠标抬起由 WorkerClient.terminate 补发）。"""
        if not self._running:
            return
        if not self._stopping:
            self._stopping = True
            self.worker.send({"cmd": "stop"})
            self.stop_btn.setText("强制结束")
            self.stop_btn.setToolTip("再点一次 = 直接结束执行进程，立即停止")
            log.info("收到停止请求：已通知执行进程协作式停止；"
                     "急停请再点一次「强制结束」")
            return
        log.warning("强制结束任务执行进程")
        self.worker.terminate()
        for st in self._rows_state.values():
            if st.get("done", 0) < st.get("total", 0):
                st["current"] = "已强制结束"
        self.tasks_finished.emit()

    def shutdown_worker(self):
        """GUI 退出/重启前收尾 worker 子进程（防孤儿进程）。"""
        try:
            self.worker.shutdown()
        except Exception:
            log.exception("关闭任务执行进程失败")

    def _on_finished(self):
        self._running = False
        self._stopping = False
        self.stop_btn.setText("停止任务")
        # 本轮失败清单 → 状态面板「一键反馈」链接（App 经 tasks_finished 信号读取）
        self.last_failures = []
        for _row, st in self._rows_state.items():
            acc = st.get("acc") or {}
            label = f"{acc.get('id')}:{acc.get('character') or '?'}"
            for t in st.get("failed") or []:
                self.last_failures.append(
                    f"{label} · {self._titles.get(t, t)}")
        if self._run_started_at:
            # ② 卡的「上次摘要」（data/last_run.json）：纯展示，写失败不影响流程
            _save_json(LAST_RUN_PATH, {
                "at": time.strftime("%Y-%m-%d %H:%M"),
                "accounts": len(self._run_accounts or []),
                "tasks": self._run_task_count,
                "elapsed": int(time.time() - self._run_started_at)})
        self._run_started_at = 0
        self._run_accounts = None   # 交还给账号登录页的勾选（后续 rebuild 用）
        self._task_overrides = {}
        self._sync_run_state()
        self._refresh_quick_meta()
        for row in self._rows_state:
            self._render_row(row)

# ============================================================================
# 定时任务页
# ============================================================================


class ScheduleTab(QFrame):
    """定时计划表：条目增删改 + 启用开关（data/schedules.json 持久化）。

    2026-10-12：「定时任务」不再是独立一页，**降级为 02 任务页的区段二**。
    页面头、标题胶囊与说明行都不再由本类提供（改由 `TasksTab` 的区段标题行
    承载），本类只负责「表格 + 开关 + 增删改」；区段标题行右侧的
    「添加 / 编辑 / 删除」直接接到本类的 add_entry / edit_entry / delete_entry。

    到点由 App 的 QTimer 巡检触发（仅 GUI 开着时生效），执行走任务页的
    并行管线；到点时有任务在跑则**延后补跑**（见 `App._check_schedules`）。
    """

    COLUMNS = ("启用", "触发时间", "名称", "参与账号", "任务内容", "上次触发")
    count_changed = Signal(int)         # 计划条数变化 → 区段标题行刷新
    selection_changed = Signal(bool)    # 是否选中了行 → 编辑/删除按钮可用性

    def __init__(self):
        super().__init__()
        self.setObjectName("Card")
        self._entries = schedules.load_schedules()
        self._building = False
        self._toggles = []  # row -> QCheckBox

        lay = QVBoxLayout(self)
        lay.setContentsMargins(1, 1, 1, 1)
        lay.setSpacing(0)

        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setObjectName("DataTable")
        self.table.setHorizontalHeaderLabels(self.COLUMNS)
        self.table.setShowGrid(False)
        self.table.setAlternatingRowColors(False)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(Size.ROW_H_SCHEDULE)
        self.table.horizontalHeader().setHighlightSections(False)
        self.table.horizontalHeader().setFixedHeight(Size.TABLE_HEADER_H)
        self.table.setMouseTracking(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setFocusPolicy(Qt.NoFocus)
        self.table.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        self.table.itemSelectionChanged.connect(self._on_selection)
        self._empty = _EmptyHint(
            self.table, "还没有定时任务\n点上方的「添加」创建一个（例如每天早上 6 点跑一条龙）")
        lay.addWidget(self.table, 1)
        self.reload()

    # ---- 数据 ----

    def entries(self):
        return self._entries

    def reload(self):
        self._building = True
        self._toggles = []
        self.table.setRowCount(len(self._entries))
        all_acc = db.list_accounts()
        for row, e in enumerate(self._entries):
            toggle = QCheckBox()
            toggle.setObjectName("Toggle")
            toggle.setFixedSize(Size.TOGGLE_W, Size.TOGGLE_H)
            toggle.setChecked(e.get("enabled", True))
            toggle.toggled.connect(lambda on, r=row: self._on_toggle(r, on))
            wrap = QWidget()
            wl = QHBoxLayout(wrap)
            wl.setContentsMargins(6, 0, 0, 0)
            wl.addWidget(toggle)
            wl.addStretch(1)
            self.table.setCellWidget(row, 0, wrap)
            self._toggles.append(toggle)
            is_ytl = e.get("type") == "yitiaolong" or e.get("tasks") == ["*"]
            if is_ytl:
                plan = ytl.get(e.get("plan_id"))
                if plan:
                    # 方案条目：成员/任务都以方案为准（表格里显示方案成员）
                    by_id = {a["id"]: a for a in all_acc}
                    acc_names = "、".join(
                        by_id[m]["character"] for m in ytl.member_ids(plan)
                        if m in by_id) or "—"
                    task_names = f"一条龙 · {plan.get('name')}（{ytl.summarize(plan)}）"
                else:
                    task_names = "⚠ 旧版一条龙（未选方案，到点不会执行）——请编辑选择方案"
                    acc_names = "—"
            elif e.get("type") == "dishu":
                acc_names = "、".join(
                    a["character"] for a in all_acc
                    if a["id"] in (e.get("accounts") or [])) or "—"
                task_names = "打地鼠（组队→帮会地鼠入侵）"
            else:
                raw = e.get("tasks") or {}
                ids = (list(raw.keys()) if isinstance(raw, dict)
                       else (e.get("accounts") or []))
                ids = {int(i) for i in ids}
                acc_names = "、".join(
                    a["character"] for a in all_acc if a["id"] in ids) or "—"
                task_names = f"{len(ids)} 个账号定制"
            cells = []
            t = QTableWidgetItem(e.get("time", ""))
            t.setFont(mono_font(13))
            t.setForeground(QColor(Color.PRIMARY_STRONG))
            cells.append(t)
            cells.append(QTableWidgetItem(e.get("name", "")))
            c = QTableWidgetItem(acc_names)
            c.setForeground(QColor(Color.TEXT_SECONDARY))
            cells.append(c)
            c = QTableWidgetItem(task_names)
            c.setForeground(QColor(Color.TEXT_SECONDARY))
            cells.append(c)
            # 优先显示带时间的那份（"10-10 06:00" 比只有一个日期有用得多）
            at = e.get("last_run_at") or ""
            last_text = at[5:] if len(at) >= 16 else (e.get("last_run") or "—")
            last = QTableWidgetItem(last_text)
            last.setForeground(QColor(Color.TEXT_TERTIARY))
            cells.append(last)
            for col, item in enumerate(cells, 1):
                self.table.setItem(row, col, item)
        self._empty.sync(len(self._entries))
        self._building = False
        self.count_changed.emit(len(self._entries))
        self._on_selection()

    def _on_selection(self):
        self.selection_changed.emit(self.table.currentRow() >= 0)

    def _on_toggle(self, row, on):
        if self._building:
            return
        self._entries[row]["enabled"] = on
        schedules.save_schedules(self._entries)

    def _selected_row(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.information(self, "提示", "请先选中一条")
            return None
        return row

    # ---- 增删改 ----

    def add_entry(self):
        dlg = ScheduleDialog(self, "添加定时任务")
        if dlg.exec() and dlg.result:
            e = {"id": schedules.next_id(self._entries), "enabled": True,
                 "last_run": "", **dlg.result}
            self._entries.append(e)
            schedules.save_schedules(self._entries)
            self.reload()

    def edit_entry(self):
        row = self._selected_row()
        if row is None:
            return
        dlg = ScheduleDialog(self, "编辑定时任务", initial=self._entries[row])
        if dlg.exec() and dlg.result:
            self._entries[row].update(dlg.result)
            schedules.save_schedules(self._entries)
            self.reload()

    def delete_entry(self):
        row = self._selected_row()
        if row is None:
            return
        e = self._entries[row]
        if not _confirm_destructive(
                self, "确认删除",
                f"删除定时任务「{e.get('name') or e.get('time', '')}」？\n\n此操作不可撤销。"):
            return
        del self._entries[row]
        schedules.save_schedules(self._entries)
        self.reload()


# ============================================================================
# 设置页（2026-10-12 新增）
# ============================================================================


class _GroupHeader(QFrame):
    """设置分组卡的可点卡头。

    与 `_RailButton` 同一套做法：**QFrame 自绘**，不用 QPushButton
    （QSS 会给按钮锁死 min/max 高度，撑不满 56px 的卡头）。
    """

    clicked = Signal()

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self.rect().contains(e.position().toPoint()):
            self.clicked.emit()
            e.accept()
            return
        super().mouseReleaseEvent(e)


class SettingGroup(QFrame):
    """设置页的分组卡（手风琴）：整块卡头可点，靠 `expanded` 属性展开/收起。

    ⚠️ 切换后必须 `repolish()`，否则 `[expanded="true"]` 的选择器不会重新求值
    （QSS 第一大坑）——箭头与标题色都会停在旧状态。
    不做高度动画：`QPropertyAnimation` 对 `maximumHeight` 做动画时，内含
    QSpinBox 的布局会抖动，收益不抵复杂度（设计书 §6.10②）。
    """

    def __init__(self, title, meta="", summary="", expanded=False, body=None):
        super().__init__()
        self.setProperty("role", "settingGroup")
        self.setProperty("expanded", "true" if expanded else "false")
        v = QVBoxLayout(self)
        v.setContentsMargins(1, 1, 1, 1)
        v.setSpacing(0)

        self.header = _GroupHeader()
        self.header.setProperty("role", "groupHeader")
        self.header.setFixedHeight(Size.GROUP_HEADER_H)
        self.header.setCursor(Qt.PointingHandCursor)
        self.header.setToolTip("点击展开 / 收起")
        self.header.clicked.connect(self.toggle)
        h = QHBoxLayout(self.header)
        h.setContentsMargins(20, 0, 20, 0)
        h.setSpacing(12)
        self.title_label = QLabel(title)
        set_prop(self.title_label, role="groupTitle")
        h.addWidget(self.title_label)
        self.meta_label = QLabel(meta)
        set_prop(self.meta_label, role="groupMeta")
        h.addWidget(self.meta_label)
        h.addStretch(1)
        self.summary_label = QLabel(summary)
        set_prop(self.summary_label, role="groupSummary")
        h.addWidget(self.summary_label)
        self.glyph = QLabel("▾" if expanded else "▸")
        self.glyph.setObjectName("GroupGlyph")
        h.addWidget(self.glyph)
        v.addWidget(self.header)

        self.body = body if body is not None else QFrame()
        self.body.setProperty("role", "groupBody")
        if body is None:
            bl = QVBoxLayout(self.body)
            bl.setContentsMargins(20, 4, 20, 20)
            bl.setSpacing(14)
        self.body.setVisible(bool(expanded))
        v.addWidget(self.body)
        repolish(self)
        repolish(self.header)
        repolish(self.glyph)

    def set_summary(self, text):
        """卡头右侧的摘要（「已配置」/「自动」/「默认」）。"""
        self.summary_label.setText(text)

    def toggle(self):
        on = self.property("expanded") != "true"
        self.setProperty("expanded", "true" if on else "false")
        self.body.setVisible(on)
        self.glyph.setText("▾" if on else "▸")
        repolish(self)
        repolish(self.header)
        repolish(self.glyph)


class SettingsTab(QFrame):
    """设置页：**低频配置与程序信息**（设计书 §5 03）。

    承接三样原来无家可归的东西：① 顶栏那两个常驻配置按钮（AI 设置 / 性能）；
    ② 一直没有入口的「程序信息 / 关于」；③ 那些"要改就得去开记事本"的配置。
    正常使用几乎不用进来，所以它是三页里最静态的一页 —— 不追求一屏看完，
    追求"想找什么一定找得到"。

    页面本身没有任何"确定/取消"：**每一处改动都是立即生效的**
    （AI 与高级是显式「保存」，OCR 改 spinbox 即时应用）。
    """

    def __init__(self):
        super().__init__()
        self.setObjectName("Card")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(1, 1, 1, 1)
        lay.setSpacing(0)
        header, h = _card_header("设置", small=False)
        h.addWidget(_pill("配置"))
        h.addStretch(1)
        lay.addWidget(header)

        body = QFrame()
        body.setProperty("role", "fieldGroup")
        col = QVBoxLayout(body)
        col.setContentsMargins(20, 16, 20, 20)
        col.setSpacing(12)
        self.ai_group = self._build_ai_group()
        self.perf_group = self._build_perf_group()
        self.info_group = self._build_info_group()
        self.adv_group = self._build_adv_group()
        for g in (self.ai_group, self.perf_group, self.info_group, self.adv_group):
            col.addWidget(g)
        col.addStretch(1)
        lay.addWidget(_scroll_host(body), 1)

    # ---- 分组内的小工具 ----

    @staticmethod
    def _body():
        box = QFrame()
        box.setProperty("role", "groupBody")
        v = QVBoxLayout(box)
        v.setContentsMargins(20, 4, 20, 20)
        v.setSpacing(14)
        return box, v

    @staticmethod
    def _label(text):
        lab = QLabel(text)
        set_prop(lab, role="fieldLabel")
        return lab

    @staticmethod
    def _value(text="", mono=False):
        lab = QLabel(text)
        set_prop(lab, role="groupValueMono" if mono else "groupValue")
        lab.setWordWrap(True)
        return lab

    def _field_row(self, label, *widgets):
        """一行字段：标签（固定宽 160）+ 控件 + 右侧可选 link。"""
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(10)
        lab = self._label(label)
        lab.setFixedWidth(Size.FIELD_LABEL_W)
        row.addWidget(lab)
        for w in widgets:
            row.addWidget(w)
        row.addStretch(1)
        return row

    def _info_row(self, label, value, btn=None):
        """程序信息行：值**占据剩余宽度**（长描述只在自己的宽度里换行，
        不会把按钮挤得上下错位），动作按钮统一靠右缘成一列。
        （2026-10-12 用户反馈：原来按钮紧贴换行文本、行行参差。）"""
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(10)
        lab = self._label(label)
        lab.setFixedWidth(Size.FIELD_LABEL_W)
        row.addWidget(lab)
        row.addWidget(value, 1)
        if btn is not None:
            row.addWidget(btn)
        return row

    # ================= ① AI 兜底 =================

    def _build_ai_group(self):
        body, v = self._body()
        cfg = aihelper.config()
        v.addWidget(_hint(
            "开启后，脚本遇到没写过的画面会先交给大模型看一眼：能在允许的动作范围内"
            "处理就直接处理掉（只留一张存档截图，不打扰你），处理不了才像以前一样"
            "存图提醒。"))

        row = QHBoxLayout()
        row.setSpacing(10)
        self.ai_enabled = QCheckBox()
        self.ai_enabled.setObjectName("Toggle")
        self.ai_enabled.setFixedSize(Size.TOGGLE_W, Size.TOGGLE_H)
        self.ai_enabled.setCursor(Qt.PointingHandCursor)
        self.ai_enabled.setChecked(bool(cfg.get("enabled")))
        row.addWidget(self.ai_enabled)
        en_label = QLabel("启用 AI 兜底")
        en_label.setCursor(Qt.PointingHandCursor)
        en_label.mouseReleaseEvent = lambda _e: self.ai_enabled.toggle()
        row.addWidget(en_label)
        row.addStretch(1)
        v.addLayout(row)

        v.addLayout(self._field_row("服务商", self._make_ai_provider()))
        self.ai_provider_hint = self._value("")
        v.addWidget(self.ai_provider_hint)

        self.ai_url = QLineEdit()
        self.ai_url.setProperty("mono", "true")
        self.ai_url.setPlaceholderText("OpenAI 兼容的 chat/completions 地址")
        v.addLayout(self._field_row("接口地址", self.ai_url))

        self.ai_model = QComboBox()
        self.ai_model.setEditable(True)
        self.ai_model.setInsertPolicy(QComboBox.NoInsert)
        self.ai_model.setMinimumWidth(320)
        v.addLayout(self._field_row("模型", self.ai_model))

        self.ai_key = QLineEdit()
        self.ai_key.setEchoMode(QLineEdit.Password)
        self.ai_key.setMinimumWidth(280)
        self.ai_show = QCheckBox("显示")
        self.ai_show.toggled.connect(
            lambda on: self.ai_key.setEchoMode(
                QLineEdit.Normal if on else QLineEdit.Password))
        v.addLayout(self._field_row("API Key", self.ai_key, self.ai_show))
        if aihelper.api_key():
            self.ai_key.setPlaceholderText(
                "已配置（%s）· 留空表示不修改" % aihelper.key_source())
        else:
            self.ai_key.setPlaceholderText("在这里粘贴你的 API Key")
        self.ai_key_hint = self._value("")
        v.addWidget(self.ai_key_hint)
        v.addWidget(_hint("Key 只保存在本机（data/ai_key.txt），不会上传到任何地方。"))

        bot = QHBoxLayout()
        bot.setSpacing(8)
        self.ai_test_btn = _btn("测试连接", variant="tool",
                                slot=self._ai_start_test)
        self.ai_save_btn = _btn("保存", variant="primary", slot=self._ai_save)
        bot.addWidget(self.ai_test_btn)
        bot.addWidget(self.ai_save_btn)
        self.ai_state = QLabel("")
        set_prop(self.ai_state, role="settingState", state="idle")
        bot.addWidget(self.ai_state, 1)
        v.addLayout(bot)

        # 初始服务商：按当前 base_url 匹配预设；匹配不上选「自定义」；没配过用第一家
        cur_url = str(cfg.get("base_url") or "").strip()
        idx = next((i for i, p in enumerate(aihelper.PROVIDERS)
                    if p["base_url"] and p["base_url"] == cur_url), None)
        if idx is None:
            idx = len(aihelper.PROVIDERS) - 1 if cur_url else 0
        self.ai_provider.blockSignals(True)
        self.ai_provider.setCurrentIndex(idx)
        self.ai_provider.blockSignals(False)
        self._apply_ai_provider(idx, keep_model=str(cfg.get("model") or ""))
        self.ai_provider.currentIndexChanged.connect(self._on_ai_provider)

        self._ai_probe = None
        self._ai_timer = QTimer(self)
        self._ai_timer.setInterval(300)
        self._ai_timer.timeout.connect(self._ai_poll)

        group = SettingGroup(
            "AI 兜底", "大模型 Key 与模型选择",
            "已配置" if aihelper.api_key() else "未配置", body=body)
        return group

    def _make_ai_provider(self):
        self.ai_provider = QComboBox()
        self.ai_provider.addItems([p["name"] for p in aihelper.PROVIDERS])
        self.ai_provider.setMinimumWidth(260)
        return self.ai_provider

    def _apply_ai_provider(self, idx, keep_model=""):
        p = aihelper.PROVIDERS[idx]
        if p["base_url"]:
            self.ai_url.setText(p["base_url"])
        notes = p.get("notes") or {}
        self.ai_model.clear()
        for m in p["models"]:
            note = notes.get(m)
            self.ai_model.addItem(f"{m}   ← {note}" if note else m, m)
        want = keep_model or (p["models"][0] if p["models"] else "")
        hit = self.ai_model.findData(want)
        if hit >= 0:
            self.ai_model.setCurrentIndex(hit)
        else:
            self.ai_model.setEditText(want)
        self.ai_provider_hint.setText(p["key_hint"] or "")
        self.ai_key_hint.setText(
            ("去哪里拿 Key：%s" % p["key_page"]) if p["key_page"] else "")

    def _on_ai_provider(self, idx):
        # 手选服务商 → 换成它的官方地址与候选模型（Key 不动）
        self._apply_ai_provider(idx)

    def _ai_model_name(self):
        """取下拉里真正要用的模型名（剥掉「← 说明」后缀，手打的名字原样用）。"""
        txt = self.ai_model.currentText().strip()
        i = self.ai_model.currentIndex()
        if 0 <= i < self.ai_model.count() and txt == self.ai_model.itemText(i):
            return str(self.ai_model.itemData(i) or txt).strip()
        return txt.split("←")[0].strip() if "←" in txt else txt

    def _ai_set_state(self, text, state="idle"):
        set_prop(self.ai_state, state=state)
        self.ai_state.setText(text)

    def _ai_start_test(self):
        if self._ai_timer.isActive():
            return
        url = self.ai_url.text().strip()
        model = self._ai_model_name()
        if not url or not model:
            self._ai_set_state("请先把接口地址和模型名填上。", "fail")
            return
        self.ai_test_btn.setEnabled(False)
        self._ai_set_state("正在测试…（最多约 30 秒）", "idle")
        self._ai_probe = None
        threading.Thread(
            target=self._ai_test_worker,
            args=(url, model, self.ai_key.text().strip() or None),
            daemon=True).start()
        self._ai_timer.start()

    def _ai_test_worker(self, url, model, key):
        try:
            ok, msg = aihelper.test_connection(base_url=url, model=model,
                                               api_key_=key)
        except Exception as e:              # 绝不让线程异常吞掉结果
            ok, msg = False, "测试出错：%s" % e
        self._ai_probe = (ok, msg)

    def _ai_poll(self):
        if self._ai_probe is None:
            return
        self._ai_timer.stop()
        ok, msg = self._ai_probe
        self._ai_probe = None
        self.ai_test_btn.setEnabled(True)
        self._ai_set_state(("✓ " if ok else "✗ ") + msg, "ok" if ok else "fail")

    def _ai_save(self):
        url = self.ai_url.text().strip()
        model = self._ai_model_name()
        key = self.ai_key.text().strip()
        if not url:
            self._ai_set_state("接口地址不能为空。", "fail")
            return
        if not model:
            self._ai_set_state("模型名不能为空。", "fail")
            return
        if self.ai_enabled.isChecked() and not key and not aihelper.api_key():
            self._ai_set_state("要启用 AI 兜底就得先填一个 API Key。", "fail")
            return
        # 换了服务商 → 清掉旧的备用模型（不同家的模型名不通用，留着只会一直报错）
        old_url = str(aihelper.config().get("base_url") or "").strip()
        fallback = [] if url != old_url else None
        aihelper.save_settings(enabled=self.ai_enabled.isChecked(),
                              base_url=url, model=model,
                              fallback_models=fallback, api_key=key or None)
        self.ai_key.clear()
        self.ai_group.set_summary("已配置" if aihelper.api_key() else "未配置")
        self._ai_set_state("已保存，立即生效。", "ok")
        log.info("AI 兜底设置已更新：%s", aihelper.status())

    # ================= ② OCR 性能 =================

    def _build_perf_group(self):
        body, v = self._body()
        info = ocr.pool_config()
        saved = ocr.saved_config()
        self._perf_cpu = info["cpu_count"]
        v.addWidget(_hint("默认按本机 CPU 核数自动估算；改完立即生效，无需重启。"))

        self.perf_engines = QSpinBox()
        self.perf_engines.setRange(0, 8)
        self.perf_engines.setSpecialValueText("自动")
        self.perf_engines.setFixedWidth(90)
        self.perf_engines.setValue(int(saved["engines"] or 0))
        v.addLayout(self._field_row("并行引擎数", self.perf_engines,
                                    _link("自动", lambda: self.perf_engines.setValue(0))))

        self.perf_threads = QSpinBox()
        self.perf_threads.setRange(0, 16)
        self.perf_threads.setSpecialValueText("自动")
        self.perf_threads.setFixedWidth(90)
        self.perf_threads.setValue(int(saved["intra_op"] or 0))
        v.addLayout(self._field_row("每引擎线程数", self.perf_threads,
                                    _link("自动", lambda: self.perf_threads.setValue(0))))

        self.perf_state = self._value("")
        v.addLayout(self._field_row("当前配置", self.perf_state))

        bot = QHBoxLayout()
        bot.setSpacing(8)
        bot.addWidget(_btn("恢复自动", slot=self._perf_reset))
        bot.addStretch(1)
        v.addLayout(bot)
        v.addWidget(_hint(
            "单引擎线程数不是越大越好——线程过多会让多个引擎互相抢核，反而更慢"
            "（实测线程不限时比限线程慢一倍）。自动配置约为「引擎数 × 线程数 ≈ 0.9 × 核数」。"))

        self.perf_engines.valueChanged.connect(self._apply_perf)
        self.perf_threads.valueChanged.connect(self._apply_perf)
        # 先挂上分组卡再刷摘要（_refresh_perf_state 会写 set_summary）
        self.perf_group = SettingGroup("OCR 性能", "并行引擎数与线程数", "", body=body)
        self._refresh_perf_state()
        return self.perf_group

    def _apply_perf(self, *_):
        e = self.perf_engines.value() or None
        t = self.perf_threads.value() or None
        ocr.save_config(e, t)
        self._refresh_perf_state()
        cfg = ocr.pool_config()
        log.info("OCR 并发设置已更新：%d 引擎 × %d 线程/引擎（%s）",
                 cfg["engines"], cfg["intra_op"], cfg["source"])

    def _perf_reset(self):
        self.perf_engines.setValue(0)
        self.perf_threads.setValue(0)

    def _refresh_perf_state(self):
        info = ocr.pool_config()
        e, t = info["engines"], info["intra_op"]
        self.perf_state.setText(
            f"本机 {info['cpu_count']} 核 → {e} 引擎 × {t} 线程"
            f"（{info['source']}）")
        manual = self.perf_engines.value() or self.perf_threads.value()
        self.perf_group.set_summary(f"手动 {e}×{t}" if manual else "自动")

    # ================= ③ 程序信息 =================

    def _build_info_group(self):
        from core import logexport
        body, v = self._body()
        mode = "打包 exe" if logexport.FROZEN else "开发模式"
        ver = self._value(f"任务管家 {logexport.app_version()}（{mode}）")
        ver.setWordWrap(False)   # 一行放得下，禁止折行
        v.addLayout(self._info_row("版本", ver))
        # 授权（core/license.py）：状态行 + 「输入/切换密钥」——未到期或想直接
        # 激活的用户随时可用（不必等试用到期弹授权窗）
        self.license_state = self._value(lic.status_text(), mono=False)
        set_prop(self.license_state, role="settingState", state="idle")
        self.license_btn = _btn("输入密钥")
        self.license_btn.setToolTip(
            "粘贴维护者给的授权密钥激活这台机器；\n"
            "已激活的也可以随时换一把新密钥（如续期、换成永久）")
        self.license_btn.clicked.connect(self._on_enter_license)
        v.addLayout(self._info_row("授权", self.license_state, self.license_btn))
        self.refresh_license_state()
        root = self._value(str(logexport.ROOT), mono=True)
        root.setWordWrap(False)
        root.setToolTip(str(logexport.ROOT))
        v.addLayout(self._info_row("安装目录", root,
                                   _btn("打开目录", slot=self._open_root)))
        desc = self._value("把最近日志、配置与报错截图打包成 zip 存到桌面，发给维护者")
        v.addLayout(self._info_row("日志与诊断", desc,
                                   _btn("导出日志", slot=self.export_logs)))
        # 问题反馈通道（core/feedback.py：企业微信群机器人 / Gitee 仓双通道）
        fb_ok = feedback.configured()
        ch_name = "Gitee 仓" if feedback.channel() == "gitee" else "企业微信群机器人"
        self.feedback_state = self._value(
            f"已配置（{ch_name}）" if fb_ok
            else "未配置——任务失败时不会出现「一键反馈」入口")
        self.feedback_test_btn = _btn("测试通道")
        self.feedback_test_btn.setEnabled(fb_ok)
        self.feedback_test_btn.setToolTip("往反馈群发一条测试消息，验证通道可用")
        self.feedback_test_btn.clicked.connect(self._test_feedback)
        v.addLayout(self._info_row("问题反馈", self.feedback_state,
                                   self.feedback_test_btn))
        # 热更新（core/updater.py）：启动时自动检测并下载，这里手动触发同一流程。
        # 显示当前载荷版本 + 待生效版本，非技术用户能直接看懂"重启示后即新版"。
        cur_ver = updater.current_version()
        pend = updater.pending_version()
        if pend:
            text = f"当前 {cur_ver or '未知'}；{pend} 已下载，重启后生效"
        elif cur_ver:
            text = f"当前版本 {cur_ver}（启动时会自动检查更新）"
        else:
            text = "开发模式无热更新（打包版启动时自动检查）"
        self.update_state = self._value(text, mono=False)
        set_prop(self.update_state, role="settingState", state="idle")
        # 更新通道说明：多源回退 + 离线包兜底（2026-11-02）。鼠标停住能看到
        # 手动下载地址，网络受限时不用去翻日志。
        tip = ("更新会依次尝试：GitHub 直连 → gh-proxy.com → ghfast.top → "
               "jsDelivr 镜像，任一可用即成功。\n\n" + updater.manual_download_hint())
        loc = updater.local_packages()
        if loc and not pend:
            tip = (f"检测到离线包 {loc[-1].version}（{Path(loc[-1].local_path).name}），"
                   f"启动检查后会自动安装。\n\n" + tip)
        self.update_state.setToolTip(tip)
        self.update_btn = _btn("检查更新")
        self.update_btn.setEnabled(updater.enabled())
        self.update_btn.setToolTip("立即检查有没有新版本；有则自动下载，重启后生效")
        self.update_btn.clicked.connect(self._on_check_update)
        v.addLayout(self._info_row("检查更新", self.update_state, self.update_btn))
        # 桌面宠物（pet.py）：悬浮球 + 托盘双通道。开关即时生效并写回
        # config `gui.pet_enabled`；启动行为由 config `gui.show_main_on_start` 决定。
        pet_desc = self._value("桌面悬浮球：单击开菜单、双击开主面板；关掉后主面板照常可用")
        self.pet_toggle = _btn("桌面悬浮宠物")
        self.pet_toggle.setCheckable(True)
        self.pet_toggle.setChecked(bool(_gui_cfg().get("pet_enabled", True)))
        self.pet_toggle.setToolTip(
            "当前状态：" + ("已开启" if self.pet_toggle.isChecked() else "已关闭") + "\n"
            "点击切换。关闭后仍可从系统托盘图标唤出主面板。")
        self.pet_toggle.toggled.connect(self._on_pet_toggle)
        v.addLayout(self._info_row("桌面宠物", pet_desc, self.pet_toggle))
        start_desc = self._value("默认启动只显示宠物 + 托盘图标；打开后启动时直接显示主面板")
        self.start_main_toggle = _btn("启动时打开主面板")
        self.start_main_toggle.setCheckable(True)
        self.start_main_toggle.setChecked(
            bool(_gui_cfg().get("show_main_on_start", False)))
        self.start_main_toggle.setToolTip("只影响下次启动，写回 config gui.show_main_on_start")
        self.start_main_toggle.toggled.connect(self._on_start_main_toggle)
        v.addLayout(self._info_row("启动形态", start_desc, self.start_main_toggle))
        # 默认展开「程序信息」："我装的是哪个版本 / 装在哪"是最常被问的
        return SettingGroup("程序信息", "版本 / 安装目录 / 日志与诊断", "",
                            expanded=True, body=body)

    def _open_root(self):
        from core import logexport
        App._open_path(logexport.ROOT)

    def export_logs(self):
        """与顶栏「导出日志」同一个槽函数（由 App 在创建后覆盖为本页的入口）。

        本方法只是兜底：真正实现挂在 `App.export_logs` 上（见 `App.__init__`）。
        """
        if self._export_handler is not None:
            self._export_handler()

    _export_handler = None
    _update_handler = None   # 「检查更新」按钮 → App._check_update(manual=True)
    _license_handler = None  # 「输入密钥」按钮 → App._open_license_dialog
    _pet_handler = None      # 「桌面宠物」开关 → App.set_pet_visible(on)

    def _on_pet_toggle(self, on):
        if self._pet_handler is None:
            return
        if not self._pet_handler(on):
            # 被拒绝（如托盘不可用且主窗隐藏）：把开关拨回去
            self.pet_toggle.blockSignals(True)
            self.pet_toggle.setChecked(not on)
            self.pet_toggle.blockSignals(False)

    def _on_start_main_toggle(self, on):
        _write_config_scalar("show_main_on_start",
                             "true" if on else "false", section="gui")

    def _on_enter_license(self):
        if self._license_handler is not None:
            self._license_handler()

    def refresh_license_state(self):
        """激活/续期后刷新「授权」行（App._after_license_change 会调）。
        按钮文案随状态：已激活→「切换密钥」，其余→「输入密钥」。"""
        self.license_state.setText(lic.status_text())
        st, _ = lic.status()
        self.license_btn.setText("切换密钥" if st == "activated" else "输入密钥")

    def _test_feedback(self):
        """「测试通道」：后台线程发测试消息，QTimer 轮询结果（同 AI 测试的模式）。"""
        self.feedback_test_btn.setEnabled(False)
        set_prop(self.feedback_state, role="settingState", state="idle")
        self.feedback_state.setText("正在发送测试消息……")
        self._fb_result = None

        def work():
            self._fb_result = feedback.test_channel()

        threading.Thread(target=work, daemon=True).start()
        self._fb_timer = QTimer(self)
        self._fb_timer.setInterval(300)
        self._fb_timer.timeout.connect(self._poll_feedback)
        self._fb_timer.start()

    def _poll_feedback(self):
        if getattr(self, "_fb_result", None) is None:
            return
        self._fb_timer.stop()
        ok, msg = self._fb_result
        set_prop(self.feedback_state, role="settingState",
                 state="ok" if ok else "fail")
        self.feedback_state.setText(msg)
        self.feedback_test_btn.setEnabled(True)

    def _on_check_update(self):
        if self._update_handler is not None:
            self._update_handler()

    def set_update_state(self, text, state="idle"):
        """「检查更新」行的状态文字（App 的检查/下载回调也会写这里）。"""
        set_prop(self.update_state, role="settingState", state=state)
        self.update_state.setText(text)

    # ================= ④ 高级 =================

    def _build_adv_group(self):
        body, v = self._body()
        with open(CONFIG_PATH, encoding="utf-8") as f:
            cfg = yaml.safe_load(f) or {}
        delay = cfg.get("delay") or {}

        self.adv_click_min = QSpinBox()
        self.adv_click_min.setRange(200, 2000)
        self.adv_click_min.setSingleStep(50)
        self.adv_click_min.setSuffix(" ms")
        self.adv_click_min.setFixedWidth(110)
        self.adv_click_min.setValue(int(float(delay.get("click_min", 0.5)) * 1000))
        v.addLayout(self._field_row(
            "点击间隔", self.adv_click_min,
            _link("恢复默认", lambda: self.adv_click_min.setValue(500))))

        self.adv_threshold = QDoubleSpinBox()
        self.adv_threshold.setRange(0.50, 0.99)
        self.adv_threshold.setSingleStep(0.01)
        self.adv_threshold.setDecimals(2)
        self.adv_threshold.setFixedWidth(110)
        self.adv_threshold.setValue(float(cfg.get("threshold", 0.85)))
        v.addLayout(self._field_row(
            "匹配阈值", self.adv_threshold,
            _link("恢复默认", lambda: self.adv_threshold.setValue(0.85))))

        bot = QHBoxLayout()
        bot.setSpacing(8)
        self.adv_save_btn = _btn("保存", variant="primary", slot=self._save_adv)
        self.adv_state = self._value("")
        set_prop(self.adv_state, role="settingState", state="idle")
        bot.addWidget(self.adv_save_btn)
        bot.addWidget(self.adv_state, 1)
        v.addLayout(bot)
        v.addWidget(_hint(
            "「点击间隔」是拟人化随机延迟的基准值（每次点击后的停顿下限），"
            "调太小容易被判定为脚本；「匹配阈值」越低越宽松、越容易误匹配。"
            "这两项改完下一次任务生效。"))

        return SettingGroup("高级", "点击间隔 / 匹配阈值", "默认", body=body)

    def _save_adv(self):
        ok = _write_config_scalar("click_min",
                                  round(self.adv_click_min.value() / 1000.0, 2),
                                  section="delay")
        ok2 = _write_config_scalar("threshold",
                                   round(self.adv_threshold.value(), 2))
        if ok and ok2:
            set_prop(self.adv_state, role="settingState", state="ok")
            self.adv_state.setText("已保存，下一次任务生效。")
            log.info("高级设置已更新：点击间隔 %d ms，匹配阈值 %.2f",
                     self.adv_click_min.value(), self.adv_threshold.value())
        else:
            set_prop(self.adv_state, role="settingState", state="fail")
            self.adv_state.setText("写入 config.yaml 失败，请查看日志。")


# ============================================================================
# 热更新弹窗（core/updater.py 的 GUI 侧）
# ============================================================================


class UpdateDialog(BaseModal):
    """发现新版本：展示 当前→最新 版本号与更新日志，自动下载（进度条），
    下载完成切换为「重启生效」。

    状态机：downloading（[后台运行]）→ done（[立即重启][稍后]）；
    needs_full 的版本不下载，只给全量包链接。
    """

    def __init__(self, parent, info, tasks_busy=False):
        super().__init__(parent, "发现新版本", width=560)
        self.info = info
        self.state = "downloading"
        cur = updater.current_version() or "未知"

        ver_row = QHBoxLayout()
        ver_row.setSpacing(8)
        cur_lab = QLabel(cur)
        set_prop(cur_lab, role="groupValueMono")
        arrow = QLabel("→")
        new_lab = QLabel(info.version)
        set_prop(new_lab, role="groupValueMono")
        new_lab.setStyleSheet(f"color:{Color.SUCCESS};font-weight:600;")
        ver_row.addWidget(cur_lab)
        ver_row.addWidget(arrow)
        ver_row.addWidget(new_lab)
        ver_row.addStretch(1)
        self.content_layout.addLayout(ver_row)

        if info.changelog:
            log_view = QPlainTextEdit()
            log_view.setReadOnly(True)
            log_view.setPlainText(info.changelog)
            log_view.setMaximumHeight(140)
            self.content_layout.addWidget(log_view)

        self.status_lab = QLabel("")
        set_prop(self.status_lab, role="groupValue")
        self.content_layout.addWidget(self.status_lab)

        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setValue(0)
        self.content_layout.addWidget(self.bar)

        # 底部栏：取消键改「后台运行」，确定键下载完成前隐藏
        self.cancel_btn.setText("后台运行")
        self.cancel_btn.setToolTip("关掉弹窗，下载继续在后台进行，完成后会再次提示")
        self.ok_btn.setText("立即重启")
        self.ok_btn.setToolTip("重启后自动切换到新版本")
        self.ok_btn.setVisible(False)

        if info.needs_full:
            self.state = "needs_full"
            self.bar.setVisible(False)
            self.status_lab.setText(
                "这个版本更新了底层运行环境，热更新无法升级，需要全量安装包。")
            self.ok_btn.setText("打开下载页")
            self.ok_btn.setVisible(True)
        else:
            mb = info.size / 1024 / 1024
            self.status_lab.setText(
                f"正在下载新版本（约 {mb:.1f} MB），不耽误你继续操作……")

        if tasks_busy:
            self._tasks_busy_note = True   # 完成时「立即重启」置灰

        # 「立即重启」/「打开下载页」走 _on_ok，由 App 在构造后覆盖 _ok_handler
        self._ok_handler = None

    def _on_ok(self):
        if self._ok_handler is not None:
            self._ok_handler()
        else:
            self.accept()

    def set_progress(self, done, total):
        if self.state != "downloading":
            return
        if total > 0:
            pct = int(done * 100 / total)
            self.bar.setValue(pct)
            self.status_lab.setText(
                f"正在下载新版本…… {done / 1024 / 1024:.1f} / "
                f"{total / 1024 / 1024:.1f} MB（{pct}%）")
        else:
            self.status_lab.setText(
                f"正在下载新版本…… 已下载 {done / 1024 / 1024:.1f} MB")

    def show_done(self, ok, tasks_busy=False):
        if ok:
            self.state = "done"
            self.bar.setValue(100)
            self.status_lab.setText(
                f"✅ {self.info.version} 已下载完成，重启后生效。")
            self.cancel_btn.setText("稍后")
            self.ok_btn.setVisible(True)
            if tasks_busy:
                self.ok_btn.setEnabled(False)
                self.ok_btn.setToolTip("任务正在运行，等它跑完再重启；"
                                       "也可以直接关掉，下次启动自动用新版本")
        else:
            self.state = "failed"
            # 2026-11-02：不再只说"下次会重试"——直连 GitHub 在部分网络彻底
            # 不通，用户得知道还有两条路（离线包 / 手动地址）。
            cur_ver = self.info.version
            self.status_lab.setText(
                f"下载失败：所有更新源都不通（已忽略，不影响使用）。\n"
                f"可让维护者把 code-{cur_ver}.zip 发给你，放进\n"
                f"{updater.LOCAL_UPDATE_DIR}\n重启即自动安装；"
                f"鼠标停在这行可看手动下载地址。")
            self.status_lab.setToolTip(updater.manual_download_hint())
            self.status_lab.setWordWrap(True)
            self.cancel_btn.setText("知道了")


# ============================================================================
# 软件授权弹窗（core/license.py 的 GUI 侧）
# ============================================================================


class LicenseDialog(BaseModal):
    """软件授权：显示本机机器码（一键复制）+ 粘贴密钥激活。

    三处入口：启动门禁（试用耗尽，唯一窗口）、试用计时耗尽（模态）、
    设置页「输入密钥」（随时换/续密钥）。激活成功 accept，失败红字显示原因。
    """

    def __init__(self, parent=None, reason=""):
        super().__init__(parent, "软件授权", width=560)
        if reason:
            r = QLabel(reason)
            set_prop(r, role="groupValue")
            r.setWordWrap(True)
            r.setStyleSheet(f"color:{Color.WARNING};font-weight:600;")
            self.content_layout.addWidget(r)

        self.content_layout.addWidget(_hint(
            "这台机器还没激活授权。把下面的「机器码」发给维护者，"
            "拿到密钥后粘贴到下方输入框点「激活」即可（密钥只对本机有效）。"))

        # 机器码行：等宽大字 + 复制按钮
        code_row = QHBoxLayout()
        code_row.setSpacing(8)
        try:
            code = lic.machine_code()
        except Exception:
            code = "读取失败（请联系维护者）"
        self.code_lab = QLabel(code)
        set_prop(self.code_lab, role="groupValueMono")
        self.code_lab.setStyleSheet("font-size:16px;font-weight:600;")
        self.code_lab.setTextInteractionFlags(Qt.TextSelectableByMouse)
        code_row.addWidget(self.code_lab, 1)
        self.copy_btn = _btn("复制机器码", slot=self._copy_code)
        code_row.addWidget(self.copy_btn)
        self.content_layout.addLayout(code_row)

        key_head = QHBoxLayout()
        key_head.setSpacing(8)
        key_lab = QLabel("授权密钥")
        key_lab.setStyleSheet("font-size:13px;font-weight:600;")
        key_head.addWidget(key_lab)
        key_head.addStretch(1)
        key_head.addWidget(_link("从剪贴板粘贴", self._paste_key))
        self.content_layout.addLayout(key_head)

        self.key_edit = QPlainTextEdit()
        self.key_edit.setObjectName("LicenseKeyEdit")
        self.key_edit.setPlaceholderText("把维护者发的密钥整段粘贴到这里……")
        self.key_edit.setMinimumHeight(120)
        self.key_edit.setMaximumHeight(160)
        self.content_layout.addWidget(self.key_edit)

        self.state_lab = QLabel("")
        set_prop(self.state_lab, role="settingState", state="idle")
        self.state_lab.setWordWrap(True)
        self.content_layout.addWidget(self.state_lab)

        self.cancel_btn.setText("退出")
        self.ok_btn.setText("激活")

    def _copy_code(self):
        QApplication.clipboard().setText(self.code_lab.text())
        self.copy_btn.setText("已复制")
        QTimer.singleShot(1500, lambda: self.copy_btn.setText("复制机器码"))

    def _paste_key(self):
        text = QApplication.clipboard().text().strip()
        if text:
            self.key_edit.setPlainText(text)
            self.key_edit.setFocus()

    def _on_ok(self):
        ok, msg = lic.activate(self.key_edit.toPlainText())
        set_prop(self.state_lab, role="settingState",
                 state="ok" if ok else "fail")
        self.state_lab.setText(msg)
        log.info("授权激活%s：%s", "成功" if ok else "失败", msg)
        if ok:
            QTimer.singleShot(700, self.accept)


class MachineCodeDialog(BaseModal):
    """小工具「查看机器码」：大字显示本机机器码 + 一键复制。

    给想主动激活/续期的用户用——不用等试用到期弹授权窗，随时能查到机器码
    发给维护者。机器码只是机器指纹哈希前 20 位，本身不含隐私信息。
    """

    def __init__(self, parent=None):
        super().__init__(parent, "本机机器码", width=520)
        self.content_layout.addWidget(_hint(
            "把机器码发给维护者换取授权密钥（密钥只对本机有效）。\n"
            "机器码是这台电脑的“身份证号”，不包含账号等隐私信息。"))
        try:
            code = lic.machine_code()
        except Exception:
            code = "读取失败（请联系维护者）"
        code_lab = QLabel(code)
        set_prop(code_lab, role="groupValueMono")
        code_lab.setStyleSheet("font-size:20px;font-weight:600;")
        code_lab.setAlignment(Qt.AlignCenter)
        code_lab.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.content_layout.addWidget(code_lab)
        copy_btn = _btn("复制机器码", slot=lambda: (
            QApplication.clipboard().setText(code_lab.text()),
            copy_btn.setText("已复制"),
            QTimer.singleShot(1500, lambda: copy_btn.setText("复制机器码"))))
        self.content_layout.addWidget(copy_btn, 0, Qt.AlignCenter)
        self.ok_btn.setVisible(False)
        self.cancel_btn.setText("关闭")


# ============================================================================
# 动作宏：录制与同步广播回放（core/macro.py 的 GUI 侧）
# ============================================================================


class _RecordFloat(QFrame):
    """录制悬浮状态条：无边框置顶、不抢焦点（WA_ShowWithoutActivating）。

    录制时 MacroDialog 隐藏，屏幕右上角只剩这条提示；焦点留给游戏窗口。
    """

    def __init__(self):
        super().__init__(None, Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint
                         | Qt.Tool)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.setStyleSheet(
            "QFrame{background:#1F2937;border-radius:8px;}"
            "QLabel{color:#FFFFFF;font-size:12px;padding:2px;}")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 8, 12, 8)
        self.lab = QLabel("● 录制中…已录 0 步（按 F9 结束）")
        lay.addWidget(self.lab)
        self.adjustSize()
        scr = QApplication.primaryScreen().availableGeometry()
        self.move(scr.right() - self.width() - 24, scr.top() + 24)

    def set_count(self, n):
        self.lab.setText(f"● 录制中…已录 {n} 步（按 F9 结束）")


class MacroDialog(BaseModal):
    """动作宏：左宏列表 / 中步骤表 / 右步骤编辑器 + 底部录制与同步广播执行。

    步骤模型与回放语义见 core/macro.py；编辑即写回 data/macros.json。
    """

    rec_done = Signal(list)                 # 录制结束（步骤列表）
    exec_progress = Signal(int, int, int, int, bool)  # 步/总步/号/总号/ok
    exec_done = Signal(bool, str)           # 回放结束

    def __init__(self, parent, accounts_provider=None):
        super().__init__(parent, "动作宏 · 录制与同步回放", width=1080)
        self._accounts_provider = accounts_provider or (lambda: [])
        self.macros = macro.load_macros()
        if not self.macros:
            macro.new_macro(self.macros, "我的宏")
            macro.save_macros(self.macros)
        self._rec = None
        self._stop_event = None

        # 底部栏换成「关闭」
        self.ok_btn.setVisible(False)
        self.cancel_btn.setText("关闭")

        cols = QHBoxLayout()
        cols.setSpacing(12)
        self.content_layout.addLayout(cols, 1)
        cols.addLayout(self._build_macro_col())
        cols.addLayout(self._build_steps_col(), 1)
        cols.addLayout(self._build_edit_col())
        self.content_layout.addWidget(self._build_record_row())
        self.content_layout.addWidget(self._build_exec_row())

        self.rec_done.connect(self._on_rec_done)
        self.exec_progress.connect(self._on_exec_progress)
        self.exec_done.connect(self._on_exec_done)

        self._reload_macro_list(0)

    # ---------------------------------------------------------------- 左栏：宏列表

    def _build_macro_col(self):
        v = QVBoxLayout()
        v.setSpacing(6)
        v.addWidget(self._hdr("我的宏"))
        self.mac_list = QListWidget()
        self.mac_list.setFixedWidth(170)
        self.mac_list.currentRowChanged.connect(self._on_macro_selected)
        v.addWidget(self.mac_list, 1)
        v.addWidget(_btn("新建", slot=self._new_macro))
        v.addWidget(_btn("重命名", slot=self._rename_macro))
        v.addWidget(_btn("删除", slot=self._delete_macro))
        return v

    @staticmethod
    def _hdr(text):
        lab = QLabel(text)
        lab.setStyleSheet("font-weight:600;")
        return lab

    def _reload_macro_list(self, select=0):
        self.mac_list.blockSignals(True)
        self.mac_list.clear()
        for m in self.macros:
            self.mac_list.addItem(QListWidgetItem(m["name"]))
        self.mac_list.blockSignals(False)
        if self.macros:
            self.mac_list.setCurrentRow(min(select, len(self.macros) - 1))

    def current_macro(self):
        row = self.mac_list.currentRow()
        return self.macros[row] if 0 <= row < len(self.macros) else None

    def _on_macro_selected(self, _row):
        self._reload_steps()

    def _save(self):
        macro.save_macros(self.macros)

    def _new_macro(self):
        m = macro.new_macro(self.macros)
        self._save()
        self._reload_macro_list(len(self.macros) - 1)

    def _rename_macro(self):
        m = self.current_macro()
        if not m:
            return
        name, ok = QInputDialog.getText(self, "重命名宏", "新名称：",
                                        text=m["name"])
        if ok and name.strip():
            m["name"] = name.strip()
            self._save()
            self._reload_macro_list(self.mac_list.currentRow())

    def _delete_macro(self):
        m = self.current_macro()
        if not m:
            return
        if not _confirm_destructive(self, "删除宏",
                                    f"删除「{m['name']}」？其中的步骤一并删除。"):
            return
        self.macros.remove(m)
        if not self.macros:
            macro.new_macro(self.macros, "我的宏")
        self._save()
        self._reload_macro_list(0)

    # ---------------------------------------------------------------- 中栏：步骤表

    def _build_steps_col(self):
        v = QVBoxLayout()
        v.setSpacing(6)
        v.addWidget(self._hdr("步骤"))
        self.steps_table = QTableWidget(0, 4)
        self.steps_table.setObjectName("DataTable")
        self.steps_table.setHorizontalHeaderLabels(["#", "类型", "参数", "停顿s"])
        self.steps_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.steps_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.steps_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.steps_table.verticalHeader().setVisible(False)
        self.steps_table.itemSelectionChanged.connect(self._on_step_selected)
        v.addWidget(self.steps_table, 1)
        bar = QHBoxLayout()
        bar.setSpacing(6)
        self.step_type = QComboBox()
        self.step_type.addItems([macro.STEP_LABELS[t] for t in macro.STEP_TYPES])
        bar.addWidget(self.step_type, 1)
        bar.addWidget(_btn("插入", slot=self._insert_step))
        bar.addWidget(_btn("删除", slot=self._delete_step))
        bar.addWidget(_btn("上移", slot=lambda: self._move_step(-1)))
        bar.addWidget(_btn("下移", slot=lambda: self._move_step(1)))
        v.addLayout(bar)
        return v

    def _reload_steps(self, select=-1):
        m = self.current_macro()
        steps = m["steps"] if m else []
        self.steps_table.setRowCount(len(steps))
        for i, st in enumerate(steps):
            vals = [str(i + 1), macro.STEP_LABELS.get(st.get("type"), "?"),
                    macro.step_summary(st), str(st.get("pause", ""))]
            for c, text in enumerate(vals):
                self.steps_table.setItem(i, c, QTableWidgetItem(text))
        if steps:
            self.steps_table.selectRow(
                select if 0 <= select < len(steps) else 0)
        self._sync_edit_panel()

    def _on_step_selected(self):
        self._sync_edit_panel()

    def _insert_step(self):
        m = self.current_macro()
        if not m:
            return
        label = self.step_type.currentText()
        stype = next(t for t, lab in macro.STEP_LABELS.items() if lab == label)
        row = max(0, self.steps_table.currentRow())
        m["steps"].insert(row + (1 if m["steps"] else 0),
                          macro.make_step(stype))
        self._save()
        self._reload_steps(row + 1)

    def _delete_step(self):
        m = self.current_macro()
        row = self.steps_table.currentRow()
        if not m or not (0 <= row < len(m["steps"])):
            return
        m["steps"].pop(row)
        self._save()
        self._reload_steps(min(row, len(m["steps"]) - 1))

    def _move_step(self, delta):
        m = self.current_macro()
        row = self.steps_table.currentRow()
        if not m or not (0 <= row < len(m["steps"])):
            return
        to = row + delta
        if not (0 <= to < len(m["steps"])):
            return
        m["steps"][row], m["steps"][to] = m["steps"][to], m["steps"][row]
        self._save()
        self._reload_steps(to)

    # ---------------------------------------------------------------- 右栏：步骤编辑

    def _build_edit_col(self):
        v = QVBoxLayout()
        v.setSpacing(6)
        v.addWidget(self._hdr("步骤编辑"))

        def row(label, w):
            h = QHBoxLayout()
            lab = QLabel(label)
            lab.setFixedWidth(52)
            h.addWidget(lab)
            h.addWidget(w, 1)
            v.addLayout(h)
            return w

        self.ed_x = row("X", QSpinBox())
        self.ed_y = row("Y", QSpinBox())
        self.ed_x2 = row("X2", QSpinBox())
        self.ed_y2 = row("Y2", QSpinBox())
        for sp in (self.ed_x, self.ed_y, self.ed_x2, self.ed_y2):
            sp.setRange(0, 2000)
        self.ed_text = row("文字", QLineEdit())
        self.ed_method = row("方式", QComboBox())
        self.ed_method.addItems(["粘贴（支持中文）", "逐键（数字字母）"])
        self.ed_seconds = row("秒数", QDoubleSpinBox())
        self.ed_seconds.setRange(0.1, 600)
        self.ed_seconds.setSingleStep(0.5)
        self.ed_template = row("模板", QComboBox())
        self.ed_template.setEditable(True)
        self.ed_template.addItems(macro.list_templates())
        self.ed_timeout = row("超时s", QSpinBox())
        self.ed_timeout.setRange(1, 600)
        self.ed_timeout.setValue(15)
        self.ed_on_timeout = row("超时后", QComboBox())
        self.ed_on_timeout.addItems(["中止整轮", "跳过继续"])
        self.ed_pause = row("停顿s", QDoubleSpinBox())
        self.ed_pause.setRange(0, 60)
        self.ed_pause.setSingleStep(0.1)
        v.addWidget(_btn("应用修改", variant="primary", slot=self._apply_edit))
        self.edit_hint = _hint("选中中栏的一步后在这里修改；坐标为客户区"
                               "（405×720）相对坐标。")
        v.addWidget(self.edit_hint)
        v.addStretch(1)
        # 包一层固定宽度，防止字段拉伸
        host = QWidget()
        host.setFixedWidth(260)
        host.setLayout(v)
        wrap = QVBoxLayout()
        wrap.addWidget(host)
        return wrap

    def _sync_edit_panel(self):
        m = self.current_macro()
        row = self.steps_table.currentRow()
        st = m["steps"][row] if m and 0 <= row < len(m["steps"]) else None
        widgets = (self.ed_x, self.ed_y, self.ed_x2, self.ed_y2, self.ed_text,
                   self.ed_method, self.ed_seconds, self.ed_template,
                   self.ed_timeout, self.ed_on_timeout, self.ed_pause)
        for w in widgets:
            w.blockSignals(True)
        if st is None:
            for w in widgets:
                w.setEnabled(False)
        else:
            t = st.get("type")
            for w in widgets:
                w.setEnabled(False)
            if t == "click":
                self.ed_x.setValue(int(st.get("x", 0)))
                self.ed_y.setValue(int(st.get("y", 0)))
                self.ed_x.setEnabled(True)
                self.ed_y.setEnabled(True)
            elif t == "drag":
                self.ed_x.setValue(int(st.get("x1", 0)))
                self.ed_y.setValue(int(st.get("y1", 0)))
                self.ed_x2.setValue(int(st.get("x2", 0)))
                self.ed_y2.setValue(int(st.get("y2", 0)))
                for w in (self.ed_x, self.ed_y, self.ed_x2, self.ed_y2):
                    w.setEnabled(True)
            elif t == "text":
                self.ed_text.setText(st.get("text", ""))
                self.ed_method.setCurrentIndex(
                    0 if st.get("method") == "paste" else 1)
                self.ed_text.setEnabled(True)
                self.ed_method.setEnabled(True)
            elif t == "wait":
                self.ed_seconds.setValue(float(st.get("seconds", 1)))
                self.ed_seconds.setEnabled(True)
            elif t == "wait_image":
                self.ed_template.setCurrentText(st.get("template", ""))
                self.ed_timeout.setValue(int(st.get("timeout", 15)))
                self.ed_on_timeout.setCurrentIndex(
                    0 if st.get("on_timeout") == "stop" else 1)
                for w in (self.ed_template, self.ed_timeout, self.ed_on_timeout):
                    w.setEnabled(True)
            if t != "wait":
                self.ed_pause.setValue(float(st.get("pause", 0.5)))
                self.ed_pause.setEnabled(True)
        for w in widgets:
            w.blockSignals(False)

    def _apply_edit(self):
        m = self.current_macro()
        row = self.steps_table.currentRow()
        if not m or not (0 <= row < len(m["steps"])):
            return
        st = m["steps"][row]
        t = st.get("type")
        if t == "click":
            st["x"], st["y"] = self.ed_x.value(), self.ed_y.value()
        elif t == "drag":
            st.update(x1=self.ed_x.value(), y1=self.ed_y.value(),
                      x2=self.ed_x2.value(), y2=self.ed_y2.value())
        elif t == "text":
            st["text"] = self.ed_text.text()
            st["method"] = "paste" if self.ed_method.currentIndex() == 0 else "type"
        elif t == "wait":
            st["seconds"] = self.ed_seconds.value()
        elif t == "wait_image":
            st["template"] = self.ed_template.currentText().strip()
            st["timeout"] = self.ed_timeout.value()
            st["on_timeout"] = ("stop" if self.ed_on_timeout.currentIndex() == 0
                                else "continue")
        if t != "wait":
            st["pause"] = self.ed_pause.value()
        err = macro.validate_step(
            st, template_exists=lambda n: n in macro.list_templates())
        if err:
            self.edit_hint.setText(f"⚠️ {err}")
        self._save()
        self._reload_steps(row)

    # ---------------------------------------------------------------- 录制区

    def _build_record_row(self):
        box = QFrame()
        box.setProperty("role", "subpanel")
        h = QHBoxLayout(box)
        h.setContentsMargins(12, 8, 12, 8)
        h.setSpacing(8)
        h.addWidget(self._hdr("录制"))
        self.ref_combo = QComboBox()
        self._reload_windows()
        self.ref_combo.setMinimumWidth(180)
        h.addWidget(self.ref_combo)
        h.addWidget(_btn("刷新窗口", slot=self._reload_windows))
        self.rec_btn = _btn("开始录制", variant="primary",
                            slot=self._start_record)
        h.addWidget(self.rec_btn)
        h.addWidget(_hint("录制本窗口里的点击/拖拽（按 F9 结束；录制中别移动窗口；"
                          "ESC 不录制，需要时右侧编辑器手动插）"))
        h.addStretch(1)
        return box

    def _reload_windows(self):
        self.ref_combo.clear()
        try:
            hwnds = Device.find_all()
        except Exception:
            hwnds = []
        for i, h in enumerate(hwnds):
            self.ref_combo.addItem(f"窗口{i + 1}（{h}）", h)

    def _start_record(self):
        hwnd = self.ref_combo.currentData()
        if not hwnd:
            self.exec_state.setText("没有可录制的游戏窗口（先启动客户端）")
            return
        import win32gui
        self._rec = macro.Recorder(
            origin_fn=lambda: win32gui.ClientToScreen(hwnd, (0, 0)))
        self.hide()
        self._float = _RecordFloat()
        self._float.show()
        self._rec_timer = QTimer(self)
        self._rec_timer.setInterval(200)
        self._rec_timer.timeout.connect(
            lambda: self._float.set_count(len(self._rec.steps)))
        self._rec_timer.start()

        def work():
            steps = self._rec.run()
            self.rec_done.emit(steps)

        threading.Thread(target=work, daemon=True).start()

    def _on_rec_done(self, steps):
        if getattr(self, "_rec_timer", None):
            self._rec_timer.stop()
        if getattr(self, "_float", None):
            self._float.close()
            self._float = None
        m = self.current_macro()
        if m and steps:
            m["steps"].extend(steps)
            self._save()
            self._reload_steps(len(m["steps"]) - 1)
        self.exec_state.setText(f"录制结束，新增 {len(steps)} 步")
        self.show()

    # ---------------------------------------------------------------- 执行区

    def _build_exec_row(self):
        box = QFrame()
        box.setProperty("role", "subpanel")
        v = QVBoxLayout(box)
        v.setContentsMargins(12, 8, 12, 8)
        v.setSpacing(6)
        top = QHBoxLayout()
        top.setSpacing(8)
        top.addWidget(self._hdr("同步广播执行"))
        self._acc_checks = []
        for acc in self._accounts_provider():
            cb = QCheckBox(f"{acc.get('id')}:{acc.get('character') or '?'}")
            cb.setChecked(True)
            cb.setEnabled(bool(acc.get("hwnd")))
            if not acc.get("hwnd"):
                cb.setToolTip("该账号未绑定客户端句柄，无法参与回放")
            self._acc_checks.append((cb, acc))
            top.addWidget(cb)
        top.addStretch(1)
        self.exec_btn = _btn("同步广播执行", variant="primary",
                             slot=self._start_exec)
        self.stop_btn = _btn("停止", slot=self._stop_exec)
        self.stop_btn.setEnabled(False)
        top.addWidget(self.exec_btn)
        top.addWidget(self.stop_btn)
        v.addLayout(top)
        bot = QHBoxLayout()
        self.exec_bar = QProgressBar()
        self.exec_bar.setRange(0, 100)
        bot.addWidget(self.exec_bar, 1)
        self.exec_state = QLabel("")
        set_prop(self.exec_state, role="groupValue")
        bot.addWidget(self.exec_state, 2)
        v.addLayout(bot)
        v.addWidget(_hint("回放是盲放（除「等图出现」外不读屏）：某号画面状态不一致"
                          "就会点歪，执行前请确认各号画面状态一致；执行前会自动平铺窗口。"))
        return box

    def selected_hwnds(self):
        return [acc["hwnd"] for cb, acc in self._acc_checks
                if cb.isChecked() and acc.get("hwnd")]

    def _start_exec(self):
        m = self.current_macro()
        hwnds = self.selected_hwnds()
        if not m or not m["steps"]:
            self.exec_state.setText("当前宏没有步骤")
            return
        if not hwnds:
            self.exec_state.setText("没有勾选可回放的账号（需已绑定窗口句柄）")
            return
        templates = set(macro.list_templates())
        for i, st in enumerate(m["steps"]):
            err = macro.validate_step(st, template_exists=templates.__contains__)
            if err:
                self.exec_state.setText(f"第 {i + 1} 步不合法：{err}")
                return
        self._stop_event = threading.Event()
        self.exec_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.rec_btn.setEnabled(False)
        self.exec_bar.setValue(0)
        self.exec_state.setText("执行中……")
        steps = list(m["steps"])
        stop = self._stop_event

        def work():
            ok, detail = macro.replay(
                steps, hwnds,
                progress_cb=lambda *a: self.exec_progress.emit(*a),
                stop_event=stop)
            self.exec_done.emit(ok, detail)

        threading.Thread(target=work, daemon=True).start()

    def _stop_exec(self):
        if self._stop_event:
            self._stop_event.set()
            self.exec_state.setText("正在停止……")

    def _on_exec_progress(self, si, total, di, ndev, ok):
        self.exec_bar.setValue(int((si + (di + 1) / max(1, ndev)) / total * 100))
        self.exec_state.setText(f"第 {si + 1}/{total} 步 · 第 {di + 1}/{ndev} 个窗口")

    def _on_exec_done(self, ok, detail):
        self.exec_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.rec_btn.setEnabled(True)
        self.exec_bar.setValue(100 if ok else self.exec_bar.value())
        self.exec_state.setText(("✅ " if ok else "⚠️ ") + detail)
        log.info("宏回放结束：ok=%s %s", ok, detail)


class FeedbackDialog(BaseModal):
    """一键反馈（core/feedback.py 的 GUI 侧）：失败清单自动带入 + 描述 →
    发到维护者的企业微信群（摘要 + 日志 zip 附件）。

    发送在后台线程，send_done 信号回主线程；任何失败给兜底指引（导出日志）。
    """

    send_done = Signal(bool, str)

    def __init__(self, parent, failures):
        super().__init__(parent, "一键反馈", width=560)
        self._failures = list(failures or [])
        self._sending = False

        self.content_layout.addWidget(self._fb_hdr("本轮失败任务（会随日志一起发出）"))
        fail_text = "\n".join(self._failures) if self._failures else "（本轮没有失败记录）"
        self.fail_lab = QLabel(fail_text)
        set_prop(self.fail_lab, role="groupValue")
        self.fail_lab.setWordWrap(True)
        self.content_layout.addWidget(self.fail_lab)

        self.content_layout.addWidget(self._fb_hdr("补充描述（选填）"))
        self.desc_edit = QPlainTextEdit()
        self.desc_edit.setPlaceholderText(
            "当时发生了什么？比如：卡在某个画面不动 / 点不动某个按钮……\n"
            "越具体越好定位。")
        self.desc_edit.setMaximumHeight(110)
        self.content_layout.addWidget(self.desc_edit)

        self.privacy_hint = _hint(
            "日志里包含账号手机号和角色名，只会发到维护者自己建的群里，不会公开。")
        self.content_layout.addWidget(self.privacy_hint)

        self.state_lab = QLabel("")
        set_prop(self.state_lab, role="settingState", state="idle")
        self.content_layout.addWidget(self.state_lab)

        self.cancel_btn.setText("取消")
        self.ok_btn.setText("发送")
        self.send_done.connect(self._on_done)

    @staticmethod
    def _fb_hdr(text):
        lab = QLabel(text)
        lab.setStyleSheet("font-weight:600;")
        return lab

    def _on_ok(self):
        if self._sending:
            return
        self._sending = True
        self.ok_btn.setEnabled(False)
        self.cancel_btn.setEnabled(False)
        set_prop(self.state_lab, role="settingState", state="idle")
        self.state_lab.setText("正在打包日志并发送……")
        desc = self.desc_edit.toPlainText().strip()
        failures = list(self._failures)

        def work():
            ok, msg = feedback.send(desc, failures)
            self.send_done.emit(ok, msg)

        threading.Thread(target=work, daemon=True).start()

    def _on_done(self, ok, msg):
        set_prop(self.state_lab, role="settingState",
                 state="ok" if ok else "fail")
        self.state_lab.setText(msg)
        if ok:
            self.ok_btn.setText("已发送 ✓")
            self.cancel_btn.setText("关闭")
            log.info("问题反馈已发送（%d 条失败记录）", len(self._failures))
        else:
            self.ok_btn.setEnabled(True)
            self._sending = False
        self.cancel_btn.setEnabled(True)
        log.info("反馈发送结果：ok=%s %s", ok, msg)


# ============================================================================
# 主窗口
# ============================================================================


class App(QMainWindow):
    """主窗口。三页导航：`账号 | 任务 | 设置`（2026-10-12 信息架构重组）。

    页签索引用具名常量，**不要在代码里写死 0/1/2** —— 加页/换序时一处改、
    其余自动跟着走（重组前正是靠索引硬编码，改起来到处漏）。
    """

    PAGES = ("账号", "任务", "设置")
    PAGE_ACCOUNT, PAGE_TASKS, PAGE_SETTINGS = 0, 1, 2

    # 热更新（core/updater.py）：检测/下载在工作线程跑，结果经信号回主线程
    update_check_done = Signal(object)       # UpdateInfo 或 None
    update_dl_progress = Signal(int, int)    # 已下载字节 / 总字节
    update_dl_done = Signal(bool)            # 暂存是否成功

    def __init__(self):
        super().__init__()
        self.setWindowTitle("任务管家")
        self.resize(Size.WINDOW_W, Size.WINDOW_H)
        # 桌面宠物/托盘（pet.py）：main() 里创建后回填，closeEvent/show_main 用
        self.pet = None
        self.tray = None
        self._hide_hint_shown = False

        root = QFrame()
        root.setObjectName("Root")
        self.setCentralWidget(root)
        root_lay = QVBoxLayout(root)
        root_lay.setContentsMargins(0, 0, 0, 0)
        root_lay.setSpacing(0)

        root_lay.addWidget(self._build_topbar())
        root_lay.addLayout(self._build_body(), 1)

        # 账号勾选变化时刷新状态面板
        self.login_tab.tree.itemChanged.connect(
            lambda *_: self.tasks_tab.rebuild_status())
        self.tasks_tab.rebuild_status()

        self._install_log_bridge()
        self._start_timers()
        self._install_shortcuts()

        # 初始页（账号）：右面板按 §4 表复位（状态展开 + 日志收起）
        self._apply_right_panel_for_page(self.PAGE_ACCOUNT)

        self._setup_update_and_license()

    def _build_topbar(self):
        """顶栏：品牌方块 + 分段页签 + 试用/状态徽章 + 唯一常驻动作按钮（导出日志）。"""
        top = QFrame()
        top.setObjectName("TopBar")
        top.setFixedHeight(Size.TOPBAR_H)
        tl = QHBoxLayout(top)
        tl.setContentsMargins(Size.TOPBAR_PAD_L, 0, Size.TOPBAR_PAD_R, 0)
        tl.setSpacing(10)
        # 顶栏品牌方块：与应用图标同一套视觉（青底 + 白剑齿轮），QSS 的青底做背板
        logo = QLabel()
        logo.setObjectName("BrandLogo")
        logo.setFixedSize(Size.LOGO, Size.LOGO)
        logo.setPixmap(icon("app-icon.svg").pixmap(Size.LOGO, Size.LOGO))
        tl.addWidget(logo)
        brand = QLabel("任务管家")
        brand.setObjectName("BrandName")
        tl.addWidget(brand)
        tl.addStretch(1)
        seg = QFrame()
        seg.setObjectName("Segmented")
        sl = QHBoxLayout(seg)
        sl.setContentsMargins(3, 3, 3, 3)
        sl.setSpacing(2)
        self._seg_group = QButtonGroup(self)
        self._seg_btns = []
        for i, name in enumerate(self.PAGES):
            b = QPushButton(name)
            styled(b, role="seg")
            b.setCheckable(True)
            b.clicked.connect(lambda _=False, idx=i: self._switch_page(idx))
            self._seg_group.addButton(b, i)
            sl.addWidget(b)
            self._seg_btns.append(b)
        self._seg_btns[0].setChecked(True)
        tl.addWidget(seg)
        tl.addStretch(1)
        self.trial_pill = QLabel("")
        self.trial_pill.setObjectName("StatusPill")
        set_state(self.trial_pill, "warning")
        self.trial_pill.setToolTip("未激活授权的试用剩余时间，到期后需要密钥激活")
        self.trial_pill.setVisible(False)
        tl.addWidget(self.trial_pill)
        self.status_pill = QLabel("空闲")
        self.status_pill.setObjectName("StatusPill")
        set_state(self.status_pill, "idle")
        tl.addWidget(self.status_pill)
        # 顶栏右侧**只保留 1 个常驻动作按钮**（2026-10-12 信息架构重组）：
        # 「导出日志」是"动作"不是"配置"，且非技术用户取日志全靠它一眼可见，
        # 所以留在手边；「AI 设置 / 性能」这两个**配置**类入口一律进设置页，
        # 不要再往顶栏加按钮（否则就回到"配置散在顶栏"的老路）。
        export_btn = QPushButton("导出日志")
        export_btn.setIcon(icon("export.svg"))
        export_btn.setIconSize(QSize(14, 14))
        export_btn.setCursor(Qt.PointingHandCursor)
        export_btn.setToolTip(
            "把最近的运行日志、配置和报错截图打包成 zip 放到桌面，\n"
            "直接把这个 zip 发给维护者即可（日志在安装目录的 debug 文件夹里）")
        styled(export_btn, variant="tool")
        export_btn.clicked.connect(self._export_logs)
        tl.addWidget(export_btn)
        return top

    def _build_body(self):
        """主体：左页栈（三页）+ 右侧面板（执行状态 + 运行日志 + 折叠竖条）。"""
        body = QHBoxLayout()
        body.setContentsMargins(20, 4, 20, 20)
        body.setSpacing(16)
        self.stack = QStackedWidget()
        self.login_tab = LoginTab()
        self.tasks_tab = TasksTab()
        self.settings_tab = SettingsTab()
        # 定时计划表仍由 App 创建（到点巡检 _check_schedules 挂在 App 上，要拿到它），
        # 但**挂载位置从页栈换成任务页的区段二** —— 经 set_schedule_widget() 注入，
        # 与 set_status_widget() / set_account_provider() 同一套做法。
        self.schedule_tab = ScheduleTab()
        self.tasks_tab.set_account_provider(self.login_tab.checked_accounts)
        self.tasks_tab.set_schedule_widget(self.schedule_tab)
        self.stack.addWidget(self.login_tab)
        self.stack.addWidget(self.tasks_tab)
        self.stack.addWidget(self.settings_tab)
        # 设置页「程序信息」里的「导出日志」与顶栏同一个槽函数
        self.settings_tab._export_handler = self._export_logs
        # 设置页「桌面宠物」开关 → 即时显隐悬浮球并写回 config
        self.settings_tab._pet_handler = self.set_pet_visible
        body.addWidget(self.stack, 1)
        body.addWidget(self._build_right_panel())
        return body

    def _build_right_panel(self):
        """右侧面板：执行状态 + 运行日志卡 + 折叠把手；返回外层容器（含竖条）。"""
        self.status_panel = StatusPanel()
        # 行内「重跑」按钮 → 弹失败任务清单（曾漏接信号，点击无任何反应）。
        # 落点是 TasksTab.show_failures（它是 TasksTab 的方法、读 TasksTab._rows_state），
        # 不能写成 self.show_failures——App 没这个方法，__init__ 里会 AttributeError 闪退。
        self.status_panel.rerun_requested.connect(self.tasks_tab.show_failures)
        self.status_panel.feedback_requested.connect(self._open_feedback)
        self.tasks_tab.set_status_widget(self.status_panel)

        right = QVBoxLayout()
        right.setSpacing(16)
        self._right_layout = right
        right.addWidget(self.status_panel, 2)
        right.addWidget(self._build_log_card(), 3)

        # 折叠把手：收起后整块右侧只剩一条 34px 竖条，把 360px 宽度还给内容区
        # （「任务」「定时任务」两页里运行日志本来就是空的，一直占着很浪费）
        self._right_open = True
        self.right_rail = _RailButton("◀")
        self.right_rail.setFixedWidth(Size.RIGHT_PANEL_RAIL_W)
        self.right_rail.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Expanding)
        self.right_rail.setToolTip("收起右侧「执行状态 / 运行日志」面板")
        self.right_rail.clicked.connect(self._toggle_right_panel)

        self.right_body = QFrame()
        self.right_body.setProperty("role", "fieldGroup")
        self.right_body.setLayout(right)

        self._right_wrap = QFrame()
        self._right_wrap.setProperty("role", "fieldGroup")
        wl = QHBoxLayout(self._right_wrap)
        wl.setContentsMargins(0, 0, 0, 0)
        wl.setSpacing(8)
        # 竖条要撑满整列高度：QHBoxLayout 直接放控件只会给它 sizeHint 高度（居中成小方块），
        # 所以外面套一层竖直布局并给 stretch=1，高度就一定吃满。
        rail_col = QVBoxLayout()
        rail_col.setContentsMargins(0, 0, 0, 0)
        rail_col.addWidget(self.right_rail, 1)
        wl.addLayout(rail_col)
        wl.addWidget(self.right_body, 1)
        self._right_wrap.setFixedWidth(Size.RIGHT_PANEL_W)
        return self._right_wrap

    def _build_log_card(self):
        """「运行日志」卡：可收起标题行（导出/打开目录/清空）+ 只读日志视图。"""
        log_card = QFrame()
        log_card.setObjectName("Card")
        ll = QVBoxLayout(log_card)
        ll.setContentsMargins(1, 1, 1, 1)
        ll.setSpacing(0)
        header, hh = _card_header("运行日志", small=True)
        # 日志可收起：收起后把高度让给上面的「执行状态」
        self.log_toggle = QPushButton("收起")
        self.log_toggle.setToolTip("收起日志框，把高度让给上面的「执行状态」")
        self.log_toggle.setCursor(Qt.PointingHandCursor)
        styled(self.log_toggle, variant="link")
        self.log_toggle.clicked.connect(self._toggle_log)
        hh.addWidget(self.log_toggle)
        hh.addStretch(1)
        # 日志面板自带"导出/打开目录"：别人拿到软件后，在日志窗口上就能直接取日志
        export_link = QPushButton("导出")
        export_link.setToolTip("打包最近日志 + 配置 + 报错截图为 zip 存到桌面（发给维护者）")
        export_link.setCursor(Qt.PointingHandCursor)
        styled(export_link, variant="link")
        export_link.clicked.connect(self._export_logs)
        hh.addWidget(export_link)
        open_dir = QPushButton("打开目录")
        open_dir.setToolTip("用资源管理器打开日志所在文件夹（安装目录\\debug）")
        open_dir.setCursor(Qt.PointingHandCursor)
        styled(open_dir, variant="link")
        open_dir.clicked.connect(self._open_logs_dir)
        hh.addWidget(open_dir)
        clear = QPushButton("清空")
        styled(clear, variant="link")
        hh.addWidget(clear)
        ll.addWidget(header)
        self.log_box = QPlainTextEdit()
        self.log_box.setObjectName("LogView")
        self.log_box.setReadOnly(True)
        self.log_box.setMaximumBlockCount(2000)
        self.log_box.setFont(mono_font(FontSize.CAPTION))
        ll.addWidget(self.log_box, 1)
        clear.clicked.connect(self.log_box.clear)
        self.log_card = log_card
        self._log_open = True
        return log_card

    def _install_log_bridge(self):
        """把 Python logging 接到界面日志框（HH:MM:SS|[账号标签]|正文）。

        另订阅 worker 子进程的日志事件（任务执行 2026-10-25 起在子进程里跑，
        日志经 IPC 回来，着色规则与本地 GuiLogHandler 一致）。
        """
        self._bridge = LogBridge()
        handler = GuiLogHandler(self._bridge)
        handler.setFormatter(gui_formatter())
        logging.getLogger().addHandler(handler)
        logging.getLogger().setLevel(logging.INFO)
        self._bridge.line.connect(self._append_log)
        self.tasks_tab.worker_event.connect(self._on_worker_log)

    def _on_worker_log(self, ev):
        """worker 子进程的日志事件 → 日志面板（行已是 gui_formatter 格式）。"""
        if ev.get("ev") != "log":
            return
        text = ev.get("line", "")
        lv = ev.get("level", "INFO")
        if lv in ("ERROR", "CRITICAL"):
            level = "fail"
        elif lv == "WARNING":
            level = "queue"
        elif "完成" in text or "成功" in text:
            level = "success"
        else:
            level = "normal"
        self._append_log(text, level)

    def _start_timers(self):
        """定时器：定时任务巡检（30s）+ 状态徽章联动。"""
        # 定时任务巡检：每 30 秒检查一次到点条目
        self._sched_timer = QTimer(self)
        self._sched_timer.setInterval(30000)
        self._sched_timer.timeout.connect(self._check_schedules)
        self._sched_timer.start()
        # 到点时有任务在跑 → 延后重试（entry_id -> 到点时刻）；不再"今日跳过"
        self._sched_wait = {}

        # 状态徽章：任务运行状态联动
        self.tasks_tab.tasks_finished.connect(self._sync_pill)
        self.tasks_tab.tasks_finished.connect(self._sync_feedback_link)
        self.tasks_tab.progress_update.connect(lambda *_: self._sync_pill())

    def _install_shortcuts(self):
        """快捷键：Ctrl+1/2/3 切三页、Ctrl+E 导出日志、Ctrl+F 聚焦搜索框。"""
        for i in range(len(self.PAGES)):
            QShortcut(QKeySequence(f"Ctrl+{i + 1}"), self,
                      activated=lambda idx=i: self._switch_page(idx))
        QShortcut(QKeySequence("Ctrl+E"), self, activated=self._export_logs)
        QShortcut(QKeySequence("Ctrl+F"), self, activated=self._focus_search)

    def _setup_update_and_license(self):
        """热更新自动检测（启动 2 秒后）+ 授权试用计时（每 60s 累计）。"""
        # 热更新：启动 2 秒后后台自动检测（不阻塞开界面；开发模式静默禁用）
        self._update_dialog = None
        self._update_info = None
        self._update_manual = False
        self.update_check_done.connect(self._on_update_checked)
        self.update_dl_done.connect(self._on_update_dl_done)
        self.settings_tab._update_handler = lambda: self._check_update(manual=True)
        QTimer.singleShot(2000, lambda: self._check_update(manual=False))

        # 授权试用计时：试用期内每 60s 累计 60s 真实运行时长（改系统时间无效），
        # 耗尽弹授权窗模态拦截；激活后计时器停、徽章隐藏
        self.settings_tab._license_handler = self._open_license_dialog
        st, rem = lic.status()
        self._trial_timer = QTimer(self)
        self._trial_timer.setInterval(60000)
        self._trial_timer.timeout.connect(self._trial_tick)
        if st == "trial":
            self._trial_timer.start()
            self._refresh_trial_pill(rem)

    # ---- 热更新（core/updater.py；弹窗 = UpdateDialog）----

    def _check_update(self, manual=False):
        """后台线程查 manifest；结果经 update_check_done 信号回主线程。"""
        if not updater.enabled():
            if manual:
                self.settings_tab.set_update_state(
                    "开发模式或未配置更新源，无热更新", "idle")
            return
        self._update_manual = manual
        if manual:
            self.settings_tab.set_update_state("正在检查更新……", "idle")

        def work():
            try:
                info = updater.check_update()
            except Exception:
                info = None
            self.update_check_done.emit(info)

        threading.Thread(target=work, daemon=True).start()

    def _on_update_checked(self, info):
        manual, self._update_manual = self._update_manual, False
        if info is None:
            if manual:
                # 区分「确实是最新」和「网络不通」：旧代码两者都是 None，
                # 界面只能说"已是最新"，断网时用户完全看不出来（2026-11-02）
                err = updater.last_error()
                if err:
                    self.settings_tab.set_update_state("检查更新失败（网络受限）",
                                                       "fail")
                    self.settings_tab.update_state.setToolTip(
                        err + "\n\n" + updater.manual_download_hint())
                else:
                    self.settings_tab.set_update_state("已是最新版本", "ok")
            return
        self._update_info = info
        self.settings_tab.set_update_state(f"发现新版本 {info.version}", "ok")
        dlg = UpdateDialog(self, info,
                           tasks_busy=bool(self.tasks_tab._running))
        dlg._ok_handler = lambda: self._update_ok(dlg)
        self._update_dialog = dlg
        self.update_dl_progress.connect(dlg.set_progress)
        if not info.needs_full:
            self._start_update_download(info)
        dlg.show()

    def _start_update_download(self, info):
        def work():
            ok = updater.download_and_stage(
                info,
                progress_cb=lambda d, t: self.update_dl_progress.emit(d, t))
            self.update_dl_done.emit(bool(ok))

        threading.Thread(target=work, daemon=True).start()

    def _on_update_dl_done(self, ok):
        info = self._update_info
        dlg = self._update_dialog
        busy = bool(self.tasks_tab._running)
        if ok and info is not None:
            self.settings_tab.set_update_state(
                f"{info.version} 已下载，重启后生效", "ok")
        elif not ok:
            self.settings_tab.set_update_state("下载失败，下次启动重试", "fail")
        if dlg is None:
            return
        dlg.show_done(ok, tasks_busy=busy)
        if ok and not dlg.isVisible():
            dlg.show()   # 用户中途点了「后台运行」，完成时再次提示

    def _update_ok(self, dlg):
        """UpdateDialog 主按钮：needs_full → 打开全量包下载页；否则立即重启。"""
        info = dlg.info
        if info.needs_full:
            if info.full_url:
                QDesktopServices.openUrl(QUrl(info.full_url))
            dlg.accept()
            return
        if self.tasks_tab._running:
            return   # 按钮已置灰，这里兜底
        self.tasks_tab.shutdown_worker()   # 重启前先杀 worker，防孤儿进程
        if updater.restart_app():
            QApplication.instance().quit()

    # ---- 授权（core/license.py；弹窗 = LicenseDialog）----

    def _trial_tick(self):
        """每分钟累计一次试用时长；耗尽弹授权窗模态拦截。"""
        used = lic.trial_add(60)
        rem = max(0, lic.TRIAL_SECONDS - used)
        self._refresh_trial_pill(rem)
        if rem <= 0:
            self._trial_timer.stop()
            log.info("试用时长已用完，弹出授权窗口")
            dlg = LicenseDialog(self, reason="试用时长已用完。")
            dlg.exec()
            self._after_license_change()

    def _refresh_trial_pill(self, rem):
        h, m = rem // 3600, (rem % 3600) // 60
        self.trial_pill.setText(f"试用 剩 {h}:{m:02d}")
        self.trial_pill.setVisible(True)

    def _open_license_dialog(self):
        """设置页「输入密钥」入口：激活成功刷新设置页状态行与顶栏徽章。"""
        dlg = LicenseDialog(self)
        if dlg.exec() == QDialog.Accepted:
            self._after_license_change()

    def _after_license_change(self):
        self.settings_tab.refresh_license_state()
        st, _ = lic.status()
        if st != "trial":
            self._trial_timer.stop()
            self.trial_pill.setVisible(False)

    # ---- 问题反馈（core/feedback.py；弹窗 = FeedbackDialog）----

    def _sync_feedback_link(self):
        """任务结束后刷新「一键反馈」链接：有失败项且通道已配置才显示。"""
        has_failures = bool(getattr(self.tasks_tab, "last_failures", None))
        self.status_panel.set_feedback_visible(has_failures
                                               and feedback.configured())

    def _open_feedback(self):
        FeedbackDialog(self, list(self.tasks_tab.last_failures)).exec()

    def _switch_page(self, idx):
        """切到第 idx 页：同步分段按钮选中态 + **按页复位右侧面板**。

        - 分段按钮点击本身会置 checked，但快捷键 / 程序内跳转不会，
          不在这里同步就会出现"页面变了、高亮还停在原来那个"。
        - 右面板复位（§4 表）：账号=状态展开+日志收起 / 任务=全展开 /
          设置=整块收起成 34px 竖条。**不记忆用户的手动开合** —— 用"切页"
          这个显式动作复位，比记住一个上次状态更好解释。
        """
        self.stack.setCurrentIndex(idx)
        if 0 <= idx < len(self._seg_btns):
            self._seg_btns[idx].setChecked(True)
        self._apply_right_panel_for_page(idx)

    def _apply_right_panel_for_page(self, idx):
        """按页复位右侧面板（见 `_switch_page` 的说明）。"""
        if idx == self.PAGE_SETTINGS:
            self._set_right_open(False)     # 整块收起：只剩 34px 竖条
            return
        self._set_right_open(True)
        # 账号页：登录时日志基本是空的，高度让给「执行状态」；任务页：运行日志是主信息
        self._set_log_open(idx == self.PAGE_TASKS)

    def _set_right_open(self, on):
        self._right_open = bool(on)
        self.right_body.setVisible(self._right_open)
        self.right_rail.setText("◀" if self._right_open else "▶")
        self.right_rail.setToolTip(
            "收起右侧「执行状态 / 运行日志」面板" if self._right_open
            else "展开右侧「执行状态 / 运行日志」面板")
        self._right_wrap.setFixedWidth(
            Size.RIGHT_PANEL_W if self._right_open else Size.RIGHT_PANEL_RAIL_W)

    # ------------------------------------------------------------------
    # 桌面宠物形态（pet.py）：主窗常驻但可隐藏，宠物悬浮球/托盘唤回

    def show_main(self, page=None):
        """从宠物/托盘唤出主面板；page 传 PAGE_* 常量则同时切页。"""
        self.showNormal()
        self.raise_()
        self.activateWindow()
        if page is not None:
            self._switch_page(page)

    def set_pet_visible(self, on):
        """宠物悬浮球显隐（设置页开关与宠物菜单「隐藏宠物」共用）。

        返回是否真的执行了——宠物关掉 + 主窗没开 + 托盘不可用 = 程序彻底
        没有唤回入口，这种情况拒绝并提示。
        """
        pet = getattr(self, "pet", None)
        if pet is None:
            return False
        if not on and not self.isVisible() and getattr(self, "tray", None) is None:
            QMessageBox.warning(
                self, "桌面宠物",
                "系统托盘不可用，关掉宠物后将无法再唤出主面板，已保持显示。")
            return False
        pet.setVisible(bool(on))
        _write_config_scalar("pet_enabled", "true" if on else "false",
                             section="gui")
        return True

    def closeEvent(self, e):
        """主窗关闭 = 隐藏到后台（宠物/托盘仍在），不退出进程。

        quitOnLastWindowClosed 已关；只有宠物与托盘都不可用（=没有任何
        唤回入口）时才真正退出。显式退出走宠物/托盘菜单的「退出」。
        """
        pet = getattr(self, "pet", None)
        tray = getattr(self, "tray", None)
        has_pet = pet is not None and pet.isVisible()
        has_tray = tray is not None and tray.isVisible()
        if has_pet or has_tray:
            e.ignore()
            self.hide()
            if not self._hide_hint_shown:
                self._hide_hint_shown = True
                petwin.show_hide_hint(tray)
            return
        e.accept()
        self.tasks_tab.shutdown_worker()   # 真退出前收尾 worker 子进程
        QApplication.quit()

    def _set_log_open(self, on):
        self._log_open = bool(on)
        self.log_box.setVisible(self._log_open)
        self.log_toggle.setText("收起" if self._log_open else "展开")
        self.log_toggle.setToolTip("收起日志框，把高度让给上面的「执行状态」"
                                   if self._log_open else "展开日志框")
        self._right_layout.setStretch(0, 2 if self._log_open else 1)
        self._right_layout.setStretch(1, 3 if self._log_open else 0)

    def _focus_search(self):
        """Ctrl+F：切到账号页并聚焦搜索框。"""
        self._switch_page(self.PAGE_ACCOUNT)
        self.login_tab.search.setFocus()
        self.login_tab.search.selectAll()

    def _toggle_right_panel(self):
        """收起/展开整个右侧面板（执行状态 + 运行日志）。"""
        self._set_right_open(not self._right_open)

    def _toggle_log(self):
        """收起/展开运行日志框；收起时把高度让给执行状态。"""
        self._set_log_open(not self._log_open)

    def _open_ocr_perf(self):
        """打开 OCR 性能设置弹窗（保留的入口：将来别处要就地改配置时仍可用）。

        2026-10-12 起**不再从顶栏进入**，顶栏那个按钮已移入设置页的
        「OCR 性能」分组卡（改 spinbox 即时生效，连弹窗都不用了）。
        """
        dlg = OcrPerfDialog(self)
        if dlg.exec() == QDialog.Accepted:
            cfg = ocr.pool_config()
            log.info("OCR 并发设置已更新：%d 引擎 × %d 线程/引擎（%s）",
                     cfg["engines"], cfg["intra_op"], cfg["source"])

    def _open_ai_settings(self):
        """打开 AI 兜底设置弹窗（同上：保留但不再从顶栏进入）。"""
        dlg = AiSettingsDialog(self)
        if dlg.exec() == QDialog.Accepted:
            log.info("AI 兜底设置已更新：%s", aihelper.status())

    def _export_logs(self):
        """打包最近 run.log + 各账号分文件 + 配置 + 失败截图为 zip，供发回分析。

        出口有两个：顶栏「导出日志」按钮、日志面板头部「导出」——给非技术用户用，
        所以成功后弹窗必须给出**完整路径**并附带「打开文件夹」按钮。
        """
        from core import logexport
        try:
            zip_path = logexport.export_logs(Path.home() / "Desktop")
        except Exception as e:
            log.exception("导出日志失败")
            QMessageBox.warning(
                self, "导出日志失败",
                f"{e}\n\n手动取日志：把安装目录下的 debug 文件夹整个发出去即可。")
            return
        box = QMessageBox(self)
        box.setWindowTitle("日志已导出")
        box.setIcon(QMessageBox.Information)
        box.setText("日志包已保存到桌面：")
        box.setInformativeText(
            f"{zip_path}\n\n"
            "把这个 zip 文件发给维护者即可。\n"
            "若桌面找不到，可点「打开文件夹」直接定位。\n\n"
            "注意：日志里含登录手机号与角色名，请确认接收人可信。")
        open_btn = box.addButton("打开文件夹", QMessageBox.ActionRole)
        box.addButton("知道了", QMessageBox.AcceptRole)
        box.exec()
        if box.clickedButton() is open_btn:
            self._open_path(zip_path.parent)

    def _open_logs_dir(self):
        """用资源管理器打开日志目录（打包后 = exe 同级 debug\\）。"""
        self._open_path(DEBUG_DIR)

    @staticmethod
    def _open_path(path):
        p = Path(path)
        if not p.exists():
            QMessageBox.warning(None, "目录不存在", f"找不到：\n{p}")
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(p)))

    def _sync_pill(self):
        running = self.tasks_tab._running
        n = len(self.login_tab.checked_accounts())
        if running:
            self.status_pill.setText(f"运行中 · {n} 个账号")
            set_state(self.status_pill, "ok")
        else:
            self.status_pill.setText("空闲")
            set_state(self.status_pill, "idle")

    def _append_log(self, text, level):
        # 格式：[HH:MM:SS] 消息（handler 用 | 分隔时间戳与正文）
        ts, _, msg = text.partition("|")
        if not msg:
            ts, msg = time.strftime("%H:%M:%S"), text
        append_log(self.log_box, ts, msg, level)

    # ---- 定时任务触发 ----

    def _check_schedules(self):
        entries = self.schedule_tab.entries()
        if not entries:
            return
        now = time.localtime()
        today = time.strftime("%Y-%m-%d")
        changed = False
        for e in entries:
            if not e.get("enabled", True) or e.get("last_run") == today:
                continue
            eid = e.get("id")
            wait_since = self._sched_wait.get(eid)
            if wait_since is not None:
                # 之前到点但被"正在执行的任务"占用 → 每隔 30 秒回来看一眼
                if self.tasks_tab._running:
                    if time.time() - wait_since <= SCHED_DEFER_MAX:
                        continue
                    log.warning("定时任务 [%s] 到点后一直被占用，已延后 %d 分钟仍无法"
                                "执行，今日放弃", e["name"], SCHED_DEFER_MAX // 60)
                    self._sched_wait.pop(eid, None)
                    e["last_run"] = today
                    e["last_run_at"] = time.strftime("%Y-%m-%d %H:%M")
                    changed = True
                    continue
                log.info("定时任务 [%s] 之前被占用，现已空闲，补跑（延后 %.0f 秒）",
                         e["name"], time.time() - wait_since)
                self._sched_wait.pop(eid, None)
                e["last_run"] = today
                e["last_run_at"] = time.strftime("%Y-%m-%d %H:%M")
                changed = True
                self._fire_schedule(e)
                continue
            try:
                hh, mm = (int(x) for x in e["time"].split(":"))
            except Exception:
                continue
            if (now.tm_hour, now.tm_min) != (hh, mm):
                continue  # 只在到点的那一分钟触发（添加早于当前时间的条目不会立即执行）
            if self.tasks_tab._running:
                # 用户规则 2026-10-12：到点被占用**不能今日跳过**——限时玩法
                #（打地鼠 12:00/18:00 刷新）错过就没了。记下到点时刻延后重试。
                log.warning("定时任务 [%s] 到点，但当前有任务在执行，延后重试"
                            "（最多 %d 分钟，不占用今日名额）",
                            e["name"], SCHED_DEFER_MAX // 60)
                self._sched_wait[eid] = time.time()
                continue
            e["last_run"] = today  # 先标记，防重复触发（只有日期，用于去重）
            # 另存一份带时间的，仅用于界面展示"上次触发"具体几点跑的
            e["last_run_at"] = time.strftime("%Y-%m-%d %H:%M")
            changed = True
            self._fire_schedule(e)
        if changed:
            schedules.save_schedules(entries)
            self.schedule_tab.reload()

    def _fire_schedule(self, e):
        is_ytl = e.get("type") == "yitiaolong" or e.get("tasks") == ["*"]
        if e.get("type") == "dishu":
            # 打地鼠（限时，12:00/18:00 整点刷新；条目触发时间锁死 11:50/17:50，
            # 提前 10 分钟进场组队等刷新）：只跑 5开组队 + 打地鼠，先 preflight
            # 登录（含被顶号重登）
            accounts = [a for a in db.list_accounts()
                        if a["id"] in (e.get("accounts") or [])]
            if not accounts:
                log.warning("定时任务 [%s] 没有有效账号，跳过", e["name"])
                return
            # 打地鼠必须组队，队长不能空缺（2026-10-12 教训：不传 team 时
            # zudui 全部"未指定队长，跳过组队"→ 打地鼠全队判负）。条目可配
            # "captain"（账号 id）；未配置默认取账号列表顺序的第一个。
            accounts.sort(key=lambda a: a.get("sort_order") or 0)
            cap = None
            if e.get("captain") is not None:
                cap = next((a for a in accounts if a["id"] == e["captain"]), None)
                if cap is None:
                    log.warning("定时任务 [%s] 指定的队长 id=%s 不在账号列表，"
                                "回退为第一个账号", e["name"], e["captain"])
            cap = cap or accounts[0]
            # 队长标记写进内存态（不落库）：与"开始任务向导/一条龙"两条入口保持一致。
            # 缺了它 base._is_following_member()（category=="日常副本" and not
            # is_captain）会把**队长也当队员**——zudui 跑之前不做 opening_reset/
            # ensure_yunmeng，队长可能停在帮会领地/副本里就去点"帮会"按钮
            # （2026-10-12 补：本地鼠条目是唯一漏标队长的入口）。
            for a in accounts:
                a["is_captain"] = 1 if a["id"] == cap["id"] else 0
            team = {"captain": cap["id"], "members": [a["id"] for a in accounts],
                    "extra_names": [], "mode": "auto"}
            log.info("定时任务触发: [%s] 打地鼠（组队→帮会地鼠入侵），账号 %d 个，"
                     "队长 %s", e["name"], len(accounts), cap["character"])
            self.tasks_tab._start_run(["zudui", "dishu"], accounts=accounts,
                                      preflight=True, team=team)
            return
        if is_ytl:
            plan = ytl.get(e.get("plan_id"))
            if plan:
                # 方案一条龙：成员/队长/组队方式/每人任务全部按方案（任务页向导里配的）
                log.info("定时任务触发: [%s] 一条龙方案 [%s]（%d 人）",
                         e["name"], plan.get("name"),
                         len(plan.get("members") or []))
                self.tasks_tab.start_yitiaolong(plan.get("id"), preflight=True)
                return
            # 旧版"一条龙"条目已废弃：一条龙必须选任务页里配好的方案模板
            # （按账号定制清单功能已删除，没有可回退的执行方式）
            log.warning("定时任务 [%s] 是旧版一条龙条目（未选方案），已跳过——"
                        "请到定时任务页编辑该条目，选择一条龙方案", e["name"])
            return
        # 定时小任务：按账号定制的任务映射
        raw = e.get("tasks") or {}
        if isinstance(raw, dict):
            names_map = {int(k): list(v) for k, v in raw.items()}
        else:  # 旧格式（tasks: [names]）：同一批任务应用到所有勾选账号
            names_map = {i: list(raw) for i in (e.get("accounts") or [])}
        accounts = [a for a in db.list_accounts() if a["id"] in names_map]
        if not accounts:
            log.warning("定时任务 [%s] 没有有效账号，跳过", e["name"])
            return
        log.info("定时任务触发: [%s] 小任务，%d 个账号按各自清单执行",
                 e["name"], len(accounts))
        self.tasks_tab._start_run([], accounts=accounts, names_map=names_map,
                                  preflight=True)


def _set_windows_app_id(app_id: str = "cahx-helper.taskmaster") -> None:
    """Windows：显式声明 AppUserModelID（必须早于任何窗口创建）。

    不设的话进程 AUMID 默认跟随 python.exe —— 标题栏/Alt-Tab 是我们设的图标，
    但**任务栏按钮与「固定到任务栏」会沿用 Python 的图标**（Windows 按 AUMID
    分组并取该 app 的图标）。设了之后系统才把我们当成独立应用，
    `setWindowIcon` 给的图标才会出现在任务栏/固定项上。非 Windows 直接跳过。
    """
    if sys.platform != "win32":
        return
    try:
        import ctypes

        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(app_id)
    except Exception:
        pass


def main():
    ensure_user_files()  # 打包首启：把默认 config/素材复制到 exe 同级
    _set_windows_app_id()  # 任务栏图标/分组：必须在 QApplication/窗口之前

    # 沙盘小工具的提权子进程入口：打包后本程序自己就是 exe，没有别的 python
    # 可以调，只能靠这个参数让提权后的自己退出去做 CLI（砂盘配置改动需要管理员
    # 权限，详见 core/sandbox_tools.py）。
    argv = sys.argv[1:]
    if sandbox_tools.CLI_FLAG in argv:
        i = argv.index(sandbox_tools.CLI_FLAG)
        action = argv[i + 1] if i + 1 < len(argv) else ""
        sys.exit(sandbox_tools.run_cli_action(action))

    # 单实例锁（2026-10-13）：两个 GUI = 两套定时巡检，会重复点同一批客户端、
    # 互抢置前/OCR，甚至把对方当成"顶号"。第二个实例激活已有窗口后直接退出。
    # 放在 QApplication 之前：重复实例不建窗口、不拉 OCR 引擎池、不写日志横幅。
    if single_instance is not None and not single_instance.acquire():
        print("任务管家已在运行，已激活已有窗口。", file=sys.stderr)
        return

    app = QApplication(sys.argv)
    apply_theme(app)  # Fusion + 字体 + 高 DPI + QSS（设计规范 §7 第 1~4 条）
    # 程序图标（theme/icons/app-icon.ico 随包分发，见 cahx-helper.spec datas）：
    # 窗口标题栏 / 任务栏 / 弹窗统一生效。exe 文件本身的图标在 spec EXE icon= 里配。
    app.setWindowIcon(icon("app-icon.ico"))
    # 桌面宠物形态（pet.py，2026-10-24）：进程靠显式「退出」结束，
    # 关掉最后一个窗口（含主窗关闭→隐藏）不退出。
    app.setQuitOnLastWindowClosed(False)

    # 授权门禁（core/license.py）：试用耗尽且未激活 → 只弹授权窗，
    # 主界面完全不出现；开发模式 status 恒 dev 不拦截
    st, _ = lic.status()
    if st == "expired":
        dlg = LicenseDialog(reason="试用期已结束，请输入授权密钥继续使用。")
        if dlg.exec() != QDialog.Accepted:
            sys.exit(0)

    win = App()

    # 默认只显示宠物悬浮球 + 系统托盘，主窗口常驻但隐藏（定时巡检/试用计时/
    # 热更新都挂在 App 上，隐藏照常运行）。config `gui:` 段两个开关：
    # pet_enabled（悬浮球，默认开）/ show_main_on_start（启动即开主面板，默认关）。
    gui_cfg = _gui_cfg()
    pet = petwin.PetWindow(win)
    win.pet = pet
    win.tray = petwin.build_tray(win, pet)
    if win.tray is not None:
        win.tray.show()
    pet_on = bool(gui_cfg.get("pet_enabled", True))
    if pet_on:
        pet.show()
    if gui_cfg.get("show_main_on_start", False) or (not pet_on and win.tray is None):
        # 用户显式要主面板；或"宠物关了 + 托盘不可用"=没有任何入口，兜底开主窗
        win.show()
    # 热更新：宠物/主窗任一已正常显示 = 当前载荷起得来，清崩溃计数（防误回退）
    updater.mark_boot_ok()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
