import ctypes
import logging
import random
import threading
import time

import cv2
import mss
import numpy as np
import win32api
import win32con
import win32gui
import win32process

from core.xlock import InputLock

log = logging.getLogger("device")


def force_mouse_up():
    """在当前光标位置补发一次鼠标左键抬起。

    用于强制结束（terminate）worker 子进程之后：worker 若死在拖拽/按下的
    中间态，鼠标左键会一直按着不放（整台电脑鼠标失灵）。terminate 后补这
    一发即可解除。空闲时补一次抬起无副作用。
    """
    try:
        ctypes.windll.user32.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
    except Exception:
        log.debug("force_mouse_up 失败（可忽略）", exc_info=True)


class _ScreenCapture:
    """屏幕截图后端：优先 dxcam（DXGI 桌面复制，~1ms/帧），不可用时退回 mss（~15ms/帧）。

    dxcam 的 grab() 在屏幕无更新时返回 None（DXGI 只交付新帧），
    因此按 region 缓存最近一帧：返回 None 即画面没变，缓存帧就是当前内容。
    多个窗口线程共用 camera，grab 加锁串行（dxcam 非线程安全）。
    """

    _lock = threading.Lock()
    _cameras = None      # [((left, top, right, bottom), camera)]
    _failed = False
    _cache = {}          # (left, top, w, h) -> 最近一帧 BGR
    # dxcam 禁用截止时刻：DuplicateOutput 访问丢失时 dxcam 的恢复循环会在
    # cam.grab() 内部**无限同步重试**（2s/5s 间隔，永不放弃），而本类 _lock
    # 是全进程共享锁——一个账号触发恢复循环，其余账号的截图全部堵死在锁上
    # （2026-10-15 实机事故：7 号 DuplicateOutput=0x80070005 死循环，5 个账号
    # 全员静默）。所以 dxcam 调用必须在看门狗线程里限时，超时即整体冷却、
    # 冷却期内一律 mss；冷却到期再试一次，dxcam 自愈后自动恢复快路径。
    _DX_TIMEOUT = 8.0        # 单次 dxcam 抓帧上限秒（正常 <50ms）
    _DX_COOLDOWN = 120.0     # 超时后禁用 dxcam 的秒数
    _dx_dead_until = 0.0

    @classmethod
    def _init(cls):
        try:
            import dxcam
        except ImportError:
            log.info("未安装 dxcam，截图使用 mss 后端")
            cls._failed = True
            return
        cams = []
        for idx in range(8):
            try:
                cam = dxcam.create(output_idx=idx, output_color="BGR")
            except IndexError:
                break  # 没有更多显示器
            except Exception as e:
                log.warning("dxcam 初始化显示器 %d 失败: %s", idx, e)
                break
            if cam is None:
                break
            cams.append((tuple(cam.region), cam))
        if cams:
            cls._cameras = cams
            log.info("截图后端: dxcam（%d 个显示器）", len(cams))
        else:
            cls._failed = True
            log.info("dxcam 无可用显示器，截图使用 mss 后端")

    @classmethod
    def grab(cls, left, top, w, h):
        """截取屏幕区域，返回 BGR numpy 数组。"""
        if cls._cameras is None and not cls._failed:
            cls._init()
        if cls._cameras:
            frame = cls._grab_dx(left, top, w, h)
            if frame is not None:
                return frame
            log.warning("dxcam 截图失败，本帧退回 mss")
        return cls._grab_mss(left, top, w, h)

    @classmethod
    def _grab_dx(cls, left, top, w, h):
        if time.time() < cls._dx_dead_until:
            return None  # dxcam 冷却期内，直接走 mss
        key = (left, top, w, h)
        right, bottom = left + w, top + h
        for (cl, ct, cr, cb), cam in cls._cameras:
            if cl <= left and ct <= top and right <= cr and bottom <= cb:
                break
        else:
            return None  # 区域跨显示器，放弃 dxcam
        # 看门狗线程执行真实抓取（dxcam 恢复循环会在 grab 内部无限重试且
        # 持有 _lock，不能在调用线程内直接等）。
        box = []
        done = threading.Event()

        def _worker():
            try:
                with cls._lock:
                    box.append(cam.grab(region=(left - cl, top - ct,
                                                right - cl, bottom - ct)))
            except BaseException as exc:   # noqa: BLE001 —— 原样带回
                box.append(exc)
            finally:
                done.set()

        t = threading.Thread(target=_worker, daemon=True, name="dxgrab")
        t.start()
        if not done.wait(cls._DX_TIMEOUT):
            cls._dx_dead_until = time.time() + cls._DX_COOLDOWN
            log.warning(
                "dxcam 抓帧 %.0f 秒未返回（疑似 DuplicateOutput 恢复死循环），"
                "%.0f 秒内全部改用 mss 截图，到期自动重试 dxcam",
                cls._DX_TIMEOUT, cls._DX_COOLDOWN)
            return None
        if not box:
            return None
        if isinstance(box[0], BaseException):
            log.warning("dxcam 抓帧异常: %s", box[0])
            return None
        frame = box[0]
        if frame is not None:
            cls._cache[key] = frame
            return frame
        cached = cls._cache.get(key)
        if cached is not None:
            return cached
        # 尚无缓存（首次抓取即遇 None）：退 mss 拿一帧垫底
        cls._cache[key] = cls._grab_mss(left, top, w, h)
        return cls._cache[key]

    @staticmethod
    def _grab_mss(left, top, w, h):
        with mss.MSS() as sct:
            raw = sct.grab({"left": left, "top": top, "width": w, "height": h})
        return cv2.cvtColor(np.array(raw), cv2.COLOR_BGRA2BGR)


def _set_dpi_awareness():
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass


def _window_hung(hwnd):
    """目标窗口消息泵是否已挂起（弹窗导致的假死/卡死，游戏端偶发）。

    ⚠️ 对挂起窗口调 SetWindowPos/SetForegroundWindow 会同步阻塞（它们要向
    目标窗口 SendMessage，消息泵死了就永远不返回），任务线程会无声卡死——
    2026-10-11 实测：灵珠详情弹窗导致客户端假死，账号线程沉默 4 分半直到
    手动停止，协作式超时（_check_stop 断点）也救不了。所以一切置顶/置前
    操作前必须先查 IsHungAppWindow。"""
    try:
        return bool(ctypes.windll.user32.IsHungAppWindow(hwnd))
    except Exception:
        return False


class Device:
    """定位游戏窗口，提供截图与点击能力。坐标统一使用客户区相对坐标。

    多开场景：用 find_all() 拿到全部窗口句柄，再逐个构造 Device(hwnd=...)。
    """

    DEFAULT_KEYWORD = "《长安幻想》手游桌面版"

    # 全局输入设备锁：并行登录/任务时多个窗口线程共享一只鼠标/键盘，
    # 点击/按键的完整动作（置前→移动→点击→拟人停顿）必须在锁内原子完成。
    # 2026-10-25 起为跨进程命名互斥量（core/xlock.py）：worker 子进程与 GUI
    # 进程抢鼠标走同一把锁；持锁进程被 terminate 时 OS 自动释放。
    _input_lock = InputLock()

    def __init__(self, keyword=None, background_click=False, click_delay=(0.12, 0.3), hwnd=None,
                 overlay_click=True):
        """click_delay 是每次点击后的**额外**停顿（拟人化）。

        鼠标动作本身已有 0.2~0.4 秒的固有延迟（移动→按下→松开→复位光标），
        加上每帧截图 + OCR 本身就有秒级延迟，默认值取 0.12~0.3 已足够"不像
        机器"。登录路径用这个默认值（并行登录时点击经 _input_lock 全局串行，
        停顿直接叠加到总时长上，越小越好）；任务执行路径由 config.yaml 的
        delay.click_min/click_max 显式传入（可自行调大做更强拟人化）。

        overlay_click：登录/公告阶段存在 Qt 覆盖层（Qt5152QWindowToolSaveBits，
        登录框/「进入游戏」/公告都在这一层）时，优先 PostMessage 后台点击——
        不置前、不动物理光标（2026-11-14 实测覆盖层失焦也收消息，「进入游戏」
        一击命中）。覆盖层进游戏后销毁，找不到时自动回落原路径，因此默认开启
        对游戏内点击零影响。
        """
        _set_dpi_awareness()
        self.keyword = keyword or self.DEFAULT_KEYWORD
        self.background_click = background_click
        self.overlay_click = overlay_click
        self.click_delay = click_delay
        self.hwnd = hwnd if hwnd is not None else self._find_window()
        # ---- 输入层失败信号（整窗失灵看门狗的数据源，2026-10-29）----
        # 见 note_input_miss() 的说明：任务层"该有的面板/模板就是找不到"都记
        # 在这里，由 runner 在任务失败时取走，用于区分"任务本身没办成"与
        # "客户端压根不收点击"。
        self._input_misses = []
        self._miss_lock = threading.Lock()

    def note_input_miss(self, kind, detail=""):
        """记一次"输入层失败"信号（模板等待超时 / 面板点不开 等）。

        背景（2026-10-29 事故）：沙盒客户端会进入一种"渲染正常、窗口不挂起、
        点击落点守卫也全过，但客户端不响应任何点击"的运行态故障——表现就是
        每个任务都在"等某个面板/模板出现"上超时，直到把整轮任务耗完。
        这里只做**记账**（每次点击/等待失败记一笔），判定交给 runner：
        单个信号说明不了问题（可能是真没有），但"连续多个任务每任务都有
        这类信号"基本就是客户端坏了。
        """
        with self._miss_lock:
            self._input_misses.append((time.time(), kind, str(detail)))

    def take_input_misses(self):
        """取走本轮累积的输入层失败信号（读取后清零），返回列表。"""
        with self._miss_lock:
            out = list(self._input_misses)
            self._input_misses = []
        return out

    @classmethod
    def find_all(cls, keyword=None):
        """枚举所有游戏窗口，按屏幕位置从左到右排序。

        只匹配精确标题《长安幻想》手游桌面版（含沙盒的 [#] 变体），
        避免误中本工具 GUI 等标题含"长安幻想"的窗口。
        """
        keyword = keyword or cls.DEFAULT_KEYWORD
        result = []

        def cb(hwnd, _):
            if win32gui.IsWindowVisible(hwnd) and keyword in win32gui.GetWindowText(hwnd):
                result.append(hwnd)

        win32gui.EnumWindows(cb, None)
        result.sort(key=lambda h: win32gui.GetWindowRect(h))
        return result

    def _find_window(self):
        all_hwnds = self.find_all(self.keyword)
        return all_hwnds[0] if all_hwnds else None

    def client_origin(self):
        """客户区左上角在屏幕上的坐标。"""
        return win32gui.ClientToScreen(self.hwnd, (0, 0))

    def client_size(self):
        _, _, w, h = win32gui.GetClientRect(self.hwnd)
        return w, h

    def screenshot(self):
        """截取客户区画面，返回 BGR 格式的 numpy 数组。

        截图读的是屏幕像素，窗口被遮挡会截到别的程序，
        因此前台模式下截图前先把本窗口置顶。
        """
        # 最小化窗口的客户区坐标是 (-32000, -32000) 且尺寸为 0，直接截图会
        # 抛 ScreenShotError（"Region has zero or negative size"），并顺着
        # 调用栈拖垮整个 preflight（2026-10-15 实机：5 号窗口被最小化后
        # 3 轮运行的登录准备全部秒崩）。这里先还原窗口再截。
        if win32gui.IsIconic(self.hwnd):
            try:
                win32gui.ShowWindow(self.hwnd, win32con.SW_RESTORE)
                log.info("窗口 hwnd=%s 处于最小化，已还原后截图", self.hwnd)
                time.sleep(0.25)   # 等窗口完成还原动画
            except Exception as e:
                log.warning("还原最小化窗口失败 hwnd=%s: %s", self.hwnd, e)
        if not self.background_click:
            self.bring_to_top()
            time.sleep(0.06)  # 等 DWM 完成合成，否则可能截到下层窗口
        x0, y0 = self.client_origin()
        w, h = self.client_size()
        if w <= 0 or h <= 0:
            raise RuntimeError(
                f"窗口 hwnd={self.hwnd} 客户区尺寸异常 ({w}x{h})，无法截图")
        return _ScreenCapture.grab(x0, y0, w, h)

    def is_hung(self):
        """窗口消息泵是否已挂起（IsHungAppWindow）——公开给登录状态机判定"运行中假死"。

        见模块级 _window_hung 的注释：挂起窗口只能用 PostMessage（异步）通信，
        一切置顶/置前/同步点击都会阻塞或无效，调用方应尽快关窗重启而不是空等超时。
        """
        return _window_hung(self.hwnd)

    def bring_to_top(self):
        """把窗口提到 Z 序最前（不抢焦点，不受 SetForegroundWindow 限制）。"""
        if _window_hung(self.hwnd):
            log.warning("窗口 hwnd=%s 已挂起（未响应），跳过置顶", self.hwnd)
            return
        try:
            win32gui.SetWindowPos(self.hwnd, win32con.HWND_TOP, 0, 0, 0, 0,
                                  win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)
        except Exception as e:
            log.warning("窗口置顶失败: %s", e)

    def activate(self):
        if _window_hung(self.hwnd):
            log.warning("窗口 hwnd=%s 已挂起（未响应），跳过置前", self.hwnd)
            return
        try:
            win32gui.SetForegroundWindow(self.hwnd)
            time.sleep(0.2)
        except Exception as e:
            log.warning("窗口置前失败: %s", e)

    def click(self, cx, cy, jitter=3):
        """点击客户区内坐标 (cx, cy)，带随机位置抖动和拟人化停顿。"""
        x = cx + random.randint(-jitter, jitter)
        y = cy + random.randint(-jitter, jitter)
        with Device._input_lock:
            clicked = False
            if self.overlay_click:
                # 登录/公告阶段走覆盖层 PostMessage（不动物理光标）；
                # 游戏内没有覆盖层，返回 False 自动回落
                clicked = self._try_click_overlay(x, y)
            if not clicked:
                if self.background_click:
                    self._click_background(x, y)
                else:
                    self._click_foreground(x, y)
            time.sleep(random.uniform(*self.click_delay))

    # 登录框/公告页所在层：框架窗口（UnityWndClass）own 的 Qt 覆盖层，
    # 消息驱动、失焦也收 PostMessage（2026-11-14 实测）
    _OVERLAY_CLASS = "Qt5152QWindowToolSaveBits"

    def _find_overlay(self):
        """找本客户端进程当前**可见**的 Qt 覆盖层，返回 hwnd 或 None。

        覆盖层只在登录/公告阶段存在、进游戏后销毁（句柄失效报 1400），
        必须每次点击前动态枚举，不能缓存。
        """
        try:
            pid = win32process.GetWindowThreadProcessId(self.hwnd)[1]
        except Exception:
            return None
        found = []

        def cb(h, _):
            try:
                if not win32gui.IsWindowVisible(h):
                    return True
                if win32gui.GetClassName(h) != self._OVERLAY_CLASS:
                    return True
                if win32process.GetWindowThreadProcessId(h)[1] != pid:
                    return True
                found.append(h)
            except Exception:
                pass
            return True

        try:
            win32gui.EnumWindows(cb, None)
        except Exception:
            return None
        return found[0] if found else None

    def _try_click_overlay(self, x, y):
        """覆盖层后台点击：PostMessage 三连（MOVE→DOWN→UP），不置前不抢鼠标。

        lParam 用相对覆盖层客户区的坐标（经 ScreenToClient 换算，覆盖层
        与游戏客户区是否完全重合都正确）。找不到覆盖层/发送异常返回 False，
        调用方回落原点击路径，绝不吞点击。
        """
        ov = self._find_overlay()
        if not ov:
            return False
        x0, y0 = self.client_origin()
        try:
            ox, oy = win32gui.ScreenToClient(ov, (x0 + x, y0 + y))
        except Exception:
            return False
        lparam = win32api.MAKELONG(ox, oy)
        for msg, wparam in (
            (win32con.WM_MOUSEMOVE, 0),
            (win32con.WM_LBUTTONDOWN, win32con.MK_LBUTTON),
            (win32con.WM_LBUTTONUP, 0),
        ):
            try:
                win32gui.PostMessage(ov, msg, wparam, lparam)
            except Exception as e:
                log.warning("覆盖层后台点击失败 ov=%s: %s", ov, e)
                return False
            time.sleep(random.uniform(0.04, 0.09))
        return True

    def _click_background(self, x, y):
        lparam = win32api.MAKELONG(x, y)
        win32gui.PostMessage(self.hwnd, win32con.WM_LBUTTONDOWN, win32con.MK_LBUTTON, lparam)
        time.sleep(random.uniform(0.05, 0.12))
        win32gui.PostMessage(self.hwnd, win32con.WM_LBUTTONUP, 0, lparam)

    # 落点校验用 GA_ROOTOWNER（见 _click_foreground 注释）；2=GA_ROOT 会把游戏
    # 客户端自己的 Qt 覆盖层误判成"别人的窗口"
    _GA_ROOTOWNER = 3

    def _point_belongs_to_me(self, sx, sy):
        """屏幕坐标 (sx,sy) 最上层的窗口是否属于本客户端（框架窗口或它的覆盖层）。

        返回 (ok, 命中窗口 owner 根 hwnd)。
        """
        try:
            mine = win32gui.GetAncestor(self.hwnd, self._GA_ROOTOWNER)
            wpt = win32gui.WindowFromPoint((sx, sy))
            root = win32gui.GetAncestor(wpt, self._GA_ROOTOWNER) if wpt else None
        except Exception as e:
            log.warning("落点校验异常（%s）", e)
            return False, None
        return bool(root) and root == mine, root

    def _click_foreground(self, x, y):
        x0, y0 = self.client_origin()
        sx, sy = x0 + x, y0 + y
        # 点击前把目标窗口提到 Z 序最前：并行任务/ GUI 窗口可能叠在游戏窗口上，
        # SetForegroundWindow 常因前台锁失败，SetWindowPos 不受限，必须双保险
        #
        # ⚠️ 点击落点守卫：mouse_event 是全局屏幕点击，落在"该屏幕坐标最上层
        # 的窗口"上。若目标窗口置前失败，这一下就会点到别的窗口（其他客户端
        # 的准备面板/邀请弹窗/主界面）——2026-10-12 实测把队员的「拒绝」点了，
        # 副本挑战被取消、整队判负。落点不属于本窗口时必须丢弃这次点击。
        #
        # 判定必须用 GA_ROOTOWNER**不能**用 GA_ROOT：游戏客户端是"框架窗口 +
        # 覆盖层"两层——框架是 UnityWndClass，标题《长安幻想》手游桌面版
        # （find_all 匹配到的、Device.hwnd 存的就是它）；铺满客户区、真正接收
        # 点击的是它拥有的 Qt 覆盖层（类 Qt5152QWindowToolSaveBits，标题
        # "cahx-win"，登录界面/「进入游戏」/账号下拉都在这一层）。两层是
        # **owner 关系而非父子关系**（IsChild=False，GetParent 虽返回框架但
        # GA_ROOT 归到自己）→ 用 GA_ROOT 会把**本客户端自己的**点击当"别人的
        # 窗口"全部丢弃（2026-10-12 17:51 实测：5 个号卡在登录界面各点几十次
        # 「进入游戏」，362 次点击 100% 被丢，任务整体卡死）。
        # GA_ROOTOWNER 会归到框架：同客户端的框架/覆盖层 → 同一个 owner 根；
        # 跨客户端 / 本工具 GUI / 桌面 → 不同 → 照旧丢弃，防护能力不变。
        ok = False
        root = None
        for attempt in (0, 1):          # 置前偶发失败再试一次（GUI/用户窗口抢 Z 序）
            self.bring_to_top()
            self.activate()
            ok, root = self._point_belongs_to_me(sx, sy)
            if ok:
                break
            if attempt == 0:
                time.sleep(0.1)
        if not ok:
            log.warning("点击落点不在本窗口（疑似置前失败：命中窗口 owner 根 hwnd=%s），"
                        "丢弃本次点击 @ 客户区(%d,%d)", root, x, y)
            return False
        # 保存用户鼠标位置，点击后恢复：该客户端只响应驱动级输入（Unity 不读
        # 窗口消息队列，PostMessage/SendMessage 均无效），只能用前台点击，
        # 恢复位置可以把"抢鼠标"的影响降到一次瞬间跳动
        try:
            old_pos = win32gui.GetCursorPos()
        except Exception:
            old_pos = None
        win32api.SetCursorPos((sx, sy))
        time.sleep(random.uniform(0.05, 0.15))
        win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, sx, sy, 0, 0)
        time.sleep(random.uniform(0.06, 0.12))
        win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, sx, sy, 0, 0)
        if old_pos is not None:
            # 松开后再停留片刻才恢复：游戏按帧轮询光标位置计算点击落点，
            # 立刻恢复会让它认为在窗口外松开，直接丢弃这次点击（实测）
            time.sleep(random.uniform(0.1, 0.15))
            win32api.SetCursorPos(old_pos)
        return True

    def drag(self, cx1, cy1, cx2, cy2, steps=15):
        """从客户区 (cx1,cy1) 拖拽到 (cx2,cy2)（世界地图滑动等场景）。

        该客户端不响应 PostMessage，拖拽只有前台模式：按住后分步移动再松开。
        """
        x0, y0 = self.client_origin()
        sx, sy = x0 + cx1, y0 + cy1
        ex, ey = x0 + cx2, y0 + cy2
        with Device._input_lock:
            self.bring_to_top()
            self.activate()
            try:
                old_pos = win32gui.GetCursorPos()
            except Exception:
                old_pos = None
            win32api.SetCursorPos((sx, sy))
            time.sleep(random.uniform(0.05, 0.12))
            win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, sx, sy, 0, 0)
            for i in range(1, steps + 1):
                ix = int(sx + (ex - sx) * i / steps)
                iy = int(sy + (ey - sy) * i / steps)
                win32api.SetCursorPos((ix, iy))
                time.sleep(random.uniform(0.015, 0.035))
            time.sleep(random.uniform(0.05, 0.1))
            win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, ex, ey, 0, 0)
            if old_pos is not None:
                time.sleep(random.uniform(0.1, 0.15))  # 同 click：立刻恢复会被游戏丢弃
                win32api.SetCursorPos(old_pos)
            time.sleep(random.uniform(0.4, 0.8))

    def type_text(self, text, interval=(0.08, 0.16)):
        """前台逐键输入文本（数字/字母，驱动级 keybd_event，不动鼠标）。

        用于二级密码/验证码输入框。调用前通常需要先点击输入框获得焦点。
        """
        with Device._input_lock:
            self.bring_to_top()
            self.activate()
            for ch in text:
                vk = ord(ch.upper())
                win32api.keybd_event(vk, 0, 0, 0)
                time.sleep(random.uniform(0.03, 0.07))
                win32api.keybd_event(vk, 0, win32con.KEYEVENTF_KEYUP, 0)
                time.sleep(random.uniform(*interval))

    def paste_text(self, text):
        """前台粘贴文本（支持中文等任意字符）：写剪贴板后对窗口发 Ctrl+V。

        游戏输入框输中文（好友搜索等）无法用 keybd_event 逐键模拟
        （只支持 ASCII），走系统剪贴板粘贴。调用前需先点击输入框获得焦点。
        剪贴板是全局资源：写入+粘贴必须在输入锁内原子完成，
        避免多窗口线程并发粘贴串内容。
        """
        import win32clipboard
        with Device._input_lock:
            self.bring_to_top()
            self.activate()
            opened = False
            for _ in range(5):  # 剪贴板可能被其它进程短暂占用，重试
                try:
                    win32clipboard.OpenClipboard()
                    opened = True
                    break
                except Exception:
                    time.sleep(0.2)
            if not opened:
                log.warning("剪贴板打开失败，粘贴取消")
                return False
            try:
                win32clipboard.EmptyClipboard()
                win32clipboard.SetClipboardData(win32clipboard.CF_UNICODETEXT, text)
            finally:
                win32clipboard.CloseClipboard()
            time.sleep(random.uniform(0.1, 0.2))
            win32api.keybd_event(win32con.VK_CONTROL, 0, 0, 0)
            win32api.keybd_event(ord("V"), 0, 0, 0)
            time.sleep(random.uniform(0.05, 0.1))
            win32api.keybd_event(ord("V"), 0, win32con.KEYEVENTF_KEYUP, 0)
            win32api.keybd_event(win32con.VK_CONTROL, 0, win32con.KEYEVENTF_KEYUP, 0)
            time.sleep(random.uniform(0.4, 0.8))
            return True

    def press_backspace(self, count=24, interval=(0.03, 0.08)):
        """前台连发退格键（清空输入框用，先点击输入框获得焦点）。"""
        with Device._input_lock:
            self.bring_to_top()
            self.activate()
            for _ in range(count):
                win32api.keybd_event(win32con.VK_BACK, 0, 0, 0)
                time.sleep(random.uniform(0.02, 0.05))
                win32api.keybd_event(win32con.VK_BACK, 0,
                                     win32con.KEYEVENTF_KEYUP, 0)
                time.sleep(random.uniform(*interval))

    def press_esc(self):
        """发送 ESC，前台/后台模式分别处理。"""
        with Device._input_lock:
            if self.background_click:
                win32gui.PostMessage(self.hwnd, win32con.WM_KEYDOWN, win32con.VK_ESCAPE, 0)
                time.sleep(0.05)
                win32gui.PostMessage(self.hwnd, win32con.WM_KEYUP, win32con.VK_ESCAPE, 0)
            else:
                self.bring_to_top()
                self.activate()
                win32api.keybd_event(win32con.VK_ESCAPE, 0, 0, 0)
                time.sleep(0.05)
                win32api.keybd_event(win32con.VK_ESCAPE, 0, win32con.KEYEVENTF_KEYUP, 0)
            time.sleep(random.uniform(0.4, 0.9))
