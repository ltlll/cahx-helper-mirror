"""游戏内系统弹窗处理：登录流程（login_flow）与日常任务（tasks）共用。

"内存占用较高，一键优化游戏设置"提示会在登录后随机时间弹出（含任务进行中），
处理方式：勾选"永久不提示"后点"确认"。后续其它通用弹窗也在此扩展。
"""
import logging
import random
import re
import time

from core import ocr, pace

log = logging.getLogger("dialogs")

# 屏幕中部弹窗统一扫描区（405x720 客户区）
DIALOG_SCAN_REGION = (60, 40, 285, 510)
# "永久不提示"复选框相对其文字中心的横向偏移
MEMORY_CHECKBOX_DX = -55

# 顶号（被迫下线）弹窗特征文字：实测文案"当前角色已经在别处登录，你被迫下线"，
# 弹窗标题"提示"，唯一按钮"退出游戏"（**不能点**，点了客户端直接退出）。
# "网络已断开，请重新登录"（按钮"重新登录"）同属"账号已不在游戏里"的定局弹窗：
# 不断网时不会出现，出现即任务无法继续——2026-10-12 起并入顶号类处理
# （任务侧抛 AccountKicked → 账号线程重登，最多 3 次）。
KICKED_KEYWORDS = ("被迫下线", "在别处登录", "网络已断开")


def handle_kicked(device, screen, texts=None):
    """检测"被迫下线"顶号 / "网络已断开"断网弹窗，命中返回 True。

    命中时**不点任何按钮**（"退出游戏"/"重新登录"由重登流程 login._quit_kicked
    统一点击）。由调用方抛 tasks.base.AccountKicked 中止该账号剩余任务
    （dialogs 不反向 import tasks，保持现有 handler 的返回值风格）。
    """
    if texts is None:
        texts = ocr.scan(screen, DIALOG_SCAN_REGION)
    if any(k in t for t, *_ in texts for k in KICKED_KEYWORDS):
        log.warning("检测到顶号/断网弹窗，账号已不在游戏中")
        return True
    return False


# 客户端休眠（省电模式）：画面变暗，中央"省电模式中..."，底部滑轨文字
# "向右滑动解锁"（y≈536，DIALOG_SCAN_REGION 下沿可能盖不住，用独立区域），
# 滑轨左端是圆形头像滑块；按住滑块向右拖到滑轨末端解锁
SLEEP_KEYWORDS = ("省电模式", "滑动解锁")
SLEEP_SCAN_REGION = (40, 280, 325, 340)  # 覆盖中央文字与底部滑轨
SLEEP_SLIDER_DX_START = -105             # 头像滑块在"向右滑动解锁"文字左侧约 105px 同高度
SLEEP_SLIDER_DX_END = 125                # 拖到文字右侧约 125px（滑轨右端）
SLEEP_SLIDER_FALLBACK = (147, 536, 380)  # OCR 定位失败的固定起点 (147,536) / 终点 x=380


def handle_sleep_mode(device, screen, texts=None):
    """检测客户端休眠（省电模式）并滑动解锁，命中返回 True。

    texts 传入时（DIALOG_SCAN_REGION 的扫描结果）先做快速初筛，命中后再用
    SLEEP_SCAN_REGION 精确定位滑轨文字：头像滑块在文字左侧约 105px，
    device.drag 拖到文字右侧约 125px（drag 内部已置顶+激活窗口，前台拖拽）。
    拖一次后确认解锁文字消失，没消失再拖，最多 3 次。
    """
    if texts is not None:
        if not any(k in t for t, *_ in texts for k in SLEEP_KEYWORDS):
            return False
    else:
        texts = ocr.scan(screen, SLEEP_SCAN_REGION, min_score=0.5)
        if not any(k in t for t, *_ in texts for k in SLEEP_KEYWORDS):
            return False
    log.info("检测到省电模式（客户端休眠），执行滑动解锁")
    for attempt in range(1, 4):
        slide = [(cx, cy) for t, cx, cy, _ in
                 ocr.scan(device.screenshot(), SLEEP_SCAN_REGION, min_score=0.5)
                 if "滑动解锁" in t]
        if slide:
            cx, y = slide[0]
            x1 = max(10, cx + SLEEP_SLIDER_DX_START)
            x2 = min(395, cx + SLEEP_SLIDER_DX_END)
        else:
            x1, y, x2 = SLEEP_SLIDER_FALLBACK
        log.info("滑动解锁 (%d/3): (%d, %d) → (%d, %d)", attempt, x1, y, x2, y)
        device.drag(x1, y, x2, y)
        pace.wait(1.5, 2.0)
        if not any(k in t for t, *_ in
                   ocr.scan(device.screenshot(), SLEEP_SCAN_REGION, min_score=0.5)
                   for k in SLEEP_KEYWORDS):
            log.info("已退出省电模式")
            return True
    log.warning("省电模式滑动解锁 3 次仍未成功")
    return True


def handle_memory_dialog(device, screen, texts=None):
    """检测并处理"内存优化"提示弹窗，命中返回 True。

    texts: 可选，预先对 DIALOG_SCAN_REGION 扫描得到的 OCR 结果（避免重复识别）。
    """
    if texts is None:
        texts = ocr.scan(screen, DIALOG_SCAN_REGION)
    tip = [r for r in texts if "永久不提示" in r[0]]
    if not tip:
        return False
    _, cx, cy, _ = tip[0]
    log.info("点击 [永久不提示-勾选] @ (%d, %d)", cx + MEMORY_CHECKBOX_DX, cy)
    device.click(cx + MEMORY_CHECKBOX_DX, cy)
    confirm = [r for r in texts if r[0].strip() == "确认"]
    if confirm:
        _, cx, cy, _ = confirm[0]
        log.info("点击 [优化提示-确认] @ (%d, %d)", cx, cy)
        device.click(cx, cy)
    return True


# 变身卡提示弹窗右上角 X 的位置（实测：弹窗"当前烛龙信物变身点数已耗尽，
# 是否前往补充点数？"，只有"前往"按钮，关闭走 X）
TRANSFORM_X_POS = (375, 274)

# 变身卡提示的特征文字（实测文案是"烛龙信物变身点数已耗尽"，不含"变身卡"）
TRANSFORM_KEYWORDS = ("变身点数", "变身卡")

# 主界面右侧任务提示卡（"宗门任务 可领取"/"玩法之书 尚未完成"等）的"取消"按钮区
HINT_CARD_CANCEL_REGION = (270, 285, 125, 55)

# 安全锁/验证码弹窗（出售物品时触发；405x720 客户区坐标）
SEC_PWD_INPUT_POS = (195, 340)      # 安全锁"点击输入6位数字二级密码"输入框
SEC_PWD_CONFIRM_POS = (195, 429)    # 安全锁"确定"
SEC_LOCK_X_POS = (384, 226)         # 安全锁弹窗右上角 X（未设密码时关闭用）
CAPTCHA_INPUT_POS = (197, 346)      # 验证码"点击输入验证码"输入框
CAPTCHA_CONFIRM_POS = (274, 404)    # 验证码"确认"（左侧是"取消"，别点错）


def handle_security_lock(device, screen, pwd2, texts=None):
    """处理"安全锁-验证二级密码"弹窗（出售物品时触发）。

    自动点击输入框、逐键输入账号的二级密码、点"确定"。验证通过一次当日
    免密。注意：验证只是关掉弹窗，被中断的出售需要调用方补点一次出售。
    返回值：False=无弹窗；True=已输入密码；"no_pwd"=有弹窗但账号未设
    密码（已点 X 关掉弹窗，调用方应跳过相关业务而不是反复撞墙）。
    """
    if texts is None:
        texts = ocr.scan(screen, DIALOG_SCAN_REGION)
    if not any("二级密码" in t for t, *_ in texts):
        return False
    if not pwd2:
        log.warning("检测到二级密码验证，但账号未设置二级密码，关闭弹窗并跳过")
        device.click(*SEC_LOCK_X_POS)
        return "no_pwd"
    log.info("安全锁：输入二级密码并确定")
    device.click(*SEC_PWD_INPUT_POS)
    pace.wait(0.6)
    device.type_text(pwd2)
    device.click(*SEC_PWD_CONFIRM_POS)
    return True


def handle_captcha(device, screen, texts=None):
    """处理"出售确认-请输入验证码"弹窗（神蕴灵砂等珍稀物品），命中返回 True。

    验证码数字直接写在弹窗文字里（"请输入验证码8896"，每次不同），
    OCR 提取后逐键输入并点"确认"（即完成出售）。
    """
    if texts is None:
        texts = ocr.scan(screen, DIALOG_SCAN_REGION)
    code = None
    for t, *_ in texts:
        m = re.search(r"验证码\D{0,4}(\d{3,6})", t)
        if m:
            code = m.group(1)
            break
    if code is None:
        return False
    log.info("出售确认：识别到验证码 %s，输入并确认", code)
    device.click(*CAPTCHA_INPUT_POS)
    pace.wait(0.6)
    device.type_text(code)
    device.click(*CAPTCHA_CONFIRM_POS)
    return True


def handle_dungeon_continue(device, screen, texts=None):
    """处理副本接续弹窗（"你已完成六道法门，是否继续前往钟馗捉鬼？
    [取消|前往]"），命中返回 True。

    该弹窗在六道法门"完成挑战"后弹出，会挡住场景右缘"离开"按钮。
    点"前往"虽能直达钟馗，但会被任务流的云梦长安场景保证绕回来，
    因此一律点"取消"，钟馗捉鬼从主界面正常进。
    判定：正文可能分框或被 OCR 漏读（"钟道捉鬼"等），认"继续前往/
    已完成"关键词，或"取消+前往"按钮对 + 标题含"捉鬼"。
    """
    if texts is None:
        texts = ocr.scan(screen, DIALOG_SCAN_REGION)
    body = any("继续前往" in t or "已完成" in t for t, *_ in texts)
    cancel = [r for r in texts if r[0].strip() == "取消"]
    go = [r for r in texts if r[0].strip() == "前往"]
    title = any("捉鬼" in t for t, *_ in texts)
    if not (body or (cancel and go and title)):
        return False
    if cancel:
        _, cx, cy, _ = cancel[0]
        log.info("副本接续弹窗：点击 [取消] @ (%d, %d)", cx, cy)
        device.click(cx, cy)
    return True


def handle_hint_card(device, screen):
    """关闭主界面右侧的任务提示卡（"X任务 可领取 [取消|前往]"/
    "玩法之书 尚未完成 [取消|查看]"等），命中返回 True。

    这类提示卡不会自动消失、ESC 也关不掉，还会吞掉部分点击（实测会导致
    玩法面板/地图节点点击失效）。点"取消"只是关掉卡片，不影响任务本身。
    区域限定在右侧卡片位置，居中确认弹窗的"取消"不在此列。
    """
    hit = ocr.find_text(screen, "取消", region=HINT_CARD_CANCEL_REGION,
                        min_similarity=1.0)
    if not hit:
        return False
    log.info("关闭任务提示卡：点击 [取消] @ (%d, %d)", hit[0], hit[1])
    device.click(hit[0], hit[1])
    return True


def handle_transform_dialog(device, screen, texts=None):
    """检测并关闭"变身点数即将用完/已用完"提示弹窗，命中返回 True。

    任务进行中随机弹出（含战斗中），会遮挡追踪面板/按钮导致误判。
    两种变体：①"烛龙信物变身点数已耗尽，是否前往补充点数？"只有"前往"
    按钮（不能点），关闭走右上角 X (375,274)；②"变身点数即将耗尽，请
    及时充能"有 [前往|关闭]，直接点"关闭"（OCR 定位）。
    """
    if texts is None:
        texts = ocr.scan(screen, DIALOG_SCAN_REGION)
    if not any(k in t for t, *_ in texts for k in TRANSFORM_KEYWORDS):
        return False
    cancel = [r for r in texts if r[0].strip() in ("取消", "关闭")]
    if cancel:
        text, cx, cy, _ = cancel[0]
        log.info("变身卡提示：点击 [%s] @ (%d, %d)", text.strip(), cx, cy)
        device.click(cx, cy)
    else:
        log.info("变身卡提示：点击 [X] @ %s", TRANSFORM_X_POS)
        device.click(*TRANSFORM_X_POS)
    return True

# ---------------------------------------------------------------- 邮箱容量提示
# "提示：邮箱容量接近上限，请及时清理~ [确定]"（2026-10-18 run 7792f4 实测
# 截图，确认按钮 @ (202,446)）。**驻留型模态弹窗**，遮罩全屏吞掉一切点击，
# 且会反复弹出（关掉几分钟后再弹）——4 号从 05:52 到 08:06 被 it 反复挡住，
# liyao/jingji/haishi/huoyue 连环失败、退场景/开地图全部失效。必须进
# dismiss_popups 常规清理，不能只靠 AI 兜底偶尔关一次。
MAILBOX_CONFIRM_POS = (202, 446)   # 「确定」固定坐标（按钮 OCR 失效兜底）


def handle_mailbox_full(device, screen, texts=None):
    """处理"邮箱容量接近上限"提示弹窗，点「确定」关闭，命中返回 True。"""
    if texts is None:
        texts = ocr.scan(screen, DIALOG_SCAN_REGION)
    if not any("邮箱容量" in t for t, *_ in texts):
        return False
    ok = [r for r in texts if r[0].strip() == "确定"]
    if ok:
        _, cx, cy, _ = ok[0]
        log.info("邮箱容量提示：点击 [确定] @ (%d, %d)", cx, cy)
        device.click(cx, cy)
    else:
        log.info("邮箱容量提示：点击 [确定] @ %s（按钮 OCR 未命中，固定坐标）",
                 MAILBOX_CONFIRM_POS)
        device.click(*MAILBOX_CONFIRM_POS)
    return True


# ------------------------------------------------------- 军需官属性兑换弹窗
# "军需官 / 停留在69级或89级的御灵师可在此消耗一定经验和铜币兑换属性，等级
# 突破之后属性将消失 / [兑换属性] [返回]"（2026-10-20 实测截图
# debug/1792447124_zongmen_fail.png：军需官@(292,258)、兑换属性@(202,450)、
# 返回@(202,492)）。它**不是【括号】选项**、底部 DIALOG_ADVANCE_POS(200,605)
# 又落在弹窗外，所以宗门任务的"点对话推进"与 AI 兜底都清不掉：4 号被它挡住
# 追踪面板 → zongmen「追踪面板未展开」判失败，紧接着 xunbao 两次尝试也被它
# 连坐（AI 三次兜底都在点"返回/任务/活动"，弹窗纹丝不动）。
# 一律点「返回」——**绝不点兑换属性**（会消耗经验和铜币改属性）。
# 该弹窗文字全在 DIALOG_SCAN_REGION 内，直接复用 dismiss_popups 已扫描的
# texts，不额外做区域 OCR（也不用登记 POPUP_PROBE_REGIONS）。
MERCHANT_BACK_POS = (202, 492)   # 「返回」固定坐标（按钮 OCR 失效兜底）


def handle_merchant_exchange(device, screen, texts=None):
    """处理军需官"消耗经验/铜币兑换属性"弹窗：点「返回」，命中返回 True。"""
    if texts is None:
        texts = ocr.scan(screen, DIALOG_SCAN_REGION)
    if not any("兑换属性" in t for t, *_ in texts):
        return False
    if not any(("军需官" in t or "等级突破" in t) for t, *_ in texts):
        return False
    btn = [r for r in texts if r[0].strip() == "返回"]
    if btn:
        _, cx, cy, _ = btn[0]
        log.info("军需官兑换属性弹窗：点击 [返回] @ (%d, %d)", cx, cy)
        device.click(cx, cy)
    else:
        log.info("军需官兑换属性弹窗：点击 [返回] @ %s（按钮 OCR 未命中，固定坐标）",
                 MERCHANT_BACK_POS)
        device.click(*MERCHANT_BACK_POS)
    return True


# ---------------------------------------------------------------- 未知弹窗通用兜底
# 用户规则（2026-10-20）：遇到不认识的弹窗，优先找「返回」文字按钮；没有再找
# 右上角 X 圆形按钮（深色圆底 + 亮色 X 图形，模板 assets/images/anchors/x_btn.png，
# 2026-10-20 实机军需官弹窗 X 中心 (347,221) 裁制）。两者都能退回主界面。
#
# 守卫（防误关任务故意打开的子页面）：只有主界面左侧栏图标（玩法/坊市/商城…）
# 在 OCR 文本里可见时才动手——军需官这类"叠在主界面上的弹窗"左栏不会被盖住，
# 而任务主动进入的子页面（制作台/玩法面板等）是全屏的、左栏不可见，兜底静默。
UNKNOWN_RAIL_KEYWORDS = ("玩法", "活动", "坊市", "商城", "帮会", "好友",
                         "背包", "收益", "排行", "称号")
UNKNOWN_BACK_MIN_Y = 340      # 「返回」按钮只会出现在弹窗下半部（按钮区）
UNKNOWN_X_REGION = (260, 40, 140, 300)   # X 圆钮只出现在弹窗右上角附近
# 任务主动打开、绝不能被兜底误关的行动面板标志（副本入口"开始挑战/便捷组队"、
# 整理/出售面板等——2026-10-20 _chk_cap6 实证：副本入口面板左栏可见且右上有 X，
# 光靠左栏守卫拦不住，必须见这些按钮就整体放弃兜底）
UNKNOWN_DENYLIST = ("开始挑战", "开始匹配", "便捷组队", "整理", "出售")


def _main_rail_visible(screen, texts, matcher=None):
    """主界面左侧栏图标是否可见（x<60 的栏位文字/图标）。

    双通道：调用方传全屏 texts 时 OCR 免费命中；dismiss_popups 传的是
    DIALOG_SCAN_REGION（x 从 60 起）扫不到左栏，退而用栏位图标模板
    （assets/images/anchors/rail_icon.png，取自常驻的「坊市」图标，
    2026-10-20 实机裁制）做一次廉价模板匹配。全屏子页面（制作台/出售
    面板等）左栏被盖住 → None，兜底静默，不会误关任务主动打开的页面。
    """
    if any(cx < 60 and any(k in t for k in UNKNOWN_RAIL_KEYWORDS)
           for t, cx, cy, *_ in texts):
        return True
    if matcher is not None and matcher.has_template("rail_icon"):
        return matcher.find(screen, "rail_icon", region=(0, 150, 80, 420),
                            threshold=0.8) is not None
    return False


def handle_unknown_exit(device, screen, texts=None, matcher=None):
    """兜底关闭未知弹窗：点「返回」文字按钮，其次点右上角 X 圆钮。

    必须最后调用（所有专项处理器之后）——它没有弹窗身份校验，只认
    "主界面左栏可见 + 屏上有返回/X"。命中返回 True。
    """
    if texts is None:
        texts = ocr.scan(screen, DIALOG_SCAN_REGION)
    if any(k in t for t, *_ in texts for k in UNKNOWN_DENYLIST):
        return False
    if not _main_rail_visible(screen, texts, matcher):
        return False
    btn = [r for r in texts
           if r[0].strip() == "返回" and r[2] >= UNKNOWN_BACK_MIN_Y]
    if btn:
        _, cx, cy, _ = btn[0]
        log.info("未知弹窗兜底：点击 [返回] @ (%d, %d)", cx, cy)
        device.click(cx, cy)
        return True
    if matcher is not None and matcher.has_template("x_btn"):
        # ccoeff_floor=0.85：掩码 CCORR 在亮背景上虚高（实测误报 0.96+），
        # 靠未掩码 CCOEFF 二次验证区分——真 X ≥0.92，场景误报 ≤0.59
        hit = matcher.find(screen, "x_btn", region=UNKNOWN_X_REGION,
                           threshold=0.85, ccoeff_floor=0.85)
        if hit:
            cx, cy, score = hit
            log.info("未知弹窗兜底：点击 [X] @ (%d, %d) score=%.2f",
                     cx, cy, score)
            device.click(int(cx), int(cy))
            return True
    return False


# ---------------------------------------------------------------- 赛季等级提升弹窗
# 「赛季等级提升 灵光点+1 [前往]」驻留通知条（2026-10-21 新赛季出现，多张实机
# 截图证实会挂几分钟不消失）：悬浮在主界面右上部 MEMBER_LIST_REGION 内，
# 「前往」(371,274) 两个字被 _team_panel_markers 的"前往组队"包含匹配误判成
# solo 视图 → 队长端读队伍永远 0 人（run 5e0d6d 中午地鼠 5 号全跳过的根因之一，
# _like 已加短词守卫双保险）。这里主动点掉它：X 圆钮在弹窗左缘，实测标题
# (312,266) → X (225,271)，按 OCR 命中点相对偏移，绝不点「前往」。
SEASON_POPUP_KEYWORDS = ("赛季等级", "灵光点")
SEASON_X_OFFSET = (-87, 5)


def handle_season_popup(device, screen, texts=None):
    """关闭「赛季等级提升 灵光点+1」通知条：点左缘 X 圆钮，命中返回 True。"""
    if texts is None:
        texts = ocr.scan(screen, DIALOG_SCAN_REGION)
    anchor = [r for r in texts
              if any(k in r[0] for k in SEASON_POPUP_KEYWORDS)]
    if not anchor:
        return False
    _, cx, cy, _ = anchor[0]
    pos = (int(cx + SEASON_X_OFFSET[0]), int(cy + SEASON_X_OFFSET[1]))
    log.info("赛季等级提升弹窗：点击 [X] @ (%d, %d)", *pos)
    device.click(*pos)
    return True


# ---------------------------------------------------------------- 订单刷新确认弹窗
# 「当前存在孤品及以上订单，是否继续刷新？[取消|确认]」（2026-10-21 实测，
# debug/unknown/zongmen__dialog_option_loop__1792532843.png）：妖灵渡口订单
# 页的模态确认框，宗门/订单任务进行中弹出，挂在屏上会吞掉后续点击并诱发
# dialog_option_loop。点「取消」保住孤品订单（**绝不点确认**——确认会把孤品
# 及以上订单刷新掉）。按钮布局与「提示」弹窗一致：取消 (113,445)。
ORDER_REFRESH_KEYWORDS = ("孤品", "继续刷新")
ORDER_CANCEL_POS = (113, 445)


def handle_order_refresh_confirm(device, screen, texts=None):
    """处理订单刷新确认弹窗：点「取消」保留孤品订单，命中返回 True。"""
    if texts is None:
        texts = ocr.scan(screen, DIALOG_SCAN_REGION)
    if not any(k in t for t, *_ in texts for k in ORDER_REFRESH_KEYWORDS):
        return False
    btn = [r for r in texts if "取消" in r[0]]
    if btn:
        _, cx, cy, _ = btn[0]
        log.info("订单刷新确认弹窗：点击 [取消] @ (%d, %d)", cx, cy)
        device.click(cx, cy)
    else:
        log.info("订单刷新确认弹窗：点击 [取消] @ %s（按钮 OCR 未命中，固定坐标）",
                 ORDER_CANCEL_POS)
        device.click(*ORDER_CANCEL_POS)
    return True


# ---------------------------------------------------------------- 同袍节弹窗
# 「同袍节」活动介绍弹窗（2026-10-25 首次出现，张若昀立绘 + 正文"知己交心，
# 义结盟约，响伴同袍，共赴长安" + 三个按钮「领取同袍好礼」(202,428) /
# 「前往同袍信箱」(202,471) / 「我只是路过」(202,514)）。
# 危害不只是"挡主界面"：三个按钮**正好落在对话选项区**（cx≈202、cy 428~514），
# 宗门任务的选项扫描会把它当成剧情选项连点 → 4 个号的宗门任务当天全部
# dialog_option_loop / chain_stuck 失败。所以必须进通用清理。
# 处理策略：点「我只是路过」关掉；**不点「领取同袍好礼」**——那是活动页入口，
# 点进去又是一层菜单，会把当前任务流程直接拖走（奖励留给用户自己领）。
TONGPAO_CLOSE_TEXT = "我只是路过"
TONGPAO_CLOSE_POS = (202, 514)   # 「我只是路过」固定坐标（按钮 OCR 失效兜底）


def handle_tongpao_popup(device, screen, texts=None):
    """处理「同袍节」活动介绍弹窗，点「我只是路过」关闭，命中返回 True。

    身份判定要**两个关键词同时命中**：追踪面板里的「同袍赠礼」任务条目也含
    "同袍"，单看"同袍"会在主界面上误命中（那会儿点 (202,514) 等于乱点）。
    """
    if texts is None:
        texts = ocr.scan(screen, DIALOG_SCAN_REGION)
    if not any("同袍" in t for t, *_ in texts):
        return False
    btn = [r for r in texts if TONGPAO_CLOSE_TEXT in r[0]]
    if not btn:
        return False
    _, cx, cy, _ = btn[0]
    log.info("同袍节弹窗：点击 [我只是路过] @ (%d, %d) 关闭", cx, cy)
    device.click(cx, cy)
    return True


# ---------------------------------------------------------------- 家园「旅行吧喵喵」
# 家园里猫出门旅行带回礼物的模态弹窗（标题「旅行吧喵喵」@ (202,237)，
# 正文「喵喵在神木谷带回来的礼物，请收下」@ y≈434，金色按钮「赠送」@ (202,483)）。
# 它是**模态**：挂着时右缘「离开」、底下所有图标点击全被吞。
# 2026-10-31 run e5ee47 实测：3 号做跑商前被它挡在家园里——
# `settle_scene` 认得出"在家园"，但点「离开」23 次全部无效（全被弹窗吃掉），
# 开场复位硬耗 304s 判失败，随后 escape_scene_fail ×4，跑商 1200s 硬超时；
# AI 兜底三次（地图/任务/返回）也全是点空。
# 处理策略：点「赠送」把礼物收下（弹窗正常关闭，奖励照收）。
PET_TRAVEL_KEYWORDS = ("旅行吧喵喵", "带回来的礼物")
PET_TRAVEL_GIFT_TEXT = "赠送"
PET_TRAVEL_GIFT_POS = (202, 483)   # 「赠送」按钮中心（OCR 失效兜底）


def handle_pet_travel_gift(device, screen, texts=None):
    """处理家园「旅行吧喵喵」礼物弹窗：点「赠送」收下，命中返回 True。"""
    if texts is None:
        texts = ocr.scan(screen, DIALOG_SCAN_REGION)
    if not any(k in t for t, *_ in texts for k in PET_TRAVEL_KEYWORDS):
        return False
    btn = [r for r in texts if PET_TRAVEL_GIFT_TEXT in r[0]]
    if btn:
        _, cx, cy, _ = btn[0]
        log.info("家园「旅行吧喵喵」礼物弹窗：点击 [赠送] @ (%d, %d)", cx, cy)
        device.click(cx, cy)
    else:
        log.info("家园「旅行吧喵喵」礼物弹窗：点击 [赠送] @ %s（按钮 OCR 未命中，"
                 "固定坐标）", PET_TRAVEL_GIFT_POS)
        device.click(*PET_TRAVEL_GIFT_POS)
    return True


# "队长<角色名>·<等级>长时间无操作，您是否愿意成为队长？[不同意(16秒)|同意]"
# （2026-10-13 01:58 实测截图）：队长挂机等待（如地鼠轮在帮会领地等刷新）时
# 队员端会弹出，模态挡住一切点击。一律点"不同意"（用户规则：绝不接受转让，
# 也不能因这个弹窗卡住流程）。按钮带倒计时后缀，OCR 常读成"不同意(16秒)"
# 且与括号粘连，整词 find_text 会被拒 → 正文与按钮都用包含匹配。
CAPTAIN_TRANSFER_DECLINE_POS = (102, 435)   # 「不同意」固定坐标（按钮 OCR 失效兜底）


def handle_captain_transfer(device, screen, texts=None):
    """处理"队长长时间无操作"转让弹窗，点「不同意」，命中返回 True。"""
    if texts is None:
        texts = ocr.scan(screen, DIALOG_SCAN_REGION)
    if not any("愿意成为队长" in t for t, *_ in texts):
        return False
    # 只认左半屏的候选：正常"不同意"按钮在 x≈102（倒计时宽窄漂移 ±10px 内）；
    # 若 OCR 把两个按钮粘连成一行，行中心会落在 ~197（两按钮之间，点了无效），
    # 阈值 150 能把它拒掉，交给固定坐标兜底
    btn = [r for r in texts if "不同意" in r[0] and r[1] < 150]
    if btn:
        _, cx, cy, _ = btn[0]
        log.info("队长转让弹窗：点击 [不同意] @ (%d, %d)", cx, cy)
        device.click(cx, cy)
        return True
    # 按钮文字没读到/被粘连（倒计时数字、低置信度过滤）：
    # 按弹窗固定布局点"不同意"，绝不能点成"同意"
    log.warning("队长转让弹窗：未读到「不同意」按钮文本，按固定坐标 %s 点击",
                CAPTAIN_TRANSFER_DECLINE_POS)
    device.click(*CAPTAIN_TRANSFER_DECLINE_POS)
    return True

# ---------------------------------------------------------------- 灵珠吞噬弹窗
# 月光宝盒"领取"后弹出的灵珠吞噬全屏动画（2026-10-13 02:21 用户截图）：
# 灵兽立绘 + 气泡"今天灵珠已经吃饱啦，明天再来吧~" + 底部「关闭」按钮。
# 不是"点击空白处关闭"类型，close_reward_popup/settle_home 的点空白抓不到它，
# 挂机不点会一直挡着主界面。认"灵珠+吃饱"双关键词（主界面/其他页面也可能
# 出现"灵珠"字样，单关键词会误关正常界面），点「关闭」。
ORB_FULL_CLOSE_POS = (202, 535)   # 「关闭」固定坐标（按钮 OCR 失效兜底，截图标定）


def handle_orb_full(device, screen, texts=None):
    """处理"灵珠已经吃饱"展示弹窗，点「关闭」，命中返回 True。"""
    if texts is None:
        texts = ocr.scan(screen, DIALOG_SCAN_REGION)
    has_orb = any("灵珠" in t for t, *_ in texts)
    has_full = any("吃饱" in t for t, *_ in texts)
    if not (has_orb and has_full):
        return False
    btn = [r for r in texts if "关闭" in r[0]]
    if btn:
        _, cx, cy, _ = btn[0]
        log.info("灵珠吃饱展示弹窗：点击 [关闭] @ (%d, %d)", cx, cy)
        device.click(cx, cy)
        return True
    log.warning("灵珠吃饱展示弹窗：未读到「关闭」按钮文本，按固定坐标 %s 点击",
                ORB_FULL_CLOSE_POS)
    device.click(*ORB_FULL_CLOSE_POS)
    return True

# ---------------------------------------------------------- 家园布置/场景编辑
# 家园底部「布置」进入的家具摆设/场景编辑模式（2026-10-13 实机事故：AI 兜底
# 喂猫时误点「布置」进入后无法自愈，账号 5 从 07:01 卡到用户起床）。该模式下：
# - ESC 无效（AI 实测连按 3 次无效果）；
# - 右缘没有「离开」（那是普通家园的图标 @ (383,510)，布置模式点它无效）；
# - 唯一出口是右缘中下部的「退出」按钮（AI 实测 OCR @ (382,478)，相似度 0.99）；
# - 「退出」可能被中央聊天窗等浮层遮住 OCR 不到——右下「隐藏」按钮 @ (382,423)
#   点一下收起浮层即可露出（2026-10-13 用户实机验证）。
# 退出后回到普通家园场景，由 settle_scene 的家园分支继续点「离开」回主界面。
# 识别门槛（防误关正常界面）：顶部 HUD 有家园系字样**且**右缘扫到「退出」；
# 普通家园 HUD 相同但右缘是「离开」，据此排除。主界面两条件都不会命中。
DECOR_EXIT_REGION = (335, 400, 70, 160)   # 右缘「退出/离开」按钮扫描区
DECOR_HIDE_REGION = (350, 398, 60, 50)    # 右缘「隐藏」按钮（收起浮层用）
DECOR_HUD_REGION = (0, 0, 405, 60)        # 顶部 HUD 条（判家园/布置模式，见 _decor_hud_hit）


def _decor_hud_hit(screen, texts=None):
    """顶部 HUD 是否家园系界面（普通家园与布置模式都有）。

    「美观度」的「美」常被 OCR 误读成「关」（实测「总关观度：17858」），
    用「观度」子串兜住两种读法；主界面没有这些字样。
    texts 传入时直接用（批量 OCR 的结果），避免重复识别。"""
    if texts is None:
        texts = ocr.scan(screen, region=DECOR_HUD_REGION, min_score=0.5)
    return any("观度" in t or "家园" in t for t in (x[0] if isinstance(x, (tuple, list)) else x for x in texts))


def _decor_exit_btn(screen):
    """右缘扫描区找「退出」按钮，返回 (x, y) 或 None。

    min_score 放宽：按钮小字 OCR 分数波动大（实测 0.69~0.99），且常把
    图标误并进文本（「退出」读成「退出下」，ratio=0.8 仍可接受）。"""
    return ocr.find_text(screen, "退出", region=DECOR_EXIT_REGION,
                         min_score=0.4, min_similarity=0.75)


def _decor_exit_hit(screen):
    """当前是否处于布置/场景编辑模式：返回「退出」按钮坐标或 None。

    家园 HUD + 右缘「退出」双条件；普通家园（右缘「离开」）不算。"""
    if not _decor_hud_hit(screen):
        return None
    if ocr.find_text(screen, "离开", region=DECOR_EXIT_REGION,
                     min_score=0.4, min_similarity=0.8):
        return None
    return _decor_exit_btn(screen)


def handle_decor_exit(device, screen, texts=None):
    """退出家园「布置/场景编辑」模式，命中并处理返回 True。

    点右缘「退出」→ 若弹确认框优先点「不保存」（布置是误入的，不该保存
    AI 乱摆的家具），没有再点「确定」（避开「取消」）→ 复查「退出」按钮
    是否消失，最多 3 轮。全程 ESC 无效（实测），不浪费步数。
    「退出」被浮层遮住时先点右缘「隐藏」收起浮层再扫（实测有效）。
    返回 True=检测到布置模式并已动手（调用方下一帧重扫即可）；
    3 轮仍未退出也返回 True 并告警（调用方的外层超时会兜底上报）。
    """
    if not _decor_hud_hit(screen):
        return False
    if ocr.find_text(screen, "离开", region=DECOR_EXIT_REGION,
                     min_score=0.4, min_similarity=0.8):
        return False  # 普通家园，交给 settle_scene 的家园分支
    hit = _decor_exit_btn(screen)
    if not hit:
        # 「退出」被中央聊天窗等浮层遮挡：点「隐藏」收起后重扫
        hide = ocr.find_text(screen, "隐藏", region=DECOR_HIDE_REGION,
                             min_score=0.4, min_similarity=0.6)
        if not hide:
            return False
        log.info("布置模式「退出」被浮层遮挡，先点「隐藏」@ (%d, %d) 收起",
                 hide[0], hide[1])
        device.click(hide[0], hide[1])
        pace.wait(1.0, 1.5)
        hit = _decor_exit_btn(device.screenshot())
        if not hit:
            log.warning("点「隐藏」后仍未见「退出」，本轮放弃")
            return True
    log.warning("检测到家园布置/场景编辑模式，点「退出」@ (%d, %d)",
                hit[0], hit[1])
    for attempt in range(3):
        # ⚠️「退出」OCR 文字在门形图标**下方**（2026-10-13 实机实测：文字
        # 中心 (384,478)、图标中心 (372,463)）：点文字位置落在热区外，游戏
        # 毫无反应——正是 AI 卡死 1 小时的根因。必须上移到图标中心。
        device.click(hit[0] - 10, hit[1] - 15)
        pace.wait(1.2, 1.8)
        # 确认框（2026-10-13 实机：「尚有未保存的改动，是否撤回改变并退出？」，
        # 按钮=「取消/确定」，无「不保存」）：优先「不保存」（若有），其次
        # 「确定」=撤回 AI 乱摆的改动并退出（绝不点「取消」）。按钮文字
        # 精确匹配——确认框标题以"…"退出？」结尾但不含纯「确定」二字，
        # 包含匹配会点到标题上
        texts_now = [(t.replace(" ", ""), x, y) for t, x, y, _ in
                     ocr.scan(device.screenshot(), DIALOG_SCAN_REGION,
                              min_score=0.5)]
        save_btn = [r for r in texts_now if r[0] == "不保存"]
        ok_btn = [r for r in texts_now if r[0] == "确定"]
        target = save_btn or ok_btn
        if target:
            _, cx, cy = target[0]
            log.info("布置退出确认框：点击 [%s] @ (%d, %d)",
                     "不保存" if save_btn else "确定(撤回改动)", cx, cy)
            device.click(cx, cy)
            pace.wait(1.5, 2.2)
        hit = _decor_exit_hit(device.screenshot())
        if not hit:
            log.info("已退出布置模式")
            return True
        log.warning("点「退出」后仍在布置模式，重试 (%d/3)", attempt + 1)
    log.warning("连续 3 次退出布置模式失败，交给外层兜底")
    return True
