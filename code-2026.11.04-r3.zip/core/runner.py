# -*- coding: utf-8 -*-
"""任务执行引擎（core/runner.py，2026-10-25 从 gui.py 迁入）

worker 子进程内运行的一轮并行执行：preflight（启动/登录客户端）→ 窗口配对
→ teamup.begin → 每账号一个线程按清单跑任务 → 结束汇报。

本模块**零 Qt 依赖**，对"界面"的全部输出经 `emit(kind, **kw)` 回调：
- `emit("row", acc_id=…, state={...})`  行状态增量（total/done/current/failed，
  GUI 按 acc_id 找行合并重绘——不按行号，抗状态面板重建）；
- 日志不经 emit——worker 里挂一个 logging handler 直接走协议通道（worker.py），
  runner 内的 log.info/warning 照旧写；
- 结束由调用方（worker.py）在 run_session 返回后发 `finished` 事件。

run_payload（worker.py 从 stdin 命令原样传入）：
    {accounts:[dict], names:[任务名], names_map:{str(账号id):[任务名]}|None,
     preflight:bool, overrides:{任务名:{键:值}}, titles:{任务名:显示名},
     team:None|{captain,members,extra_names,mode}}

stop_event：threading.Event，worker 收到 stop 命令置位；任务链路与
teamup.wait_*(check_stop=…) 全部经它中断（协作式停止的唯一通道）。
"""
from __future__ import annotations

import logging
import random
import threading
import time

import yaml

from core import binding, locate, teamup
from core.device import Device
from core.logsetup import (account_tag, fmt_duration, session_end,
                           session_start, set_account)
from core.matcher import Matcher
from core.paths import ASSETS_DIR, CONFIG_PATH
from core.session_keepalive import keep_alive
from login import preflight_clients, relaunch_dead_client, relogin_kicked

log = logging.getLogger("gui")  # 与 GUI 同 logger 名：run.log 行文格式保持一致


def _load_config():
    with open(CONFIG_PATH, encoding="utf-8") as f:
        return yaml.safe_load(f)


def _task_entry(config, overrides, name):
    """任务执行参数：config.yaml 该任务条目的完整副本 + 本轮 overrides
    （一条龙/向导把组队方式写进 zudui.mode 等）。"""
    cfg = next((t for t in config.get("tasks", []) if t.get("name") == name), None)
    entry = dict(cfg) if cfg else {"name": name}
    entry.update((overrides or {}).get(name) or {})
    entry["enabled"] = True
    return entry


def run_session(params, emit, stop_event):
    """一轮并行执行（原 gui.TasksTab._tasks_worker）。

    params/emit/stop_event 语义见模块 docstring。全程不抛异常（兜底捕获），
    返回 None；结束事件由调用方发。
    """
    accounts = list(params.get("accounts") or [])
    names = list(params.get("names") or [])
    names_map = params.get("names_map")          # {str(acc_id): [任务名]}
    preflight = bool(params.get("preflight"))
    overrides = params.get("overrides") or {}
    # 按账号任务参数（2026-11-04，一条龙方案 task_params）：{str(acc_id): {任务:{键:值}}}，
    # 账号级条目优先于全局 overrides（逐键覆盖，dict 合并顺序实现）。
    overrides_map = params.get("overrides_map") or {}
    titles = params.get("titles") or {}
    team = params.get("team")

    # 运行期间阻止息屏/睡眠/屏保锁屏：锁屏下 dxcam/mss 全部失效，
    # dxcam 还会陷入无限恢复循环拖死全部账号线程（2026-10-15 事故）。
    keep_alive.start(reason="任务运行")
    session_start("worker", extra=f"账号 {len(accounts)} 个，任务 {len(names)} 个")
    try:
        config = _load_config()
        keyword = config.get("window_keyword") or Device.DEFAULT_KEYWORD
        matcher = Matcher(ASSETS_DIR, threshold=config.get("threshold", 0.85))
        login_ok = None
        if preflight:
            log.info("定时任务准备：检查客户端窗口，缺失则启动并登录...")
            for acc in accounts:
                emit("row", acc_id=acc["id"],
                     state={"current": "正在启动客户端并登录…"})
            try:
                # 就地补全 login 段的路径（config 里写 auto/留空时自动探测），
                # 再拷一份给 preflight——它会启动缺失的客户端，必须拿到真实 exe 路径
                login_cfg = dict(locate.apply_login_paths(config))
                login_cfg.setdefault("window_keyword", keyword)
                login_ok = set(preflight_clients(accounts, login_cfg, matcher,
                                                 stop_event=stop_event))
                log.info("定时任务准备完成：%d/%d 个账号已登录",
                         len(login_ok), len(accounts))
            except Exception:
                log.exception("定时任务登录准备异常，本轮按现有窗口继续")
                login_ok = None  # 准备失败不阻断：退回原有"窗口配对"行为
            for acc in accounts:
                emit("row", acc_id=acc["id"], state={"current": ""})
            if stop_event.is_set():
                return
        hwnds = Device.find_all(keyword)
        resolved = binding.resolve_hwnds(accounts, hwnds, keyword)
        from core.scheduler import Scheduler
        registry = Scheduler._load_tasks()
        # 地鼠轮（本轮任务含 dishu，打地鼠限时副本）：启用宽容规则——
        # 被顶号重登一次、队长被顶随机改选、邀不进队的队员放弃
        dishu_mode = ("dishu" in names) or bool(
            names_map and any("dishu" in v for v in names_map.values()))
        if dishu_mode:
            log.info("本轮含打地鼠：启用宽容规则（顶号重登一次/队长被顶随机改选/"
                     "邀不进队的队员放弃）")
        # 组队协调器：只把实际能跑到任务的账号（hwnd 解析成功、preflight
        # 登录成功）纳入参与集，否则组队任务会永远等一个不会到来的账号；
        # team 给了编制时 begin() 会把 expected 进一步收窄到"参与组队的
        # 账号"（不勾队员的账号只跑单人任务，不参与组队等待）。
        # 人数下限（用户规则 2026-10-12：必须组满**指定的**全员）：
        # 非地鼠轮 = 参与账号数 + 队外名单数（严格名单核对，见 zudui）；
        # 地鼠轮保持宽容（2 人即可）
        active = [acc for acc in accounts
                  if resolved[acc["id"]][0] is not None
                  and (login_ok is None or resolved[acc["id"]][0] in login_ok)]
        extra_names = (team or {}).get("extra_names") or []
        teamup.coordinator().begin(
            active, lenient=dishu_mode,
            min_members=2 if dishu_mode else len(active) + len(extra_names),
            extra_names=extra_names,
            team=team)
        threads = []
        for acc in accounts:
            hwnd, source = resolved[acc["id"]]
            if hwnd is None:
                # 句柄失效/没有窗口不直接放弃：找未被其它账号认领的游戏窗口
                # （含最小化的），还原后走重登状态机（用户规则：不能一个任务
                # 都不跑；重登最多 3 次，仍失败才跳过本轮）
                # 同上：重登可能重启客户端，路径按需自动补全
                login_cfg = dict(locate.apply_login_paths(config))
                login_cfg.setdefault("window_keyword", keyword)
                free = [h for h in hwnds
                        if h not in {x for x, _ in resolved.values() if x}]
                if free:
                    log.warning("账号 %s（%s）%s，尝试窗口恢复（候选 hwnd=%s）",
                                acc["account"], acc["character"],
                                "绑定句柄已失效" if source == "dead" else "没有对应的游戏窗口",
                                free[0])
                    emit("row", acc_id=acc["id"],
                         state={"current": "恢复窗口，重新登录…"})
                    new_hwnd = relogin_kicked(acc, login_cfg, matcher,
                                              hwnd=free[0],
                                              stop_event=stop_event)
                    if new_hwnd:
                        hwnd = new_hwnd
                        resolved[acc["id"]] = (hwnd, "recovered")
                        if login_ok is not None:
                            login_ok.add(hwnd)
                    else:
                        log.warning("账号 %s（%s）窗口恢复失败，本轮跳过",
                                    acc["account"], acc["character"])
                else:
                    log.warning("账号 %s（%s）%s，且没有空闲窗口可恢复，本轮跳过",
                                acc["account"], acc["character"],
                                "绑定句柄已失效" if source == "dead" else "没有对应的游戏窗口")
            if hwnd is None:
                emit("row", acc_id=acc["id"], state={
                    "current": "句柄失效" if source == "dead" else "无窗口",
                    "done": None})  # done=None 约定：GUI 置 done=total
                continue
            if login_ok is not None and hwnd not in login_ok:
                log.warning("账号 %s（%s）登录失败，本轮任务跳过",
                            acc["account"], acc["character"])
                emit("row", acc_id=acc["id"],
                     state={"current": "登录失败", "done": None})
                continue
            t = threading.Thread(
                target=_account_worker,
                args=(acc, hwnd, names, config, registry, keyword, matcher,
                      names_map,
                      {**overrides, **overrides_map.get(str(acc["id"]), {})},
                      titles, emit, stop_event),
                daemon=True)
            t.start()
            threads.append(t)
        for t in threads:
            t.join()
        if stop_event.is_set():
            log.info("全部账号已停止")
    except Exception:
        log.exception("任务流程异常")
    finally:
        session_end("worker")
        keep_alive.stop()


def _account_worker(acc, hwnd, names, config, registry, keyword, matcher,
                    names_map, overrides, titles, emit, stop_event,
                    relogin_limit=3):
    """单账号线程（原 gui.TasksTab._account_worker）：在自己的窗口上按顺序
    跑勾选的任务。names_map（定时小任务/开始任务向导/一条龙）优先。

    被顶号/断网（AccountKicked）时调用 login.relogin_kicked 重登——
    每轮每号最多 relogin_limit 次（用户规则：重登 3 次仍被顶就放弃），
    成功则重跑被中断的任务继续本轮；重登额度用尽才中止该号剩余任务并
    从组队协调器减员。
    """
    from tasks.base import AccountKicked, TaskSkipped, TaskStopped
    from core.scheduler import (drop_unavailable_names, expand_followups,
                                order_closing_tasks)
    acc_id = acc["id"]
    d = config["delay"]
    if names_map is not None:
        # JSON 键是字符串：names_map 的键统一按 str 取
        names = list(names_map.get(str(acc_id), []))
    # FOLLOWUPS 跟随任务展开进序列（如活跃奖励领完固定接整理背包）
    names = expand_followups(names, registry)
    # 收尾任务（整理背包/做烹饪/战令周礼）统一挪到全序列最后：单人与组队
    # 任务全部跑完后再执行（用户规则 2026-10-14）
    names = order_closing_tasks(names, registry)
    # 流程未定稿的任务（available=False，如「灵珠收集」）不执行：GUI 任务页
    # 已置灰不可勾，这里再兜一层（定时任务/一条龙方案里可能残留旧数据）。
    names, blocked = drop_unavailable_names(names, registry)
    if blocked:
        log.warning("以下任务流程未定稿（暂不可选），本次跳过：%s", "、".join(blocked))
    emit("row", acc_id=acc_id, state={"total": len(names)})
    tag = account_tag(acc, hwnd)
    set_account(tag)  # 本线程后续所有日志自动带该账号标签
    log.info("########## 账号 %s | %s | %s%s (hwnd=%s) ##########",
             acc["account"], acc["character"], acc.get("role", ""),
             " | 队长" if acc.get("is_captain") else "", hwnd)
    log.info("账号 %s 本轮任务 %d 个：%s", tag, len(names),
             " → ".join(names) if names else "（无）")
    device = Device(keyword=keyword,
                    background_click=config.get("background_click", False),
                    click_delay=(d["click_min"], d["click_max"]), hwnd=hwnd)
    device.activate()
    started = time.time()
    ok_count = 0
    failed = []
    stop_reason = "全部完成"
    relogin_count = 0   # 本轮已用掉的重登次数（用户规则：最多 3 次）
    opened = False      # 开场复位（回主界面 + 退队）本轮只做一次
    i = 0
    task = None         # 当前任务实例（供整窗失灵探针使用）
    # ---- 整窗失灵看门狗（2026-10-29：沙盒客户端"跑着跑着不收点击"）----
    # 故障形态：渲染正常、IsHungAppWindow=0、点击落点守卫全过，但客户端不响应
    # 任何点击 → 每个任务都死在"等某个面板/模板出现"上，一路把整轮耗完
    # （当天 05:30 轮：6/7 号两个沙盒客户端各 16/18 项全灭，还把 5 个号的
    # 组队任务连坐成 15 例失败）。这类客户端换个新的就好，所以这里在**运行中**
    # 补一道闸：连续多个任务都是同一个死法 → 关窗换新客户端重登继续跑。
    # 登录期的同类检测见 core/login_flow.py 的 ui_broken（那道只覆盖登录瞬间）。
    # 判据在 core/clientwatch.py（可纯桩测），这里只负责"判定为真之后的动作"。
    from core.clientwatch import InputDeadWatch
    _lc = config.get("login") or {}
    dead_watch = bool(_lc.get("input_dead_watchdog", True))
    try:
        watch = InputDeadWatch(
            consecutive=_lc.get("input_dead_consecutive", 3),
            misses=_lc.get("input_dead_misses", 1),
            max_relaunch=_lc.get("input_dead_relaunch", 2),
            enabled=dead_watch, character=acc["character"])
    except Exception:
        # ⚠️ 2026-10-30 事故：这里一旦抛异常，是在账号线程的**最开头**抛的，
        # 线程当场静默死掉（异常不进 run.log），现场表现就是"5 个号登录成功、
        # 打印完任务清单后整轮 4 分钟就结束、一个任务都没跑"。看门狗是辅助
        # 功能，绝不允许它的初始化失败拖垮整个账号 —— 出错就退回不检测。
        log.exception("整窗失灵看门狗初始化失败，本号不做该检测（任务照常跑）")
        watch = InputDeadWatch(enabled=False, character=acc["character"])

    def _maybe_relaunch_dead_client(name):
        """看门狗入口（带兜底）：自身出任何问题都不许影响任务流程。"""
        try:
            return _relaunch_dead_client(name)
        except Exception:
            log.exception("整窗失灵看门狗处理异常（忽略，按普通失败继续）")
            return False

    def _relaunch_dead_client(name):
        """判定该窗口整窗失灵就关窗换新客户端。

        返回 True = 已换新并重登成功，调用方 continue 重跑当前任务（不推进
        索引、不计失败）；False = 没到阈值 / 探针证明还活着 / 换新失败，调用
        方按普通失败处理。
        """
        nonlocal device, hwnd, tag
        if not watch.judge(device, task=task):
            return False
        nth = watch.begin_relaunch()
        emit("row", acc_id=acc_id, state={"current": "客户端失灵，换新重登…"})
        log.warning("账号 %s 判定整窗失灵，开始换新客户端（第 %d/%d 次）",
                    acc["character"], nth, watch.max_relaunch)
        teamup.coordinator().mark_task(acc_id, None)
        # 换新可能要重启客户端，走同一套路径补全（config 里是 auto 也能用）
        login_cfg = dict(locate.apply_login_paths(config))
        login_cfg.setdefault("window_keyword", keyword)
        try:
            new_hwnd = relaunch_dead_client(acc, login_cfg, matcher,
                                            stop_event=stop_event)
        except Exception:
            log.exception("账号 %s 换新客户端异常", acc["character"])
            new_hwnd = None
        if not new_hwnd:
            watch.note_relaunch_fail()
            log.error("账号 %s 换新客户端失败，后续任务按普通失败继续",
                      acc["character"])
            emit("row", acc_id=acc_id, state={"current": ""})
            return False
        hwnd = new_hwnd
        acc["hwnd"] = hwnd          # 回填：让本轮后续解析不再拿旧句柄
        device = Device(keyword=keyword,
                        background_click=config.get("background_click", False),
                        click_delay=(d["click_min"], d["click_max"]), hwnd=hwnd)
        device.activate()
        teamup.coordinator().rejoin(acc)
        tag = account_tag(acc, hwnd)
        set_account(tag)
        watch.note_relaunch_ok()
        log.info("账号 %s 已换新客户端（hwnd=%s），重跑被中断的任务: %s",
                 tag, hwnd, name)
        return True

    while i < len(names):
        name = names[i]
        if stop_event.is_set():
            stop_reason = "收到停止请求"
            break
        emit("row", acc_id=acc_id, state={"current": titles.get(name, name)})
        log.info("=== 开始任务: %s ===", name)
        task_t0 = time.time()
        # 实时汇报"本号正在跑哪项任务"给组队协调器：队长端据此判断没到达
        # 组队任务的号是"真卡在任务里"（继续等）还是"空闲"（马上就到，
        # 可直接开组）——用户规则 2026-10-14：一个号卡死不能拖住全队。
        teamup.coordinator().mark_task(acc_id, name)
        try:
            task = registry[name](device, matcher,
                                  _task_entry(config, overrides, name),
                                  account=acc)
            task.stop_event = stop_event
            task.dismiss_popups()
            if not opened:
                # 登录后的第一步：退出残留队伍（队员状态下切不了地图，
                # 见 tasks/base.py::opening_reset）。只做一次，顶号重登后
                # 不重做——那时队伍可能是本轮队长刚组好的，退了反而坏事。
                opened = True
                log.info("=== 开场复位：先退出残留队伍，再开始本轮任务 ===")
                task.opening_reset()
            task.run()
            ok_count += 1
            watch.note_ok(device)   # 成功=窗口还能用，清掉这轮的输入失灵计数
            log.info("=== 任务完成: %s (%.1fs) ===", name, time.time() - task_t0)
        except AccountKicked:
            if relogin_count < relogin_limit:
                # 被顶号/断网：重登（最多 relogin_limit 次），成功则重跑被中断的任务
                relogin_count += 1
                log.warning("=== 账号 %s 被顶号/断网（第 %d/%d 次重登）: %s ===",
                            acc["character"], relogin_count, relogin_limit, name)
                emit("row", acc_id=acc_id, state={"current": "被顶号，重新登录…"})
                # 重登可能要重启客户端，走同一套路径补全（config 里是 auto 也能用）
                login_cfg = dict(locate.apply_login_paths(config))
                login_cfg.setdefault("window_keyword", keyword)
                new_hwnd = relogin_kicked(acc, login_cfg, matcher,
                                          stop_event=stop_event)
                if new_hwnd:
                    hwnd = new_hwnd
                    device = Device(keyword=keyword,
                                    background_click=config.get("background_click", False),
                                    click_delay=(d["click_min"], d["click_max"]),
                                    hwnd=hwnd)
                    device.activate()
                    teamup.coordinator().rejoin(acc)
                    tag = account_tag(acc, hwnd)
                    set_account(tag)
                    log.info("账号 %s 重登成功，重跑被中断的任务: %s",
                             acc["character"], name)
                    continue  # 不推进索引：重跑当前任务
                log.error("账号 %s 第 %d 次重登失败，按被顶号处理",
                          acc["character"], relogin_count)
            else:
                log.warning("账号 %s 已重登 %d 次仍被顶，按有人看管处理，不再重登",
                            acc["character"], relogin_count)
            log.warning("=== 账号 %s 被顶号（被迫下线），剩余任务跳过: %s ===",
                        acc["character"], name)
            emit("row", acc_id=acc_id,
                 state={"current": "被顶号", "done": None})
            # 从组队协调器减员：其余账号照常组队（队长被顶号则组队判负；
            # 地鼠轮 lenient 时改为随机改选新队长）
            teamup.coordinator().drop(acc_id)
            stop_reason = "被顶号下线"
            break
        except TaskSkipped as e:
            if _maybe_relaunch_dead_client(name):
                continue   # 已换新客户端：重跑当前任务，不计失败
            # 主动跳过但计入失败（如组队失败后副本未执行）：不重试、
            # 不留失败截图，继续下一个任务——小结里如实反映"没跑成"
            log.warning("=== 任务跳过（计入失败）: %s (%.1fs) —— %s ===",
                        name, time.time() - task_t0, e)
            emit("row", acc_id=acc_id, state={"failed_add": name})
            failed.append(name)
        except TaskStopped:
            log.info("=== 任务已停止: %s ===", name)
            emit("row", acc_id=acc_id, state={"current": "已停止", "done_add": 1})
            stop_reason = "用户停止"
            break
        except Exception:
            if _maybe_relaunch_dead_client(name):
                continue   # 已换新客户端：重跑当前任务，不计失败
            log.exception("=== 任务异常: %s (%.1fs) ===", name, time.time() - task_t0)
            emit("row", acc_id=acc_id, state={"failed_add": name})
            failed.append(name)
        emit("row", acc_id=acc_id, state={"done_add": 1, "current": ""})
        i += 1
        teamup.coordinator().mark_task(acc_id, None)  # 任务间隙=空闲
        if not stop_event.is_set():
            time.sleep(random.uniform(d["between_tasks_min"], d["between_tasks_max"]))
    # 本轮小结：一眼看清该账号成功/失败/耗时/中止原因（便于按账号排查）
    if failed:
        log.warning("---- 账号小结 %s：成功 %d/%d，失败 %d 个 %s，用时 %s，"
                    "结束原因：%s ----", tag, ok_count, len(names), len(failed),
                    failed, fmt_duration(time.time() - started), stop_reason)
    else:
        log.info("---- 账号小结 %s：成功 %d/%d，失败 0，用时 %s，结束原因：%s ----",
                 tag, ok_count, len(names), fmt_duration(time.time() - started),
                 stop_reason)


def rerun_task(params, emit, stop_event):
    """单独重跑某账号的某个失败任务（原 gui.TasksTab._rerun_worker）。

    params = {acc: dict, name: 任务名, titles: {...}}。不抛异常。
    """
    acc = params["acc"]
    name = params["name"]
    titles = params.get("titles") or {}
    acc_id = acc["id"]
    try:
        config = _load_config()
        keyword = config.get("window_keyword") or Device.DEFAULT_KEYWORD
        hwnd, source = binding.resolve_hwnds(
            [acc], Device.find_all(keyword), keyword)[acc_id]
        if hwnd is None:
            log.error("重跑失败：账号 %s 无可用客户端（%s）", acc["character"], source)
            return
        set_account(account_tag(acc, hwnd))  # 重跑日志也带账号标签
        from core.scheduler import Scheduler
        registry = Scheduler._load_tasks()
        emit("row", acc_id=acc_id,
             state={"current": f"重跑: {titles.get(name, name)}"})
        d = config["delay"]
        device = Device(keyword=keyword,
                        background_click=config.get("background_click", False),
                        click_delay=(d["click_min"], d["click_max"]), hwnd=hwnd)
        device.activate()
        log.info("=== 重跑任务: %s ===", name)
        task = registry[name](device,
                              Matcher(ASSETS_DIR,
                                      threshold=config.get("threshold", 0.85)),
                              _task_entry(config, params.get("overrides"), name),
                              account=acc)
        task.stop_event = stop_event
        task.dismiss_popups()
        task.run()
        emit("row", acc_id=acc_id, state={"failed_remove": name})
        log.info("重跑完成: %s | %s", acc["character"], name)
    except Exception:
        log.exception("重跑异常: %s | %s", acc["character"], name)
    finally:
        emit("row", acc_id=acc_id, state={"current": ""})
        emit("rerun_done", acc_id=acc_id)
