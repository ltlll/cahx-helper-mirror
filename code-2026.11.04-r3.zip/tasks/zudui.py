import logging
import random
import re
import time
from difflib import SequenceMatcher

from core import ocr, pace, teamup
from tasks.base import (BANGHUI_REGION, MEMBER_LIST_REGION,
                        TEAM_MEMBER_ROWS_REGION,
                        TEAM_PANEL_MARK_REGION, TEAM_TAB_POS, TEAM_TAB_REGION,
                        Task)

log = logging.getLogger("task.zudui")

# 以下均为 405x720 客户区坐标（按 421x759 窗口截图换算：客户区 = 窗口坐标 - (8, 31)）
BIANDUI_TAB_REGION = (110, 160, 110, 45)    # 帮会面板"编队"页签（旁边是 成员/新闻）
NEWS_TAB_REGION = (190, 170, 90, 45)        # 帮会面板"新闻"页签（帮会面板打开的判定；编队页没有"回帮"不能拿它判定）
YIJIAN_REGION = (20, 555, 170, 80)          # 编队页左下"一键组队"文字区（坐标化后不再依赖，留作 OCR 排查/校验）
BIANDUI_TAB_POS = (140, 192)             # 帮会面板"编队"页签固定槽位（实测两次点击都命中 (140,192)）
BANGHUI_POS = (30, 551)                     # 主界面左下角"帮会"图标固定中心（实测稳定；模板漏检时盲点）
CONFIRM_BTN_POS = (297, 446)                # "是否给其他所有队员发出组队邀请"弹窗的"确定"固定点（实测命中 (297,446)）
CONFIRM_POPUP_REGION = (60, 320, 290, 130)  # 该确认弹窗整体（用于在"确定"二字漏读时确认弹窗确实在）
YIJIAN_BTN_POS = (93, 613)                  # "一键组队"按钮兜底固定点（2026-10-13 失败截图实测：OCR 整批漏读按钮
                                            # 文字、只读到区域右缘'官职'图标的'职位'，按钮明明在画面上——5 开并发时
                                            # OCR 经常这样，确认在编队页后直接盲点，不再依赖 OCR）
VIEW_TEAM_REGION = (235, 590, 145, 45)      # 编队页右下"查看编队"按钮（备用锚点，中心实测 (310,613)）
CONFIRM_REGION = (235, 395, 120, 60)        # "是否给其他所有队员发出组队邀请"弹窗的"确定"
ACCEPT_REGION = (235, 380, 120, 60)         # "组队邀请"弹窗的"接受"（左侧"拒绝"不在区域内）
ACCEPT_BTN_POS = (296, 430)                 # "接受"按钮兜底固定点（2026-10-13 12:01 实测 dismiss_popups 盲点命中）
TEAM_ICON_REGION = (60, 420, 300, 120)     # 画面中部"组队"浮标小图标（文字实测 @ (230,512)，旧区域下边缘 510 差 2px 漏掉；高度固定，x 会漂）

# ---- 手动组队（mode: manual，队长经好友面板逐个搜索邀请）----
# 以下均为 405x720 客户区坐标，来源：用户截图经项目 OCR 实测换算（cx=x-1, cy=y-31），
# 并经 2026-10-10 真机验证逐步修正（创建队伍/取消/队伍页签/离队等已实机命中）
FRIEND_ICON_REGION = (0, 608, 55, 42)       # 主界面左下角"好友"图标文字 @ (25,628)（OCR 常读成"好发"，须放宽相似度；右侧 (76,628) 是"协助"）
FRIEND_ICON_POS = (25, 628)                 # 好友图标兜底坐标（OCR 不中时盲点）
MSG_TAB_REGION = (5, 155, 55, 45)           # 关系面板左侧栏"消息"页签 @ (34,175)（面板打开判定）
FRIEND_TAB_REGION = (5, 202, 55, 45)        # 关系面板左侧栏"好友"页签 @ (34,223)
FIND_FRIEND_REGION = (90, 165, 150, 40)     # 好友页顶部"找好友"条目 @ (165,184)
SEARCH_TITLE_REGION = (70, 165, 180, 40)    # "搜索好友"面板标题 @ (179,185)（已到搜索面板的判定）
INPUT_CLICK_POS = (200, 206)                # 搜索输入框（框内文字 @ (190,207)，点击聚焦；清空靠退格键）
SEARCH_BTN_REGION = (320, 190, 80, 35)      # "搜索"按钮 @ (357,207)
SEARCH_BTN_POS = (357, 207)                 # 搜索按钮兜底坐标（OCR 不中时盲点）
RESULT_REGION = (30, 262, 345, 70)          # 搜索结果首行文字（名字 y≈289，第二行 y≈368，勿越界）
FRIEND_AVATAR_POS = (116, 295)              # 首行头像中心（列位置固定，在名字左侧；OCR 核对名字后直接点这里）
FRIEND_NAME_REGION = (60, 115, 250, 40)     # 好友信息卡顶部名字 @ (168,135)
INVITE_BTN_REGION = (240, 560, 85, 42)      # 好友信息卡右下"邀请" @ (279,581)（左侧"聊天" @ (140,581) 不进区域）
TIP_CANCEL_REGION = (48, 478, 110, 45)      # 创建队伍后"提示"弹窗（是否前往设置目标）的"取消" @ (109,500)（右侧"前往"不进区域）
TEAM_PANEL_BLANK_POS = (200, 55)            # 队伍面板上缘之外的空白（点它关面板回主界面，已实机验证）

MAX_ROUNDS = 5          # 组队最多邀请轮数（每轮间隔 INVITE_WAIT 秒，仍不足判失败）
INVITE_WAIT = 60        # 每轮邀请后的等待时长（用户规则：隔 60 秒补邀一轮）
ACCEPT_WAIT = 50        # 队员端每轮等邀请弹窗的时长；等不到按"已加入队伍"处理
                        # （2026-10-16：35s 太短——队长逐个搜索邀请 3 人要 60~80 秒，
                        #  队员窗口必须覆盖到"最后一个邀请送达"之后。配合
                        #  _captain_manual 把 start_round 挪到邀请发完之后。）
MEMBER_GIVEUP = 1800    # 队员端等组队结果的最长时长（5 轮补邀可长达 10+ 分钟）
SENSE_WAIT = 25         # 队长发邀请后静默等"队员全部感知邀请"的上限（秒）。
                        # 用户规则 2026-10-13：这期间队长不截图/不判人数，资源全给
                        # 队员端点接受；全部打卡或超时后队长才接管判是否组齐。
                        # （队员端不再做周期性队伍自检——退队判定一次成功即静默，
                        # 见 _member_flow；MEMBER_CHECK_INTERVAL/RELEAVE_INTERVAL
                        # 与 _member_team_check 已随该规则删除）

INVITE_NAME_TTL = 120   # 单个队友超过 2 分钟未同意先放弃（用户规则）
NAME_SIM_FLOOR = 0.6    # 搜索结果名字相似度兜底线（OCR 生僻字误读）
CREATE_COOLDOWN = 60    # 离队后组队冷却（"创建队伍"按钮灰色期），实测 20s 仍灰

# 队员列表区里不算成员行的文本（面板按钮/页签/占位符）
_MEMBER_ROW_MARKERS = ("招募", "创建队伍", "前往组队", "离队", "申请", "加入",
                       "队伍", "任务", "附近")


def _member_row_like(text):
    """队员列表区的一行 OCR 文本是否像"成员行"（用于数人头）。

    成员可能是别人登录的号（不在工具账号库里），所以人数只能数行。排除
    按钮文字/纯数字（等级 109、-109级 之类）；名字行至少 2 个非数字字符。
    """
    t = (text or "").strip()
    if len(t) < 2:
        return False
    if any(m in t for m in _MEMBER_ROW_MARKERS):
        return False
    return len(re.sub(r"[0-9\-+.%\s级人]", "", t)) >= 2


def _name_in_texts(name, texts):
    """已知角色名是否出现在 OCR 文本里（包含匹配 + 相似度兜底；队员列表里
    只有队内成员，名字两两差异大，不会互相误中）。"""
    for t in texts:
        if len(t) >= 2 and (name in t or t in name
                            or SequenceMatcher(None, t, name).ratio() >= 0.65):
            return True
    return False


class Zudui(Task):
    """5开组队：由队长发起组队邀请（一键组队或好友逐个邀请），队员端等弹窗
    点"接受"，最后按**队伍面板识别到的人数**判定是否成队。

    人数规则（用户 2026-10-11 确认）：
    - 只指定队长，不逐个核对名单——成员可能是别人登录的号（不在工具的账号
      库里），所以成功判据 = 队伍人数 ≥ coord.min_members（组队任务 3 人 /
      含打地鼠 2 人，由协调器 begin() 传入）；
    - 邀请节奏 = 每轮发出邀请后等 INVITE_WAIT 秒（期间每 5 秒识别一次队伍
      人数，达标即止），不足就补邀，最多 MAX_ROUNDS 轮；单个队友超过
      INVITE_NAME_TTL（2 分钟）仍未同意先放弃；
    - 轮数用完仍不足下限 → 组队判负（team_success=False），本轮后续的
      日常副本任务全部跳过，单人任务照常跑完。轮数用完但**指定成员命中数
      已达下限** → 移出缺席者判成功（2026-10-26 兜底，见 _captain_manual 末尾）。

    两种组队方式（config.yaml 该任务条目的 mode，开始任务向导/一条龙方案
    会覆盖），**两种都"先离队、再组队"**（用户规则 2026-10-11：只要执行
    组队操作，一律先离队，由队长从零组队——绝不沿用残留队伍：人数判定只看
    队伍人数，残留在队里的旧成员会被误计成"组队成功"）：
    - auto（默认，一键组队）：全员先各自离队并确认单人状态（队长等全员确认
      离队后才发起邀请），队长在帮会编队页"一键组队"发出邀请，队员弹窗点
      "接受"（或点画面中部"组队"浮标再接受）；
    - manual（手动组队）：全员确认离队后，队长点"队伍→创建队伍"（提示弹窗
      点"取消"）建队，再经好友面板按名字逐个搜索→点头像→邀请。
      邀请名单 = 参与账号的角色名 + 手输的队外队员名（coord.extra_names）。

    组队结果写入 core/teamup 协调器（team_success），以后的日常副本任务
    据此决定是否执行。必须是任务列表的最后一个任务。
    前置条件不满足（队长不在参与账号里 / 未指定队长 / 命令行模式）直接跳过，
    不算失败。账号被顶号时由 GUI worker 调 teamup.drop() 减员，其余账号照常组队。
    """

    name = "zudui"
    title = "5开组队"
    category = "日常副本"

    # ---- 耗时打点（用户规则 2026-10-13：必须能量出各阶段耗时才能定优化项）----

    def _tick(self, tag):
        """记录一条时间线打点并打日志：`[耗时] 阶段：累计 Ns（本步 Ms）`。

        起点 = 本号到达组队任务（_try_once 里第一次打点）。日志里的账号标签
        （如 [5:早起只为干饭★]）已经把每号分开，日后再按需加减打点即可。
        """
        now = time.time()
        t0 = getattr(self, "_t_t0", None)
        if t0 is None:
            self._t_t0 = t0 = now
        last = getattr(self, "_t_last", t0)
        self._t_last = now
        total = now - t0
        log.info("[耗时] %s：累计 %.1fs（本步 %.1fs）", tag, total, now - last)
        return total

    def _try_once(self):
        coord = teamup.coordinator()
        me = self.account
        if not me or not coord.begun:
            log.info("非 GUI 5 开并行模式（协调器未初始化），跳过组队")
            return True
        if coord.result is not None:
            # 结果已定（本任务是短路的重试尝试，或队长被顶号提前判负）：
            # 直接返回不重复操作；队员端永不判失败
            return coord.result if me["id"] == coord.captain_id else True
        coord.arrive(me["id"])
        self._tick("到达组队任务")
        if not coord.wait_all_ready(self._check_stop):
            log.info("等待全员完成超时（参与账号未全部到达组队任务），跳过")
            return True
        self._tick("全员到齐")
        if not coord.expected:
            log.info("参与账号为空（可能有账号被顶号减员），跳过组队")
            return True
        if coord.captain_id is None:
            log.info("未指定队长，跳过组队")
            return True
        mode = str(self.config.get("mode") or "auto").strip().lower()
        coord.set_team_mode(mode)  # dishu 在帮会领地等待期间按同样方式补邀
        if me["id"] == coord.captain_id:
            log.info("本号是队长（组队方式 %s，人数下限 %d，邀请名单 %s）",
                     mode, coord.min_members, coord.known_names)
            if mode == "manual":
                return self._captain_manual(coord)
            return self._captain_flow(coord)
        if mode == "manual":
            return self._member_manual(coord)
        return self._member_flow(coord)

    # ---- 队长端 ----

    def _ensure_clean_team(self, coord, tag):
        """组队硬前置（队长端，用户规则 2026-10-11/12）：**只要发起组队，一律先
        离队**，由队长从零组队，绝不沿用残留队伍。

        残留队伍有两个坑：① 旧队伍里可能有不在本轮名单里的人（上一轮/上一天
        留下的），人数判定只看队伍人数 → 会被误判成"组队成功"；② 仍挂在旧
        队伍里的队员收不到新的邀请弹窗。所以队长先退自己的队（多次尝试确认
        单人），再等全部队员确认离队；等不到的队员移出本轮（向在队里的号发
        邀请纯属浪费整轮）。

        用户规则 2026-10-12 加强：
        - 先 begin_leave_round() 作废旧的离队确认——一键组队解散转手动时队员
          仍挂在旧队里，不重新离队的话邀请根本发不进（实测）；
        - 队长自己也可能在战斗/家园/副本里：先 settle_scene 全场景复位（战斗
          等打完，不计超时）再退队；队员在复位中时 wait_all_left 不计超时。

        返回 False = 队长已不在参与集里（被顶号减员），组队无法继续。
        """
        log.info("%s：先离队，从干净的单人状态开始组队（用户规则）", tag)
        coord.begin_leave_round()
        me_id = self.account["id"]
        coord.mark_settling(me_id, True)
        try:
            self.settle_scene(tag=f"{tag}-场景复位")
        finally:
            coord.mark_settling(me_id, False)
        solo = False
        for attempt in range(1, 4):
            self._check_stop()
            if self.leave_team():
                solo = True
                break
            log.warning("%s：退出当前队伍未确认（%d/3），重试", tag, attempt)
            pace.wait(4)
        if not solo:
            log.warning("%s：多次尝试仍未确认单人状态，按流程继续组队"
                        "（人数判定兜底）", tag)
        log.info("%s：等待全部队员确认离队后再发邀请...", tag)
        pending = coord.wait_all_left(150, self._check_stop)
        if pending:
            coord.drop_unconfirmed_left()
        if not coord.expected:
            log.warning("队长已不在参与账号里，组队无法进行")
            return False
        # 用户规则 2026-10-14：离队确认全部到齐（内存里全部离队）后，再静等 5 秒
        # 才发起下一轮组队——游戏侧"离队→创建队伍"有冷却（实测 20s 内按钮灰），
        # 全员同时离队后立刻组队容易撞冷却，统一留 5 秒缓冲。
        pace.wait(5)
        self._tick("离队确认完成（队长）")
        return True

    def _leave_and_report(self, coord, tag):
        """组队硬前置（队员端，用户规则 2026-10-11/12：一律先离队）：退出残留
        队伍并确认单人状态后，向协调器上报"已离队"——队长等全员确认才发邀请
        （残留在旧队伍里的号收不到邀请弹窗）。确认不了就不上报（队长等待超时
        后把本号减员，比向仍在队伍里的号发邀请浪费整轮强）。返回是否已确认。

        用户规则 2026-10-12 加强：离队前先 settle_scene 全场景复位——可能在
        战斗（等打完，不计超时）/家园/副本/剧情对话里，这些状态下队伍面板根本
        点不开；复位期间向协调器标记 settling，队长的等待不计入超时。"""
        me_id = self.account["id"]
        log.info("%s：先离队，确认单人后等待队长邀请", tag)
        # 与当前离队轮次对齐（2026-10-13）：_left_epoch 默认 -1 时，队员等待
        # 循环里第一次 _check_releave 必定"检测到队长重新整队"→ 立刻再跑一整轮
        # 离队（含 settle_scene），实测白烧 20~30 秒；失败时更不能让轮次错位。
        self._left_epoch = coord.leave_epoch()
        coord.mark_settling(me_id, True)
        try:
            self.settle_scene(tag=f"{tag}-场景复位")
        finally:
            coord.mark_settling(me_id, False)
        for attempt in range(1, 4):
            self._check_stop()
            left = self.leave_team()
            # leave_team() 内部已用 _ensure_team_view() 判过单人并把结论发到
            # _leave_confirmed，这里**不再复查**：原代码拿到 True 后又跑一遍
            # _ensure_team_view()，等于同一件事做两遍——实测队员离队 37 秒里
            # 有 9.7 秒（12:56:24.7→12:56:34.5）耗在这次重复校验上，5 个号
            # 并发时队长的"等全员离队"跟着多等 10 秒起步。
            if left and getattr(self, "_leave_confirmed", False):
                # 记录确认时的离队轮次：之后队长若解散重整（begin_leave_round
                # 使轮次 +1），本号在等待循环里会发现轮次变化并重新离队
                self._left_epoch = coord.leave_epoch()
                coord.mark_team_left(me_id)
                # ⚠️必须回主界面：邀请弹窗只在主界面弹（2026-10-13 14:05 实机
                # 事故：6 号离队重试期间点进了「组队大厅」页，一直停在那，
                # 整轮收不到邀请→队长判缺席→解散重整，白烧 8 分钟）
                self.ensure_main_screen()
                self._tick("已确认离队并上报（队员）")
                return True
            # 走到这里 = 未确认（leave_team 命中了"异常画面/状态不明"的宽容分支，
            # 或离队本身失败）；概率很低，补一次完整校验再决定是否重试。
            if not left:
                log.warning("退出当前队伍失败（%d/3）", attempt)
            markers = self._ensure_team_view()
            if markers == "solo":
                self._restore_quest_view()
                self._left_epoch = coord.leave_epoch()
                coord.mark_team_left(me_id)
                self.ensure_main_screen()  # 同上：邀请弹窗只在主界面弹
                self._tick("已确认离队并上报（队员）")
                return True
            log.warning("离队未确认（队伍视图=%r），重试（%d/3）", markers, attempt)
            pace.wait(2, 3)  # 原 6 秒：离队是本地 UI 操作，2~3 秒足够生效
        self._restore_quest_view()
        log.error("多次尝试仍无法确认单人状态，不上报离队（队长将等待超时"
                  "并把本号减员，避免邀请发不进队伍）")
        return False

    def _check_releave(self, coord, tag):
        """等待邀请期间检查离队轮次：队长解散重整（begin_leave_round）后，
        本号仍挂在旧队伍里（队长离队队伍不散、自动继位），必须重新离队确认，
        否则新邀请发不进来（2026-10-12 实测：一键组队解散转手动后队员全员
        挂旧队，手动邀请全部落空）。轮次未变返回 False，重新离队返回 True。"""
        if coord.leave_epoch() == getattr(self, "_left_epoch", -1):
            return False
        log.info("%s：检测到队长重新整队（离队轮次已变），重新离队确认", tag)
        self._leave_and_report(coord, tag)
        return True

    def _captain_flow(self, coord):
        """一键组队（严格名单，用户规则 2026-10-12）：**必须组满指定的全员**。

        先全员离队 → 一键组队发邀请 → 等INVITE_WAIT 秒轮询名单 →
        - 指定名单全部进队 → 成功；
        - 到时仍有缺席（= 组成的不是指定的 5 人）→ **解散队伍改为手动组队**
          （_captain_manual 开头的 _ensure_clean_team 即解散：队长先离队、
          等全员确认离队，再建队逐个邀请指定名单）。
        """
        if not self._ensure_clean_team(coord, "一键组队（队长）"):
            coord.set_result(False)
            return False
        known = list(coord.known_names)
        self._check_stop()
        log.info("===== 一键组队（需指定 %d 人：%s）=====",
                 len(known), "、".join(known))
        # 邀请确认发出去才算数（2026-10-13 教训：_send_invite 返回 False=
        # 帮会面板/一键组队按钮没找到，邀请根本没发，旧逻辑不检查返回值，
        # 白等 60 秒判 0/5 又降级手动重来一遍，白烧 5 分钟）
        sent = False
        for attempt in range(1, 4):
            self._check_stop()
            sent = self._send_invite()
            if sent:
                break
            log.warning("一键组队邀请未发出（帮会面板/按钮未到位），重试 (%d/3)",
                        attempt)
            self.exit_panel_to_home()
            pace.wait(1.0, 2.0)
        if not sent:
            # "没读到确认弹窗"也可能是**队伍已经满员**（满员时不再弹邀请框）：
            # 放弃前先看一眼队伍人数，真齐了就当一键组队其实成功了，不再白走
            # 一遍手动组队（手动建队+逐个邀请要 2 分钟起步）。
            cnt, miss, _extras = self._team_status(coord)
            if not miss:
                log.info("一键组队虽没读到邀请确认弹窗，但已知名单已全齐（%d 人），"
                         "按组队成功处理", cnt)
                coord.set_result(True)
                self.exit_panel_to_home()
                return True
            log.warning("一键组队 3 次都未能把邀请发出去，转手动组队")
            return self._captain_manual(coord)
        self._tick("一键组队邀请已发出（队长）")
        self.exit_panel_to_home()
        # 用户要求：发起组队回主界面后留一段延迟，等队员接受
        pace.wait(5, 8)
        coord.start_round()
        # 静默等队员感知邀请（用户规则 2026-10-13）：邀请播报后队长不再每 5 秒
        # 截图数人头，而是静默等 4 名队员主动打卡"已感知邀请"，全部到位后再独占
        # 资源判是否组齐（这一步只读内存状态，不占屏幕/OCR）。
        self._wait_members_sense(coord, known)
        count, missing, extras = self._wait_team_ready(coord)
        if missing and getattr(self, "_invite_likely_failed", False):
            log.warning("邀请疑似没发出去（队里只有自己），重发一次再等")
            if self._send_invite():
                self.exit_panel_to_home()
                pace.wait(0.5, 1.0)
                coord.start_round()
                count, missing, extras = self._wait_team_ready(coord)
        if not missing:
            self._tick("名单全齐-组队成功（队长）")
            log.info("指定名单全部进队（%d 人），组队成功%s", count,
                     f"（名单外参考 {extras}，OCR 噪音不参与判定）"
                     if extras else "")
            coord.set_result(True)
            self.exit_panel_to_home()
            return True
        log.warning("一键组队名单未到齐：%d/%d（缺席: %s），解散队伍改为手动组队"
                    "（用户规则：组成的不是指定的 5 人）",
                    count, len(known), "、".join(missing) or "无")
        return self._captain_manual(coord)

    def _wait_members_sense(self, coord, targets):
        """队长静默等队员"感知到邀请"（用户规则 2026-10-13）。

        邀请播报（coord.start_round）之后，屏幕与 OCR 资源全给队员端点接受；
        队长这段时间**不截图、不数人头**，只轮询协调器里队员主动打上的
        `sensed` 标记。全部队员打卡或超时后返回，由调用方接管资源判是否组齐。

        targets 只用于日志（未打卡名单）；实际判定以协调器 expected 为准——
        等待期间可能有账号被顶号减员，减员者不该继续拖住队长。"""
        t0 = time.time()
        ok, pending = coord.wait_all_sensed(SENSE_WAIT, self._check_stop)
        if ok:
            log.info("全部队员已感知邀请（队长静默 %.1fs），交还资源判定组队人数",
                     time.time() - t0)
        else:
            log.warning("静默等待 %.0f 秒仍有队员未感知邀请（%s），交还资源判定"
                        "组队人数（以实际队伍人数为准）",
                        SENSE_WAIT, "、".join(pending) or "无")
        return ok

    def _wait_team_ready(self, coord, timeout=INVITE_WAIT, empty_abort=25):
        """发出邀请后等指定名单进队：每 5 秒识别一次，指定名单全部命中即成功。

        判定时机（2026-10-12 实测教训）：队员是**陆续**点接受的（实测 5 号比
        第一个队员晚 12 秒），所以给满 INVITE_WAIT 窗口轮询，名单全齐立即返回。
        **"名单外成员"不参与判定**——成员列表区 OCR 会混入面板下方"附近玩家/
        招募"行的名字（'商路''路清''技小路音'等，每帧都不同；用户确认一键
        组队不会拉路人，11:34 那轮 5 个指定号 17 秒内全部进队后仍被噪音误判
        解散过）。缺人到超时 → 返回给上层转手动组队，即覆盖"组成的不是指定
        5 人"的情形。返回 (人数, 未进队的已知名单, 名单外参考)。

        ⚠️ 宽容轮（lenient）**同样等满窗口**：旧逻辑"人数≥下限即返回"用的是
        含噪音的成员行计数（噪音行会把 4 人吹成 6 人），导致 6 号还在进队途中
        就被误判"到齐→有缺席→解散"（12:14 实测）；宽容的放行点在手动组队
        末尾（_captain_manual 移出缺席者后按下限判成功），不在这里抢跑。
        """
        deadline = time.time() + timeout
        start = time.time()
        self._invite_likely_failed = False
        while True:
            count, missing, extras = self._team_status(coord)
            if not missing:
                return count, missing, extras
            if time.time() >= deadline:
                return count, missing, extras
            # 空队早退（2026-10-13）：发完邀请 25 秒队里还是"只有自己"（连一个
            # 名单外陌生人都没有）= 邀请根本没发出去（或全都没收到）。旧逻辑
            # 白等满 60 秒才判 0/5 转手动，白烧半分钟起步；这里提前收手让队长
            # 重发一次邀请。
            if (empty_abort and count <= 1 and not extras
                    and time.time() - start >= empty_abort):
                # 2026-10-21 对账守卫（run 5e0d6d）：只要本轮**已有队员上报
                # 接受**，"队里只有自己"就与队员端证据直接矛盾——多半是队长端
                # 面板未刷新/识别误判（当时「赛季等级提升」弹窗的「前往」按钮
                # 把列表区误判成 solo），此时重发邀请毫无意义、照旧解散更是把
                # 组好的队白扔。改为点一次队伍页签强制刷新面板再读，仍读不到
                # 就禁用早退等满窗口（多帧记忆兜 OCR 抖动）。
                if self._any_accepted_current_round(coord):
                    log.warning("发出邀请 %.0f 秒后队长端仍读不到队员，但已有"
                                "队员上报接受邀请——疑似面板未刷新/识别误判，"
                                "强制刷新队伍面板后继续等待（不重发）",
                                time.time() - start)
                    self.device.click(*TEAM_TAB_POS)   # 队伍视图下点它会收起，下轮 _ensure_team_view 会再展开重读
                    pace.wait(1.2, 1.8)
                    empty_abort = 0                    # 本轮禁用早退，等满窗口
                    pace.wait(3)
                    continue
                self._invite_likely_failed = True
                log.warning("发出邀请 %.0f 秒后队里仍只有自己，判定邀请没发出去，"
                            "提前结束等待", time.time() - start)
                return count, missing, extras
            pace.wait(5)

    @staticmethod
    def _any_accepted_current_round(coord):
        """本轮是否已有队员上报"已接受邀请"（队员点掉弹窗后才上报）。"""
        rnd = coord.current_round()
        return any(coord.accepted_round(a["id"]) >= rnd
                   for a in list(coord.expected.values()))

    def _drop_missing_lenient(self, coord, missing, force=False):
        """把多轮邀请仍未进队的已知成员移出本轮（副本"准备"计数不再等他们）。

        默认仅宽容轮（coord.lenient）生效；force=True 供轮数用尽后的兜底放行
        （非宽容轮也允许：见 _captain_manual 末尾 2026-10-26 注）。
        注意人数判定只看队伍实际人数，减员不能把"不足下限"变成"达标"——
        下限校验交给调用方。"""
        if not missing or (not coord.lenient and not force):
            return
        missing_set = set(missing)
        for a in list(coord.expected.values()):
            if a["character"] in missing_set:
                log.warning("多次邀请仍未进队，移出本轮组队：%s（id=%s）",
                            a["character"], a["id"])
                coord.drop(a["id"])

    def _send_invite(self):
        """帮会 → 编队页签 → 一键组队 → 确定。返回 True=已点出邀请。

        **2026-10-13 坐标化**（用户要求："直接按坐标流程找帮派、编队、一键组队，
        等两秒，队员在固定位置点接受"）：5 开并发时单帧 OCR 要 2~3 秒，按钮
        文字/锚点还经常低置信度被过滤——实测这一步靠 OCR 确认要 56 秒
        （12:51:29→12:52:26），其中一次"没读到按钮"（区域 OCR 明明读出了
        ['一键组队']，但置信度 <0.6 被 min_score 过滤掉）整轮作废、白等 60 秒
        又降级手动。现在只有"帮会面板是否打开"和"确定弹窗"用 OCR，其余全走
        固定坐标 + 短等待，正常路径约 4 秒（人手约 2~3 秒）。

        返回 False 只有一种情形：帮会面板没打开（邀请肯定没发出去），
        调用方会立即重试而不是白等窗口。
        """
        t0 = time.time()
        self.dismiss_popups()
        log.info("[耗时] _send_invite：清弹窗用 %.1fs", time.time() - t0)
        # 1) 帮会图标：模板优先，漏检/等满超时就按固定坐标盲点
        #    （实测模板匹配在 5 开并发下要 12~16 秒才命中，白烧时间）
        opened = False
        for i in range(1, 4):
            if not self.matcher.find_and_click(self.device, "帮会", timeout=3,
                                               region=BANGHUI_REGION,
                                               ccoeff_floor=0.45):
                log.info("「帮会」模板未命中，按固定坐标盲点 @ %s", BANGHUI_POS)
                self.device.click(*BANGHUI_POS)
            deadline = time.time() + 6
            while time.time() < deadline:
                # 帮会面板会记住上次停留的页签，编队页没有"回帮"，用顶部
                # 成员/编队/新闻 里的"新闻"当打开判定
                if ocr.find_text(self.device.screenshot(), "新闻",
                                 region=NEWS_TAB_REGION, min_similarity=0.9):
                    opened = True
                    break
                pace.wait(0.4)
            if opened:
                break
            log.warning("帮会面板未打开，重试 (%d/3)", i)
        if not opened:
            log.warning("帮会面板多次点击未打开")
            return False
        log.info("[耗时] _send_invite：帮会面板已打开（自进入 %.1fs）",
                 time.time() - t0)
        # 2) 编队页签：坐标固定（面板可能已停在该页，点了也无害）
        log.info("点击 [编队页签] @ (%d, %d)", *BIANDUI_TAB_POS)
        self.device.click(*BIANDUI_TAB_POS)
        pace.wait(0.5, 0.8)
        # 3) 一键组队：坐标固定（不再看按钮文字——它是最容易漏读/低置信度的）
        log.info("点击 [一键组队] @ (%d, %d)", *YIJIAN_BTN_POS)
        self.device.click(*YIJIAN_BTN_POS)
        # 4) 确认框：OCR 优先（实测能命中 (297,446)）；"确定"二字漏读时先在
        #    弹窗区域找其它文字确认弹窗确实在，在才按固定坐标盲点——
        #    没有证据绝不盲点（那个位置下面是编队列表，乱点会打开别人的编队）
        for _ in range(2):
            hit = None
            deadline = time.time() + 2.5
            while time.time() < deadline:
                hit = ocr.find_text(self.device.screenshot(), "确定",
                                    region=CONFIRM_REGION, min_similarity=1.0)
                if hit:
                    break
                pace.wait(0.3)
            if hit:
                log.info("点击 [确定-发出组队邀请] @ (%d, %d)", hit[0], hit[1])
                self.device.click(hit[0], hit[1])
                pace.wait(0.8, 1.2)
                log.info("[耗时] _send_invite：确定已点（总 %.1fs）", time.time() - t0)
                return True
            texts = [t for t, *_ in ocr.scan(self.device.screenshot(),
                                             CONFIRM_POPUP_REGION, min_score=0.5)]
            if any(k in t for t in texts for k in ("是否", "邀请", "取消", "确定")):
                log.info("「确定」OCR 未命中但确认弹窗在（读到 %s），按固定坐标盲点 @ %s",
                         texts, CONFIRM_BTN_POS)
                self.device.click(*CONFIRM_BTN_POS)
                pace.wait(0.5, 0.8)
                log.info("[耗时] _send_invite：确定盲点已点（总 %.1fs）", time.time() - t0)
                return True
        # 2026-10-16：旧写法在这里无条件 `return True` = **假成功**——调用方以为
        # 邀请已发出，白等满 INVITE_WAIT 才判 0/N 再降级手动（本轮实测同一步
        # 4 次假成功，白烧约 4×26 秒）。没读到「确定」弹窗就老实返回 False 让
        # 调用方重试；确实"已满员所以没有弹窗"的情形，由 `_captain_flow` 在放弃
        # 前看一眼队伍人数兜住。
        log.warning("未弹出组队邀请确认框，判定邀请没发出去（返回 False 让调用方重试）")
        return False

    def _team_status(self, coord):
        """识别当前队伍构成（先确保面板停在队伍视图）。返回
        (人数, 未进队的已知名单, 名单外的陌生人)。详见 _team_status_from。"""
        return self._team_status_from(coord, self._ensure_team_view())

    def _team_status_from(self, coord, markers):
        """已知队伍视图判定结果 markers（_ensure_team_view 的返回值）时统计
        队伍构成，返回 (人数, 未进队的已知名单, 名单外的陌生人)。

        人数判定（用户规则 2026-10-12 升级：必须组满**指定的**队伍，不再
        "只数人头"）：
        - count = max(已知名单命中数, 队员列表区的"成员行"数, 1)；
          已知名单 = coord.known_names（参与账号角色名 + 手输队外队员名）；
        - missing = 名单里还没进队的；
        - extras = 成员行中不命中名单的名字（一键组队会从帮会拉路人，
          实测"与君相"占坑导致指定队员进不来、队长误判成功）。
        OCR 误读防误报：与名单中任意名字相似度 ≥0.5 的行视为误读
        （实测"外卖点到手颤"被读成"外卖点到手数/额"），不算陌生人。
        必须先确认面板处于"队伍视图"（_ensure_team_view）——任务视图同位置
        是任务条目文本，会把任务标题误计成成员（实测教训）。
        markers 为 None（面板打不开/不在可判定场景）时按 0 人计。
        """
        known = coord.known_names
        if markers is None:
            log.warning("队伍视图未能展开，按 0 人计")
            return 0, list(known), []
        if markers == "solo":
            # 2026-10-21 加日志：这条路径原本静默返回，run 5e0d6d 排障时
            # 25 秒内一行日志都没有，无法定位是识别问题还是真没进队
            log.info("队伍视图判定 solo（无队员名单），按 0 人计")
            return 0, list(known), []
        screen = self.device.screenshot()
        # 用**窄**的名单行区域（TEAM_MEMBER_ROWS_REGION）而不是整块 MEMBER_LIST_REGION：
        # 整块 190px 高会框到面板下方的背景场景文字，人数每帧 1~6 乱跳（2026-10-16）。
        texts = [t for t, *_ in ocr.scan(screen, TEAM_MEMBER_ROWS_REGION,
                                         min_score=0.5)]
        count, missing, extras, found, rows = Zudui._count_team_texts(texts, known)
        # 多帧记忆（同一邀请轮次内）：队员名 OCR 会抖（同一屏这帧读到、下帧读不到），
        # 单帧判定会让 missing 反复"复活"→ 白等满窗口还不判成功。同一轮内只要**任何
        # 一帧**认出了某个已知队员，就当他已经进队（真没进队的人永远不会被认出来）。
        # 轮次推进时清空（每轮开始时队员可能刚被解散重邀）。
        epoch = coord.current_round()
        if getattr(self, "_found_epoch", None) != epoch:
            self._found_epoch, self._found_union = epoch, set()
        self._found_union |= set(found)
        found = [n for n in known if n in self._found_union]
        missing = [n for n in known if n not in self._found_union]
        count = max(count, len(found))
        log.info("队伍识别：%d 人（已知命中 %s / 成员行 %s / 名单外 %s / 原始 %s）",
                 count, found, rows, extras, texts)
        return count, missing, extras

    @staticmethod
    def _count_team_texts(texts, known):
        """按队员列表区的 OCR 文本统计队伍构成。返回
        (人数, 未进队的已知名单, 名单外的陌生人, 命中的已知名单, 成员行文本)。"""
        found = [n for n in known if _name_in_texts(n, texts)]
        rows = [t for t in texts if _member_row_like(t)]
        extras = []
        for t in rows:
            if any(_name_in_texts(n, [t]) for n in known):
                continue
            best = max((SequenceMatcher(None, t, n).ratio() for n in known),
                       default=0.0)
            if best < 0.5:
                extras.append(t)
        # markers=True 至少能看到自己名字（单人队伍也显示自己）→ 保底 1 人
        count = max(len(found), len(rows), 1)
        return count, [n for n in known if n not in found], extras, found, rows

    def _reinforce_team(self, coord, tag="补邀请", fallback_tab_pos=None):
        """任务开始前补邀"还没进队"的指定队员（用户规则 2026-10-12）。

        场景：队长已带全队在帮会领地等任务开始（打地鼠 12:00/18:00 刷新），
        期间若有人没进来，**不需要离队重组**——只要重复发邀请即可：
        - auto（一键组队）：重复点「一键组队 → 确定」，游戏会自动把剩余队员
          拉进来（用户实测结论）；
        - manual（手动组队）：按名字逐个搜索邀请缺席的人（_invite_friend）。

        返回 True=名单已齐（无需补邀）/ False=已补发邀请但仍缺人 /
        None=队伍构成无法确认（面板打不开，本轮不动作，等下一轮再试）。
        """
        me_name = (self.account or {}).get("character")
        markers = self._ensure_team_view(fallback_pos=fallback_tab_pos)
        if markers is None:
            log.warning("%s：队伍视图打不开，无法确认队伍构成，本轮不补邀请", tag)
            return None
        count, missing, extras = Zudui._team_status_from(self, coord, markers)
        missing = [n for n in missing if n != me_name]
        if not missing:
            log.info("%s：队伍已齐（%d 人，名单命中全部），无需补邀请", tag, count)
            self._restore_quest_view()
            return True
        mode = getattr(coord, "team_mode", "auto")
        log.info("%s：队伍 %d 人，仍在缺 %d 人（%s）%s，按 [%s] 方式补发邀请",
                 tag, count, len(missing), "、".join(missing),
                 f"，名单外 {extras}" if extras else "", mode)
        self._restore_quest_view()
        if mode == "manual":
            for name in missing:
                self._check_stop()
                # 显式走 Zudui 的方法（本方法可能被别的任务借调，见 dishu）
                if Zudui._invite_friend(self, name):
                    log.info("%s：已向 %s 补发邀请", tag, name)
                else:
                    log.warning("%s：向 %s 补发邀请失败（搜索/邀请未生效）", tag, name)
                pace.wait(1.0, 2.0)
        else:
            ok = Zudui._send_invite(self)
            if not ok and not getattr(self, "_reinforce_fail_reported", False):
                # 补邀没发出去（帮会面板/一键组队按钮未找到）——留一次现场证据
                self._reinforce_fail_reported = True
                self.report_unknown(
                    "reinforce_invite_fail",
                    note="帮会领地等待期间补发「一键组队」邀请失败"
                         "（帮会面板未打开或未找到一键组队按钮）")
        return False

    # ---- 队员端 ----

    def _member_flow(self, coord):
        """队员端（一键组队）：**退队确认一次 → 静默等待 → 只为邀请醒来**。

        用户规则 2026-10-13：
        - 退队**判定一次**离队成功即上报，此后**不再周期性校验队伍**（等组队
          期间队员中途真离队也不理会）；
        - 等邀请期间队员端静默，不抢屏幕/不进 OCR（资源全给队长发邀请）；
        - 队长发出邀请（coord.start_round）后队员端才被唤醒，**感知被邀请动作**
          （点接受/点组队浮标）并上报 sensed，队长静默等 4 人感知完再判是否组齐。

        保留的例外只有两个，都是被动触发、不主动抢资源：
        - 队长解散重整（离队轮次变化）→ 必须重新离队，否则新邀请发不进来；
        - 队长被顶号后本号被改选为队长（地鼠轮）→ 接管发邀请。
        """
        me_id = self.account["id"]
        # 日志必须能分清是哪个号（5 开并发日志交织，不带名字无法定位谁没进队）
        me_name = (self.account or {}).get("character") or f"id{me_id}"
        tag = f"一键组队（队员·{me_name}）"
        # 用户规则：一律先离队再组队（残留在旧队伍收不到邀请弹窗）——只判定一次
        left_ok = self._leave_and_report(coord, tag)
        if left_ok:
            log.info("%s：离队已确认（判定一次），进入静默等待（不再校验队伍）", tag)
        last = coord.current_round()   # 已消费的邀请轮次（初见即为当前轮）
        deadline = time.time() + MEMBER_GIVEUP
        while time.time() < deadline:
            self._check_stop()
            if coord.result is None and me_id == coord.captain_id:
                # 地鼠轮：原队长被顶号减员，本号被随机改选为队长，接管发邀请
                log.warning("原队长已退出，本号被改选为队长，接管发起组队")
                return self._captain_flow(coord)
            if coord.result is not None:
                log.info("组队已结束（%s）", "成功" if coord.result else "失败")
                return True
            # 唯一的主动补充：此前离队没确认成功（很罕见）——没退干净收不到邀请。
            # 确认成功的号走 here 不再复查（用户规则：判定一次后静默）。
            if not left_ok:
                left_ok = self._leave_and_report(coord, f"{tag}-重试离队")
                if left_ok:
                    log.info("%s：补退队确认成功，转入静默等待", tag)
                last = coord.current_round()
                continue
            # 队长解散重整（一键→手动）后需重新离队，否则邀请发不进来
            if self._check_releave(coord, tag):
                left_ok = True
                continue
            # —— 静默等待：阻塞直到队长发出新一轮邀请（或组队结果落地）——
            # 这里不截图、不 OCR、不点击；只有轮次前进（=队长播报邀请）才醒来，
            # 把屏幕资源让给队长发邀请、也避免 5 开并发时队员自己抢帧。
            r = coord.wait_invite(last, timeout=5, check_stop=self._check_stop)
            if coord.result is not None:
                return True
            if r == last:
                continue   # 队长还没发邀请，继续静默
            last = r
            log.info("%s：感知到第 %d 轮组队邀请", tag, r)
            self._sense_and_accept(coord, me_id, r)
        log.warning("等待组队结果超时")
        return True  # 队员端永不判失败

    def _sense_and_accept(self, coord, me_id, round_):
        """队员端被唤醒后"感知邀请"并点接受（用户规则 2026-10-13）。

        这是队员端在组队期间**唯一的**识别/点击时机：队长播报邀请（轮次前进）
        后立刻打卡 sensed 并调 `_accept_invite` 点掉弹窗；没弹窗也按"已加入
        队伍"处理并上报 accepted（用户规则）。

        打卡要**先于**点击：感知是"我被邀请了"的事实，点击可能被吞（置前失败），
        但队长据此判"4 人已完成接收动作"，与是否点掉弹窗解耦。"""
        coord.mark_sensed(me_id, round_)
        if self._accept_invite():
            log.info("队员 %s：已接受第 %d 轮组队邀请", me_id, round_)
        else:
            # 用户规则：没有再弹窗的时候就认为已经加入队伍了。但这条是**乐观兜底**，
            # 实测经常是"其实没进队"（2026-10-16：队员端这句打了一夜，队长那边
            # 人数永远不齐）。改成 WARNING 并把时长打出来，跟队长端"队里只有自己"
            # 对得上就能立刻定位是邀请链路的问题，不用再翻半天日志。
            log.warning("队员 %s：第 %d 轮等了 %.0f 秒没见到邀请弹窗，按已加入队伍"
                        "处理（若队长端人数一直不齐，多半就是这里其实没真进队）",
                        me_id, round_, ACCEPT_WAIT)
            self.save_debug_screenshot(f"invite_not_seen_r{round_}")
        coord.mark_accepted(me_id, round_)

    def _accept_invite(self, timeout=ACCEPT_WAIT):
        """等"组队邀请"弹窗点"接受"，**弹窗消失才算接受成功**——点击可能被
        "窗口置前失败"吞掉（2026-10-12 实测 6 号：点了接受→置前失败→弹窗一直
        挂着→整场缺席副本），没消失就重点，最多 3 次，仍不行返回 False（诚实
        上报，由上层兜底）。没弹窗则找画面中部"组队"浮标，点开浮标再点"接受"。
        两者都没出现返回 False。

        **热路径只花一次 OCR**（2026-10-13 二次优化）：先用 `probe_team_invite`
        把「组队邀请」标题区 + 「接受」按钮区拼成一张图扫一次，命中就点；只有
        邀请不在时，才回退到完整 `dismiss_popups` 去清别的遮挡（顶号/休眠/
        提示卡/福卡/家园布置…）。旧实现每轮都要走整套 dismiss_popups
        （DIALOG_SCAN + 批量探路 = 2 次 OCR）再单独读「接受」「组队邀请」，
        5 开并发下每次 OCR 有 1~2 秒固定开销，一轮 3~4 次 → 轮询周期 5~8 秒，
        这就是"队长播报邀请后好久才点接受"的主因。
        """
        deadline = time.time() + timeout
        clicked_icon = False
        clicks = 0
        seen_reported = False
        while time.time() < deadline:
            self._check_stop()
            screen = self.device.screenshot()
            title_up, hit = self.probe_team_invite(screen)   # 1 次 OCR
            if title_up and not seen_reported:
                seen_reported = True
                self._log_invite_seen()
            if title_up or hit:
                if not hit:
                    # 弹窗标题在但"接受"二字 OCR 漏读 → 固定坐标盲点
                    #（按钮位置固定，base 实测 @ (296,425)）
                    log.info("「接受」OCR 未命中但弹窗在，按固定坐标盲点 @ (%d, %d)",
                             *self.TEAM_INVITE_ACCEPT_POS)
                    hit = self.TEAM_INVITE_ACCEPT_POS
                clicks += 1
                log.info("点击 [接受组队邀请] #%d @ (%d, %d)",
                         clicks, hit[0], hit[1])
                self.device.click(hit[0], hit[1])
                pace.wait(0.35, 0.6)
                if clicks >= 3:
                    log.warning("接受点击 3 次弹窗仍未消失，按接受失败处理"
                                "（留存截图便于回看是弹窗没消失还是点击被吞）")
                    self.save_debug_screenshot("accept_invite_fail")
                    return False
                # 弹窗消失才算接受成功（标题消失为准，按钮文字会整批漏读）
                if not self.probe_team_invite(self.device.screenshot())[0]:
                    self._tick("已接受组队邀请（队员）")
                    return True
                continue
            # 邀请不在：这时才值得花两次 OCR 清别的遮挡
            if self.dismiss_popups(screen):
                continue
            if not clicked_icon:
                icon = ocr.find_text(screen, "组队", region=TEAM_ICON_REGION,
                                     min_similarity=1.0)
                if icon:
                    # 图标本体在文字上方 ~20px
                    log.info("点击 [组队浮标] @ (%d, %d)", icon[0], icon[1] - 20)
                    self.device.click(icon[0], icon[1] - 20)
                    clicked_icon = True
                    pace.wait(0.5)
                    continue
            pace.wait(0.4)
        return False

    def _log_invite_seen(self):
        """打点：首次看到「组队邀请」弹窗距队长播报过了多久（每轮只打一条）。

        用来把"播报 → 弹窗出现（游戏侧推送）"和"弹窗出现 → 点掉（我方轮询）"
        这两段分开——用户 2026-10-13 直接问过"为什么要好久才点接受，在等 OCR
        吗"，没有这个打点就只能猜。"""
        try:
            from core import teamup
            coord = teamup.coordinator()
            r = coord.invite_round
            ts = getattr(coord, "invite_ts", 0.0) or 0.0
        except Exception:
            return
        if getattr(self, "_invite_seen_round", None) == r:
            return
        self._invite_seen_round = r
        if ts:
            log.info("[耗时] 首次看到组队邀请弹窗：距队长播报 %.1fs",
                     time.time() - ts)

    # ---- 手动组队（mode: manual）：队长好友搜索逐个邀请，队员弹窗点接受 ----

    def _captain_manual(self, coord):
        """手动组队：队长建队后按名单逐个搜索邀请，每轮间隔 INVITE_WAIT 秒、
        只补邀未进队的人，最多 MAX_ROUNDS 轮；人数达 coord.min_members 即成功。

        邀请名单 = 参与账号角色名 + 手输的队外队员名（coord.extra_names）。
        队外队员是别人在登录的号，只能靠他自己点接受——超过 2 分钟未进队先
        放弃（用户规则），下一轮人数仍不足时再补邀。
        """
        log.info("手动组队：先全员离队，再由队长建队并按名单逐个邀请"
                 "（每 %d 秒补邀一轮，最多 %d 轮，需 %d 人）",
                 INVITE_WAIT, MAX_ROUNDS, coord.min_members)
        if not self._ensure_clean_team(coord, "手动组队（队长）"):
            coord.set_result(False)
            return False
        if not self._create_team_with_cooldown(coord):
            coord.set_result(False)
            return False
        if not self._goto_friend_search():
            log.warning("无法进入搜索好友面板，手动组队失败")
            coord.set_result(False)
            return False
        me_name = self.account["character"]
        # 邀请名单在等待后取：等待期间可能有账号被顶号减员/未确认被移出
        targets = [n for n in coord.known_names if n != me_name]
        log.info("手动组队邀请名单 %d 人: %s", len(targets), "、".join(targets))
        missing = list(targets)
        count = 0
        for round_ in range(1, MAX_ROUNDS + 1):
            self._check_stop()
            if not missing:
                break
            if round_ > 1:
                log.info("第 %d/%d 轮补邀 %d 人: %s", round_, MAX_ROUNDS,
                         len(missing), "、".join(missing))
            # ① 先把邀请**真正发出去**（逐个搜索好友邀请，3 人约 60~80 秒）
            for name in missing:
                self._check_stop()
                if self._invite_friend(name):
                    log.info("已向 %s 发出邀请", name)
                else:
                    log.warning("搜索/邀请 %s 失败，留待下轮补邀", name)
                pace.wait(1.0, 2.0)
            # ② **邀请发完再播报本轮**（2026-10-16 事故修）：旧写法在发邀请
            #    **之前**就 `start_round()`，而逐个搜索邀请要 60~80 秒，队员端的
            #    等弹窗窗口只有 ACCEPT_WAIT(35s) → 队员在窗口末尾就判"未出现
            #    邀请弹窗"收手了（实测 22:36:31 播报 → 22:37:12 才发出第一个
            #    邀请，队员 22:37:13 已经退出等待）→ 队员**从没进队** → 一夜 4 个
            #    组队任务全灭。而且旧写法整局只播报一次，第 2~5 轮补邀根本没
            #    唤醒队员端（它们一直静默睡到 MEMBER_GIVEUP）。
            coord.start_round()
            # ③ 静默等队员感知邀请（用户规则 2026-10-13）：队长这段时间不截图、
            #    不判人数，屏幕/OCR 全留给队员端点接受
            self._wait_members_sense(coord, missing)
            # ④ 回主界面等接受：INVITE_WAIT 秒内每 5 秒识别一次队伍构成，达标即止
            self.exit_panel_to_home()
            deadline = time.time() + INVITE_WAIT
            while True:
                count, missing, extras = self._team_status(coord)
                missing = [n for n in missing if n != me_name]
                if extras:
                    log.warning("队里出现名单外名字 %s（OCR 噪音或残留），仅记录",
                                extras)  # 手动邀请名单精确，不据 extras 判败
                strict_ok = not missing
                # 宽容轮按下限放行，但只数**指定名单命中数**——成员行计数含
                # "附近玩家"OCR 噪音，会把 4 人吹成 6 人误判达标（12:14 实测）
                known_found = len(coord.known_names) - len(missing)
                lenient_ok = coord.lenient and known_found >= coord.min_members
                if strict_ok or lenient_ok or time.time() >= deadline:
                    break
                pace.wait(5)
            if strict_ok or lenient_ok:
                log.info("指定名单全部进队（%d 人），手动组队成功", count)
                coord.set_result(True)
                self.exit_panel_to_home()
                return True
            log.warning("第 %d 轮后名单未到齐：%d/%d 人，未进队: %s", round_,
                        count, len(coord.known_names),
                        "、".join(missing) or "（已知名单外仍缺）")
        if coord.lenient:
            # 宽容轮（地鼠轮）：多轮邀不进的人移出本轮后，剩余指定成员达下限
            # 即组队成功（用户规则：邀不进队的队员放弃；含打地鼠 2 人即可）
            self._drop_missing_lenient(coord, missing)
        # 非宽容轮兜底（2026-10-26 run f52bd9）：早前非宽容轮必须名单全齐，
        # 一个号收不到邀请（客户端会话劣化，邀请推送根本不到）就 5 轮打完判负，
        # haishi/liudao/zhongkui 全队连环短路——尽管队伍 3 人已满足下限。
        # 现在轮数用完后同样按"指定名单命中数 ≥ 下限"放行：缺席者多为"登错号/
        # 客户端半死"的号，邀不进来硬判负只会白丢全队三个副本。判定用已知
        # 命中数（不含名单外噪音行），与宽容轮同标准。
        self._drop_missing_lenient(coord, missing, force=True)
        _count, missing2, _extras = self._team_status(coord)
        known_found = len(coord.known_names) - len(missing2)
        if known_found >= coord.min_members:
            log.info("轮数用完后兜底放行：指定成员 %d 人达到下限 %d（缺席者已移出"
                     "本轮：%s），组队成功", known_found, coord.min_members,
                     "、".join(missing2) or "无")
            coord.set_result(True)
            self.exit_panel_to_home()
            return True
        log.warning("%d 轮邀请后仍不足 %d 人，组队判负", MAX_ROUNDS,
                    coord.min_members)
        coord.set_result(False)
        return False

    def _member_manual(self, coord):
        """队员端（手动组队）：与 `_member_flow` 同款——退队确认一次后静默等待，
        只被"队长播报邀请"唤醒去感知/点接受（用户规则 2026-10-13）。

        不再周期性自检队伍、不再轮询截图清弹窗；资源全给队长逐个搜索邀请。
        """
        me_id = self.account["id"]
        me_name = (self.account or {}).get("character") or f"id{me_id}"
        tag = f"手动组队（队员·{me_name}）"
        left_ok = self._leave_and_report(coord, tag)
        if left_ok:
            log.info("%s：离队已确认（判定一次），进入静默等待（不再校验队伍）", tag)
        last = coord.current_round()
        deadline = time.time() + MEMBER_GIVEUP
        while time.time() < deadline:
            self._check_stop()
            if coord.result is None and me_id == coord.captain_id:
                # 地鼠轮：原队长被顶号减员，本号被随机改选为队长，接管发邀请
                log.warning("原队长已退出，本号被改选为队长，接管发起组队")
                return self._captain_manual(coord)
            if coord.result is not None:
                log.info("组队已结束（%s）", "成功" if coord.result else "失败")
                return True
            if me_id not in coord.expected:
                log.info("本号已被减员，退出等待")
                return True
            if not left_ok:
                left_ok = self._leave_and_report(coord, f"{tag}-重试离队")
                if left_ok:
                    log.info("%s：补退队确认成功，转入静默等待", tag)
                last = coord.current_round()
                continue
            if self._check_releave(coord, tag):
                left_ok = True
                continue
            # 静默等待（同 _member_flow）：不抢屏幕，只为队长播报邀请醒来
            r = coord.wait_invite(last, timeout=5, check_stop=self._check_stop)
            if coord.result is not None:
                return True
            if r == last:
                continue
            last = r
            log.info("%s：感知到第 %d 轮组队邀请", tag, r)
            self._sense_and_accept(coord, me_id, r)
        log.warning("等待组队结果超时")
        return True  # 队员端永不判失败

    def _create_team_with_cooldown(self, coord):
        """创建队伍，失败按"离队后组队冷却"处理：2026-10-12 实测，队长离队后
        约 20 秒就点"创建队伍"，按钮灰色不可点、点击静默无效（无提示弹窗/
        队伍面板）——等 60 秒再试，最多 3 次。"""
        for attempt in range(1, 4):
            if self._create_team():
                return True
            log.warning("创建队伍未生效（疑似离队后组队冷却），%d 秒后重试 (%d/3)",
                        CREATE_COOLDOWN, attempt)
            time.sleep(CREATE_COOLDOWN)
            # 2026-10-16 事故：上一轮点击可能**其实已经建队成功**（提示弹窗/
            # 队伍面板没被识别到就判了失败），此时队伍视图会一直停在"非单人"，
            # 下一轮 _create_team 的前置校验（必须 solo）永远过不去 → 60s×3
            # 白等 → 组队判负（当晚 4 个组队任务全灭）。重试前先清队复位。
            if attempt < 3 and self._ensure_team_view() is True:
                log.info("重试前队伍视图仍非单人（上一轮可能已建队/有残留队伍），先离队复位")
                self.leave_team()
                self._restore_quest_view()
        return False

    def _create_team(self):
        """队长建队：追踪面板队伍视图（单人）→ 创建队伍 → "提示"弹窗点
        "取消"（不前往设置队伍目标）→ 确认队伍面板打开 → 点空白关闭回主界面。
        返回 True=队伍已创建。"""
        # 前置：必须从主界面出发——上游导航（离队/关面板）可能停在玩法面板
        # 等奇怪页面，直接找队伍页签会跑偏（实测跑偏到玩法地图，队员名被
        # BOSS 名误中误判成"组队中"）
        if not self.on_main_screen(self.device.screenshot()):
            log.info("建队前不在主界面，先回主界面")
            self.ensure_main_screen()
        markers = self._ensure_team_view()
        if markers == "solo":
            pass  # 无队伍（看得到"创建队伍/前往组队"）→ 可以建队
        elif markers is True and self._team_is_self_only():
            # 队员列表区只看到自己 = 自己建的 1 人队伍已经在了（上一轮"创建队伍"
            # 其实已生效，只是当时没识别到面板标记就判了失败）。不认这一点的话，
            # 前置"必须单人"永远过不去 → 60s×3 白等 → 组队判负（2026-10-16 事故）。
            log.info("队伍视图里只有自己，判定队伍已建好（上一轮建队其实已生效），继续组队流程")
            return self._close_team_panel()
        else:
            log.warning("队伍视图未确认单人状态（%r），无法创建队伍", markers)
            self.save_debug_screenshot("manual_team_view_fail")
            return False
        # 点"创建队伍"（点击可能被吞，见 open_wanfa 的教训：最多重试 3 次，
        # 每轮先确认"提示"弹窗或队伍面板是否已出现，出现即视为上次点击已生效）
        tip_hit = panel_hit = None
        for i in range(3):
            self._check_stop()
            screen = self.device.screenshot()
            tip_hit = ocr.find_text(screen, "取消", region=TIP_CANCEL_REGION,
                                    min_similarity=0.8)
            panel_hit = ocr.find_text(screen, "招募",
                                      region=TEAM_PANEL_MARK_REGION,
                                      min_similarity=1.0)
            if tip_hit or panel_hit:
                break
            hit = ocr.find_text(screen, "创建队伍", region=MEMBER_LIST_REGION,
                                min_similarity=0.75)
            if not hit:
                log.warning("队伍视图未见创建队伍按钮 (%d/3)", i + 1)
                pace.wait(1.0, 1.5)
                continue
            log.info("点击 [创建队伍] @ (%d, %d)", hit[0], hit[1])
            self.device.click(hit[0], hit[1])
            pace.wait(1.5, 2.2)
        if not (tip_hit or panel_hit):
            # ⚠️ 循环的命中检查在**每轮开头**，第 3 次点击后循环直接结束——
            # 从不在"最后一次点击之后"再确认一遍。2026-10-13 13:49 实机事故：
            # 前两次点击落在离队冷却期被静默吞掉，第 3 次才生效（「创建队伍
            # 成功」弹窗都已弹出，截图 manual_create_team_fail 可证），这里却
            # 判"3 次均未生效"；随后 2 轮重试又因"队伍视图非单人"（队伍其实
            # 已经建好了）白等 60s×2，整场手动组队被拖死。这里补一次最多 6s
            # 的收尾确认；"取消"二字按钮带字距（"取 消"），相似度放宽到 0.8。
            deadline = time.time() + 6
            while time.time() < deadline:
                self._check_stop()
                screen = self.device.screenshot()
                tip_hit = ocr.find_text(screen, "取消", region=TIP_CANCEL_REGION,
                                        min_similarity=0.8)
                panel_hit = ocr.find_text(screen, "招募",
                                          region=TEAM_PANEL_MARK_REGION,
                                          min_similarity=1.0)
                if tip_hit or panel_hit:
                    log.info("第 3 次点击后弹窗/面板才出现（点击已生效），继续")
                    break
                pace.wait(0.5)
        if not (tip_hit or panel_hit):
            log.warning("创建队伍点击 3 次均未生效（无提示弹窗/队伍面板）")
            self.save_debug_screenshot("manual_create_team_fail")
            return False
        if tip_hit:
            # 2026-10-16：点一次可能被吞（实测失败截图里"提示"弹窗还挂着，队伍
            # 面板因此永远开不出来 → 判"创建队伍失败"，其实队伍已经建好了）。
            # 点完复查，弹窗还在就再点，最多 3 次。
            for i in range(3):
                self._check_stop()
                if i == 0:
                    log.info("点击 [取消-不设置队伍目标] @ (%d, %d)",
                             tip_hit[0], tip_hit[1])
                else:
                    log.info("「提示」弹窗仍在，第 %d 次点 [取消-不设置队伍目标] @ (%d, %d)",
                             i + 1, tip_hit[0], tip_hit[1])
                self.device.click(tip_hit[0], tip_hit[1])
                pace.wait(1.0, 1.5)
                again = ocr.find_text(self.device.screenshot(), "取消",
                                      region=TIP_CANCEL_REGION, min_similarity=0.8)
                if not again:
                    break
                tip_hit = again
        opened = False
        deadline = time.time() + 10
        while time.time() < deadline:
            if ocr.find_text(self.device.screenshot(), "招募",
                             region=TEAM_PANEL_MARK_REGION, min_similarity=1.0):
                opened = True
                break
            pace.wait(0.6)
        if not opened:
            # 招募标记没出现，但队伍可能已经建好了（面板标记漏读/刷新慢）：
            # 队员列表区只有自己即可认定建队成功（2026-10-16 事故）。
            if self._team_is_self_only():
                log.info("未见「招募」标记，但队员列表区只有自己 —— 判定建队成功")
                return self._close_team_panel()
            log.warning("队伍面板未打开，创建队伍失败")
            self.save_debug_screenshot("manual_create_team_fail")
            return False
        log.info("队伍已创建，点空白关闭面板回主界面")
        return self._close_team_panel()

    def _close_team_panel(self):
        """点队伍面板上缘空白处关面板回主界面（建队收尾统一走这里）。"""
        self.device.click(*TEAM_PANEL_BLANK_POS)
        deadline = time.time() + 6
        while time.time() < deadline:
            if self.on_main_screen(self.device.screenshot()):
                self._restore_quest_view()  # 追踪面板切回任务视图（防后续任务误判）
                return True
            pace.wait(0.6)
        log.warning("点空白未关掉队伍面板，按 ESC 兜底")
        self.back_to_home()
        self._restore_quest_view()
        return self.on_main_screen(self.device.screenshot())

    def _team_is_self_only(self):
        """队伍视图的队员列表区里**只有自己**（自己建的 1 人队伍、招募位空着）。

        用于把"建队其实已生效"从失败里救回来（2026-10-16 事故：4 个组队任务
        因为这个判负全灭）。判定必须保守——宁可返回 False 退回原流程，也绝不
        能凭"没读到别人"就认成功：
        - 先要求本帧队员列表区确实读到"像成员行"的文本；
        - 每行都要命中自己的角色名（含相似度兜底）；
        - 读到"前往"（任务视图条目的特征）一律不算。
        """
        me = (self.account or {}).get("character") or ""
        if not me:
            return False
        try:
            texts = [t for t, *_ in ocr.scan(self.device.screenshot(),
                                             TEAM_MEMBER_ROWS_REGION,
                                             min_score=0.5)]
        except Exception:
            return False
        if not texts or any("前往" in t for t in texts):
            return False
        rows = [t for t in texts if _member_row_like(t)]
        if not rows:
            return False
        for t in rows:
            if _name_in_texts(me, [t]):
                continue
            return False
        return True

    def _goto_friend_search(self):
        """进入"搜索好友"面板：主界面左下角好友图标 → 关系面板"好友"页签
        → "找好友"。已在搜索面板时直接成功。"""
        for attempt in range(2):
            self._check_stop()
            screen = self.device.screenshot()
            if self.dismiss_popups(screen):
                continue
            if ocr.find_text(screen, "搜索好友", region=SEARCH_TITLE_REGION,
                             min_similarity=0.8):
                return True
            if not self.on_main_screen(screen):
                self.exit_panel_to_home()
            hit = ocr.find_text(self.device.screenshot(), "好友",
                                region=FRIEND_ICON_REGION, min_similarity=0.5)
            if hit:
                log.info("点击 [好友图标] @ (%d, %d)", hit[0], hit[1])
                self.device.click(hit[0], hit[1])
            else:
                # OCR 常把"好友"读成"好发"仍不中时按实测坐标盲点（已确认在主界面）
                log.info("好友图标 OCR 未中，按固定坐标盲点 @ %s", FRIEND_ICON_POS)
                self.device.click(*FRIEND_ICON_POS)
            tab = None
            deadline = time.time() + 8
            while time.time() < deadline:
                tab = ocr.find_text(self.device.screenshot(), "好友",
                                    region=FRIEND_TAB_REGION, min_similarity=1.0)
                if tab:
                    break
                pace.wait(0.6)
            if not tab:
                log.warning("关系面板未打开或无好友页签")
                self.back_to_home()
                continue
            log.info("点击 [好友页签] @ (%d, %d)", tab[0], tab[1])
            self.device.click(tab[0], tab[1])
            entry = None
            deadline = time.time() + 8
            while time.time() < deadline:
                entry = ocr.find_text(self.device.screenshot(), "找好友",
                                      region=FIND_FRIEND_REGION,
                                      min_similarity=0.8)
                if entry:
                    break
                pace.wait(0.6)
            if not entry:
                log.warning("好友页未找到找好友入口")
                continue
            log.info("点击 [找好友] @ (%d, %d)", entry[0], entry[1])
            self.device.click(entry[0], entry[1])
            deadline = time.time() + 8
            while time.time() < deadline:
                if ocr.find_text(self.device.screenshot(), "搜索好友",
                                 region=SEARCH_TITLE_REGION, min_similarity=0.8):
                    log.info("已进入搜索好友面板")
                    return True
                pace.wait(0.6)
            log.warning("搜索好友面板未打开，重试 (%d/2)", attempt + 1)
        log.warning("多次尝试仍未能进入搜索好友面板")
        self.save_debug_screenshot("manual_goto_search_fail")
        return False

    def _invite_friend(self, name):
        """在搜索好友面板搜索角色 name 并从信息卡点"邀请"。
        返回 True=邀请已发出。"""
        for attempt in range(2):
            self._check_stop()
            if not self._goto_friend_search():
                return False
            screen = self.device.screenshot()
            # 清空输入框：⊗ 位置随文字长度漂移点不中（实测残留旧文字会被
            # 粘贴插成乱码），改点输入框聚焦后连发退格清干净，再粘贴
            log.info("点击 [搜索输入框] @ (%d, %d)", *INPUT_CLICK_POS)
            self.device.click(*INPUT_CLICK_POS)
            self.device.press_backspace()
            pace.wait(0.3, 0.6)
            if not self.device.paste_text(name):
                continue
            btn = ocr.find_text(self.device.screenshot(), "搜索",
                                region=SEARCH_BTN_REGION, min_similarity=1.0)
            pos = (btn[0], btn[1]) if btn else SEARCH_BTN_POS
            log.info("点击 [搜索] @ (%d, %d)", *pos)
            self.device.click(*pos)
            # 等结果行出现目标名字；搜索点击可能被吞（实测点了搜索列表仍是
            # 默认推荐列表），8 秒无果就重点一次，最多 3 次
            hit = None
            deadline = time.time() + 30
            next_click = time.time() + 8
            while time.time() < deadline:
                self._check_stop()
                screen = self.device.screenshot()
                if self.dismiss_popups(screen):
                    continue
                hit = self._find_name_in(screen, RESULT_REGION, name)
                if hit:
                    break
                if time.time() >= next_click:
                    btn = ocr.find_text(screen, "搜索",
                                        region=SEARCH_BTN_REGION,
                                        min_similarity=1.0)
                    pos = (btn[0], btn[1]) if btn else SEARCH_BTN_POS
                    log.info("搜索无结果，重点 [搜索] @ (%d, %d)", *pos)
                    self.device.click(*pos)
                    next_click = time.time() + 8
                pace.wait(0.6)
            if not hit:
                log.warning("搜索结果中未找到 %s", name)
                self.save_debug_screenshot("manual_search_none")
                continue
            # 点结果首行头像（列位置固定，名字已核对无误）；信息卡可能因
            # 点击被吞没弹出，等 5 秒没出现就重点一次头像
            log.info("点击 [好友头像] @ (%d, %d)（结果: %s）",
                     *FRIEND_AVATAR_POS, name)
            self.device.click(*FRIEND_AVATAR_POS)
            btn = None
            reclicked = False
            deadline = time.time() + 10
            while time.time() < deadline:
                self._check_stop()
                screen = self.device.screenshot()
                if self.dismiss_popups(screen):
                    continue
                btn = ocr.find_text(screen, "邀请", region=INVITE_BTN_REGION,
                                    min_similarity=1.0)
                if btn:
                    break
                if not reclicked and time.time() > deadline - 5:
                    reclicked = True
                    log.info("信息卡未弹出，重点 [好友头像]")
                    self.device.click(*FRIEND_AVATAR_POS)
                pace.wait(0.6)
            if not btn:
                log.warning("好友信息卡未出现邀请按钮")
                self.save_debug_screenshot("manual_invite_card_fail")
                self.back_to_home()
                continue
            log.info("点击 [邀请] @ (%d, %d)", btn[0], btn[1])
            self.device.click(btn[0], btn[1])
            # 等信息卡关闭（邀请发出后自动收卡；收不掉按 ESC 兜底）
            deadline = time.time() + 5
            while time.time() < deadline:
                screen = self.device.screenshot()
                if not ocr.find_text(screen, "邀请", region=INVITE_BTN_REGION,
                                     min_similarity=1.0):
                    log.info("邀请已发出：%s", name)
                    return True
                pace.wait(0.6)
            log.info("邀请已发出（信息卡未自动关闭，按 ESC 关闭）")
            self.device.press_esc()
            return True
        return False

    @staticmethod
    def _find_name_in(screen, region, name):
        """区域内找目标角色名：OCR 生僻字易错（见 _name_in_texts），
        包含匹配之外再按相似度 ≥NAME_SIM_FLOOR 兜底。返回命中中心坐标。"""
        best = None  # (sim, cx, cy)
        for t, cx, cy, _score in ocr.scan(screen, region, min_score=0.5):
            if len(t) < 2:
                continue
            if name in t or t in name:
                return cx, cy
            sim = SequenceMatcher(None, t, name).ratio()
            if sim >= NAME_SIM_FLOOR and (best is None or sim > best[0]):
                best = (sim, cx, cy)
        if best:
            return best[1], best[2]
        return None
