import difflib
import logging
import random
import re
import time

from core import ocr
from tasks.base import PANEL_BACK_POS
from tasks.home_base import (CHECKIN_CLOSE_POS, CHECKIN_KEYWORDS,  # noqa: F401 (re-export)
                             GARDEN_HUD_TIMEOUT, GARDEN_MARK_REGION,
                             HOME_CARD_MARK, HOME_CARD_REGION, HUIJIA_POS,
                             HUIJIA_REGION, JIATIN_REGION, LEAVE_POS,
                             LEAVE_REGION, PLUS_REGION, REWARD_BLANK_POS,
                             SHARE_CLOSE_POS, SHARE_PANEL_KEYWORDS,
                             SIGNPOST_CCOEFF_FLOOR, SIGNPOST_THRESHOLD,
                             YAOMIAO_GIFT_REGION, YAOMIAO_KEYWORDS, HomeTask,
                             is_garden_scene)

log = logging.getLogger("task.zhongcai")

# 以下均为 405x720 客户区坐标（按用户真机截图校准）。
# 进家园导航 / 家园开场弹窗 / 离开家园等公共部分在 tasks/home_base.py（HomeTask）。
# （上面的 re-export 保持旧 import 路径兼容，如 debug/_verify_zhongcai.py）

# ---- 家园场景：指向标（粉红路牌「我在菜园 很想你」）----
SIGNPOST_TEXT_REGION = (0, 120, 300, 400)  # 路牌文字大致出现范围
SIGNPOST_KEYWORDS = ("很想你", "我在菜园", "我在家园", "前往菜园", "路牌")
SIGNPOST_FALLBACK_POS = (101, 270)         # 兜底点击位 = 真正的可点热区（见下面的 SIGNPOST_CLICK_POS）
# 路牌**可点热区**（⭐ 实测 2026-10-10 账号7）：
#   模板命中 (108,236)、OCR 牌心 (105,237) —— **点了都没反应**（→ no_warp_dialog）；
#   点 (101,270) 则 **1 秒内弹出**「可一步轻功飞到菜园，是否前往？」。
#   即路牌两行字「我在菜园 / 很想你」中间，也是 128 格分区图 42/43/50/51 四格的交汇中心。
SIGNPOST_CLICK_POS = (101, 270)
# 以下 OCR 位移表已废弃（旧相机位标定，指向模板命中点而非热区），仅保留备查。
SIGNPOST_TEXT_DY = {
    "很想你": -41,
    "我在菜园": -21,
    "我在家园": -21,
    "前往菜园": -138,
    "路牌": -140,
}

# ---- 「可一步轻功飞到菜园，是否前往?」弹窗 ----
DLG_TEXT_REGION = (60, 330, 300, 60)       # 弹窗正文"可一步轻功飞到菜园，是否前往？"（实测中心 ≈(200,358)）
DLG_CONFIRM_REGION = (205, 412, 185, 62)   # "确定"文字区（实测文字中心 ≈(297,445)）
DLG_CONFIRM_POS = (298, 445)               # 兜底：确定按钮中心

# ---- 菜园 ----
PLOT_BUBBLE_REGION = (110, 18, 265, 305)   # 菜地上方浮出的工具气泡（镰刀=收 / 铲子=种，共用模板"工具气泡"）
PLOT_CLICK_POS = (207, 100)                # 点菜地/菜品，浮出工具气泡（菜地横跨屏幕上部的斜排）
HARVEST_ROUNDS = 5                         # 收割轮次上限（每轮点一次气泡）
PANEL_MARK_REGION = (285, 452, 120, 50)    # 播种面板"快捷种菜"（判定面板已打开）

# ---- 播种面板 ----
CROP_TILE_POS = ((56, 593), (155, 593), (252, 593))  # 前三个菜品格（配方高亮项**每日轮换**，
                                           # 实测 2026-10-10 为甘蔗/西瓜/南瓜；按位置取前 3 格不受影响）
CROP_CLICKS_EACH = 3                       # 每格点击次数
MAX_PLANT_CLICKS = 60                      # 播种点击硬上限（每日上限 48，防读不到提示时死循环）

# ---- 美食配方（2026-11-03 用户需求：家园做菜可选做什么菜，播种时按配方种）----
# 用户从游戏「玩法美食/属性美食」配方页截图录入的 10 种配方（3 种原料各一）。
# config.yaml 的 zhongcai 条目 / 向导「种菜 · 美食配方」选 dish=配方 id；
# 播种时按配方在面板里 OCR 定位对应作物格去点，不再盲点前三个菜品格
# （前三个 = 游戏每日轮换的推荐配方，未必是用户想做的菜）。
DISH_AUTO = "auto"                         # 不选配方：沿用旧行为（前三个菜品格轮点）
DISH_RECIPES = {
    "daluandun":        ("大乱炖",   ("白菜", "辣椒", "南瓜")),
    "malatang":         ("麻辣烫",   ("大豆", "辣椒", "茄子")),
    "taohuaniang":      ("桃花酿",   ("小麦", "甘蔗", "蟠桃")),
    "qingbuliang":      ("清补凉",   ("小麦", "西瓜", "蟠桃")),
    "xiangsijuan":      ("相思卷",   ("大豆", "甘蔗", "草莓")),
    "baiyugao":         ("白玉糕",   ("小麦", "大豆", "草莓")),
    "longfengjuanbing": ("龙凤卷饼", ("白菜", "小麦", "辣椒")),
    "xiantiaoqiang":    ("仙跳墙",   ("甘蔗", "西瓜", "南瓜")),
    "xianhuabing":      ("鲜花饼",   ("小麦", "大豆", "茄子")),
    "qiancengbing":     ("千层饼",   ("小麦", "甘蔗", "草莓")),
}

# 作物名 OCR 形近字兜底（ocr.scan 已带相似度，这里收实测/常见误读，命中即算）：
CROP_NAME_ALIASES = {
    "小麦": ("小麦", "小雯"),
    "大豆": ("大豆", "人豆", "太豆"),
    "甘蔗": ("甘蔗", "甘庶", "甘荐"),
    "白菜": ("白菜", "日菜"),
    "茄子": ("茄子", "芬子"),
    "南瓜": ("南瓜", "南爪"),
    "西瓜": ("西瓜", "西爪"),
    "草莓": ("草莓", "草毒", "草苺"),
    "蟠桃": ("蟠桃", "潘桃", "番桃", "磐桃"),
}

# 面板里的作物格子区（作物名文字都在这范围：第一行名 ≈y548，第二行露头 ≈y677；
# 上边界 528 挡住上方的配方条「属性美食 ⇄ 千层饼 = …」，防误匹配菜名）。
CROP_GRID_REGION = (0, 528, 405, 192)
CROP_NAME_DY = 45                          # 作物名文字中心 → 格子可点中心（图标）的 y 偏移
                                           # （旧坐标实测：名 ≈548 → 图标 593）
PANEL_SCROLL_MAX = 3                       # 作物定位时面板向上滚动的次数上限
                                           # （默认视野只有前 8 格，南瓜/蟠桃等在下面）
TOAST_REGION = (30, 95, 345, 165)          # 播种提示 toast（上限/地满共用区域）
# 播种结束提示关键词（TOAST_REGION 内包含匹配，命中任一即停止播种）：
#   "明天再来吧" = 每日 48 次上限（实测 2026-10-10 账号4）；
#   "等待成熟"/"田地不足"/"用地不足" = **菜地种满、没有可种植的田地**提示
#   「可种植的田地不足，请等待成熟吧」（实测 2026-10-11 第 4 个客户端）——
#   ⚠️ OCR 会把"田地"误读成"用地"（田→用），故两种读法都收，另用"等待成熟"
#   做主锚点（不受该误识别影响）。
PLANT_END_TOAST_KEYWORDS = ("明天再来吧", "等待成熟", "田地不足", "用地不足")
EXIT_REGION = (342, 388, 64, 64)           # 播种面板右缘"退出"（OCR 判定存在用）
EXIT_POS = (382, 410)                      # 退出按钮图标中心（实测：OCR 文字中心 (382,422) 点了没反应，
                                           # 图标中心一次生效。用 click_pos 固定坐标点它）

# ---- 菜园/家园底部栏「美食」→ 制作台 ----
# "美食"文字太小 OCR 识别不到，用图标模板"美食"（限定在小区域，避免场景里同形锅具误命中）
MEISHI_REGION = (145, 578, 92, 58)
MEISHI_POS = (187, 610)                    # 兜底固定坐标
MAKE_REGION = (138, 555, 138, 75)          # 制作台中部"制作"大按钮（OCR 判定存在）
MAKE_POS = (205, 597)                      # 制作按钮中心（OCR 文字框偏下，用固定中心更稳）
MAKE_CLICKS = 10                           # 连续制作次数
MAKE_INTERVAL = 3.0                        # 每次制作间隔（秒；已勾「跳过动画」故比原先的 5s 短）

# ---- 制作台按配方备料（2026-11-03 用户需求：选了配方先「放回」清锅，再从
#      下方食材格把配方作物点进锅（点击后自动放入，数量按配方自动补足），
#      然后才点「制作」；dish=auto 时不做这一步，全按旧逻辑）----
# 坐标按用户 2026-11-03 真机截图校准，与 debug/_zc/craft.png 1:1 对齐（已模板互验）。
# 实测：**锅空时「放回」按钮整个消失** → 放回可见=锅里有食材；点完食材它重新
# 出现 = 备料成功（比画面 diff 更可靠的判据）。
PUTBACK_REGION = (210, 300, 160, 100)      # 「放回」按钮（灰圆+托手图标）搜索区
PUTBACK_POS = (278, 350)                   # 放回按钮图标中心（兜底固定坐标）
PUTBACK_TOAST_REGION = (110, 200, 190, 55) # 「食材已放回」toast（锅上方居中）
FOOD_GRID_REGION = (0, 430, 405, 170)      # 食材格区域：首屏两行行中心 y≈476/555，
                                           # 滚动后行位上移到 y≈452/535（实测 2026-11-03
                                           # 五张真机截图），列中心 x≈56+73c —— 上界 430
                                           # 必须盖住滚动后的顶行图标（y≈433 起）
FOOD_GRID_SCROLL_MAX = 3                   # 食材格向下滚动查找次数上限
# 10 种食材模板清单（assets/images/tasks/zhongcai/食材_<名>.png，2026-11-03 全部抠齐；
# 同一作物不同品质变体图标几乎一致，命中任一变体即可 —— 判别矩阵 10 模板×7 真机
# 截图全绿，无跨作物误命中，被绿√盖住的格子不会命中）
FOOD_CROPS = ("白菜", "小麦", "大豆", "辣椒", "茄子", "甘蔗", "草莓", "西瓜", "蟠桃", "南瓜")
POT_REGION = (60, 150, 290, 150)           # 锅+周围三个食材槽（备料前后对比辅助判据）
# ⚠️ 食材格图标模板 食材_<作物>.png 从用户真机截图抠取（2026-11-03）。实测同一作物的
# 不同品质种子图标几乎一致（大豆模板在相邻变体格 0.995 vs 本格 1.0），且放入后格子会被
# 大绿√盖住导致模板失配 —— 故必须「同一视野内先定位、后点击」，跨视野的坐标会因
# 滚动失效；点击后用「放回按钮重新出现 / 锅区域画面变化」验证食材真的进锅
# （见 _prepare_recipe_pot）。某食材本账号没有时按用户规则用任意未选中格子顶替
# （_substitute_missing）。

# ---- 制作台「跳过动画」勾选框（默认可能是已勾选状态，点错了会变成取消，必须先判定）----
SKIP_ANIM_TEXT_REGION = (280, 600, 100, 30)  # "跳过动画"文字（OCR 判存在，实测中心 ≈(303,615)）
SKIP_ANIM_BOX_REGION = (265, 609, 12, 12)    # 勾选框内部（橙√像素比例判定是否已勾，已勾≈0.31）
SKIP_ANIM_BOX_POS = (271, 615)               # 勾选框中心（点击用）
SKIP_ANIM_TICK_MIN = 0.15                    # 橙√像素占比 ≥ 此值 = 已勾选

# ---- 制作台「恭喜获得」结算窗（实测 2026-10-10：不是只弹一次，10 次里弹 6 次）----
# 窗体内容："恭喜获得 / 成功激活配方，制作出N★仙跳墙，经验+50 / 仙跳墙 / 点击空白处关闭"，
# 会**盖住制作按钮**，不关掉下一次制作就找不到按钮。点空白处即可关闭。
CRAFT_POPUP_REGION = (20, 130, 370, 350)     # 结算窗文字范围（y 130-480；限区避免误匹配底部聊天里的"恭喜"）
CRAFT_POPUP_KEYWORDS = ("恭喜获得", "点击空白处关闭")
CRAFT_POPUP_BLANK_POS = (202, 500)           # 结算窗下方空白处（点它关闭）


class Zhongcai(HomeTask):
    """种菜（家园）：主界面十字 → 功能面板"家园" → 家园名片"回家" → 家园场景点
    指向标（粉红路牌）→ 弹窗"确定" → 菜园 → 收割/播种 → 退出 → 底部"美食" →
    制作台勾"跳过动画"、点"制作"×10（间隔 3s）→ 返回到菜园 → 右缘"离开"回主界面。

    菜园判定与收割：成熟菜品/空地上方会浮出一个白色工具气泡（镰刀=可收割、
    铲子=可播种，两者气泡外观相同，共用模板"工具气泡"）。点气泡后按结果分支——
    弹出播种面板就去播种，否则视为收割完成，继续找下一个气泡；都没有则收工。

    播种：config 选了配方（dish，向导「种菜 · 美食配方」）则按配方 OCR 定位
    对应作物格去点（见 _plant_by_dish）；未选则点前三个菜品格（配方高亮项
    **每日轮换**，2026-10-10 实测为甘蔗/西瓜/南瓜）各 3 下，循环点击，
    直到"播种结束"。结束判定见 _plant（按优先序）：
    ① 提示区 toast——每日上限「明天再来吧」或**菜地种满/没有空地**类提示；
    ② 连续 2 轮画面无变化（兜底）；③ MAX_PLANT_CLICKS 硬上限。
    ⚠️ **菜地会先于每日 48 上限被填满**（实测账号5）：填满后点击全部无效、上限 toast
    永远不出现。
    ⚠️ 2026-10-11 第 4 个客户端实测：**地满时弹的是「可种植的田地不足，请等待
    成熟吧」**（不是每日上限）——关键词见 PLANT_END_TOAST_KEYWORDS；OCR 会把
    "田地"误读成"用地"，两种读法都收。若再出现别的提示，没匹配上的文字会
    原样打进日志（「播种提示区新文字：…」）并留证（plant_full_toast）。

    不确定项（首次真机跑完请对照 debug/run.log 校准）：
      - 制作台先勾「跳过动画」（已勾则不点，防点成取消），再点"制作"×10、间隔 3s；
        若某次点完动画没跑完导致点击被吞，可把 MAKE_INTERVAL 调大。
      - 制作台的「恭喜获得」结算窗**会反复弹**（实测 10 次弹 6 次）并盖住制作按钮 →
        每轮点「制作」前先 _close_craft_popup() 关掉。
      - 播种结束提示均已实测到：每日上限"明天再来吧"（账号4）+ 地满提示
        「可种植的田地不足，请等待成熟吧」（2026-10-11 第 4 个客户端，注意
        OCR 把"田地"误读成"用地"，关键词两种读法都收）；仍有
        MAX_PLANT_CLICKS 硬上限兜底。

    加载速度差异：**账号间进家园耗时差很多**，故等家园 HUD 的超时 GARDEN_HUD_TIMEOUT=14s，
    超时后若仍停在家园名片页会**补点一次「回家」再等一轮**（实测账号4 >8s 仍在名片页）。

    复位（用户说明 + 实机验证）：路牌是场景物件，角色走到别处就看不见了；
    此时 **「离开」回主界面 → 重新进家园** 会让角色回到起始视角、路牌重新出现。
    （喂猫 → 种菜连续跑同理：喂猫结束回主界面，种菜重新进家园视角复位。）
    「离开」按钮要点**图标中心 (383,510)**，点文字位置 (382,530) 无效（实测）。

    凡是"该出现的图案没出现 / 到了没见过的界面"，一律走 self.report_unknown(tag, note)，
    截图存进 debug/unknown/ 并打「问题：…（需要确认）」日志；跑完把截图发出来即可
    补充处理分支，不在代码里瞎猜。
    """

    name = "zhongcai"
    title = "种菜"
    category = "日常任务"

    def _try_once(self):
        self._stage = "清理系统弹窗"
        self.dismiss_popups()
        self._stage = "进家园"
        if not self._open_garden():
            return False
        self._stage = "收割/播种"
        self._tend_garden()
        self._stage = "制作美食"
        self._craft_food()
        self._stage = "离开家园回主界面"
        self._leave_home()
        return True

    # ---------- 导航 ----------

    def _tend_garden(self):
        """家园场景 → 点指向标 → 弹窗确定 → 菜园 → 收割/播种 → 退出播种。"""
        # 1) 点家园场景的指向标（粉红路牌）
        self._stage = "找路牌"
        pos = self._wait_signpost(timeout=8)
        if pos is None:
            # 路牌是场景物件，位置随角色视角漂；角色一旦走到别处（比如点了地面）
            # 路牌就离开视野。按用户说明：**离开回主界面再重新进家园，角色会复位到
            # 起始视角，路牌重新出现在左侧中部**（实测模板 score ≈0.96）。
            log.info("路牌不在视野，按用户说明复位家园视角（离开 → 重新进家园）")
            if self._reset_garden_view():
                pos = self._wait_signpost(timeout=8)
        if pos is None:
            self.report_unknown(
                "no_signpost",
                note="复位后仍识别不到指向标（模板+OCR 文字都没命中），"
                     "已按兜底坐标 %s 点击" % (SIGNPOST_FALLBACK_POS,))
            pos = SIGNPOST_FALLBACK_POS
        log.info("点击指向标 @ (%d, %d)", pos[0], pos[1])
        self.device.click(pos[0], pos[1])
        time.sleep(random.uniform(1.0, 1.8))
        # 2) 弹窗「可一步轻功飞到菜园，是否前往?」→ 确定
        # 实测：路牌点偏会静默失败（不出弹窗），所以没弹窗就重点一次再等
        if not self._wait_dialog(timeout=6):
            log.info("首次点路牌未出弹窗，重试点击 @ (%d, %d)", pos[0], pos[1])
            self.device.click(pos[0], pos[1])
            time.sleep(random.uniform(1.2, 2.0))
        if self._wait_dialog(timeout=6):
            if not self._click_text("确定", DLG_CONFIRM_REGION, timeout=5, min_similarity=0.9):
                log.warning("弹窗未识别到「确定」，按兜底坐标 (%d, %d) 点击", *DLG_CONFIRM_POS)
                self.device.click(*DLG_CONFIRM_POS)
            time.sleep(random.uniform(1.5, 2.5))
        else:
            self.report_unknown("no_warp_dialog",
                                note="点指向标后 6s 内未见「是否前往」弹窗，按已直达菜园继续")
        # 3) 菜园：收割 + 播种
        self._stage = "菜园收割/播种"
        self._harvest_and_plant()
        # 4) 退出播种面板回菜园场景（点图标中心 EXIT_POS，文字中心点不动）
        if self._click_text("退出", EXIT_REGION, timeout=5, min_similarity=0.9,
                            click_pos=EXIT_POS):
            time.sleep(random.uniform(1.0, 1.6))
        else:
            log.info("未点中「退出」（可能已不在播种面板）")

    # ---------- 菜园：收割 / 播种 ----------

    def _harvest_and_plant(self):
        """点菜地/菜品 → 浮出工具气泡 → 点气泡。点完没进播种面板视为收割，
        继续找下一个气泡；出现播种面板则进入播种流程。

        边界（实测账号4 第二轮）：**每日播种配额用完后，点铲子气泡只弹
        「明天再来吧」toast、不弹播种面板** → 会被误判成"收割"而空转到轮次上限（白耗 ~40s）。
        故加两条收工判据：① 直接检测到上限 toast；② 同一位置的气泡连续 3 轮点不掉。
        """
        last_bubble = None
        stuck = 0
        for rnd in range(1, HARVEST_ROUNDS + 1):
            self._check_stop()
            screen = self.device.screenshot()
            if self._panel_open(screen):
                self._plant()
                return True
            bubble = self.matcher.find(screen, "工具气泡", region=PLOT_BUBBLE_REGION,
                                       threshold=0.85, ccoeff_floor=0.45)
            if bubble is None:
                log.info("菜地无工具气泡，点击菜地 (%d, %d) 尝试浮出", *PLOT_CLICK_POS)
                self.device.click(*PLOT_CLICK_POS)
                bubble = self.matcher.wait_for(self.device, "工具气泡", timeout=4,
                                               region=PLOT_BUBBLE_REGION,
                                               threshold=0.85, ccoeff_floor=0.45)
            if bubble is None:
                if rnd == 1:
                    # 第一轮就没气泡可能是"界面不对"（还停在家园/弹窗没关），也可能菜地
                    # 本来就空且已种满——留图给人确认，日志里说明两种可能
                    self.report_unknown("no_tool_bubble",
                                        note="点菜地后仍无镰刀/铲子气泡（若菜地本来就无可操作项属正常）")
                log.info("菜地无可操作项（既无镰刀也无铲子），收工")
                return True
            log.info("点击工具气泡 @ (%d, %d) score=%.3f（第 %d 轮）",
                     bubble[0], bubble[1], bubble[2], rnd)
            self.device.click(bubble[0], bubble[1])
            time.sleep(random.uniform(1.2, 2.0))
            screen = self.device.screenshot()
            if self._panel_open(screen):
                self._plant()
                return True
            if self._plant_limit_reached(screen):
                log.info("出现「明天再来吧」：今日播种配额已满，收工")
                return True
            if (last_bubble is not None
                    and abs(bubble[0] - last_bubble[0]) <= 8
                    and abs(bubble[1] - last_bubble[1]) <= 8):
                stuck += 1
                if stuck >= 2:
                    log.info("同一位置气泡连续 %d 轮点不掉（配额已满或该地不可操作），收工",
                             stuck + 1)
                    return True
            else:
                stuck = 0
            last_bubble = (bubble[0], bubble[1])
            log.info("本轮为收割（未弹出播种面板），继续查找下一个气泡")
        log.warning("收割轮次达上限 %d，收工", HARVEST_ROUNDS)
        return True

    def _plant(self):
        """播种入口：config 选了配方（dish ≠ auto）→ 按配方播种；
        否则/配方无效 → 旧行为（前三个菜品格轮点）。结束判定两者一致。"""
        dish = str(self.config.get("dish") or "").strip()
        name, ingredients = DISH_RECIPES.get(dish, ("", None))
        if dish and dish != DISH_AUTO and ingredients is None:
            log.warning("未知美食配方 %r，按默认（前三个菜品格）播种", dish)
        if dish and dish != DISH_AUTO and ingredients:
            log.info("今日配方：%s（%s）——按配方播种", name, "+".join(ingredients))
            return self._plant_by_dish(name, ingredients)
        return self._plant_auto()

    def _plant_by_dish(self, dish_name, ingredients):
        """按配方播种：轮询配方里的 3 种作物，各自 OCR 定位格子后连点。

        与 _plant_auto 的差异只在「点哪里」：
        - 每轮依次对每个作物 _locate_crop（当前视野 OCR 作物名；找不到则
          向上滚动面板再找，南瓜/蟠桃等在第二屏）；
        - 某作物定位不到就跳过（可能种子没解锁/在更下面的屏），全部都定位
          不到时 report_unknown 留证并**回退旧逻辑**（宁可种错不空转）；
        - 结束判定（toast/画面无变化/硬上限）与旧行为完全一致。
        ⚠️ 种子有「拥有」库存（面板格子上可见），某作物点完没反应时靠
        整体「画面无变化」判据收工，不做每作物库存计数。
        """
        log.info("进入播种面板，按配方〔%s〕播种（%s）",
                 dish_name, " / ".join(ingredients))
        clicks = 0
        stale_rounds = 0
        prev_shot = self.device.screenshot()
        prev_toasts = self._toast_texts(prev_shot)   # 基线：任务面板等常驻文字不算"新"
        reported_toast = False
        reported_missing = False
        while clicks < MAX_PLANT_CLICKS:
            clicked_round = 0
            scrolled = 0
            # 逐「视野」播种（2026-11-03 修正）：本视野一次 OCR 扫全部配方作物，
            # 只点看得见的；点完再上滑换下一视野。旧写法按作物各自滚动查找，
            # 一旦为南瓜/蟠桃滚到底，上排的小麦/白菜就再也找不回来 —— 而
            # 桃花酿/清补凉/仙跳墙/大乱炖正是「上排+下排混合」的配方。
            for view in range(PANEL_SCROLL_MAX + 1):
                found = self._scan_all_crops(self.device.screenshot(), ingredients)
                for crop, pos in found.items():
                    log.info("本视野定位到「%s」@ (%d, %d)", crop, pos[0], pos[1])
                    for _ in range(CROP_CLICKS_EACH):
                        self._check_stop()
                        self.device.click(pos[0], pos[1])
                        clicks += 1
                        clicked_round += 1
                        time.sleep(random.uniform(0.35, 0.7))
                        screen = self.device.screenshot()
                        done, kw, texts = self._plant_end_toast(screen)
                        if done:
                            log.info("出现播种结束提示「%s」，停止播种（累计点击 %d 次）",
                                     kw, clicks)
                            return True
                        # 没命中关键词但提示区冒出了新文字：留痕（同 _plant_auto）
                        reported_toast = self._log_new_toasts(screen, texts, prev_toasts,
                                                             reported_toast)
                        prev_toasts = texts
                if len(found) == len(ingredients):
                    break                      # 配方作物全在本视野，不必再滚
                if view < PANEL_SCROLL_MAX:
                    self.device.drag(202, 706, 202, 566)   # 上滑：露出下面几行
                    scrolled += 1
                    time.sleep(random.uniform(0.9, 1.4))
            # 滚回顶部视野，下一轮才扫得到上排作物
            for _ in range(scrolled):
                self.device.drag(202, 566, 202, 706)
                time.sleep(random.uniform(0.5, 0.8))
            if clicked_round == 0:
                if not reported_missing:
                    self.report_unknown(
                        "dish_crops_not_found",
                        note="配方〔%s〕的作物 %s 在播种面板 %d 个视野内均未定位到"
                             "（OCR 均未命中），回退默认播种"
                             % (dish_name, "、".join(ingredients), PANEL_SCROLL_MAX + 1))
                    reported_missing = True
                log.warning("配方作物全部定位不到，回退默认播种（前三个菜品格）")
                return self._plant_auto()
            shot = self.device.screenshot()
            changed = self._screen_changed(prev_shot, shot)
            log.info("播种循环完成一轮（累计点击 %d 次，画面变化=%s）", clicks, changed)
            if not changed:
                stale_rounds += 1
                if stale_rounds >= 2:
                    log.info("连续 %d 轮画面无变化，判定播种已结束（累计点击 %d 次）",
                             stale_rounds, clicks)
                    return True
            else:
                stale_rounds = 0
            prev_shot = shot
        self.report_unknown("plant_limit_not_seen",
                            note="播种点击达硬上限 %d 次仍未见播种结束提示"
                                 "（「明天再来吧」/种满类），可能提示是短 toast 被漏检，"
                                 "也可能点击没生效" % MAX_PLANT_CLICKS)
        return True

    def _locate_crop(self, crop):
        """在播种面板里定位某作物的可点格子，返回 (x, y) 或 None。

        先在当前视野 OCR 作物名（作物名文字在每格上部，点击点 = 名字中心
        向下 CROP_NAME_DY）；找不到则向上滚动面板（露出下面几行）再找，
        最多 PANEL_SCROLL_MAX 次。⚠️ 滚动后画面位移，返回的坐标**只对当前
        视野有效**——调用方应在定位后立刻点击，不要跨滚动缓存坐标。
        """
        aliases = CROP_NAME_ALIASES.get(crop, (crop,))
        for attempt in range(PANEL_SCROLL_MAX + 1):
            pos = self._scan_crop(self.device.screenshot(), aliases)
            if pos is not None:
                if attempt:
                    log.info("「%s」经滚动后定位 @ (%d, %d)（第 %d 次滚动）",
                             crop, pos[0], pos[1], attempt)
                return pos
            if attempt < PANEL_SCROLL_MAX:
                self.device.drag(202, 706, 202, 566)   # 向上滚：露出下面几行作物
                time.sleep(random.uniform(0.9, 1.4))
        return None

    @staticmethod
    def _scan_all_crops(screen, crops):
        """一次 OCR 扫描把多个配方作物都定位出来，返回 {作物: (x, y)}。

        与 _scan_crop 同款别名/形近字匹配，但一次扫全部、避免为每个作物各扫
        一遍（真机上每轮可省 2 次 OCR + 多次滚动）。同一作物命中多处（重复
        识别/形近字）取相似度最高者。"""
        result, best_score = {}, {}
        for text, cx, cy, score in ocr.scan(screen, region=CROP_GRID_REGION):
            for crop in crops:
                aliases = CROP_NAME_ALIASES.get(crop, (crop,))
                hit = any(text == a or (len(text) <= 4 and len(a) <= 4
                                        and difflib.SequenceMatcher(None, text, a).ratio() >= 0.75)
                          for a in aliases)
                if hit and (crop not in best_score or score > best_score[crop]):
                    best_score[crop] = score
                    result[crop] = (cx, cy + CROP_NAME_DY)
        return result

    @staticmethod
    def _scan_crop(screen, aliases):
        """在作物格子区 OCR 找作物名，返回点击坐标 (x, y) 或 None。
        命中多个（同屏误识别/相似度重叠）取分数最高者。"""
        best = None
        for text, cx, cy, score in ocr.scan(screen, region=CROP_GRID_REGION):
            hit = any(text == a or (len(text) <= 4 and len(a) <= 4
                                    and difflib.SequenceMatcher(None, text, a).ratio() >= 0.75)
                      for a in aliases)
            if not hit:
                continue
            if best is None or score > best[2]:
                best = (cx, cy + CROP_NAME_DY, score)
        if best is not None:
            return best[0], best[1]
        return None

    def _plant_auto(self):
        """播种（默认）：点前三个菜品格（配方高亮项）各 3 下，循环直到播种结束。

        结束判定（按优先序）：
        ① toast 提示——每日上限「明天再来吧」，或**菜地种满**提示
           「可种植的田地不足，请等待成熟吧」（关键词见 PLANT_END_TOAST_KEYWORDS，
           没匹配上的新文案会打日志+留截图）；
        ② 连续 2 轮画面无变化（2026-10-10 账号5 判据，保留兜底）；
        ③ MAX_PLANT_CLICKS 硬上限。
        ⚠️ 实测（2026-10-11 账号3/7）：菜地种满后画面仍会"变"——生长百分比气泡
        跳动、角色待机动画、底部聊天滚动都会骗过整帧比较 → ②只能兜底，
        主判据是①的提示文字。"""
        log.info("进入播种面板，开始播种（前三个菜品格 ×%d 下/轮）", CROP_CLICKS_EACH)
        clicks = 0
        stale_rounds = 0
        prev_shot = self.device.screenshot()
        prev_toasts = self._toast_texts(prev_shot)   # 基线：任务面板等常驻文字不算"新"
        reported_toast = False
        while clicks < MAX_PLANT_CLICKS:
            for pos in CROP_TILE_POS:
                for _ in range(CROP_CLICKS_EACH):
                    self._check_stop()
                    self.device.click(pos[0], pos[1])
                    clicks += 1
                    time.sleep(random.uniform(0.35, 0.7))
                screen = self.device.screenshot()
                done, kw, texts = self._plant_end_toast(screen)
                if done:
                    log.info("出现播种结束提示「%s」，停止播种（累计点击 %d 次）",
                             kw, clicks)
                    return True
                # 没命中关键词但提示区冒出了新文字：可能是那条没见过的
                # 「没有空地」类提示，打日志+留证，便于下次补关键词
                reported_toast = self._log_new_toasts(screen, texts, prev_toasts,
                                                      reported_toast)
                prev_toasts = texts
            shot = self.device.screenshot()
            changed = self._screen_changed(prev_shot, shot)
            log.info("播种循环完成一轮（累计点击 %d 次，画面变化=%s）", clicks, changed)
            if not changed:
                stale_rounds += 1
                if stale_rounds >= 2:
                    log.info("连续 %d 轮画面无变化，判定播种已结束（累计点击 %d 次）",
                             stale_rounds, clicks)
                    return True
            else:
                stale_rounds = 0
            prev_shot = shot
        self.report_unknown("plant_limit_not_seen",
                            note="播种点击达硬上限 %d 次仍未见播种结束提示"
                                 "（「明天再来吧」/种满类），可能提示是短 toast 被漏检，"
                                 "也可能点击没生效" % MAX_PLANT_CLICKS)
        return True

    # 提示区里的数字噪声：生长百分比 "63%"、任务栏倒计时 "1时1分" 等
    _TOAST_NOISE_RE = re.compile(r'^[\d%．.:/分时秒+~-]+$')

    # 播种成功的正常提示（2026-10-13 实测误报根因）：每轮播种都会刷
    # 「消耗6000 | 成功种下[甘蔗]，今天还能种45次」，此前被当"没见过的提示"
    # 上报 → AI 兜底被召进来点「快捷种菜」开启快捷模式（改游戏设置），
    # 每号白耗 3 次 AI 调用 ~40-60s（3/4/7 号当天全中）
    _TOAST_SUCCESS_RE = re.compile(r"成功种下|还能种\d*次|^消耗\d+")

    def _log_new_toasts(self, screen, texts, prev_texts, reported):
        """提示区新出现的文字：打日志留痕；疑似游戏提示（非纯数字噪声）时
        report_unknown 留截图（toast 短暂，必须用当前帧），每任务只报一次。
        播种成功类 toast（成功种下/还能种 n 次/消耗 n）是正常流水，只留日志
        不上报。返回新的 reported 标志。"""
        new = [t for t in texts if t not in prev_texts
               and not self._TOAST_NOISE_RE.fullmatch(t)]
        if not new:
            return reported
        log.info("播种提示区新文字：%s", " | ".join(new))
        if reported:
            return reported
        if all(self._TOAST_SUCCESS_RE.search(t) for t in new):
            return reported  # 全是成功流水，不算异常
        self.report_unknown("plant_full_toast", screen=screen,
                            note="播种期间提示区出现新文字（可能就是「没有空地」"
                                 "类播种结束提示，toast 短暂）：%s"
                                 % "；".join(new))
        return True

    @staticmethod
    def _toast_texts(screen):
        """提示区（TOAST_REGION）OCR 出的全部文字。"""
        return ocr.dump_texts(screen, region=TOAST_REGION)

    @staticmethod
    def _plant_end_toast(screen):
        """播种是否已结束（提示区 toast 判定）。
        返回 (是否结束, 命中关键词, 提示区全部文字)。"""
        texts = ocr.dump_texts(screen, region=TOAST_REGION)
        joined = "".join(texts)
        for kw in PLANT_END_TOAST_KEYWORDS:
            if kw in joined:
                return True, kw, texts
        return False, "", texts

    @staticmethod
    def _screen_changed(a, b, frac=0.02):
        """两张截图是否有实质变化（判据：差异像素占比 > frac）。
        种上一轮作物差异 ≈6%+，面板自身抖动 <1%，2% 可分。"""
        import numpy as np
        d = np.abs(a.astype(int) - b.astype(int)).sum(axis=2)
        return float((d > 60).mean()) > frac

    @staticmethod
    def _panel_open(screen):
        """播种面板是否已打开（"快捷种菜"）。"""
        return bool(ocr.find_text(screen, "快捷种菜", region=PANEL_MARK_REGION,
                                  min_similarity=0.9))

    @staticmethod
    def _plant_limit_reached(screen):
        """是否出现每日播种上限提示「每天最多种植48次，明天再来吧」。"""
        return ocr.contains_text(screen, "明天再来吧", region=TOAST_REGION)

    # ---------- 制作台 ----------

    def _craft_food(self):
        """菜园底部「美食」→ 制作台 →（选了配方：放回清锅 + 按配方放食材）→
        勾「跳过动画」→ 点「制作」×10（间隔 3s）→ 返回。"""
        self._stage = "打开制作台"
        if not self._click_template("美食", MEISHI_REGION, timeout=5, threshold=0.85):
            self.report_unknown("no_meishi_icon",
                                note="底部栏未识别到「美食」图标，已按兜底坐标 %s 点击" % (MEISHI_POS,))
            self.device.click(*MEISHI_POS)
        time.sleep(random.uniform(1.5, 2.5))
        # 选了美食配方（dish ≠ auto）：先备料；备料失败就不点制作（避免做错菜白耗食材）
        dish = str(self.config.get("dish") or "").strip()
        dish_name, ingredients = DISH_RECIPES.get(dish, ("", None))
        if dish and dish != DISH_AUTO and ingredients:
            if not self._prepare_recipe_pot(dish_name, ingredients):
                log.warning("配方〔%s〕备料失败，跳过制作，直接返回", dish_name)
                self.device.click(*PANEL_BACK_POS)
                time.sleep(random.uniform(1.0, 1.6))
                return
        self._ensure_skip_anim()
        for i in range(1, MAKE_CLICKS + 1):
            self._check_stop()
            # 结算窗会盖住制作按钮，先关（实测隔几次弹一次，须每轮检查）
            if self._close_craft_popup():
                log.info("制作结算窗已关闭")
            if not self._click_text("制作", MAKE_REGION, timeout=6, min_similarity=0.9,
                                    click_pos=MAKE_POS):
                self.report_unknown("no_make_button",
                                    note="第 %d/%d 次未找到「制作」按钮，提前结束制作"
                                         % (i, MAKE_CLICKS))
                break
            log.info("制作台点击「制作」(%d/%d)", i, MAKE_CLICKS)
            if i < MAKE_CLICKS:
                time.sleep(MAKE_INTERVAL)
        # 返回（制作台左下角返回箭头）
        self.device.click(*PANEL_BACK_POS)
        time.sleep(random.uniform(1.0, 1.6))

    def _prepare_recipe_pot(self, dish_name, ingredients):
        """制作台按配方备料：点「放回」清锅 → 把配方作物逐个点进锅。

        返回 True=锅已按配方放好（可以点制作）；False=备料失败（调用方应
        跳过制作——食材没放对就点制作会做出错菜、白耗食材）。

        判据（2026-11-03 实测）：**锅空时「放回」按钮整个消失** ——
        ① 开局「放回」可见 = 锅里有上次的食材，点它清锅，等按钮消失；
        ② 食材全部点完后「放回」重新出现（或锅区域画面变化）= 备料成功。
        ⚠️ 食材点进锅后格子会被大绿√盖住、模板失配 —— 所以**先在一张截图
        里把全部食材定位完，再逐个点击**；不同品质种子图标几乎一致
        （大豆 1.0 vs 相邻格 0.995），定位取最高分。
        """
        self._stage = "制作台放回食材"
        screen = self.device.screenshot()
        putback = self.matcher.find(screen, "放回", region=PUTBACK_REGION,
                                    threshold=0.8, ccoeff_floor=0.5)
        if putback:
            log.info("锅里有上次食材（「放回」按钮可见 @ %s），点击清锅",
                     (putback[0], putback[1]))
            self.device.click(putback[0], putback[1])
            # 等「放回」消失（= 清锅完成），最多 6s
            deadline = time.time() + 6
            while time.time() < deadline:
                self._check_stop()
                time.sleep(random.uniform(0.8, 1.2))
                if not self.matcher.find(self.device.screenshot(), "放回",
                                         region=PUTBACK_REGION,
                                         threshold=0.8, ccoeff_floor=0.5):
                    log.info("锅已清空（「放回」按钮已消失）")
                    break
            else:
                self.report_unknown(
                    "putback_button_still_there",
                    note="点「放回」6s 后按钮仍在（清锅可能没生效），继续备料")
            if ocr.contains_text(self.device.screenshot(), "食材已放回",
                                 region=PUTBACK_TOAST_REGION):
                log.info("确认提示「食材已放回」")
        else:
            log.info("「放回」按钮不可见，锅本来就是空的，直接备料")
        empty_shot = self.device.screenshot()
        # 逐「视野」放食材（2026-11-03 修正）：滚动会挪动格子，坐标只对本视野
        # 有效 —— 本视野一次把还缺的作物全定位、再逐个点（点击只盖√、格子
        # 不挪位，已定位坐标不会失效），点完仍缺才滚动换下一视野。
        # ⚠️ 食材点进锅后格子会被大绿√盖住、模板失配 —— 必须先定位后点击；
        # 不同品质种子图标几乎一致（大豆 1.0 vs 相邻变体格 0.995），取最高分。
        self._stage = "制作台按配方放食材"
        remaining = list(dict.fromkeys(ingredients))
        clicked = []                       # 已点击的格子（含顶替），供重试与去重
        for view in range(FOOD_GRID_SCROLL_MAX + 1):
            screen = self.device.screenshot()
            found = {}
            for crop in remaining:
                pos = self._locate_food_in_view(screen, crop)
                if pos is not None:
                    found[crop] = pos
            for crop, (x, y) in found.items():
                self._check_stop()
                self.device.click(x, y)
                clicked.append((x, y))
                log.info("点击食材「%s」@ (%d, %d)", crop, x, y)
                time.sleep(random.uniform(0.9, 1.4))
            for crop in found:
                remaining.remove(crop)
            if not remaining:
                break
            if view < FOOD_GRID_SCROLL_MAX:
                self.device.drag(202, 585, 202, 465)   # 食材格向下滚：露出下面几行
                time.sleep(random.uniform(0.8, 1.2))
        # 缺货顶替（用户规则 2026-11-03：有的账号根本没有某食材 —— 点任意
        # 未选中的食材格顶上，宁可做出别的菜也不空手）
        if remaining:
            self._stage = "制作台缺货顶替"
            if not self._substitute_missing(dish_name, remaining, clicked):
                return False
        # 成功判据：「放回」重新出现（= 锅里有食材）或锅区域画面变化
        for pass_i in (1, 2):
            filled = self.device.screenshot()
            if (self.matcher.find(filled, "放回", region=PUTBACK_REGION,
                                  threshold=0.8, ccoeff_floor=0.5)
                    or self._region_changed(empty_shot, filled, POT_REGION,
                                            frac=0.05)):
                log.info("配方〔%s〕食材已进锅（「放回」按钮重新出现/锅区域变化）",
                         dish_name)
                return True
            if pass_i == 1 and clicked:
                log.warning("点完一轮食材锅仍无变化（可能一键只放 1 个、需点 2 次），原格重试一轮")
                for x, y in clicked:
                    self._check_stop()
                    self.device.click(x, y)
                    time.sleep(random.uniform(0.9, 1.4))
        self.report_unknown(
            "dish_pot_not_filled",
            note="配方〔%s〕食材点击两轮后锅仍无变化（「放回」未出现），"
                 "食材可能没进锅（点击被吞/格子无效），放弃按配方制作" % dish_name)
        return False

    def _locate_food_in_view(self, screen, crop):
        """在当前视野的食材格里找某作物的格子，返回点击坐标 (x, y) 或 None。

        只扫当前视野、不滚动 —— 滚动由 _prepare_recipe_pot 的视野循环负责
        （跨视野缓存坐标会点错格子）。模板名 = 食材_<作物>.png。
        """
        name = f"食材_{crop}"
        if not self.matcher.has_template(name):
            log.warning("缺少食材模板 %s.png，无法定位「%s」", name, crop)
            return None
        hit = self.matcher.find(screen, name, region=FOOD_GRID_REGION,
                                threshold=0.8, ccoeff_floor=0.5)
        return (hit[0], hit[1]) if hit else None

    def _substitute_missing(self, dish_name, missing, clicked):
        """缺货顶替：配方食材在本账号食材格里找不到时，点任意未选中格子顶上。

        「未选中」判据：被√盖住的格子图标被挡、模板失配 —— 所以只要**任一
        食材模板还能命中**、且离已点击的格子足够远（>45px，格距约 73px），
        就是没有选过的格子。所有模板都找不到候选时 report_unknown 并返回
        False（调用方放弃制作，不空锅点制作）。
        """
        screen = self.device.screenshot()
        used = list(clicked)
        for crop in missing:
            pick = None
            for other in FOOD_CROPS:
                name = f"食材_{other}"
                if not self.matcher.has_template(name):
                    continue
                for x, y, _s in self.matcher.find_all(screen, name,
                                                      region=FOOD_GRID_REGION,
                                                      threshold=0.8):
                    if all(abs(x - ux) > 45 or abs(y - uy) > 45 for ux, uy in used):
                        pick = (x, y)
                        break
                if pick:
                    break
            if pick is None:
                self.report_unknown(
                    "dish_no_substitute",
                    note="配方〔%s〕缺 %s，且当前视野找不到可顶替的未选中食材格"
                         "（%d 个食材模板均未命中或全被选中），放弃按配方制作"
                         % (dish_name, "、".join(missing), len(FOOD_CROPS)))
                return False
            self.device.click(*pick)
            used.append(pick)
            log.warning("配方〔%s〕缺「%s」，已按用户规则点任意食材格 (%d, %d) 顶替",
                        dish_name, crop, pick[0], pick[1])
            time.sleep(random.uniform(0.9, 1.4))
        return True

    @staticmethod
    def _region_changed(a, b, region, frac=0.05):
        """两张截图在指定区域内是否有实质变化（差异像素占比 > frac）。"""
        import numpy as np
        x, y, w, h = region
        d = np.abs(a[y:y + h, x:x + w].astype(int)
                   - b[y:y + h, x:x + w].astype(int)).sum(axis=2)
        return float((d > 60).mean()) > frac

    def _close_craft_popup(self):
        """关闭「恭喜获得」结算窗（点空白处），最多试 3 次。返回是否出现过。"""
        closed = False
        for _ in range(3):
            screen = self.device.screenshot()
            if not any(ocr.contains_text(screen, kw, region=CRAFT_POPUP_REGION)
                       for kw in CRAFT_POPUP_KEYWORDS):
                return closed
            closed = True
            self.device.click(*CRAFT_POPUP_BLANK_POS)
            time.sleep(random.uniform(1.2, 1.8))
        return closed

    def _ensure_skip_anim(self):
        """勾上制作台的「跳过动画」。**必须先判定**：这个框默认可能就是勾上的，
        盲点一下会变成取消，之后 10 次制作都在等动画（点击被吞）。"""
        screen = self.device.screenshot()
        if not ocr.find_text(screen, "跳过动画", region=SKIP_ANIM_TEXT_REGION,
                             min_similarity=0.9):
            log.info("制作台未见「跳过动画」勾选框，按原速制作")
            return False
        if self._skip_anim_checked(screen):
            log.info("「跳过动画」已是勾选状态，不重复点击")
            return True
        self.device.click(*SKIP_ANIM_BOX_POS)
        time.sleep(random.uniform(0.5, 0.9))
        if not self._skip_anim_checked(self.device.screenshot()):
            self.report_unknown("skip_anim_not_checked",
                                note="点了「跳过动画」勾选框 %s 但复核仍未见橙√"
                                     % (SKIP_ANIM_BOX_POS,))
            return False
        log.info("已勾上「跳过动画」")
        return True

    @staticmethod
    def _skip_anim_checked(screen):
        """勾选框是否已是勾选态：框内橙色√的像素占比（实测已勾≈0.31，未勾≈0）。"""
        x, y, w, h = SKIP_ANIM_BOX_REGION
        c = screen[y:y + h, x:x + w].astype(int)
        b, g, r = c[:, :, 0], c[:, :, 1], c[:, :, 2]
        orange = ((r > 150) & (g > 90) & (b < 130)).mean()
        return float(orange) >= SKIP_ANIM_TICK_MIN

    # ---------- 指向标 / 弹窗 ----------

    def _wait_dialog(self, timeout=6):
        """等「可一步轻功飞到菜园，是否前往？」弹窗出现。"""
        deadline = time.time() + timeout
        while time.time() < deadline:
            self._check_stop()
            screen = self.device.screenshot()
            if ocr.contains_text(screen, "是否前往", region=DLG_TEXT_REGION):
                log.info("出现前往菜园弹窗")
                return True
            time.sleep(0.5)
        return False

    def _wait_signpost(self, timeout=8):
        """等路牌出现，返回点击坐标；超时返回 None。"""
        deadline = time.time() + timeout
        while time.time() < deadline:
            self._check_stop()
            hit = self._find_signpost(self.device.screenshot())
            if hit:
                return hit
            time.sleep(0.6)
        return None

    def _find_signpost(self, screen):
        """检测家园场景的指向标（粉红路牌）是否在视野内，返回**点击坐标**。

        优先模板**全图**搜索——路牌是场景里的物件、位置随角色视角漂，且模板带自动
        掩码（缩 region 会让 CCOEFF 归一化基准变化、分数骤降，实测缩到
        (0,235,180,160) 直接匹配失败）；模板失手时用路牌上的文字兜底。
        ⚠️ **检测命中点不是可点热区**：模板命中 (108,236)/OCR 牌心 (105,237) 点了都没
        反应（实测 no_warp_dialog），真正能出弹窗的是 SIGNPOST_CLICK_POS=(101,270)。
        所以本方法只把命中当作"路牌在视野内"的判据，一律返回固定热区。
        """
        hit = self.matcher.find(screen, "指向标", threshold=SIGNPOST_THRESHOLD,
                                ccoeff_floor=SIGNPOST_CCOEFF_FLOOR)
        if hit:
            log.info("指向标模板命中 @ (%d, %d) score=%.3f → 点击热区 %s",
                     hit[0], hit[1], hit[2], SIGNPOST_CLICK_POS)
            return SIGNPOST_CLICK_POS
        for kw in SIGNPOST_KEYWORDS:
            t = ocr.find_text(screen, kw, region=SIGNPOST_TEXT_REGION,
                              min_similarity=0.8)
            if t:
                log.info("指向标经 OCR「%s」@ (%d, %d) 定位 → 点击热区 %s",
                         kw, t[0], t[1], SIGNPOST_CLICK_POS)
                return SIGNPOST_CLICK_POS
        return None
